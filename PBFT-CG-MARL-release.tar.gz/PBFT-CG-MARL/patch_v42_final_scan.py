#!/usr/bin/env python3
"""
v4.2 完整修复 - 一次性精确修改
基于行号的精确插入，不再用字符串替换

修复内容：
1. __init__: 添加 v4.2 参数
2. act(): 软共识模式 - 不修改动作
3. update(): 添加交叉熵共识损失 + 最小熵底线（全部用 tensor）
4. 修复 loss.backward() 的类型混合问题
5. metrics: 添加新指标
"""
import os, shutil

filepath = "src/algorithms/pbft_cg_mappo.py"

with open(filepath, 'r', encoding='utf-8') as f:
    lines = f.readlines()

# 先扫描关键行号
print("=== 扫描关键行 ===")
key_lines = {}
for i, line in enumerate(lines):
    s = line.strip()
    if 'self.consensus_blend_ratio = config.get("consensus_blend_ratio"' in line:
        key_lines['blend_ratio'] = i
        print(f"L{i+1}: consensus_blend_ratio")
    if 'self._consensus_step_counter += 1' in line:
        key_lines['consensus_counter'] = i
        print(f"L{i+1}: consensus_step_counter")
    if 'consensus_actions, consensus_info = self.pbft_consensus(' in line:
        key_lines['consensus_call'] = i
        print(f"L{i+1}: consensus call")
    if 'consensus_actions = [a for a, _ in proposals]' in line:
        key_lines['skip_consensus'] = i
        print(f"L{i+1}: skip consensus")
    if '步骤3：使用共识后的动作' in line:
        key_lines['step3'] = i
        print(f"L{i+1}: step3")
    if 'consensus_actions[0].shape' in line:
        key_lines['ref_shape'] = i
        print(f"L{i+1}: ref_shape")
    if 'consensus_loss = torch.tensor(0.0, device=self.device)' in line:
        key_lines['consensus_loss'] = i
        print(f"L{i+1}: consensus_loss init")
    if 'consensus_loss = torch.tensor(' in line and 'consensus_rate' in line:
        key_lines['consensus_loss_compute'] = i
        print(f"L{i+1}: consensus_loss compute")
    if 'loss = (' in line and 'policy_loss' not in line:
        key_lines['loss_start'] = i
        print(f"L{i+1}: loss start")
    if '+ consensus_loss' in line and ')' in line:
        key_lines['loss_end'] = i
        print(f"L{i+1}: loss end")
    if '"entropy_coef": self.entropy_coef' in line:
        key_lines['entropy_coef_metric'] = i
        print(f"L{i+1}: entropy_coef metric")
    if 'entropies.append(entropy)' in line:
        key_lines['entropies_append'] = i
        print(f"L{i+1}: entropies append")
    if 'log_prob, entropy, _ = self.actor.evaluate_action' in line:
        key_lines['eval_actor'] = i
        print(f"L{i+1}: evaluate_action actor")
    if 'log_prob, entropy, _ = self.actors[agent_id].evaluate_action' in line:
        key_lines['eval_actors'] = i
        print(f"L{i+1}: evaluate_action actors")

print(f"\n找到 {len(key_lines)} 个关键行")
print("key_lines:", key_lines)
