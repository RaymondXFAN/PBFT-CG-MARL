#!/usr/bin/env python3
"""
v4.2 最终修复 - 逐行重建文件，最稳的方式
"""
import os, shutil

filepath = "src/algorithms/pbft_cg_mappo.py"

with open(filepath, 'r', encoding='utf-8') as f:
    original_lines = f.readlines()

shutil.copy2(filepath, filepath + ".v42h.bak")

# 用状态机逐行处理
output = []
in_act_consensus = False  # 是否在 act() 共识块中
in_loss_area = False  # 是否在 loss 计算区域
skip_until_step3 = False  # 跳过旧共识块
skip_until_loss_end = False  # 跳过旧 loss 块
act_consensus_done = False
loss_done = False

for i, line in enumerate(original_lines):
    s = line.strip()
    
    # ===== 修改 1: __init__ 添加 v4.2 参数 =====
    if 'self.consensus_blend_ratio = config.get("consensus_blend_ratio"' in line:
        output.append(line)
        output.append('\n')
        output.append('        # v4.2: 软共识参数\n')
        output.append('        self.soft_consensus_mode = config.get("soft_consensus_mode", False)\n')
        output.append('        self.kl_consensus_coef = config.get("kl_consensus_coef", 0.1)\n')
        output.append('        self.entropy_floor = config.get("entropy_floor", 0.05)\n')
        output.append('        self._kl_consensus_loss_val = 0.0\n')
        output.append('        self._entropy_floor_penalty_val = 0.0\n')
        print(f"修改1: L{i+1} 后添加 v4.2 参数")
        continue
    
    # ===== 修改 2: act() 软共识模式 =====
    # 找到 "步骤2：PBFT共识层" 行，开始替换
    if '步骤2' in line and 'PBFT' in line and not act_consensus_done:
        # 输出新的共识块
        output.append('        # 步骤2：PBFT共识层（v4.2: 支持软共识模式）\n')
        output.append('        self._consensus_step_counter += 1\n')
        output.append('        if self.soft_consensus_mode:\n')
        output.append('            # V42_SOFT_CONSENSUS: 计算共识但不修改动作\n')
        output.append('            consensus_actions, consensus_info = self.pbft_consensus(\n')
        output.append('                proposals, obs, step=self._training_step, action_type=self.action_type\n')
        output.append('            )\n')
        output.append('            self._last_consensus_actions = consensus_actions\n')
        output.append('            self._last_consensus_info = consensus_info\n')
        output.append('            # 不修改动作！agent 自由选择\n')
        output.append('            final_actions = [a for a, _ in proposals]\n')
        output.append('        elif self.consensus_freq <= 1 or self._consensus_step_counter % self.consensus_freq == 0:\n')
        output.append('            # 硬共识模式\n')
        output.append('            if hasattr(self, "pbft_consensus") and hasattr(self, "consensus_blend_ratio"):\n')
        output.append('                self.pbft_consensus.blend_ratio = self.consensus_blend_ratio\n')
        output.append('            consensus_actions, consensus_info = self.pbft_consensus(\n')
        output.append('                proposals, obs, step=self._training_step, action_type=self.action_type\n')
        output.append('            )\n')
        output.append('            final_actions = consensus_actions\n')
        output.append('        else:\n')
        output.append('            # 跳过共识\n')
        output.append('            final_actions = [a for a, _ in proposals]\n')
        output.append('            consensus_info = {"consensus_rate": 1.0, "consensus_achieved": True, "skipped": True}\n')
        skip_until_step3 = True
        act_consensus_done = True
        print(f"修改2: L{i+1} 替换 act() 共识块")
        continue
    
    # 跳过旧共识块的行
    if skip_until_step3:
        if '步骤3' in line:
            skip_until_step3 = False
            # 不输出这行，用新的步骤3替代
            output.append('        # 步骤3：使用动作\n')
            print(f"修改2b: 跳过旧共识块，到 L{i+1} 步骤3")
        continue
    
    # ===== 修改 2b: consensus_actions → final_actions =====
    if 'consensus_actions[0]' in line and 'final_actions' not in line:
        output.append(line.replace('consensus_actions[0]', 'final_actions[0]'))
        continue
    if 'consensus_actions' in line and 'final_actions' not in line and 'last_consensus' not in line and 'consensus_actions,' not in line:
        output.append(line.replace('consensus_actions', 'final_actions'))
        continue
    
    # ===== 修改 3: 保存 action_dist =====
    if 'log_prob, entropy, _ = self.actor.evaluate_action(' in line:
        output.append(line.replace('log_prob, entropy, _ =', 'log_prob, entropy, action_dist ='))
        print(f"修改3a: L{i+1}")
        continue
    if 'log_prob, entropy, _ = self.actors[agent_id].evaluate_action(' in line:
        output.append(line.replace('log_prob, entropy, _ =', 'log_prob, entropy, action_dist ='))
        print(f"修改3b: L{i+1}")
        continue
    
    # ===== 修改 4: 在 entropies.append 后添加交叉熵 =====
    if 'entropies.append(entropy)' in line:
        output.append(line)
        output.append('                # v4.2: 计算与共识动作的交叉熵损失\n')
        output.append('                if self.soft_consensus_mode and hasattr(self, "_last_consensus_actions") and self._last_consensus_actions is not None:\n')
        output.append('                    try:\n')
        output.append('                        cons_a = self._last_consensus_actions[agent_id]\n')
        output.append('                        if isinstance(cons_a, int):\n')
        output.append('                            ca_tensor = torch.tensor(cons_a, device=self.device)\n')
        output.append('                        else:\n')
        output.append('                            ca_tensor = cons_a.detach().clone().to(self.device)\n')
        output.append('                        ce_loss = -action_dist.log_prob(ca_tensor)\n')
        output.append('                        if not hasattr(self, "_batch_ce_losses"):\n')
        output.append('                            self._batch_ce_losses = []\n')
        output.append('                        self._batch_ce_losses.append(ce_loss.mean())\n')
        output.append('                    except Exception:\n')
        output.append('                        pass\n')
        print(f"修改4: L{i+1} 后添加交叉熵")
        continue
    
    # ===== 修改 5: 替换 loss 区域 =====
    # 找到 "consensus_loss = torch.tensor(0.0, device=self.device)" 行
    if 'consensus_loss = torch.tensor(0.0, device=self.device)' in line and not loss_done:
        # 输出新的 loss 计算区域
        output.append('        # v4.2: 共识损失\n')
        output.append('        consensus_loss = torch.tensor(0.0, device=self.device)\n')
        output.append('        if hasattr(self, "_last_consensus_info") and self._last_consensus_info is not None:\n')
        output.append('            consensus_rate = self._last_consensus_info.get("consensus_rate", 0.0)\n')
        output.append('            consensus_loss = torch.tensor(\n')
        output.append('                (1.0 - consensus_rate) * self.consensus_loss_coef,\n')
        output.append('                device=self.device,\n')
        output.append('            )\n')
        output.append('\n')
        output.append('        # v4.2: 最小熵底线惩罚（确保是 tensor）\n')
        output.append('        entropy_floor_penalty = torch.tensor(0.0, device=self.device)\n')
        output.append('        if hasattr(self, "entropy_floor") and mean_entropy < self.entropy_floor:\n')
        output.append('            deficit = self.entropy_floor - mean_entropy\n')
        output.append('            entropy_floor_penalty = torch.tensor(10.0 * deficit.item(), device=self.device)\n')
        output.append('\n')
        output.append('        # v4.2: 软共识交叉熵损失\n')
        output.append('        kl_consensus_loss = torch.tensor(0.0, device=self.device)\n')
        output.append('        if self.soft_consensus_mode and hasattr(self, "_batch_ce_losses") and self._batch_ce_losses:\n')
        output.append('            kl_consensus_loss = torch.stack(self._batch_ce_losses).mean()\n')
        output.append('            self._batch_ce_losses = []\n')
        output.append('\n')
        output.append('        # 记录用于 metrics\n')
        output.append('        self._kl_consensus_loss_val = kl_consensus_loss.item()\n')
        output.append('        self._entropy_floor_penalty_val = entropy_floor_penalty.item()\n')
        output.append('\n')
        output.append('        # 总损失（所有项都是 tensor）\n')
        output.append('        loss = (\n')
        output.append('            policy_loss\n')
        output.append('            + self.value_loss_coef * value_loss\n')
        output.append('            - self.entropy_coef * mean_entropy\n')
        output.append('            + consensus_loss\n')
        output.append('            + entropy_floor_penalty\n')
        output.append('            + self.kl_consensus_coef * kl_consensus_loss\n')
        output.append('        )\n')
        skip_until_loss_end = True
        loss_done = True
        print(f"修改5: L{i+1} 替换 loss 区域")
        continue
    
    # 跳过旧 loss 块的行
    if skip_until_loss_end:
        if line.strip() == ')' and 'consensus_loss' not in line:
            # 这是 loss 的右括号，跳过
            skip_until_loss_end = False
            print(f"修改5: 跳过旧 loss 块，到 L{i+1}")
        continue
    
    # ===== 修改 6: metrics 添加新指标 =====
    if '"entropy_coef": self.entropy_coef' in line:
        output.append(line)
        output.append('            "kl_consensus_loss": self._kl_consensus_loss_val,\n')
        output.append('            "entropy_floor_penalty": self._entropy_floor_penalty_val,\n')
        print(f"修改6: L{i+1} 后添加 metrics")
        continue
    
    # 其他行原样输出
    output.append(line)

# 写入文件
with open(filepath, 'w', encoding='utf-8') as f:
    f.writelines(output)

# 验证语法
import py_compile
try:
    py_compile.compile(filepath, doraise=True)
    print("\n✅ 语法检查通过！")
except py_compile.PyCompileError as e:
    print(f"\n❌ 语法错误: {e}")
    shutil.copy2(filepath + ".v42h.bak", filepath)
    print("已恢复备份")
