# ============================================================
# PBFT-CG-MAPPO — 审稿意见回复实验包 (Review-Rebuttal Experiments)
# ============================================================
#
# 本目录包含针对两位审稿人意见所需的全部真实实验脚本与配置。
# 所有实验均在 AutoDL (RTX 4090) 上运行，沙箱不跑训练。
# 严禁编造数据：所有表格数字均来自以下脚本的真实输出。
#
# 代码库：https://github.com/RaymondXFAN/PBFT-CG-MAPPO  (MIT)
#
# ------------------------------------------------------------
# 目录结构
# ------------------------------------------------------------
#   configs/          所有 YAML 配置（公平对比/因果对照/拜占庭/KL方向/熵地板/多环境）
#   patches/          对源码的最小化补丁（matched-logprob / 拜占庭对抗 / KL方向）
#   run_all_review.sh 一键串行跑完全部实验（GPU 后台）
#   analyze_results.py 从 metrics.json 提取指标 + 统计检验（t-test / Levene / CI）
#
# ------------------------------------------------------------
# 快速开始（在 AutoDL 上）
# ------------------------------------------------------------
#   cd /root/autodl-tmp/PBFT-CG-MARL
#   # 1) 应用补丁（只改源码，不动已有实验）
#   python experiments/patches/patch_matched_logprob.py
#   python experiments/patches/patch_byzantine.py
#   python experiments/patches/patch_kl_direction.py
#   # 2) 先跑预检（5分钟，1 seed × 50K 步）确认能跑通
#   bash experiments/run_all_review.sh 0 --smoke
#   # 3) 正式跑（后台，约 6-10 小时）
#   nohup bash experiments/run_all_review.sh 0 > review_exp.log 2>&1 &
#   tail -f review_exp.log
#   # 4) 出统计结果
#   python experiments/analyze_results.py --log_dir results/review
#
# ------------------------------------------------------------
# 实验与审稿意见的对应关系
# ------------------------------------------------------------
#   E1 公平三路对比        → 审稿人1 致命缺陷#2（变量控制不公）
#       (MAPPO / Hard / Soft 全部 α=0.05 固定，仅共识机制不同)
#   E2 matched-logprob对照 → 审稿人1 致命缺陷#1（核心因果论断缺对照）
#       (硬替换动作 + PPO梯度用a*的log-prob，保证log-prob与执行动作对应)
#   E3 拜占庭场景          → 审稿人1 致命缺陷#3（无拜占庭验证）
#       (随机拜占庭 f=1 / 对抗拜占庭 f=1，各 3 seed)
#   E4 KL方向消融         → 审稿人1 主要问题#3（反向KL无依据）
#       (forward KL D(π_i‖π_cons) vs reverse KL D(π_cons‖π_i))
#   E5 熵地板系数消融      → 审稿人2 #11（10×无依据）
#       (系数 1/5/10/20 ×)
#   E6 多环境泛化          → 审稿人1 主要问题#2（仅1环境）
#       (LBF 2s3f 合作采集，4 agent)
#   E7 统计检验            → 审稿人2 #6（无显著性检验）
#       (paired t-test / Wilcoxon / Levene / 95% CI)
#
# 注意：E1-E6 的数字填入论文 Table 2/3/4 及新增的 Table 5/6/7。
#       所有指标从 results/review/<exp>/seed_<n>/metrics.json 读取，绝不手填。
