#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
analyze_results.py — 从 results/review/<exp>/seed_<n>/metrics.json 提取指标
============================================================================
输出每个实验的：reward(mean±std / 95%CI)、final entropy(mean±std)、
consensus_rate(mean±std)、cross-seed variance。

统计检验（审稿人2 #6）：
  - paired t-test / Wilcoxon：PBFT vs MAPPO 的 reward 差异
  - Levene's test：两组 cross-seed 方差是否显著差异
  - 95% 置信区间

所有数字均来自真实 metrics.json，绝不手填。
用法:
  python experiments/analyze_results.py --log_dir results/review
  python experiments/analyze_results.py --log_dir results/review --exp E1_hard E1_soft E1_mappo
"""
import os, sys, json, argparse
import numpy as np

try:
    from scipy import stats
    HAVE_SCIPY = True
except ImportError:
    HAVE_SCIPY = False
    print("[WARN] 未安装 scipy，统计检验跳过（pip install scipy）")


def load(exp_dir):
    rewards, ents, crs = [], [], []
    for s in [1, 2, 3]:
        p = os.path.join(exp_dir, f"seed_{s}", "metrics.json")
        if not os.path.exists(p):
            continue
        m = json.load(open(p))
        rw = m.get("episode_reward") or m.get("eval_reward")
        en = m.get("entropy")
        cr = m.get("consensus_rate")
        if rw: rewards.append(float(np.mean(rw[-10:])))   # 末段均值
        if en: ents.append(float(en[-1]))
        if cr: crs.append(float(np.mean(cr[-10:])))
    return np.array(rewards), np.array(ents), np.array(crs)


def ci95(a):
    if len(a) < 2: return (np.nan, np.nan)
    se = a.std(ddof=1) / np.sqrt(len(a))
    h = 1.96 * se
    return (a.mean()-h, a.mean()+h)


def report(name, rw, en, cr):
    print(f"\n--- {name} (n={len(rw)}) ---")
    if len(rw):
        lo, hi = ci95(rw)
        print(f"  reward      : {rw.mean():.2f} ± {rw.std():.2f}  | 95%CI [{lo:.2f},{hi:.2f}]")
    if len(en):
        print(f"  entropy(final): {en.mean():.4f} ± {en.std():.4f}")
    if len(cr):
        print(f"  consensus_rate: {cr.mean():.4f} ± {cr.std():.4f}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--log_dir", default="results/review")
    ap.add_argument("--exp", nargs="*", default=None)
    args = ap.parse_args()

    base = args.log_dir
    exps = args.exp or sorted([d for d in os.listdir(base) if os.path.isdir(os.path.join(base, d))])

    data = {}
    for e in exps:
        d = os.path.join(base, e)
        if not os.path.isdir(d): continue
        rw, en, cr = load(d)
        if len(rw) == 0:
            print(f"[skip] {e}: 无数据"); continue
        data[e] = (rw, en, cr)
        report(e, rw, en, cr)

    # 统计检验：比较 E1_hard vs E1_mappo（公平对比）
    if HAVE_SCIPY and "E1_hard" in data and "E1_mappo" in data:
        print("\n===== 统计检验 (E1: Hard vs MAPPO, 公平 α=0.05) =====")
        hw, _, _ = data["E1_hard"]
        mw, _, _ = data["E1_mappo"]
        if len(hw) == len(mw) and len(hw) >= 2:
            t, p = stats.ttest_rel(hw, mw)
            try:
                w, pw = stats.wilcoxon(hw, mw)
            except ValueError:
                w, pw = float('nan'), float('nan')
            print(f"  paired t-test : t={t:.3f}, p={p:.4f}")
            print(f"  wilcoxon      : W={w:.1f}, p={pw:.4f}")
        # Levene: 跨种子方差 Hard vs Soft
        if "E1_soft" in data:
            _, _, _ = data["E1_hard"]
            hs = data["E1_soft"][0]
            if len(hw) >= 2 and len(hs) >= 2:
                lev, pl = stats.levene(hw, hs)
                print(f"  Levene(Hard vs Soft reward var): W={lev:.3f}, p={pl:.4f}")
                print(f"  variance ratio (Hard/Soft): {hw.var()/max(hs.var(),1e-9):.2f}×")


if __name__ == "__main__":
    main()
