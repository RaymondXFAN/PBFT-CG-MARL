#!/bin/bash
# ============================================================
# PBFT-CG-MAPPO 审稿回复实验编排（AutoDL, GPU）
# 用法:
#   bash experiments/run_all_review.sh 0            # 正式：3 seed × 300K
#   bash experiments/run_all_review.sh 0 --smoke    # 预检：1 seed × 50K（约5分钟）
# ============================================================
set -e
GPU_ID=${1:-0}
SMOKE=${2:-""}

if [ "$SMOKE" = "--smoke" ]; then
  SEEDS="1"; N_STEPS=50000; EVAL_INT=5000; EVAL_EP=5
  echo ">>> SMOKE 模式"
else
  SEEDS="1 2 3"; N_STEPS=300000; EVAL_INT=10000; EVAL_EP=10
  echo ">>> 正式模式 (3 seeds × 300K)"
fi

LOG="results/review"
ENV_MPE="configs/env/mpe_spread.yaml"
ENV_LBF="configs/env/lbf_2s3f.yaml"
CFGD="experiments/configs"

run_pbft() {
  local name=$1 algo=$2 envcfg=$3 algo_cfg=$4 extra=$5
  for S in $SEEDS; do
    echo "===== $name seed=$S ====="
    python -u src/train.py --algo $algo --env mpe_spread \
      --env_config $envcfg --algo_config $algo_cfg \
      --seed $S --n_timesteps $N_STEPS --eval_interval $EVAL_INT \
      --eval_episodes $EVAL_EP --log_dir $LOG/$name --gpu $GPU_ID $extra
  done
}
run_mappo() {
  local name=$1 algo_cfg=$2 extra=$3
  for S in $SEEDS; do
    echo "===== $name seed=$S ====="
    python -u src/train.py --algo mappo --env mpe_spread \
      --env_config $ENV_MPE --algo_config $algo_cfg \
      --seed $S --n_timesteps $N_STEPS --eval_interval $EVAL_INT \
      --eval_episodes $EVAL_EP --log_dir $LOG/$name --gpu $GPU_ID $extra
  done
}

echo "########################################"
echo "# E1 公平三路对比 (α=0.05 固定)"
echo "########################################"
run_mappo  E1_mappo       $CFGD/fair_mappo.yaml
run_pbft   E1_hard        pbft_cg_mappo $ENV_MPE $CFGD/fair_hard.yaml
run_pbft   E1_soft        pbft_cg_mappo $ENV_MPE $CFGD/fair_soft.yaml

echo "########################################"
echo "# E2 matched-logprob 因果对照"
echo "########################################"
run_pbft   E2_matched     pbft_cg_mappo $ENV_MPE $CFGD/matched_logprob.yaml

echo "########################################"
echo "# E3 拜占庭场景 (f=1)"
echo "########################################"
for MODE in random adversarial; do
  run_pbft E3_hard_$MODE     pbft_cg_mappo $ENV_MPE $CFGD/fair_hard.yaml "--byzantine_n 1 --byzantine_mode $MODE"
  run_pbft E3_soft_$MODE     pbft_cg_mappo $ENV_MPE $CFGD/fair_soft.yaml "--byzantine_n 1 --byzantine_mode $MODE"
done

echo "########################################"
echo "# E4 KL 方向消融"
echo "########################################"
run_pbft   E4_kl_forward   pbft_cg_mappo $ENV_MPE $CFGD/kl_forward.yaml
run_pbft   E4_kl_reverse   pbft_cg_mappo $ENV_MPE $CFGD/kl_reverse.yaml

echo "########################################"
echo "# E5 熵地板系数消融"
echo "########################################"
for C in 1 5 10 20; do
  run_pbft E5_floor_${C}x pbft_cg_mappo $ENV_MPE $CFGD/floor_${C}x.yaml
done

echo "########################################"
echo "# E6 多环境泛化 (LBF 2s3f)"
echo "########################################"
for S in $SEEDS; do
  echo "===== E6_lbf_mappo seed=$S ====="
  python -u src/train.py --algo mappo --env lbf --env_config $ENV_LBF \
    --algo_config $CFGD/lbf_mappo.yaml --seed $S --n_timesteps $N_STEPS \
    --eval_interval $EVAL_INT --eval_episodes $EVAL_EP --log_dir $LOG/E6_lbf_mappo --gpu $GPU_ID
  echo "===== E6_lbf_soft seed=$S ====="
  python -u src/train.py --algo pbft_cg_mappo --env lbf --env_config $ENV_LBF \
    --algo_config $CFGD/lbf_soft.yaml --seed $S --n_timesteps $N_STEPS \
    --eval_interval $EVAL_INT --eval_episodes $EVAL_EP --log_dir $LOG/E6_lbf_soft --gpu $GPU_ID
done

echo "========================================"
echo "全部实验完成 → results/review/"
echo "运行: python experiments/analyze_results.py --log_dir results/review"
echo "========================================"
