#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
补丁2：拜占庭对抗模式（审稿人1 致命缺陷#3）
=============================================
新增 --byzantine_mode {random, adversarial}：
  random      : 拜占庭 agent 执行随机动作（已有 --byzantine_n 支持时的默认行为）
  adversarial : 拜占庭 agent 主动执行「与共识相反/最破坏一致性」的动作，
                模拟 worst-case 对抗拜占庭（最大化共识率下降 / 任务奖励下降）

代码库若已有 inject_byzantine / --byzantine_n（README 显示支持），
本补丁只新增 mode 分支；否则在 act() 注入 hook 并给出手动说明。

应用：python experiments/patches/patch_byzantine.py
"""
import os, shutil
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def patch_train_args():
    fp = os.path.join(ROOT, "src", "train.py")
    src = open(fp, encoding="utf-8").read()
    if "--byzantine_mode" in src:
        print("[SKIP] train.py 已有 byzantine_mode"); return
    # 在 --byzantine_n 参数附近插入
    anchor = '--byzantine_n'
    add = ('    parser.add_argument("--byzantine_mode", type=str, default="random",\n'
           '                        choices=["random", "adversarial"],\n'
           '                        help="Byzantine attack type: random or adversarial")\n')
    if anchor in src:
        # 找包含 --byzantine_n 的那一行，在其后插入
        idx = src.index(anchor)
        line_end = src.index("\n", idx)
        src = src[:line_end+1] + add + src[line_end+1:]
    else:
        print("[WARN] 未找到 --byzantine_n，请手动添加 --byzantine_mode 参数")
    # 透传给 config
    if "byzantine_mode" not in src:
        src = src.replace('"byzantine_n": args.byzantine_n,',
                          '"byzantine_n": args.byzantine_n,\n        "byzantine_mode": args.byzantine_mode,', 1) \
            if '"byzantine_n": args.byzantine_n,' in src else src
    shutil.copy2(fp, fp + ".bak_byz")
    open(fp, "w", encoding="utf-8").write(src)
    print("[OK] train.py 已添加 --byzantine_mode")


def patch_algo():
    fp = os.path.join(ROOT, "src", "algorithms", "pbft_cg_mappo.py")
    src = open(fp, encoding="utf-8").read()
    if "self.byzantine_mode" in src:
        print("[SKIP] 算法已含 byzantine_mode"); return
    anchor = 'self.matched_logprob = config.get("matched_logprob", False)'
    add = anchor + '\n        self.byzantine_mode = config.get("byzantine_mode", "random")\n        self.byzantine_indices = config.get("byzantine_indices", [])'
    if anchor in src:
        src = src.replace(anchor, add, 1)
    else:
        print("[WARN] 未找到 matched_logprob 锚点，请手动注入 byzantine_mode")
    # 新增对抗动作生成方法
    method = '''
    def adversarial_action(self, obs_i, consensus_action_i, action_dim):
        """对抗拜占庭：选择最破坏共识的动作。
        简单有效实现：在与共识动作不同的动作中，选 argmax 距离；
        离散 5 动作环境：取 (consensus_action_i + action_dim//2) % action_dim（反向）。"""
        import numpy as np
        if consensus_action_i is None:
            return int(np.random.randint(action_dim))
        # 反向动作（最远离共识）
        return int((consensus_action_i + action_dim // 2) % action_dim)

    def apply_byzantine(self, actions, consensus_actions, action_dim):
        """对标记为拜占庭的 agent 覆写动作。"""
        if not self.byzantine_indices:
            return actions
        out = list(actions)
        for i in self.byzantine_indices:
            if i >= len(out):
                continue
            if self.byzantine_mode == "adversarial":
                c = consensus_actions[i] if consensus_actions else None
                out[i] = self.adversarial_action(None, c, action_dim)
            else:
                import numpy as np
                out[i] = int(np.random.randint(action_dim))
        return out

'''
    if "def update(" in src and "def apply_byzantine" not in src:
        src = src.replace("    def update(", method + "    def update(", 1)
    shutil.copy2(fp, fp + ".bak_byz")
    open(fp, "w", encoding="utf-8").write(src)
    print("[OK] 算法已添加 byzantine_mode / apply_byzantine（请在 act() 中 consensus 后调用 self.apply_byzantine）")


if __name__ == "__main__":
    print("=== 补丁2: 拜占庭对抗模式 ===")
    patch_train_args()
    patch_algo()
    print("注意：adversarial 覆写需在 act() 的 consensus 后调用 self.apply_byzantine(...)，若未自动插入请手动添加。")
