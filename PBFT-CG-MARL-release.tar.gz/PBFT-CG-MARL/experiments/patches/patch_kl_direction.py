#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
补丁3：KL 方向消融（审稿人1 主要问题#3）
========================================
新增 kl_direction: {reverse, forward}
  reverse : D_KL(π_consensus ‖ π_i)   —— 论文默认（模式寻求，鼓励覆盖共识模式）
  forward : D_KL(π_i ‖ π_consensus)   —— 均值寻求，鼓励策略集中在共识附近

在 KL 损失计算处根据标志切换顺序。若代码用 torch.distributions.kl_divergence(p, q)，
reverse = kl_divergence(consensus_dist, agent_dist)，forward = kl_divergence(agent_dist, consensus_dist)。

应用：python experiments/patches/patch_kl_direction.py
"""
import os, shutil
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def patch():
    fp = os.path.join(ROOT, "src", "algorithms", "pbft_cg_mappo.py")
    src = open(fp, encoding="utf-8").read()
    if "self.kl_direction" in src:
        print("[SKIP] 算法已含 kl_direction"); return

    # 1) __init__ 注入标志
    anchor = 'self.byzantine_mode = config.get("byzantine_mode", "random")'
    add = anchor + '\n        self.kl_direction = config.get("kl_direction", "reverse")'
    if anchor in src:
        src = src.replace(anchor, add, 1)
    else:
        anchor2 = 'self.matched_logprob = config.get("matched_logprob", False)'
        if anchor2 in src:
            src = src.replace(anchor2, anchor2 + '\n        self.kl_direction = config.get("kl_direction", "reverse")', 1)
        else:
            print("[WARN] 未找到锚点，请手动注入 self.kl_direction")

    # 2) KL 损失计算处切换方向
    # 常见写法：kl = F.kl_div(...) 或 kl_divergence(p, q)
    if "kl_divergence" in src:
        # 找到 kl_divergence(p, q) 调用，包裹为方向选择
        import re
        # 匹配 kl_divergence(A, B) 或 kl_divergence( A , B )
        pat = re.compile(r'kl_divergence\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)')
        m = pat.search(src)
        if m:
            p, q = m.group(1).strip(), m.group(2).strip()
            replacement = (
                'kl_divergence(%s, %s)' % (
                    f"({p} if self.kl_direction=='reverse' else ({q}))",
                    f"({q} if self.kl_direction=='reverse' else ({p}))"
                )
            )
            src = pat.sub(replacement, src, count=1)
            print(f"[OK] 已切换 KL 方向：reverse=kl({p},{q}), forward=kl({q},{p})")
        else:
            print("[WARN] 未匹配 kl_divergence 参数，请手动按 kl_direction 切换 p/q")
    elif "F.kl_div" in src or "kl_div" in src:
        print("[WARN] 代码使用 F.kl_div（需 log_softmax 输入），请手动按 kl_direction 调整输入顺序")
    else:
        print("[WARN] 未找到 KL 计算调用，请手动按 kl_direction 切换方向")

    shutil.copy2(fp, fp + ".bak_kl")
    open(fp, "w", encoding="utf-8").write(src)
    print(f"[OK] 算法已添加 kl_direction（备份: {fp}.bak_kl）")


if __name__ == "__main__":
    print("=== 补丁3: KL 方向消融 ===")
    patch()
