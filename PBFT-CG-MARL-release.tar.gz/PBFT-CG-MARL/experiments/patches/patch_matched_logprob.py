#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
补丁1：matched-logprob 因果对照（审稿人1 致命缺陷#1）
=================================================
在 pbft_cg_mappo.py 中：
  (a) 读取 matched_logprob 配置标志
  (b) 新增 evaluate_log_prob(obs, actions) 方法，用当前策略重新计算给定动作的 log-prob
  (c) 在 act() 返回前，若开启 matched_logprob 且为硬共识模式，
      将存储的 log_prob 替换为「被执行（共识）动作 a*」的 log_prob，
      从而保证 PPO 梯度的 log-prob 与执行动作完全对应。

在 train.py 中：
  (d) 在 default_config 注入 matched_logprob: false
  (e) 将该标志传给算法

应用：python experiments/patches/patch_matched_logprob.py
（在仓库根目录 /root/autodl-tmp/PBFT-CG-MARL 下运行）
"""
import os, sys, shutil

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def patch_pbft_algo():
    fp = os.path.join(ROOT, "src", "algorithms", "pbft_cg_mappo.py")
    if not os.path.exists(fp):
        print(f"[SKIP] 找不到 {fp}"); return True
    src = open(fp, encoding="utf-8").read()
    if "self.matched_logprob" in src:
        print("[SKIP] pbft_cg_mappo.py 已含 matched_logprob"); return True

    # (a) 注入标志：锚点 = consensus_freq 赋值（v4 补丁已加）
    anchor_a = 'self.consensus_freq = config.get("consensus_freq", 1)'
    add_a = anchor_a + '\n        self.matched_logprob = config.get("matched_logprob", False)'
    if anchor_a in src:
        src = src.replace(anchor_a, add_a, 1)
    else:
        # v3 基座锚点：consensus_loss_coef 赋值
        anchor_a3 = 'self.consensus_loss_coef = config.get("consensus_loss_coef", 0.1)'
        add_a3 = anchor_a3 + '\n        self.consensus_freq = config.get("consensus_freq", 1)\n        self.matched_logprob = config.get("matched_logprob", False)'
        if anchor_a3 in src:
            src = src.replace(anchor_a3, add_a3, 1)
        else:
            print("[WARN] 未找到 consensus_freq/consensus_loss_coef 锚点，请手动注入 self.matched_logprob")

    # (b) 新增 evaluate_log_prob 方法：锚点 = update() 方法定义前（或文件末尾类内）
    method = '''

    def evaluate_log_prob(self, obs, actions):
        """用当前策略网络重新计算给定动作的 log-prob（用于 matched-logprob 对照）。
        obs: dict of tensors (per-agent) 或 tensor；actions: list/np.array of executed actions。
        返回: list[float]，每个 agent 的执行动作对应的 log π(a|o)。
        若底层环境为离散动作，直接从 categorical 分布取 log_prob。"""
        import torch
        self.actor.eval()
        with torch.no_grad():
            try:
                if hasattr(self, "actor"):
                    logits = self.actor(obs)
                    if isinstance(logits, tuple):
                        logits = logits[0]
                    dist = torch.distributions.Categorical(logits=logits)
                    act_t = torch.as_tensor(actions, device=logits.device)
                    if act_t.dim() == 1:
                        act_t = act_t.unsqueeze(-1)
                    lp = dist.log_prob(act_t.squeeze(-1))
                    return lp.cpu().numpy().tolist()
            except Exception as e:
                print(f"[matched_logprob] evaluate_log_prob 失败: {e}")
        self.actor.train()
        return None

'''
    # 在 update 方法前插入（找 "def update(" 且前面是类方法缩进）
    if "def update(" in src and "def evaluate_log_prob" not in src:
        src = src.replace("    def update(", method + "    def update(", 1)
    else:
        print("[WARN] 未找到 update 方法，evaluate_log_prob 未插入，请手动添加")

    # (c) act() 返回前替换 log_prob：锚点 = "return actions, log_probs" 或类似
    # 尝试常见返回形式
    for ret_pat in ['return actions, log_probs', 'return actions, log_probs,', 'return (actions, log_probs)']:
        if ret_pat in src:
            new_ret = (
                '        if getattr(self, "matched_logprob", False) and getattr(self, "consensus_mode", "hard") == "hard":\n'
                '            try:\n'
                '                _lp = self.evaluate_log_prob(obs, consensus_actions)\n'
                '                if _lp is not None:\n'
                '                    log_probs = _lp\n'
                '            except Exception as e:\n'
                '                print(f"[matched_logprob] act 替换失败: {e}")\n'
                + "        " + ret_pat
            )
            src = src.replace(ret_pat, new_ret, 1)
            break
    else:
        print("[WARN] 未找到 act() 的 return 语句，请在 act() 返回前手动插入 log_prob 替换逻辑")

    shutil.copy2(fp, fp + ".bak_matched")
    open(fp, "w", encoding="utf-8").write(src)
    print(f"[OK] pbft_cg_mappo.py 已修改（备份: {fp}.bak_matched）")
    return True


def patch_train():
    fp = os.path.join(ROOT, "src", "train.py")
    if not os.path.exists(fp):
        print(f"[SKIP] 找不到 {fp}"); return True
    src = open(fp, encoding="utf-8").read()
    if '"matched_logprob"' in src:
        print("[SKIP] train.py 已含 matched_logprob"); return True

    # (d) default_config 注入
    anchor = '"consensus_freq": 1,'
    add = anchor + '\n        "matched_logprob": False,'
    if anchor in src:
        src = src.replace(anchor, add, 1)
    else:
        # 尝试 v3 锚点
        anchor3 = '"consensus_loss_coef": 0.1,'
        add3 = anchor3 + '\n        "consensus_freq": 1,\n        "matched_logprob": False,'
        if anchor3 in src:
            src = src.replace(anchor3, add3, 1)
        else:
            print("[WARN] train.py 未找到 default_config 锚点")

    # (e) 展平 consensus_freq 后注入 matched_logprob 到算法
    anchor_flat = 'if "pbft" in config and isinstance(config["pbft"], dict):'
    add_flat = (
        '    # matched_logprob 标志透传\n'
        '    if "matched_logprob" in config:\n'
        '        algorithm.matched_logprob = config["matched_logprob"]\n'
        + '    if "pbft" in config and isinstance(config["pbft"], dict):'
    )
    if anchor_flat in src and 'algorithm.matched_logprob' not in src:
        src = src.replace(anchor_flat, add_flat, 1)

    shutil.copy2(fp, fp + ".bak_matched")
    open(fp, "w", encoding="utf-8").write(src)
    print(f"[OK] train.py 已修改（备份: {fp}.bak_matched）")
    return True


if __name__ == "__main__":
    print("=== 补丁1: matched-logprob 因果对照 ===")
    patch_pbft_algo()
    patch_train()
    print("完成。若上方出现 [WARN]，请按提示手动注入（锚点已在 WARN 中说明）。")
