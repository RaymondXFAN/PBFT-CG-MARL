#!/usr/bin/env python3
"""
PBFT-CG-MARL v4 补丁脚本
在 AutoDL 上运行此脚本，自动修改 v3 代码为 v4 版本

修改内容：
1. src/train.py - 添加 consensus_freq 和 adaptive_entropy 参数支持
2. src/algorithms/pbft_cg_mappo.py - 实现共识频率控制和自适应熵调度
3. src/consensus/pbft.py - 添加 blend_ratio 可配置参数
4. configs/algo/pbft_cg_mappo_v4.yaml - 新增 v4 配置文件
5. configs/algo/mappo_v4.yaml - 新增 v4 对照配置文件

使用方法：
    cd /root/autodl-tmp/PBFT-CG-MARL
    python patch_v4.py
"""

import os
import sys
import shutil

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

def patch_train_py():
    """修改 train.py，添加 consensus_freq 参数到 default_config"""
    filepath = os.path.join(PROJECT_ROOT, "src", "train.py")
    
    if not os.path.exists(filepath):
        print(f"[ERROR] 找不到 {filepath}，请确认项目路径")
        return False
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 检查是否已打过补丁
    if 'consensus_freq' in content:
        print("[SKIP] train.py 已包含 consensus_freq，跳过")
        return True
    
    # 1. 在 default_config 中添加 consensus_freq
    old_consensus_loss = '"consensus_loss_coef": 0.1,'
    new_consensus_loss = '''"consensus_loss_coef": 0.1,
        "consensus_freq": 1,  # v4: 每 N 步做一次共识
        "consensus_blend_ratio": 0.3,  # v4: 软混合比例'''
    
    if old_consensus_loss in content:
        content = content.replace(old_consensus_loss, new_consensus_loss)
    else:
        print("[WARN] 未找到 consensus_loss_coef 默认配置行，尝试其他方式")
        # 在 pbft 相关参数区域末尾添加
        old_pbft_block = '"consensus_threshold": 0.5,'
        new_pbft_block = '''"consensus_threshold": 0.5,
        "consensus_freq": 1,
        "consensus_blend_ratio": 0.3,'''
        if old_pbft_block in content:
            content = content.replace(old_pbft_block, new_pbft_block, 1)
    
    # 2. 在 default_config 中添加 adaptive_entropy 参数
    old_comm_steps = '"comm_steps": 1,'
    new_comm_steps = '''"comm_steps": 1,

        # v4: 自适应熵调度
        "use_adaptive_entropy": False,
        "target_entropy": 0.10,
        "entropy_coef_min": 0.02,
        "entropy_coef_max": 0.30,
        "entropy_adjustment_rate": 0.05,'''
    
    if old_comm_steps in content:
        content = content.replace(old_comm_steps, new_comm_steps, 1)
    
    # 3. 在展平 pbft 配置后，注入 consensus_freq 和 blend_ratio 到 consensus 层
    # 找到 "if 'pbft' in config and isinstance(config['pbft'], dict):" 块之后
    old_pbft_flatten = '''    # 展平嵌套配置（如pbft: {f: 1, ...} → pbft_f: 1, ...）
    if "pbft" in config and isinstance(config["pbft"], dict):
        pbft_cfg = config.pop("pbft")
        for k, v in pbft_cfg.items():
            config[f"pbft_{k}"] = v'''
    
    new_pbft_flatten = '''    # 展平嵌套配置（如pbft: {f: 1, ...} → pbft_f: 1, ...）
    if "pbft" in config and isinstance(config["pbft"], dict):
        pbft_cfg = config.pop("pbft")
        for k, v in pbft_cfg.items():
            config[f"pbft_{k}"] = v

    # v4: 展平 adaptive_entropy 配置
    if "adaptive_entropy" in config and isinstance(config["adaptive_entropy"], dict):
        ae_cfg = config.pop("adaptive_entropy")
        for k, v in ae_cfg.items():
            config[f"ae_{k}"] = v'''
    
    if old_pbft_flatten in content:
        content = content.replace(old_pbft_flatten, new_pbft_flatten, 1)
    
    # 4. 在算法创建后，设置 consensus_freq 和 blend_ratio
    # 找到 "algorithm = algorithm_cls(config, env_info)" 之后
    old_algo_create = '''    # 注入拜占庭Agent
    if args.byzantine_n > 0 and hasattr(algorithm, "inject_byzantine"):'''
    
    new_algo_create = '''    # v4: 设置共识频率和混合比例
    if hasattr(algorithm, "pbft_consensus"):
        if "pbft_consensus_freq" in config:
            algorithm.pbft_consensus.consensus_freq = config["pbft_consensus_freq"]
            print(f"[v4] 共识频率设为: 每 {config['pbft_consensus_freq']} 步")
        if "pbft_consensus_blend_ratio" in config:
            algorithm.pbft_consensus.blend_ratio = config["pbft_consensus_blend_ratio"]
            print(f"[v4] 共识混合比例设为: {config['pbft_consensus_blend_ratio']}")
    # v4: 设置自适应熵调度
    if hasattr(algorithm, "use_adaptive_entropy"):
        if config.get("ae_enabled", False):
            algorithm.use_adaptive_entropy = True
            algorithm.target_entropy = config.get("ae_target_entropy", 0.10)
            algorithm.entropy_coef_min = config.get("ae_entropy_coef_min", 0.02)
            algorithm.entropy_coef_max = config.get("ae_entropy_coef_max", 0.30)
            algorithm.entropy_adjustment_rate = config.get("ae_adjustment_rate", 0.05)
            print(f"[v4] 自适应熵调度: target={algorithm.target_entropy}, range=[{algorithm.entropy_coef_min}, {algorithm.entropy_coef_max}]")

    # 注入拜占庭Agent
    if args.byzantine_n > 0 and hasattr(algorithm, "inject_byzantine"):'''
    
    if old_algo_create in content:
        content = content.replace(old_algo_create, new_algo_create, 1)
    
    # 备份原文件
    shutil.copy2(filepath, filepath + ".v3.bak")
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"[OK] train.py 已修改（备份: train.py.v3.bak）")
    return True


def patch_pbft_cg_mappo_py():
    """修改 pbft_cg_mappo.py，添加共识频率控制和自适应熵调度"""
    filepath = os.path.join(PROJECT_ROOT, "src", "algorithms", "pbft_cg_mappo.py")
    
    if not os.path.exists(filepath):
        print(f"[ERROR] 找不到 {filepath}")
        return False
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 检查是否已打过补丁
    if 'consensus_freq' in content and 'use_adaptive_entropy' in content:
        print("[SKIP] pbft_cg_mappo.py 已包含 v4 修改，跳过")
        return True
    
    # 1. 在 __init__ 中添加 v4 新属性
    old_consensus_loss_coef = '''        self.consensus_loss_coef = config.get("consensus_loss_coef", 0.1)'''
    new_consensus_loss_coef = '''        self.consensus_loss_coef = config.get("consensus_loss_coef", 0.1)

        # v4: 共识频率控制
        self.consensus_freq = config.get("consensus_freq", 1)
        self._consensus_step_counter = 0

        # v4: 自适应熵调度
        self.use_adaptive_entropy = config.get("use_adaptive_entropy", False)
        self.target_entropy = config.get("target_entropy", 0.10)
        self.entropy_coef_min = config.get("entropy_coef_min", 0.02)
        self.entropy_coef_max = config.get("entropy_coef_max", 0.30)
        self.entropy_adjustment_rate = config.get("entropy_adjustment_rate", 0.05)'''
    
    if old_consensus_loss_coef in content:
        content = content.replace(old_consensus_loss_coef, new_consensus_loss_coef, 1)
    
    # 2. 修改 act() 方法，添加共识频率控制
    # 找到 "步骤2：PBFT共识层聚合proposals" 并添加条件判断
    old_consensus_call = '''        # 步骤2：PBFT共识层聚合proposals
        consensus_actions, consensus_info = self.pbft_consensus(
            proposals, obs, step=self._training_step, action_type=self.action_type
        )'''
    
    new_consensus_call = '''        # 步骤2：PBFT共识层聚合proposals（v4: 支持共识频率控制）
        self._consensus_step_counter += 1
        if self.consensus_freq <= 1 or self._consensus_step_counter % self.consensus_freq == 0:
            # 执行共识
            consensus_actions, consensus_info = self.pbft_consensus(
                proposals, obs, step=self._training_step, action_type=self.action_type
            )
        else:
            # 跳过共识，直接使用actor原始输出
            consensus_actions = [a for a, _ in proposals]
            consensus_info = {"consensus_rate": 1.0, "consensus_achieved": True, "skipped": True}'''
    
    if old_consensus_call in content:
        content = content.replace(old_consensus_call, new_consensus_call, 1)
    
    # 3. 在 update() 方法末尾添加自适应熵调度逻辑
    # 找到 "self._training_step += 1" 之前
    old_training_step = '''        self._training_step += 1

        return {'''
    
    new_training_step = '''        # v4: 自适应熵调度
        if self.use_adaptive_entropy:
            current_entropy = total_entropy / self.ppo_epoch
            if current_entropy < self.target_entropy:
                # 熵太低，增加熵系数
                self.entropy_coef = min(
                    self.entropy_coef * (1.0 + self.entropy_adjustment_rate),
                    self.entropy_coef_max
                )
            elif current_entropy > self.target_entropy * 1.5:
                # 熵太高，适当降低
                self.entropy_coef = max(
                    self.entropy_coef * (1.0 - self.entropy_adjustment_rate * 0.5),
                    self.entropy_coef_min
                )

        self._training_step += 1

        return {'''
    
    if old_training_step in content:
        content = content.replace(old_training_step, new_training_step, 1)
    
    # 4. 在 loss_dict 中添加 entropy_coef 记录
    old_lr_return = '''            "lr": self.optimizer.param_groups["lr"],'''
    new_lr_return = '''            "lr": self.optimizer.param_groups["lr"],
            "entropy_coef": self.entropy_coef,'''
    
    if old_lr_return in content:
        content = content.replace(old_lr_return, new_lr_return, 1)
    
    # 备份原文件
    shutil.copy2(filepath, filepath + ".v3.bak")
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"[OK] pbft_cg_mappo.py 已修改（备份: pbft_cg_mappo.py.v3.bak）")
    return True


def patch_pbft_consensus_py():
    """修改 pbft.py，添加 blend_ratio 可配置参数"""
    filepath = os.path.join(PROJECT_ROOT, "src", "consensus", "pbft.py")
    
    if not os.path.exists(filepath):
        print(f"[ERROR] 找不到 {filepath}")
        return False
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 检查是否已打过补丁
    if 'blend_ratio' in content and 'consensus_freq' in content:
        print("[SKIP] pbft.py 已包含 v4 修改，跳过")
        return True
    
    # 1. 在 __init__ 中添加 blend_ratio 和 consensus_freq 属性
    old_consensus_threshold = '''        self.consensus_threshold = consensus_threshold
        self.action_dim = action_dim'''
    
    new_consensus_threshold = '''        self.consensus_threshold = consensus_threshold
        self.action_dim = action_dim
        self.blend_ratio = 0.3  # v4: 软混合比例，可从外部设置
        self.consensus_freq = 1  # v4: 共识频率，可从外部设置'''
    
    if old_consensus_threshold in content:
        content = content.replace(old_consensus_threshold, new_consensus_threshold, 1)
    
    # 2. 替换硬编码的 blend_ratio = 0.3
    old_blend = 'blend_ratio = 0.3  # 30%来自共识参考，70%来自自身'
    new_blend = 'blend_ratio = self.blend_ratio  # v4: 可配置的混合比例'
    
    if old_blend in content:
        content = content.replace(old_blend, new_blend)
    else:
        # 尝试其他格式
        old_blend2 = 'blend_ratio = 0.3'
        if old_blend2 in content:
            content = content.replace(old_blend2, 'blend_ratio = self.blend_ratio', 1)
    
    # 备份原文件
    shutil.copy2(filepath, filepath + ".v3.bak")
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"[OK] pbft.py 已修改（备份: pbft.py.v3.bak）")
    return True


def create_v4_configs():
    """创建 v4 配置文件"""
    # pbft_cg_mappo_v4.yaml
    pbft_v4_config = """# PBFT-CG-MAPPO v4 配置 - 熵崩塌修复版
# 修改记录（vs v3）:
#   1. entropy_coef: 0.05 → 0.15  (对抗共识模块导致的策略坍缩)
#   2. consensus_loss_coef: 0.1 → 0.01  (降低共识损失权重)
#   3. consensus_freq: 1 → 5  (每5步才做一次共识)
#   4. consensus_blend_ratio: 0.3 → 0.1  (降低软混合比例)
#   5. use_adaptive_entropy: true  (自适应熵调度)
#   6. entropy_coef_min: 0.02  (熵系数下限)

algorithm: pbft_cg_mappo

lr: 0.0005
clip_ratio: 0.2
value_loss_coef: 1.0
entropy_coef: 0.15
gamma: 0.99
gae_lambda: 0.95

ppo_epoch: 5
num_mini_batch: 1
max_grad_norm: 0.5

hidden_dim: 64
use_ReLU: true
use_feature_normalization: true
share_param: true
use_rnn: true
rnn_type: gru

# PBFT 共识参数
pbft:
  f: 1
  leader_rotation: true
  use_fallback: true
  consensus_threshold: 0.5
  temperature: 1.0
  consensus_loss_coef: 0.01
  consensus_freq: 5
  consensus_blend_ratio: 0.1

# 自适应熵调度
adaptive_entropy:
  enabled: true
  target_entropy: 0.10
  entropy_coef_min: 0.02
  entropy_coef_max: 0.30
  adjustment_rate: 0.05
"""
    
    filepath = os.path.join(PROJECT_ROOT, "configs", "algo", "pbft_cg_mappo_v4.yaml")
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(pbft_v4_config)
    print(f"[OK] 已创建 {filepath}")
    
    # mappo_v4.yaml
    mappo_v4_config = """# MAPPO v4 配置 - 对照组（与 pbft_v4 同样的 entropy_coef）
algorithm: mappo

lr: 0.0005
clip_ratio: 0.2
value_loss_coef: 1.0
entropy_coef: 0.15
gamma: 0.99
gae_lambda: 0.95

ppo_epoch: 5
num_mini_batch: 1
max_grad_norm: 0.5

hidden_dim: 64
use_ReLU: true
use_feature_normalization: true
share_param: true
use_rnn: true
rnn_type: gru

# 自适应熵调度（与 pbft_v4 一致）
adaptive_entropy:
  enabled: true
  target_entropy: 0.10
  entropy_coef_min: 0.02
  entropy_coef_max: 0.30
  adjustment_rate: 0.05
"""
    
    filepath = os.path.join(PROJECT_ROOT, "configs", "algo", "mappo_v4.yaml")
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(mappo_v4_config)
    print(f"[OK] 已创建 {filepath}")
    
    return True


def main():
    print("=" * 60)
    print("PBFT-CG-MARL v4 补丁脚本")
    print("修复熵崩塌问题：consensus_freq + adaptive_entropy + blend_ratio")
    print("=" * 60)
    
    results = []
    
    # 1. 修改 train.py
    print("\n[1/4] 修改 train.py ...")
    results.append(("train.py", patch_train_py()))
    
    # 2. 修改 pbft_cg_mappo.py
    print("\n[2/4] 修改 pbft_cg_mappo.py ...")
    results.append(("pbft_cg_mappo.py", patch_pbft_cg_mappo_py()))
    
    # 3. 修改 pbft.py
    print("\n[3/4] 修改 pbft.py ...")
    results.append(("pbft.py", patch_pbft_consensus_py()))
    
    # 4. 创建 v4 配置文件
    print("\n[4/4] 创建 v4 配置文件 ...")
    results.append(("configs", create_v4_configs()))
    
    # 汇总
    print("\n" + "=" * 60)
    print("补丁结果汇总：")
    for name, ok in results:
        status = "✅ 成功" if ok else "❌ 失败"
        print(f"  {name}: {status}")
    
    all_ok = all(ok for _, ok in results)
    if all_ok:
        print("\n🎉 所有补丁已成功应用！")
        print("原文件已备份为 .v3.bak")
        print("\n下一步：运行快速验证")
        print("  python -u src/train.py \\")
        print("    --algo pbft_cg_mappo \\")
        print("    --env mpe_spread \\")
        print("    --env_config configs/env/mpe_spread.yaml \\")
        print("    --algo_config configs/algo/pbft_cg_mappo_v4.yaml \\")
        print("    --seed 1 --n_timesteps 50000 --eval_interval 5000 \\")
        print("    --eval_episodes 5 --log_dir results/v4_quick --gpu 0")
    else:
        print("\n⚠️ 部分补丁失败，请检查上方日志")
    
    return all_ok


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
