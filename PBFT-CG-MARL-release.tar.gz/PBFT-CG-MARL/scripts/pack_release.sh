#!/bin/bash
# ============================================================
# PBFT-CG-MARL 关键数据打包脚本
# 只保留代码+关键结果，丢弃原始训练日志和大模型文件
# ============================================================

set -e
cd /root/autodl-tmp/PBFT-CG-MARL

PACK_DIR="/root/autodl-tmp/PBFT-CG-MARL-release"
rm -rf "$PACK_DIR"
mkdir -p "$PACK_DIR"

echo "=== 1. 复制核心代码 ==="
# 源代码
cp -r src "$PACK_DIR/"
cp -r configs "$PACK_DIR/"
cp -r models "$PACK_DIR/" 2>/dev/null || true

# 脚本
mkdir -p "$PACK_DIR/scripts"
cp scripts/run_kl_ablation.sh "$PACK_DIR/scripts/" 2>/dev/null || true
cp scripts/run_kl_ablation_full.sh "$PACK_DIR/scripts/" 2>/dev/null || true
cp scripts/run_v4_quick.sh "$PACK_DIR/scripts/" 2>/dev/null || true
cp scripts/run_v4_full.sh "$PACK_DIR/scripts/" 2>/dev/null || true
cp scripts/diagnose_v4.py "$PACK_DIR/scripts/" 2>/dev/null || true
cp scripts/diagnose_quick.py "$PACK_DIR/scripts/" 2>/dev/null || true

# 补丁脚本（记录修改过程）
cp patch_v4.py "$PACK_DIR/" 2>/dev/null || true
cp patch_v4_fix.py "$PACK_DIR/" 2>/dev/null || true
cp patch_v4_2.py "$PACK_DIR/" 2>/dev/null || true
cp patch_v4_2_precise.py "$PACK_DIR/" 2>/dev/null || true
cp scan_lines.py "$PACK_DIR/" 2>/dev/null || true

# 项目文件
cp README.md "$PACK_DIR/" 2>/dev/null || true
cp DEPLOY.md "$PACK_DIR/" 2>/dev/null || true
cp requirements.txt "$PACK_DIR/" 2>/dev/null || true
cp run_all.sh "$PACK_DIR/" 2>/dev/null || true
cp LICENSE "$PACK_DIR/" 2>/dev/null || true

echo "=== 2. 提取关键实验结果（只保留metrics.json） ==="

# v4.5 300K 无拜占庭
mkdir -p "$PACK_DIR/results/v45_full_300k"
for algo in pbft_cg_mappo mappo; do
    for seed in 1 2 3; do
        src="results/v45_full_300k/$algo/seed_$seed/metrics.json"
        if [ -f "$src" ]; then
            mkdir -p "$PACK_DIR/results/v45_full_300k/$algo/seed_$seed"
            cp "$src" "$PACK_DIR/results/v45_full_300k/$algo/seed_$seed/"
            echo "  ✓ v45_full_300k/$algo/seed_$seed/metrics.json"
        fi
    done
done

# KL 消融 300K
mkdir -p "$PACK_DIR/results/kl_ablation_full"
for kl in 0.01 0.1 0.5; do
    for seed in 1 2 3; do
        src="results/kl_ablation_full/kl_${kl}/pbft_cg_mappo/seed_${seed}/metrics.json"
        if [ -f "$src" ]; then
            mkdir -p "$PACK_DIR/results/kl_ablation_full/kl_${kl}/pbft_cg_mappo/seed_${seed}"
            cp "$src" "$PACK_DIR/results/kl_ablation_full/kl_${kl}/pbft_cg_mappo/seed_${seed}/"
            echo "  ✓ kl_ablation_full/kl_${kl}/seed_${seed}/metrics.json"
        fi
    done
done

# KL 消融 50K
mkdir -p "$PACK_DIR/results/kl_ablation"
for kl in 0.0 0.01 0.1 0.5 1.0; do
    src="results/kl_ablation/kl_${kl}/pbft_cg_mappo/seed_1/metrics.json"
    if [ -f "$src" ]; then
        mkdir -p "$PACK_DIR/results/kl_ablation/kl_${kl}/pbft_cg_mappo/seed_1"
        cp "$src" "$PACK_DIR/results/kl_ablation/kl_${kl}/pbft_cg_mappo/seed_1/"
        echo "  ✓ kl_ablation/kl_${kl}/seed_1/metrics.json"
    fi
done

# v4.5 快速验证
for tag in v4_check v4_quick2 v42_check v42_quick; do
    for algo in pbft_cg_mappo mappo; do
        src="results/$tag/$algo/seed_1/metrics.json"
        if [ -f "$src" ]; then
            mkdir -p "$PACK_DIR/results/$tag/$algo/seed_1"
            cp "$src" "$PACK_DIR/results/$tag/$algo/seed_1/"
            echo "  ✓ $tag/$algo/seed_1/metrics.json"
        fi
    done
done

echo "=== 3. 生成实验结果摘要 ==="
/root/miniconda3/bin/python3 -c "
import json, numpy as np

lines = []
lines.append('# PBFT-CG-MARL 实验结果摘要')
lines.append('# 生成时间: 2026-08-20')
lines.append('')

# v4.5 300K
lines.append('## v4.5 软共识 300K (无拜占庭)')
lines.append('algo | seed | reward | entropy | consensus_rate')
lines.append('---|---|---|---|---')
for algo in ['pbft_cg_mappo', 'mappo']:
    for seed in [1,2,3]:
        p = f'results/v45_full_300k/{algo}/seed_{seed}/metrics.json'
        try:
            m = json.load(open(p))
            rew = np.array(m.get('episode/episode_reward',[])[-50:])
            ent = m.get('train/entropy',[])
            cr = m.get('train/consensus_rate',[])
            lines.append(f'{algo} | {seed} | {rew.mean():.1f}±{rew.std():.1f} | {ent[-1]:.4f} | {cr[-1] if cr else 0:.4f}')
        except: pass

lines.append('')
lines.append('## KL权重消融 300K (3 seeds)')
lines.append('kl_coef | seed | reward | entropy | consensus_rate | kl_loss')
lines.append('---|---|---|---|---|---')
for kl in [0.01, 0.1, 0.5]:
    for seed in [1,2,3]:
        p = f'results/kl_ablation_full/kl_{kl}/pbft_cg_mappo/seed_{seed}/metrics.json'
        try:
            m = json.load(open(p))
            rew = np.array(m.get('episode/episode_reward',[])[-50:])
            ent = m.get('train/entropy',[])
            cr = m.get('train/consensus_rate',[])
            kl_loss = m.get('train/kl_consensus_loss',[])
            lines.append(f'{kl} | {seed} | {rew.mean():.1f}±{rew.std():.1f} | {ent[-1]:.4f} | {cr[-1]:.4f} | {kl_loss[-1]:.4f}')
        except: pass

lines.append('')
lines.append('## KL权重消融 50K (1 seed, 趋势对比)')
lines.append('kl_coef | reward | entropy | consensus_rate')
lines.append('---|---|---|---')
for kl in [0.0, 0.01, 0.1, 0.5, 1.0]:
    p = f'results/kl_ablation/kl_{kl}/pbft_cg_mappo/seed_1/metrics.json'
    try:
        m = json.load(open(p))
        rew = np.array(m.get('episode/episode_reward',[])[-50:])
        ent = m.get('train/entropy',[])
        cr = m.get('train/consensus_rate',[])
        lines.append(f'{kl} | {rew.mean():.1f} | {ent[-1]:.4f} | {cr[-1]:.4f}')
    except: pass

with open('EXPERIMENT_RESULTS.md', 'w') as f:
    f.write('\n'.join(lines))
print('  ✓ EXPERIMENT_RESULTS.md')
" 2>/dev/null

cp EXPERIMENT_RESULTS.md "$PACK_DIR/"

echo "=== 4. 清理备份文件和临时文件 ==="
# 删除备份文件
find "$PACK_DIR" -name "*.bak" -delete 2>/dev/null
find "$PACK_DIR" -name "*.bak2" -delete 2>/dev/null
# 删除大文件（model_final.pt 等）
find "$PACK_DIR/results" -name "*.pt" -delete 2>/dev/null
find "$PACK_DIR/results" -name "training.log" -delete 2>/dev/null

echo "=== 5. 打包 ==="
cd /root/autodl-tmp
rm -f PBFT-CG-MARL-release.tar.gz
tar -czf PBFT-CG-MARL-release.tar.gz -C /root/autodl-tmp PBFT-CG-MARL-release/

echo ""
echo "============================================"
echo "✅ 打包完成！"
echo ""
# 显示大小
SIZE=$(du -sh /root/autodl-tmp/PBFT-CG-MARL-release.tar.gz | cut -f1)
echo "文件: /root/autodl-tmp/PBFT-CG-MARL-release.tar.gz"
echo "大小: $SIZE"
echo ""
echo "内容预览："
tar -tzf /root/autodl-tmp/PBFT-CG-MARL-release.tar.gz | head -30
echo "..."
echo "总文件数: $(tar -tzf /root/autodl-tmp/PBFT-CG-MARL-release.tar.gz | wc -l)"
echo "============================================"
