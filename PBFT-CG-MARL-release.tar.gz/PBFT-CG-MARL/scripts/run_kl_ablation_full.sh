#!/bin/bash
# ============================================================
# KL 权重消融 - 全量实验（3 seeds × 300K）
# 预计耗时：约 6 小时
# ============================================================

set -e
GPU=${1:-0}
BASE_LOG="results/kl_ablation_full"
SEEDS="1 2 3"
N=300000
EVAL_INT=10000
EVAL_EP=10

echo "============================================"
echo "KL 权重消融全量实验"
echo "KL values: 0.01, 0.1, 0.5"
echo "Seeds: $SEEDS"
echo "Steps: $N"
echo "GPU: $GPU"
echo "预计耗时: 约6小时"
echo "============================================"

for KL in 0.01 0.1 0.5; do
    for SEED in $SEEDS; do
        LOG_DIR="${BASE_LOG}/kl_${KL}"
        echo ""
        echo "=== kl=${KL} seed=${SEED} ==="
        
        # 生成配置文件
        CONFIG_FILE="configs/algo/pbft_kl_${KL}.yaml"
        sed "s/kl_consensus_coef: .*/kl_consensus_coef: ${KL}/" \
            configs/algo/pbft_cg_mappo_v42.yaml > "$CONFIG_FILE"
        
        /root/miniconda3/bin/python3 -u src/train.py \
            --algo pbft_cg_mappo \
            --env mpe_spread \
            --env_config configs/env/mpe_spread.yaml \
            --algo_config "$CONFIG_FILE" \
            --seed $SEED \
            --n_timesteps $N \
            --eval_interval $EVAL_INT \
            --eval_episodes $EVAL_EP \
            --log_dir "$LOG_DIR" \
            --gpu $GPU
        
        echo "  kl=${KL} seed=${SEED} 完成"
    done
done

echo ""
echo "============================================"
echo "全量KL消融完成！"
echo ""
echo "提取指标："
echo 'cd /root/autodl-tmp/PBFT-CG-MARL'
echo '/root/miniconda3/bin/python3 -c "
import json, numpy as np
print(\"kl_coef | seed | reward_mean | reward_std | entropy | consensus_rate | kl_loss\")
print(\"-\" * 80)
for kl in [0.01, 0.1, 0.5]:
    for seed in [1,2,3]:
        p = f\"results/kl_ablation_full/kl_{kl}/pbft_cg_mappo/seed_{seed}/metrics.json\"
        try:
            m = json.load(open(p))
            rew = np.array(m.get(\"episode/episode_reward\",[])[-50:])
            ent = m.get(\"train/entropy\",[])
            cr = m.get(\"train/consensus_rate\",[])
            kl_loss = m.get(\"train/kl_consensus_loss\",[])
            print(f\"{kl:6.2f} | {seed} | {rew.mean():11.1f} | {rew.std():10.1f} | {ent[-1]:7.4f} | {cr[-1]:14.4f} | {kl_loss[-1]:7.4f}\")
        except Exception as e:
            print(f\"{kl:6.2f} | {seed} | FAILED ({e})\")
    # 汇总
    rewards = []
    entropies = []
    for seed in [1,2,3]:
        p = f\"results/kl_ablation_full/kl_{kl}/pbft_cg_mappo/seed_{seed}/metrics.json\"
        try:
            m = json.load(open(p))
            rew = np.array(m.get(\"episode/episode_reward\",[])[-50:])
            ent = m.get(\"train/entropy\",[])
            rewards.append(rew.mean())
            entropies.append(ent[-1])
        except: pass
    if rewards:
        print(f\"{kl:6.2f} | AVG | {np.mean(rewards):11.1f} | {np.std(rewards):10.1f} | {np.mean(entropies):7.4f} |\")

# MAPPO对照
print()
print(\"MAPPO baseline (v4.5 300K):\")
for seed in [1,2,3]:
    p = f\"results/v45_full_300k/mappo/seed_{seed}/metrics.json\"
    try:
        m = json.load(open(p))
        rew = np.array(m.get(\"episode/episode_reward\",[])[-50:])
        ent = m.get(\"train/entropy\",[])
        print(f\"  seed{seed}: reward={rew.mean():.1f}±{rew.std():.1f}, entropy={ent[-1]:.4f}\")
    except: pass
"'
echo "============================================"
