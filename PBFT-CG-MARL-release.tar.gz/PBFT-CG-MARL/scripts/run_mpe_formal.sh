#!/bin/bash
set -e
PYTHON="/root/miniconda3/bin/python"
BASE="/root/autodl-tmp/PBFT-CG-MARL"
LOG="/root/autodl-tmp/PBFT-CG-MARL/results/v3_formal"
echo "=== v3 Formal MPE === $(date)"
mkdir -p $LOG

$PYTHON -u $BASE/src/train.py --algo pbft_cg_mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/pbft_cg_mappo_v3.yaml --seed 1 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_pbft_forge_seed1 --byzantine_n 1 --byzantine_type message_forge --gpu 0
$PYTHON -u $BASE/src/train.py --algo pbft_cg_mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/pbft_cg_mappo_v3.yaml --seed 2 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_pbft_forge_seed2 --byzantine_n 1 --byzantine_type message_forge --gpu 0
$PYTHON -u $BASE/src/train.py --algo pbft_cg_mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/pbft_cg_mappo_v3.yaml --seed 3 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_pbft_forge_seed3 --byzantine_n 1 --byzantine_type message_forge --gpu 0
$PYTHON -u $BASE/src/train.py --algo pbft_cg_mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/pbft_cg_mappo_v3.yaml --seed 4 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_pbft_forge_seed4 --byzantine_n 1 --byzantine_type message_forge --gpu 0
$PYTHON -u $BASE/src/train.py --algo pbft_cg_mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/pbft_cg_mappo_v3.yaml --seed 5 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_pbft_forge_seed5 --byzantine_n 1 --byzantine_type message_forge --gpu 0

echo "=== Phase 1 PBFT+forge done === $(date)"

$PYTHON -u $BASE/src/train.py --algo mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/mappo_v3.yaml --seed 1 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_mappo_forge_seed1 --byzantine_n 1 --byzantine_type message_forge --gpu 0
$PYTHON -u $BASE/src/train.py --algo mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/mappo_v3.yaml --seed 2 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_mappo_forge_seed2 --byzantine_n 1 --byzantine_type message_forge --gpu 0
$PYTHON -u $BASE/src/train.py --algo mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/mappo_v3.yaml --seed 3 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_mappo_forge_seed3 --byzantine_n 1 --byzantine_type message_forge --gpu 0
$PYTHON -u $BASE/src/train.py --algo mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/mappo_v3.yaml --seed 4 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_mappo_forge_seed4 --byzantine_n 1 --byzantine_type message_forge --gpu 0
$PYTHON -u $BASE/src/train.py --algo mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/mappo_v3.yaml --seed 5 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_mappo_forge_seed5 --byzantine_n 1 --byzantine_type message_forge --gpu 0

echo "=== Phase 2 MAPPO+forge done === $(date)"

$PYTHON -u $BASE/src/train.py --algo pbft_cg_mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/pbft_cg_mappo_v3.yaml --seed 1 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_pbft_clean_seed1 --gpu 0
$PYTHON -u $BASE/src/train.py --algo pbft_cg_mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/pbft_cg_mappo_v3.yaml --seed 2 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_pbft_clean_seed2 --gpu 0
$PYTHON -u $BASE/src/train.py --algo pbft_cg_mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/pbft_cg_mappo_v3.yaml --seed 3 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_pbft_clean_seed3 --gpu 0
$PYTHON -u $BASE/src/train.py --algo pbft_cg_mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/pbft_cg_mappo_v3.yaml --seed 4 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_pbft_clean_seed4 --gpu 0
$PYTHON -u $BASE/src/train.py --algo pbft_cg_mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/pbft_cg_mappo_v3.yaml --seed 5 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_pbft_clean_seed5 --gpu 0

echo "=== Phase 3 PBFT+clean done === $(date)"

$PYTHON -u $BASE/src/train.py --algo mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/mappo_v3.yaml --seed 1 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_mappo_clean_seed1 --gpu 0
$PYTHON -u $BASE/src/train.py --algo mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/mappo_v3.yaml --seed 2 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_mappo_clean_seed2 --gpu 0
$PYTHON -u $BASE/src/train.py --algo mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/mappo_v3.yaml --seed 3 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_mappo_clean_seed3 --gpu 0
$PYTHON -u $BASE/src/train.py --algo mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/mappo_v3.yaml --seed 4 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_mappo_clean_seed4 --gpu 0
$PYTHON -u $BASE/src/train.py --algo mappo --env mpe_spread --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $BASE/configs/algo/mappo_v3.yaml --seed 5 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/mpe_mappo_clean_seed5 --gpu 0

echo "=== ALL MPE DONE === $(date)"