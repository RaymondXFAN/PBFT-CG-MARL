#!/usr/bin/env python3
"""v5: Separate Optimizer Patch for PBFT-CG-MAPPO and MAPPO"""

import sys

BASE = "/root/autodl-tmp/PBFT-CG-MARL"

# === PBFT ===
with open(f"{BASE}/src/algorithms/pbft_cg_mappo.py", "r") as f:
    code = f.read()

# 1. Replace optimizer init
old1 = """        # 优化器
        self.optimizer = torch.optim.Adam(
            self.parameters(), lr=self.lr, eps=1e-5
        )"""

new1 = """        # v5: Separate optimizers - actor and critic
        actor_params = list(self.actor.parameters()) if self.share_param else list(self.actors.parameters())
        critic_params = list(self.critic.parameters())
        self.actor_optimizer = torch.optim.Adam(actor_params, lr=self.lr, eps=1e-5)
        self.critic_optimizer = torch.optim.Adam(critic_params, lr=self.lr, eps=1e-5)
        self.optimizer = self.actor_optimizer  # compat for lr_scheduler"""

assert old1 in code, "PBFT optimizer init not found!"
code = code.replace(old1, new1)
print("1. PBFT optimizer init patched")

# 2. Replace combined loss + gradient update
old2 = """            loss = (
                policy_loss
                + self.value_loss_coef * value_loss
                - self.entropy_coef * mean_entropy
                + consensus_loss
                + entropy_floor_penalty
                + self.kl_consensus_coef * kl_consensus_loss
            )
            # 梯度更新
            self.optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(self.parameters(), self.max_grad_norm)
            self.optimizer.step()"""

new2 = """            # v5: Separate actor/critic updates
            actor_loss = (
                policy_loss
                - self.entropy_coef * mean_entropy
                + consensus_loss
                + entropy_floor_penalty
                + self.kl_consensus_coef * kl_consensus_loss
            )
            critic_loss = self.value_loss_coef * value_loss
            # Actor gradient update
            self.actor_optimizer.zero_grad()
            actor_loss.backward(retain_graph=True)
            if self.share_param:
                nn.utils.clip_grad_norm_(self.actor.parameters(), self.max_grad_norm)
            else:
                nn.utils.clip_grad_norm_(self.actors.parameters(), self.max_grad_norm)
            self.actor_optimizer.step()
            # Critic gradient update
            self.critic_optimizer.zero_grad()
            critic_loss.backward()
            nn.utils.clip_grad_norm_(self.critic.parameters(), self.max_grad_norm)
            self.critic_optimizer.step()"""

assert old2 in code, "PBFT loss block not found!"
code = code.replace(old2, new2)
print("2. PBFT loss block patched")

# 3. Replace save
old3 = '"optimizer_state_dict": self.optimizer.state_dict(),'
new3 = '"actor_optimizer_state_dict": self.actor_optimizer.state_dict(),\n            "critic_optimizer_state_dict": self.critic_optimizer.state_dict(),\n            "optimizer_state_dict": self.actor_optimizer.state_dict(),  # compat'
assert old3 in code, "PBFT save not found!"
code = code.replace(old3, new3)
print("3. PBFT save patched")

# 4. Replace load
old4 = 'self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])'
new4 = '# v5: Load separate optimizers\n        if "actor_optimizer_state_dict" in checkpoint:\n            self.actor_optimizer.load_state_dict(checkpoint["actor_optimizer_state_dict"])\n            self.critic_optimizer.load_state_dict(checkpoint["critic_optimizer_state_dict"])\n        else:\n            self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])'
assert old4 in code, "PBFT load not found!"
code = code.replace(old4, new4)
print("4. PBFT load patched")

with open(f"{BASE}/src/algorithms/pbft_cg_mappo.py", "w") as f:
    f.write(code)
print("PBFT DONE!")

# === MAPPO ===
with open(f"{BASE}/src/algorithms/mappo.py", "r") as f:
    code = f.read()

# 1. Replace optimizer init
old1m = """        # 优化器
        self.optimizer = torch.optim.Adam(
            self.parameters(), lr=self.lr, eps=1e-5
        )"""

new1m = """        # v5: Separate optimizers
        actor_params = list(self.actor.parameters()) if self.share_param else list(self.actors.parameters())
        critic_params = list(self.critic.parameters())
        self.actor_optimizer = torch.optim.Adam(actor_params, lr=self.lr, eps=1e-5)
        self.critic_optimizer = torch.optim.Adam(critic_params, lr=self.lr, eps=1e-5)
        self.optimizer = self.actor_optimizer  # compat"""

if old1m not in code:
    # Try alternative without comment
    old1m = """        self.optimizer = torch.optim.Adam(
            self.parameters(), lr=self.lr, eps=1e-5
        )"""
    new1m = """        # v5: Separate optimizers
        actor_params = list(self.actor.parameters()) if self.share_param else list(self.actors.parameters())
        critic_params = list(self.critic.parameters())
        self.actor_optimizer = torch.optim.Adam(actor_params, lr=self.lr, eps=1e-5)
        self.critic_optimizer = torch.optim.Adam(critic_params, lr=self.lr, eps=1e-5)
        self.optimizer = self.actor_optimizer  # compat"""

assert old1m in code, "MAPPO optimizer init not found!"
code = code.replace(old1m, new1m)
print("5. MAPPO optimizer init patched")

# 2. Replace loss block
old2m = """            loss = (
                policy_loss
                + self.value_loss_coef * value_loss
                - self.entropy_coef * mean_entropy
            )

            self.optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(self.parameters(), self.max_grad_norm)
            self.optimizer.step()"""

new2m = """            # v5: Separate actor/critic updates
            actor_loss = policy_loss - self.entropy_coef * mean_entropy
            critic_loss = self.value_loss_coef * value_loss
            # Actor gradient update
            self.actor_optimizer.zero_grad()
            actor_loss.backward(retain_graph=True)
            if self.share_param:
                nn.utils.clip_grad_norm_(self.actor.parameters(), self.max_grad_norm)
            else:
                nn.utils.clip_grad_norm_(self.actors.parameters(), self.max_grad_norm)
            self.actor_optimizer.step()
            # Critic gradient update
            self.critic_optimizer.zero_grad()
            critic_loss.backward()
            nn.utils.clip_grad_norm_(self.critic.parameters(), self.max_grad_norm)
            self.critic_optimizer.step()"""

assert old2m in code, "MAPPO loss block not found!"
code = code.replace(old2m, new2m)
print("6. MAPPO loss block patched")

# 3. Save
if '"optimizer_state_dict": self.optimizer.state_dict(),' in code:
    code = code.replace(
        '"optimizer_state_dict": self.optimizer.state_dict(),',
        '"actor_optimizer_state_dict": self.actor_optimizer.state_dict(),\n            "critic_optimizer_state_dict": self.critic_optimizer.state_dict(),\n            "optimizer_state_dict": self.actor_optimizer.state_dict(),  # compat'
    )
    print("7. MAPPO save patched")

# 4. Load
if 'self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])' in code:
    code = code.replace(
        'self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])',
        'if "actor_optimizer_state_dict" in checkpoint:\n            self.actor_optimizer.load_state_dict(checkpoint["actor_optimizer_state_dict"])\n            self.critic_optimizer.load_state_dict(checkpoint["critic_optimizer_state_dict"])\n        else:\n            self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])'
    )
    print("8. MAPPO load patched")

with open(f"{BASE}/src/algorithms/mappo.py", "w") as f:
    f.write(code)
print("MAPPO DONE!")
print("ALL PATCHES APPLIED!")
