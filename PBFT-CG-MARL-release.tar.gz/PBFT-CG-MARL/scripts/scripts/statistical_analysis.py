#!/usr/bin/env python3
"""
PBFT-CG-MARL 补充实验 — 统计分析脚本
功能：
1. 从 results/ 目录读取所有 metrics.json
2. 对每个 (环境, 算法) 组合计算 mean ± std
3. 做 Welch's t-test (Additive vs Baseline, Additive vs Multiplicative Matched)
4. 做 Wilcoxon rank-sum test
5. 输出 LaTeX 格式的表格
6. 生成 comparison 图
"""
import os
import json
import glob
import numpy as np
from collections import defaultdict
from typing import Dict, List, Tuple, Optional

try:
    from scipy.stats import ttest_ind, ranksums
except ImportError:
    print("请安装 scipy: pip install scipy")
    raise

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
except ImportError:
    print("请安装 matplotlib: pip install matplotlib")
    raise


# ── 1. 读取 metrics ──────────────────────────────────────────────
def load_metrics(results_dir: str) -> Dict[Tuple[str, str], List[float]]:
    """
    从 results/ 下扫描所有 metrics.json，提取最终评估回报
    返回: {(env_name, algo_name): [seed1_return, seed2_return, ...]}
    """
    data = defaultdict(list)
    # 递归搜索
    for root, dirs, files in os.walk(results_dir):
        if "metrics.json" in files:
            filepath = os.path.join(root, "metrics.json")
            try:
                with open(filepath, 'r') as f:
                    metrics = json.load(f)
            except (json.JSONDecodeError, IOError) as e:
                print(f"  [WARN] 无法读取 {filepath}: {e}")
                continue

            # 从路径提取环境和算法信息
            # 路径格式示例: results/phase1_cross_env/mpe_spread_pbft_additive_seed1/...
            parts = root.replace(results_dir, "").strip("/").split(os.sep)
            run_name = parts[0] if parts else "unknown"

            # 解析 run_name: env_algo_seedN
            env_name = "unknown"
            algo_name = "unknown"
            for part in run_name.split("_"):
                # 尝试从 run_name 中提取
                pass
            # 更可靠的解析
            tokens = run_name.rsplit("_seed", 1)
            if len(tokens) == 2:
                name_part = tokens[0]
                # 拆分 env 和 algo
                # 已知环境前缀
                known_envs = ["mpe_spread", "smaclite_5m_vs_6m", "vmas_uav_coverage", "vmas_formation"]
                for env in known_envs:
                    if name_part.startswith(env):
                        env_name = env
                        algo_name = name_part[len(env)+1:]  # 去掉 env_ 前缀
                        break

            # 提取最终回报
            final_return = None
            if isinstance(metrics, dict):
                # 优先取 final_eval_return 或最后一个 eval_return
                if "final_eval_return" in metrics:
                    final_return = metrics["final_eval_return"]
                elif "eval_return" in metrics:
                    val = metrics["eval_return"]
                    if isinstance(val, list) and len(val) > 0:
                        final_return = val[-1]
                    else:
                        final_return = float(val)
                elif "mean_eval_return" in metrics:
                    final_return = metrics["mean_eval_return"]
            elif isinstance(metrics, list) and len(metrics) > 0:
                final_return = metrics[-1]

            if final_return is not None:
                data[(env_name, algo_name)].append(float(final_return))

    return dict(data)


# ── 2. 统计检验 ──────────────────────────────────────────────────
def statistical_tests(data: Dict[Tuple[str, str], List[float]],
                      baseline_algo: str = "mappo",
                      our_algo: str = "pbft_additive",
                      alt_algo: str = "pbft_mult_matched") -> Dict:
    """
    对每个环境做:
    - Welch's t-test: Ours vs Baseline, Ours vs Mult-Matched
    - Wilcoxon rank-sum test: 同上
    返回结果字典
    """
    results = {}
    envs = set(env for env, algo in data.keys())

    for env in sorted(envs):
        ours = data.get((env, our_algo), [])
        baseline = data.get((env, baseline_algo), [])
        alt = data.get((env, alt_algo), [])

        env_result = {}

        if len(ours) >= 2 and len(baseline) >= 2:
            t_stat, p_val = ttest_ind(ours, baseline, equal_var=False)
            r_stat, r_p = ranksums(ours, baseline)
            env_result["vs_baseline"] = {
                "t_stat": t_stat, "p_value": p_val,
                "ranksum_stat": r_stat, "ranksum_p": r_p,
                "ours_mean": np.mean(ours), "ours_std": np.std(ours),
                "baseline_mean": np.mean(baseline), "baseline_std": np.std(baseline),
            }

        if len(ours) >= 2 and len(alt) >= 2:
            t_stat, p_val = ttest_ind(ours, alt, equal_var=False)
            r_stat, r_p = ranksums(ours, alt)
            env_result["vs_mult_matched"] = {
                "t_stat": t_stat, "p_value": p_val,
                "ranksum_stat": r_stat, "ranksum_p": r_p,
                "ours_mean": np.mean(ours), "ours_std": np.std(ours),
                "alt_mean": np.mean(alt), "alt_std": np.std(alt),
            }

        results[env] = env_result

    return results


# ── 3. LaTeX 表格 ────────────────────────────────────────────────
def generate_latex_table(data: Dict[Tuple[str, str], List[float]],
                         stat_results: Dict) -> str:
    """生成 LaTeX 格式的结果表格"""
    algos = sorted(set(algo for _, algo in data.keys()))
    envs = sorted(set(env for env, _ in data.keys()))

    lines = []
    lines.append(r"\begin{table}[htbp]")
    lines.append(r"\centering")
    lines.append(r"\caption{Cross-environment comparison of PBFT-CG-MARL variants}")
    lines.append(r"\label{tab:main_results}")
    lines.append(r"\begin{tabular}{l" + "c" * len(algos) + "}")
    lines.append(r"\toprule")

    # 表头
    header = "Environment"
    for algo in algos:
        # 美化算法名
        pretty = algo.replace("pbft_", "PBFT-").replace("mappo", "MAPPO")
        header += f" & {pretty}"
    header += r" \\"
    lines.append(header)
    lines.append(r"\midrule")

    # 数据行
    for env in envs:
        row = env.replace("_", "\\_")
        for algo in algos:
            vals = data.get((env, algo), [])
            if len(vals) > 0:
                mean = np.mean(vals)
                std = np.std(vals)
                # 找该环境下的最优（最高mean）
                env_means = {a: np.mean(data.get((env, a), [0])) for a in algos}
                best_algo = max(env_means, key=env_means.get)
                if algo == best_algo:
                    row += f" & $\\mathbf{{{mean:.2f}}} \\pm {std:.2f}$"
                else:
                    row += f" & ${mean:.2f} \\pm {std:.2f}$"
            else:
                row += " & --"
        row += r" \\"
        lines.append(row)

    lines.append(r"\bottomrule")
    lines.append(r"\end{tabular}")

    # p-value 注释
    lines.append(r"\vspace{2mm}")
    for env in envs:
        if env in stat_results:
            sr = stat_results[env]
            if "vs_baseline" in sr:
                p = sr["vs_baseline"]["p_value"]
                lines.append(f"% {env}: Additive vs MAPPO p={p:.4f}")
            if "vs_mult_matched" in sr:
                p = sr["vs_mult_matched"]["p_value"]
                lines.append(f"% {env}: Additive vs Mult-Matched p={p:.4f}")

    lines.append(r"\end{table}")
    return "\n".join(lines)


# ── 4. 绘图 ──────────────────────────────────────────────────────
def plot_comparison(data: Dict[Tuple[str, str], List[float]],
                    output_dir: str = "results/figures"):
    """生成对比柱状图"""
    os.makedirs(output_dir, exist_ok=True)

    algos = sorted(set(algo for _, algo in data.keys()))
    envs = sorted(set(env for env, _ in data.keys()))

    if len(envs) == 0 or len(algos) == 0:
        print("[WARN] 无数据可绘图")
        return

    # 颜色映射
    color_map = {
        "pbft_additive": "#2196F3",
        "pbft_mult_matched": "#FF9800",
        "pbft_mult_mismatched": "#F44336",
        "mappo": "#9E9E9E",
    }

    n_envs = len(envs)
    n_algos = len(algos)
    x = np.arange(n_envs)
    width = 0.8 / n_algos

    fig, ax = plt.subplots(figsize=(max(8, n_envs * 2.5), 5))

    for i, algo in enumerate(algos):
        means = []
        stds = []
        for env in envs:
            vals = data.get((env, algo), [])
            means.append(np.mean(vals) if vals else 0)
            stds.append(np.std(vals) if vals else 0)

        offset = (i - n_algos / 2 + 0.5) * width
        color = color_map.get(algo, None)
        pretty = algo.replace("pbft_", "PBFT-").replace("mappo", "MAPPO")
        ax.bar(x + offset, means, width, yerr=stds,
               label=pretty, color=color, alpha=0.85,
               capsize=3, edgecolor='black', linewidth=0.5)

    ax.set_xlabel("Environment")
    ax.set_ylabel("Eval Return")
    ax.set_title("PBFT-CG-MARL Cross-Environment Comparison")
    ax.set_xticks(x)
    ax.set_xticklabels([e.replace("_", "\n") for e in envs])
    ax.legend(loc='best')
    ax.grid(axis='y', alpha=0.3)

    plt.tight_layout()
    fig_path = os.path.join(output_dir, "cross_env_comparison.png")
    plt.savefig(fig_path, dpi=150)
    plt.close()
    print(f"图已保存: {fig_path}")

    # ── α 敏感性折线图 ──
    alpha_data = {}
    for (env, algo), vals in data.items():
        if algo.startswith("alpha_"):
            alpha_data[algo] = (np.mean(vals), np.std(vals))

    if alpha_data:
        fig2, ax2 = plt.subplots(figsize=(6, 4))
        alphas = sorted(alpha_data.keys())
        alpha_vals = [0.01, 0.05, 0.1, 0.5, 1.0]
        means = [alpha_data[a][0] for a in alphas]
        stds_list = [alpha_data[a][1] for a in alphas]

        ax2.errorbar(alpha_vals[:len(means)], means, yerr=stds_list,
                     marker='o', capsize=4, linewidth=2, color='#2196F3')
        ax2.set_xscale('log')
        ax2.set_xlabel(r"KL coefficient $\alpha$")
        ax2.set_ylabel("Eval Return")
        ax2.set_title(r"Sensitivity to $\alpha$ (KL coefficient)")
        ax2.grid(alpha=0.3)
        plt.tight_layout()
        fig2_path = os.path.join(output_dir, "alpha_sensitivity.png")
        plt.savefig(fig2_path, dpi=150)
        plt.close()
        print(f"图已保存: {fig2_path}")


# ── 5. 主流程 ────────────────────────────────────────────────────
def main():
    import argparse
    parser = argparse.ArgumentParser(description="PBFT-CG-MARL 统计分析")
    parser.add_argument("--results_dir", type=str, default="results",
                        help="实验结果根目录")
    parser.add_argument("--output_dir", type=str, default="results/figures",
                        help="图片输出目录")
    parser.add_argument("--baseline_algo", type=str, default="mappo",
                        help="基线算法名称")
    parser.add_argument("--our_algo", type=str, default="pbft_additive",
                        help="我们的算法名称")
    parser.add_argument("--alt_algo", type=str, default="pbft_mult_matched",
                        help="对照算法名称")
    args = parser.parse_args()

    print("=" * 60)
    print("PBFT-CG-MARL 统计分析")
    print("=" * 60)

    # 1. 读取数据
    print(f"\n[1/4] 读取 metrics.json from {args.results_dir} ...")
    data = load_metrics(args.results_dir)
    print(f"  找到 {len(data)} 个 (env, algo) 组合:")
    for (env, algo), vals in sorted(data.items()):
        print(f"    {env}/{algo}: {len(vals)} seeds, mean={np.mean(vals):.2f}")

    if not data:
        print("[ERROR] 未找到任何 metrics.json，请检查 results_dir 路径")
        return

    # 2. 统计检验
    print(f"\n[2/4] 统计检验 ...")
    stat_results = statistical_tests(data, args.baseline_algo, args.our_algo, args.alt_algo)
    for env, sr in sorted(stat_results.items()):
        print(f"\n  环境: {env}")
        if "vs_baseline" in sr:
            r = sr["vs_baseline"]
            sig = "***" if r["p_value"] < 0.001 else "**" if r["p_value"] < 0.01 else "*" if r["p_value"] < 0.05 else "n.s."
            print(f"    vs {args.baseline_algo}: t={r['t_stat']:.3f}, p={r['p_value']:.4f} {sig}")
        if "vs_mult_matched" in sr:
            r = sr["vs_mult_matched"]
            sig = "***" if r["p_value"] < 0.001 else "**" if r["p_value"] < 0.01 else "*" if r["p_value"] < 0.05 else "n.s."
            print(f"    vs {args.alt_algo}: t={r['t_stat']:.3f}, p={r['p_value']:.4f} {sig}")

    # 3. LaTeX 表格
    print(f"\n[3/4] 生成 LaTeX 表格 ...")
    latex = generate_latex_table(data, stat_results)
    latex_path = os.path.join(args.output_dir, "main_results_table.tex")
    os.makedirs(args.output_dir, exist_ok=True)
    with open(latex_path, 'w') as f:
        f.write(latex)
    print(f"  LaTeX 表格已保存: {latex_path}")
    print("\n" + latex)

    # 4. 绘图
    print(f"\n[4/4] 生成对比图 ...")
    plot_comparison(data, args.output_dir)

    print("\n" + "=" * 60)
    print("分析完成！")
    print("=" * 60)


if __name__ == "__main__":
    main()
