#!/bin/bash
# Phase 0: 环境预检 - 5分钟验证3个环境都能跑通
# 用途：快速验证 MPE / SMAClite / VMAS 三个环境均可正常训练
# GPU要求：1卡
# 预计耗时：5分钟
# 监控命令：tail -f results/phase0_sanity/train.log
set -e
GPU=${1:-0}
LOG=results/phase0_sanity

echo "=== Phase 0: 环境预检 ==="
echo "GPU: $GPU, 预计5分钟"

# MPE
echo "[1/3] MPE simple_spread ..."
python -u src/train.py --algo pbft_cg_mappo --env mpe_spread \
    --env_config configs/env/mpe_spread.yaml \
    --algo_config configs/algo/pbft_additive_v5.yaml \
    --seed 1 --n_timesteps 5000 --eval_interval 5000 --eval_episodes 3 \
    --log_dir $LOG --gpu $GPU 2>&1 | tail -3

# SMAClite
echo "[2/3] SMAClite 5m_vs_6m ..."
python -u src/train.py --algo pbft_cg_mappo --env smaclite_5m_vs_6m \
    --env_config configs/env/smaclite_5m_vs_6m.yaml \
    --algo_config configs/algo/pbft_additive_v5.yaml \
    --seed 1 --n_timesteps 5000 --eval_interval 5000 --eval_episodes 3 \
    --log_dir $LOG --gpu $GPU 2>&1 | tail -3

# VMAS
echo "[3/3] VMAS uav_coverage ..."
python -u src/train.py --algo pbft_cg_mappo --env vmas_uav_coverage \
    --env_config configs/env/vmas_uav_coverage.yaml \
    --algo_config configs/algo/pbft_additive_v5.yaml \
    --seed 1 --n_timesteps 5000 --eval_interval 5000 --eval_episodes 3 \
    --log_dir $LOG --gpu $GPU 2>&1 | tail -3

echo ""
echo "=== 验证结果 ==="
for env_dir in $LOG/pbft_cg_mappo; do
    if [ -f "$env_dir/seed_1/metrics.json" ]; then
        echo "✅ $env_dir: metrics.json 存在"
    else
        echo "❌ $env_dir: metrics.json 缺失!"
    fi
done

echo "预检完成！如果全部 ✅，可以进入 Phase 1"
