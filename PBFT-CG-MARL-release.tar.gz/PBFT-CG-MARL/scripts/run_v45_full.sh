#!/bin/bash
set -e
GPU=${1:-0}
LOG=results/v45_full_300k
SEEDS="1 2 3"
N=300000
EVAL_INT=10000
EVAL_EP=10

for SEED in $SEEDS; do
  echo "=== pbft_v45_no_byz seed=$SEED ==="
  /root/miniconda3/bin/python3 -u src/train.py \
    --algo pbft_cg_mappo --env mpe_spread \
    --env_config configs/env/mpe_spread.yaml \
    --algo_config configs/algo/pbft_cg_mappo_v42.yaml \
    --seed $SEED --n_timesteps $N --eval_interval $EVAL_INT \
    --eval_episodes $EVAL_EP --log_dir $LOG --gpu $GPU
done

for SEED in $SEEDS; do
  echo "=== mappo_v45_no_byz seed=$SEED ==="
  /root/miniconda3/bin/python3 -u src/train.py \
    --algo mappo --env mpe_spread \
    --env_config configs/env/mpe_spread.yaml \
    --algo_config configs/algo/mappo_v42.yaml \
    --seed $SEED --n_timesteps $N --eval_interval $EVAL_INT \
    --eval_episodes $EVAL_EP --log_dir $LOG --gpu $GPU
done
echo "ALL DONE"
