#!/bin/bash
# ============================================================
# PBFT-CG-MARL v3 快速验证（预检任务）
# 只跑 1 env × 1 attack × 2 seeds × 50K 步
# 目标：验证消息级攻击补丁是否生效
# 预计耗时：约 15 分钟
# ============================================================

set -e
GPU_ID=${1:-0}
LOG_DIR="results/v3_quickcheck"

echo "============================================"
echo "PBFT-CG-MARL v3 快速验证"
echo "验证：消息级攻击是否真正经过PBFT过滤"
echo "============================================"

# 1. Clean baseline (MPE, seed1, 50K)
echo ""
echo "[1/5] MPE clean baseline..."
python -u src/train.py \
    --algo pbft_cg_mappo --env mpe_spread \
    --env_config configs/env/mpe_spread.yaml \
    --algo_config configs/algo/pbft_cg_mappo_v5.yaml \
    --seed 1 --n_timesteps 50000 \
    --eval_interval 5000 --eval_episodes 5 \
    --log_dir ${LOG_DIR}/mpe_pbft_clean_seed1 \
    --gpu ${GPU_ID}

# 2. message_forge 攻击 (MPE, seed1, 50K) - PBFT应该能防御！
echo ""
echo "[2/5] MPE message_forge (PBFT)..."
python -u src/train.py \
    --algo pbft_cg_mappo --env mpe_spread \
    --env_config configs/env/mpe_spread.yaml \
    --algo_config configs/algo/pbft_cg_mappo_v5.yaml \
    --seed 1 --n_timesteps 50000 \
    --eval_interval 5000 --eval_episodes 5 \
    --log_dir ${LOG_DIR}/mpe_pbft_forge_seed1 \
    --byzantine_n 1 --byzantine_type message_forge \
    --gpu ${GPU_ID}

# 3. message_forge 攻击 (MPE, MAPPO无保护, seed1, 50K) - 应该更差！
echo ""
echo "[3/5] MPE message_forge (MAPPO无保护)..."
python -u src/train.py \
    --algo mappo --env mpe_spread \
    --env_config configs/env/mpe_spread.yaml \
    --algo_config configs/algo/mappo_v5.yaml \
    --seed 1 --n_timesteps 50000 \
    --eval_interval 5000 --eval_episodes 5 \
    --log_dir ${LOG_DIR}/mpe_mappo_forge_seed1 \
    --byzantine_n 1 --byzantine_type message_forge \
    --gpu ${GPU_ID}

# 4. message_silent 攻击 (MPE, PBFT, seed1, 50K)
echo ""
echo "[4/5] MPE message_silent (PBFT)..."
python -u src/train.py \
    --algo pbft_cg_mappo --env mpe_spread \
    --env_config configs/env/mpe_spread.yaml \
    --algo_config configs/algo/pbft_cg_mappo_v5.yaml \
    --seed 1 --n_timesteps 50000 \
    --eval_interval 5000 --eval_episodes 5 \
    --log_dir ${LOG_DIR}/mpe_pbft_silent_seed1 \
    --byzantine_n 1 --byzantine_type message_silent \
    --gpu ${GPU_ID}

# 5. 旧版random攻击 (MPE, PBFT, seed1, 50K) - 对照
echo ""
echo "[5/5] MPE random (旧版动作级攻击，对照)..."
python -u src/train.py \
    --algo pbft_cg_mappo --env mpe_spread \
    --env_config configs/env/mpe_spread.yaml \
    --algo_config configs/algo/pbft_cg_mappo_v5.yaml \
    --seed 1 --n_timesteps 50000 \
    --eval_interval 5000 --eval_episodes 5 \
    --log_dir ${LOG_DIR}/mpe_pbft_random_seed1 \
    --byzantine_n 1 --byzantine_type random \
    --gpu ${GPU_ID}

echo ""
echo "============================================"
echo "快速验证完成！"
echo ""
echo "验证标准："
echo "  1. message_forge: PBFT reward > MAPPO reward（PBFT能防御！）"
echo "  2. message_forge: PBFT方差 < MAPPO方差"
echo "  3. message_silent: fallback机制正常工作"
echo "  4. clean: PBFT reward ≈ MAPPO reward（不添乱）"
echo "  5. random(旧版): PBFT reward ≈ 或 < MAPPO（攻击面错位）"
echo ""
echo "如果 1-4 都通过 → 补丁生效，可跑完整实验"
echo "如果 1 不通过 → 需要调试corrupt_proposals逻辑"
echo "============================================"
