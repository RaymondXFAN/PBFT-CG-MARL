#!/bin/bash
# Phase 2: Byzantine 鲁棒性实验
# 用途：在拜占庭故障下测试 Additive vs Mult-Matched 两种条件方式，2种故障模型 × 3环境 × 3seeds
# GPU要求：1卡
# 预计耗时：~4小时（2 algos × 3 envs × 2 fault_models × 3 seeds × ~7min/run）
# 监控命令：tail -f results/phase2_byzantine/progress.log
set -e
GPU=${1:-0}
N_TIMESTEPS=${2:-300000}
EVAL_INTERVAL=${3:-10000}
EVAL_EPISODES=10
SEEDS="1 2 3"
LOG_DIR=results/phase2_byzantine
PROGRESS_LOG=$LOG_DIR/progress.log

# 算法
declare -A ALGO_MAP=(
    ["pbft_additive"]="configs/algo/pbft_additive_v5.yaml"
    ["pbft_mult_matched"]="configs/algo/pbft_mult_matched_v5.yaml"
)

# 环境
declare -A ENV_MAP=(
    ["mpe_spread"]="configs/env/mpe_spread.yaml"
    ["smaclite_5m_vs_6m"]="configs/env/smaclite_5m_vs_6m.yaml"
    ["vmas_uav_coverage"]="configs/env/vmas_uav_coverage.yaml"
)

# 故障模型
FAULT_MODELS=("random" "adversarial")

mkdir -p $LOG_DIR

echo "=== Phase 2: Byzantine 鲁棒性实验 ===" | tee $PROGRESS_LOG
echo "GPU: $GPU" | tee -a $PROGRESS_LOG
echo "n_timesteps: $N_TIMESTEPS" | tee -a $PROGRESS_LOG
echo "byzantine_n: 1" | tee -a $PROGRESS_LOG
echo "" | tee -a $PROGRESS_LOG

TOTAL=$((${#ALGO_MAP[@]} * ${#ENV_MAP[@]} * ${#FAULT_MODELS[@]} * 3))
CURRENT=0

for env_name in "${!ENV_MAP[@]}"; do
    env_config=${ENV_MAP[$env_name]}
    for algo_name in "${!ALGO_MAP[@]}"; do
        algo_config=${ALGO_MAP[$algo_name]}
        for fault_model in "${FAULT_MODELS[@]}"; do
            for seed in $SEEDS; do
                CURRENT=$((CURRENT + 1))
                RUN_DIR=$LOG_DIR/${env_name}_${algo_name}_${fault_model}_seed${seed}
                mkdir -p $RUN_DIR
                echo "[$CURRENT/$TOTAL] env=$env_name algo=$algo_name fault=$fault_model seed=$seed" | tee -a $PROGRESS_LOG
                nohup python -u src/train.py \
                    --algo pbft_cg_mappo \
                    --env $env_name \
                    --env_config $env_config \
                    --algo_config $algo_config \
                    --seed $seed \
                    --n_timesteps $N_TIMESTEPS \
                    --eval_interval $EVAL_INTERVAL \
                    --eval_episodes $EVAL_EPISODES \
                    --log_dir $RUN_DIR \
                    --gpu $GPU \
                    --byzantine_n 1 \
                    --byzantine_type $fault_model \
                    > $RUN_DIR/train.log 2>&1 &
                # 每 4 个任务暂停一下
                if [ $((CURRENT % 4)) -eq 0 ]; then
                    wait
                    echo "  [batch done] waiting for next batch..." | tee -a $PROGRESS_LOG
                fi
            done
        done
    done
done

wait
echo "" | tee -a $PROGRESS_LOG
echo "=== Phase 2 完成 ===" | tee -a $PROGRESS_LOG
echo "结果目录: $LOG_DIR" | tee -a $PROGRESS_LOG
