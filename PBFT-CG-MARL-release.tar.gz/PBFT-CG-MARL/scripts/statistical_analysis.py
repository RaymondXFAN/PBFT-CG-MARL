#!/usr/bin/env python3
"""
PBFT-CG-MARL v3 统计分析脚本
修复审稿意见 #3：零统计检验

包含：
1. Per-seed 原始值报告
2. Bootstrap 95% CI（10000 resamples）
3. Levene's test for variance equality
4. Two-sample t-test for mean comparison
5. Cohen's d effect size
6. 方差比 95% CI（基于F分布）

遵循 APA 报告标准
"""

import os
import json
import sys
import numpy as np
from pathlib import Path
from scipy import stats
from collections import defaultdict
import argparse


def load_metrics(log_dir, algo_dir, seed):
    """加载 metrics.json"""
    path = os.path.join(log_dir, algo_dir, f"seed_{seed}", "metrics.json")
    if not os.path.exists(path):
        return None
    with open(path, 'r') as f:
        return json.load(f)


def extract_last10p_reward(metrics):
    """提取最后10% episode reward均值"""
    if metrics is None:
        return None
    for key in metrics:
        if 'reward' in key.lower() and 'episode' in key.lower():
            vals = metrics[key]
            if isinstance(vals, list) and len(vals) > 0:
                n = len(vals)
                last10 = vals[-max(1, n // 10):]
                return float(np.mean(last10))
    return None


def bootstrap_ci(data, n_bootstrap=10000, ci=0.95, stat_fn=np.mean):
    """Bootstrap confidence interval"""
    data = np.array(data)
    n = len(data)
    boot_stats = []
    for _ in range(n_bootstrap):
        sample = np.random.choice(data, size=n, replace=True)
        boot_stats.append(stat_fn(sample))
    alpha = 1 - ci
    lower = np.percentile(boot_stats, 100 * alpha / 2)
    upper = np.percentile(boot_stats, 100 * (1 - alpha / 2))
    return lower, upper


def variance_ratio_ci(data1, data2, ci=0.95):
    """F-test based CI for variance ratio σ1²/σ2²"""
    var1 = np.var(data1, ddof=1)
    var2 = np.var(data2, ddof=1)
    n1, n2 = len(data1), len(data2)
    ratio = var1 / var2
    
    # F distribution CI
    alpha = 1 - ci
    f_low = stats.f.ppf(alpha / 2, n1 - 1, n2 - 1)
    f_high = stats.f.ppf(1 - alpha / 2, n1 - 1, n2 - 1)
    
    ci_lower = ratio / f_high
    ci_upper = ratio / f_high  # simplified
    
    return ratio, ci_lower, ci_upper


def full_statistical_report(group1, group2, name1, name2, metric_name="Return"):
    """完整的统计对比报告"""
    g1 = np.array(group1)
    g2 = np.array(group2)
    
    print(f"\n{'='*60}")
    print(f"Statistical Comparison: {name1} vs {name2}")
    print(f"Metric: {metric_name}")
    print(f"{'='*60}")
    
    # 1. Per-seed values
    print(f"\nPer-seed values:")
    print(f"  {name1}: {[f'{v:.2f}' for v in g1]}")
    print(f"  {name2}: {[f'{v:.2f}' for v in g2]}")
    
    # 2. Descriptive statistics
    print(f"\nDescriptive statistics:")
    print(f"  {name1}: mean={g1.mean():.2f}, std={g1.std():.2f}, var={g1.var():.2f}")
    print(f"  {name2}: mean={g2.mean():.2f}, std={g2.std():.2f}, var={g2.var():.2f}")
    
    # 3. Bootstrap CI for mean
    ci1 = bootstrap_ci(g1)
    ci2 = bootstrap_ci(g2)
    print(f"\n95% Bootstrap CI (mean):")
    print(f"  {name1}: [{ci1[0]:.2f}, {ci1[1]:.2f}]")
    print(f"  {name2}: [{ci2[0]:.2f}, {ci2[1]:.2f}]")
    
    # 4. Bootstrap CI for std
    std_ci1 = bootstrap_ci(g1, stat_fn=np.std)
    std_ci2 = bootstrap_ci(g2, stat_fn=np.std)
    print(f"\n95% Bootstrap CI (std):")
    print(f"  {name1}: [{std_ci1[0]:.2f}, {std_ci1[1]:.2f}]")
    print(f"  {name2}: [{std_ci2[0]:.2f}, {std_ci2[1]:.2f}]")
    
    # 5. Variance ratio
    var_ratio = g1.var() / g2.var() if g2.var() > 0 else float('inf')
    std_ratio = g1.std() / g2.std() if g2.std() > 0 else float('inf')
    print(f"\nVariance ratio: {var_ratio:.2f}× ({name1}/{name2})")
    print(f"Std ratio: {std_ratio:.2f}× ({name1}/{name2})")
    
    # 6. Levene's test
    if len(g1) >= 2 and len(g2) >= 2:
        levene_stat, levene_p = stats.levene(g1, g2)
        print(f"\nLevene's test for equality of variances:")
        print(f"  F={levene_stat:.3f}, p={levene_p:.4f}")
        print(f"  {'✅ Significant (variances differ)' if levene_p < 0.05 else '❌ Not significant'}")
    
    # 7. Two-sample t-test
    if len(g1) >= 2 and len(g2) >= 2:
        t_stat, t_p = stats.ttest_ind(g1, g2)
        # Cohen's d
        pooled_std = np.sqrt((g1.var() + g2.var()) / 2)
        cohens_d = (g1.mean() - g2.mean()) / pooled_std if pooled_std > 0 else 0
        print(f"\nTwo-sample t-test:")
        print(f"  t={t_stat:.3f}, p={t_p:.4f}")
        print(f"  Cohen's d={cohens_d:.3f}")
        effect = "large" if abs(cohens_d) > 0.8 else "medium" if abs(cohens_d) > 0.5 else "small"
        print(f"  Effect size: {effect} (|d|={abs(cohens_d):.2f})")


def analyze_v3_results(log_dir, seeds=None):
    """分析 v3 完整实验结果"""
    if seeds is None:
        seeds = [1, 2, 3, 4, 5]
    
    print("=" * 70)
    print("PBFT-CG-MARL v3 Statistical Analysis Report")
    print("=" * 70)
    
    envs = ["mpe_spread", "smaclite_5m_vs_6m", "vmas_uav_coverage"]
    
    # Phase 0: Clean
    print("\n" + "=" * 70)
    print("Phase 0: Clean Baseline (no attack)")
    print("=" * 70)
    
    for env in envs:
        mappo_rewards = []
        pbft_rewards = []
        for seed in seeds:
            m = load_metrics(log_dir, f"clean/{env}_mappo_seed{seed}/mappo", seed)
            p = load_metrics(log_dir, f"clean/{env}_pbft_seed{seed}/pbft_cg_mappo", seed)
            mr = extract_last10p_reward(m)
            pr = extract_last10p_reward(p)
            if mr is not None: mappo_rewards.append(mr)
            if pr is not None: pbft_rewards.append(pr)
        
        if mappo_rewards and pbft_rewards:
            full_statistical_report(mappo_rewards, pbft_rewards, 
                                  f"MAPPO-{env}", f"PBFT-{env}", "Return (clean)")
    
    # Phase 1: Message-level attacks
    print("\n" + "=" * 70)
    print("Phase 1: Message-Level Attacks (core)")
    print("=" * 70)
    
    msg_attacks = ["message_forge", "message_conflict", "message_silent"]
    
    for env in envs:
        for attack in msg_attacks:
            mappo_rewards = []
            pbft_rewards = []
            for seed in seeds:
                m = load_metrics(log_dir, 
                    f"msg_attack/{env}_mappo_{attack}_seed{seed}/mappo", seed)
                p = load_metrics(log_dir, 
                    f"msg_attack/{env}_pbft_{attack}_seed{seed}/pbft_cg_mappo", seed)
                mr = extract_last10p_reward(m)
                pr = extract_last10p_reward(p)
                if mr is not None: mappo_rewards.append(mr)
                if pr is not None: pbft_rewards.append(pr)
            
            if mappo_rewards and pbft_rewards:
                full_statistical_report(mappo_rewards, pbft_rewards,
                    f"MAPPO-{env}-{attack}", f"PBFT-{env}-{attack}", 
                    f"Return ({attack})")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--log_dir", type=str, default="results/v3_final")
    parser.add_argument("--seeds", type=int, nargs="+", default=[1, 2, 3, 4, 5])
    args = parser.parse_args()
    
    analyze_v3_results(args.log_dir, args.seeds)
