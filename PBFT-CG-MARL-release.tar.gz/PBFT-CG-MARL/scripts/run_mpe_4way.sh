#!/bin/bash
set -e
PYTHON="/root/miniconda3/bin/python"
BASE="/root/autodl-tmp/PBFT-CG-MARL"
LOG="/root/autodl-tmp/PBFT-CG-MARL/results/v3_formal"
TS=300000
EI=10000
EE=10
ACFG_P="$BASE/configs/algo/pbft_cg_mappo_v3.yaml"
ACFG_M="$BASE/configs/algo/mappo_v3.yaml"

echo "=== v3 Formal MPE (4-way parallel) === $(date)"
mkdir -p $LOG

run_pbft_forge() {
    local S=$1
    if [ -f "$LOG/mpe_pbft_forge_seed$S/pbft_cg_mappo/seed_$S/metrics.json" ]; then
        echo "[SKIP] pbft_forge seed=$S already done"
        return
    fi
    echo "[PBFT+forge s=$S] start $(date +%H:%M:%S)"
    $PYTHON -u $BASE/src/train.py --algo pbft_cg_mappo --env mpe_spread \
        --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $ACFG_P \
        --seed $S --n_timesteps $TS --eval_interval $EI --eval_episodes $EE \
        --log_dir $LOG/mpe_pbft_forge_seed$S --byzantine_n 1 --byzantine_type message_forge --gpu 0
    echo "[PBFT+forge s=$S] done $(date +%H:%M:%S)"
}

run_mappo_forge() {
    local S=$1
    if [ -f "$LOG/mpe_mappo_forge_seed$S/mappo/seed_$S/metrics.json" ]; then
        echo "[SKIP] mappo_forge seed=$S already done"
        return
    fi
    echo "[MAPPO+forge s=$S] start $(date +%H:%M:%S)"
    $PYTHON -u $BASE/src/train.py --algo mappo --env mpe_spread \
        --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $ACFG_M \
        --seed $S --n_timesteps $TS --eval_interval $EI --eval_episodes $EE \
        --log_dir $LOG/mpe_mappo_forge_seed$S --byzantine_n 1 --byzantine_type message_forge --gpu 0
    echo "[MAPPO+forge s=$S] done $(date +%H:%M:%S)"
}

run_pbft_clean() {
    local S=$1
    if [ -f "$LOG/mpe_pbft_clean_seed$S/pbft_cg_mappo/seed_$S/metrics.json" ]; then
        echo "[SKIP] pbft_clean seed=$S already done"
        return
    fi
    echo "[PBFT+clean s=$S] start $(date +%H:%M:%S)"
    $PYTHON -u $BASE/src/train.py --algo pbft_cg_mappo --env mpe_spread \
        --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $ACFG_P \
        --seed $S --n_timesteps $TS --eval_interval $EI --eval_episodes $EE \
        --log_dir $LOG/mpe_pbft_clean_seed$S --gpu 0
    echo "[PBFT+clean s=$S] done $(date +%H:%M:%S)"
}

run_mappo_clean() {
    local S=$1
    if [ -f "$LOG/mpe_mappo_clean_seed$S/mappo/seed_$S/metrics.json" ]; then
        echo "[SKIP] mappo_clean seed=$S already done"
        return
    fi
    echo "[MAPPO+clean s=$S] start $(date +%H:%M:%S)"
    $PYTHON -u $BASE/src/train.py --algo mappo --env mpe_spread \
        --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $ACFG_M \
        --seed $S --n_timesteps $TS --eval_interval $EI --eval_episodes $EE \
        --log_dir $LOG/mpe_mappo_clean_seed$S --gpu 0
    echo "[MAPPO+clean s=$S] done $(date +%H:%M:%S)"
}

# Batch 1: PBFT+forge seeds 1-4 (4 parallel)
run_pbft_forge 1 & run_pbft_forge 2 & run_pbft_forge 3 & run_pbft_forge 4 &
wait
echo "=== PBFT+forge batch1 done === $(date)"

run_pbft_forge 5
echo "=== PBFT+forge ALL done === $(date)"

# Batch 2: MAPPO+forge seeds 1-4 (4 parallel)
run_mappo_forge 1 & run_mappo_forge 2 & run_mappo_forge 3 & run_mappo_forge 4 &
wait
echo "=== MAPPO+forge batch1 done === $(date)"

run_mappo_forge 5
echo "=== MAPPO+forge ALL done === $(date)"

# Batch 3: PBFT+clean seeds 1-4
run_pbft_clean 1 & run_pbft_clean 2 & run_pbft_clean 3 & run_pbft_clean 4 &
wait
echo "=== PBFT+clean batch1 done === $(date)"

run_pbft_clean 5
echo "=== PBFT+clean ALL done === $(date)"

# Batch 4: MAPPO+clean seeds 1-4
run_mappo_clean 1 & run_mappo_clean 2 & run_mappo_clean 3 & run_mappo_clean 4 &
wait
echo "=== MAPPO+clean batch1 done === $(date)"

run_mappo_clean 5
echo "=== MAPPO+clean ALL done === $(date)"

echo "=== ALL MPE EXPERIMENTS COMPLETE === $(date)"
