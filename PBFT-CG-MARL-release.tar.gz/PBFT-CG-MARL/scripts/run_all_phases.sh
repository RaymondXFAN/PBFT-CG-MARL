#!/bin/bash
# PBFT-CG-MARL 补充实验 — 总控脚本
# 用途：按顺序执行所有 phase（0→1→2→3→4→5）
# GPU要求：1卡
# 预计总耗时：~13小时
# 监控命令：tail -f results/run_all.log
set -e
GPU=${1:-0}
TOTAL_LOG=results/run_all.log

echo "========================================================" | tee $TOTAL_LOG
echo "  PBFT-CG-MARL 补充实验 — 总控脚本" | tee -a $TOTAL_LOG
echo "  GPU: $GPU" | tee -a $TOTAL_LOG
echo "  预计总耗时: ~13小时" | tee -a $TOTAL_LOG
echo "  监控: tail -f $TOTAL_LOG" | tee -a $TOTAL_LOG
echo "========================================================" | tee -a $TOTAL_LOG
echo "" | tee -a $TOTAL_LOG

# ── Phase 0: 环境预检 ──
echo "" | tee -a $TOTAL_LOG
echo ">>> Phase 0: 环境预检 (~5分钟) <<<" | tee -a $TOTAL_LOG
echo "按 Ctrl+C 可终止，按 Enter 继续..." | tee -a $TOTAL_LOG
read -t 30 dummy || true  # 30秒超时自动继续
bash scripts/phase0_sanity_check.sh $GPU 2>&1 | tee -a $TOTAL_LOG
echo "Phase 0 完成 ✓" | tee -a $TOTAL_LOG

# ── Phase 1: 跨环境对比 ──
echo "" | tee -a $TOTAL_LOG
echo ">>> Phase 1: 跨环境对比实验 (~6小时) <<<" | tee -a $TOTAL_LOG
echo "按 Enter 继续..." | tee -a $TOTAL_LOG
read -t 30 dummy || true
bash scripts/phase1_cross_env.sh $GPU 2>&1 | tee -a $TOTAL_LOG
echo "Phase 1 完成 ✓" | tee -a $TOTAL_LOG

# ── Phase 2: Byzantine 鲁棒性 ──
echo "" | tee -a $TOTAL_LOG
echo ">>> Phase 2: Byzantine 鲁棒性实验 (~4小时) <<<" | tee -a $TOTAL_LOG
echo "按 Enter 继续..." | tee -a $TOTAL_LOG
read -t 30 dummy || true
bash scripts/phase2_byzantine.sh $GPU 2>&1 | tee -a $TOTAL_LOG
echo "Phase 2 完成 ✓" | tee -a $TOTAL_LOG

# ── Phase 3: 敏感性 + 消融 ──
echo "" | tee -a $TOTAL_LOG
echo ">>> Phase 3: 敏感性分析 + 消融实验 (~1.5小时) <<<" | tee -a $TOTAL_LOG
echo "按 Enter 继续..." | tee -a $TOTAL_LOG
read -t 30 dummy || true
bash scripts/phase3_sensitivity.sh $GPU 2>&1 | tee -a $TOTAL_LOG
echo "Phase 3 完成 ✓" | tee -a $TOTAL_LOG

# ── Phase 4: 补跑种子 ──
echo "" | tee -a $TOTAL_LOG
echo ">>> Phase 4: 补跑 MPE seed 4,5 (~40分钟) <<<" | tee -a $TOTAL_LOG
echo "按 Enter 继续..." | tee -a $TOTAL_LOG
read -t 30 dummy || true
bash scripts/phase4_stats.sh $GPU 2>&1 | tee -a $TOTAL_LOG
echo "Phase 4 完成 ✓" | tee -a $TOTAL_LOG

# ── Phase 5: SOTA Baseline ──
echo "" | tee -a $TOTAL_LOG
echo ">>> Phase 5: SOTA Baseline 对比 (~1.5小时) <<<" | tee -a $TOTAL_LOG
echo "按 Enter 继续..." | tee -a $TOTAL_LOG
read -t 30 dummy || true
bash scripts/phase5_sota.sh $GPU 2>&1 | tee -a $TOTAL_LOG
echo "Phase 5 完成 ✓" | tee -a $TOTAL_LOG

# ── 统计分析 ──
echo "" | tee -a $TOTAL_LOG
echo ">>> 统计分析 <<<" | tee -a $TOTAL_LOG
python -u scripts/statistical_analysis.py \
    --results_dir results \
    --output_dir results/figures \
    2>&1 | tee -a $TOTAL_LOG

echo "" | tee -a $TOTAL_LOG
echo "========================================================" | tee -a $TOTAL_LOG
echo "  全部实验完成！" | tee -a $TOTAL_LOG
echo "  结果目录: results/" | tee -a $TOTAL_LOG
echo "  图片: results/figures/" | tee -a $TOTAL_LOG
echo "  LaTeX: results/figures/main_results_table.tex" | tee -a $TOTAL_LOG
echo "========================================================" | tee -a $TOTAL_LOG
