#!/usr/bin/env python3
"""
PBFT-CG-MARL v4 诊断脚本
从训练日志中提取关键指标，对比 v3 vs v4

关键指标：
1. entropy 趋势（是否还在崩塌）
2. reward 趋势（是否改善）
3. entropy_coef 变化（自适应调度是否生效）
4. consensus_rate（共识是否正常工作）
5. consensus_loss
"""

import os
import sys
import json
import numpy as np
from pathlib import Path
import argparse


def load_metrics(log_dir, algo, seed):
    """从日志目录加载 metrics.json"""
    metrics_path = os.path.join(log_dir, algo, f"seed_{seed}", "metrics.json")
    if not os.path.exists(metrics_path):
        print(f"[WARN] 找不到 {metrics_path}")
        return None
    
    with open(metrics_path, 'r') as f:
        metrics = json.load(f)
    return metrics


def extract_episode_rewards(metrics):
    """提取 episode reward"""
    if metrics is None:
        return []
    rewards = metrics.get("episode_reward", [])
    if not rewards:
        rewards = metrics.get("eval_reward", [])
    return rewards


def extract_entropy(metrics):
    """提取 entropy"""
    if metrics is None:
        return []
    return metrics.get("entropy", [])


def extract_entropy_coef(metrics):
    """提取 entropy_coef（v4 新增）"""
    if metrics is None:
        return []
    return metrics.get("entropy_coef", [])


def extract_consensus_rate(metrics):
    """提取 consensus_rate"""
    if metrics is None:
        return []
    return metrics.get("consensus_rate", [])


def summarize(values, name=""):
    """统计摘要"""
    if not values:
        return f"{name}: 无数据"
    arr = np.array(values)
    # 分段统计
    n = len(arr)
    first_10 = arr[:max(1, n//10)]
    mid = arr[n//4:3*n//4]
    last_10 = arr[-max(1, n//10):]
    
    return (
        f"{name}:\n"
        f"  全局均值={arr.mean():.4f}, 最后={arr[-1]:.4f}\n"
        f"  前10%={first_10.mean():.4f}, 中间={mid.mean():.4f}, 后10%={last_10.mean():.4f}\n"
        f"  最小={arr.min():.4f}, 最大={arr.max():.4f}"
    )


def diagnose_v4(log_dir, v3_log_dir=None):
    """v4 诊断"""
    print("=" * 60)
    print("PBFT-CG-MARL v4 诊断报告")
    print("=" * 60)
    
    seeds = [1, 2, 3]
    
    for algo in ["pbft_cg_mappo", "mappo"]:
        print(f"\n{'=' * 40}")
        print(f"算法: {algo}")
        print(f"{'=' * 40}")
        
        for seed in seeds:
            metrics = load_metrics(log_dir, algo, seed)
            if metrics is None:
                continue
            
            print(f"\n--- {algo} seed{seed} ---")
            
            # 1. Episode reward
            rewards = extract_episode_rewards(metrics)
            if rewards:
                arr = np.array(rewards)
                print(f"  reward: 均值={arr.mean():.1f}, 最后={arr[-1]:.1f}, 最差={arr.min():.1f}, 最好={arr.max():.1f}")
            
            # 2. Entropy（关键指标！）
            entropy = extract_entropy(metrics)
            if entropy:
                print(f"  {summarize(entropy, 'entropy')}")
                # 判断是否崩塌
                arr = np.array(entropy)
                if arr[-1] < 0.05:
                    print(f"  ⚠️ 熵崩塌！最后 entropy={arr[-1]:.4f} < 0.05")
                elif arr[-1] < 0.10:
                    print(f"  ⚡ 熵偏低，但比 v3 好一些")
                else:
                    print(f"  ✅ 熵正常！最后 entropy={arr[-1]:.4f}")
            
            # 3. Entropy coef（v4 自适应调度）
            entropy_coef = extract_entropy_coef(metrics)
            if entropy_coef:
                arr = np.array(entropy_coef)
                print(f"  entropy_coef: 初始={arr[0]:.4f}, 最后={arr[-1]:.4f}, 最大={arr.max():.4f}")
            
            # 4. Consensus rate
            cons_rate = extract_consensus_rate(metrics)
            if cons_rate:
                print(f"  {summarize(cons_rate, 'consensus_rate')}")
    
    # v3 vs v4 对比
    if v3_log_dir:
        print(f"\n{'=' * 60}")
        print("v3 vs v4 对比")
        print(f"{'=' * 60}")
        
        for algo in ["pbft_cg_mappo"]:
            v3_rewards = []
            v4_rewards = []
            v3_entropy = []
            v4_entropy = []
            
            for seed in seeds:
                v3_m = load_metrics(v3_log_dir, algo, seed)
                v4_m = load_metrics(log_dir, algo, seed)
                
                if v3_m:
                    v3_rewards.append(np.mean(extract_episode_rewards(v3_m) or [0]))
                    v3_entropy.append(np.array(extract_entropy(v3_m) or [0])[-1])
                if v4_m:
                    v4_rewards.append(np.mean(extract_episode_rewards(v4_m) or [0]))
                    v4_entropy.append(np.array(extract_entropy(v4_m) or [0])[-1])
            
            if v3_rewards and v4_rewards:
                print(f"\n{algo}:")
                print(f"  v3 reward: {np.mean(v3_rewards):.1f} ± {np.std(v3_rewards):.1f}")
                print(f"  v4 reward: {np.mean(v4_rewards):.1f} ± {np.std(v4_rewards):.1f}")
                improvement = (np.mean(v4_rewards) - np.mean(v3_rewards)) / abs(np.mean(v3_rewards)) * 100
                print(f"  改善: {improvement:+.1f}%")
                
                print(f"  v3 最后 entropy: {np.mean(v3_entropy):.4f}")
                print(f"  v4 最后 entropy: {np.mean(v4_entropy):.4f}")
    
    print("\n" + "=" * 60)
    print("诊断完成")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--log_dir", type=str, default="results/v4_full")
    parser.add_argument("--v3_log_dir", type=str, default="results/v3_full")
    args = parser.parse_args()
    
    diagnose_v4(args.log_dir, args.v3_log_dir)
