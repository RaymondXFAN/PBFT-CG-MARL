#!/bin/bash
# ============================================================
# PBFT-CG-MARL v4 快速验证脚本
# 50K 步，5 题评估，1 个 seed
# 目标：验证熵崩塌修复是否有效
# 预计耗时：约 5-10 分钟
# ============================================================

set -e

GPU_ID=${1:-0}
LOG_DIR="results/v4_quick"

echo "============================================"
echo "PBFT-CG-MARL v4 快速验证"
echo "GPU: ${GPU_ID}"
echo "日志目录: ${LOG_DIR}"
echo "============================================"

# 1. PBFT-CG-MAPPO v4（1 seed, 50K 步）
echo ""
echo "[1/2] 运行 pbft_cg_mappo_v4 seed1 ..."
python -u src/train.py \
    --algo pbft_cg_mappo \
    --env mpe_spread \
    --env_config configs/env/mpe_spread.yaml \
    --algo_config configs/algo/pbft_cg_mappo_v4.yaml \
    --seed 1 \
    --n_timesteps 50000 \
    --eval_interval 5000 \
    --eval_episodes 5 \
    --log_dir ${LOG_DIR} \
    --gpu ${GPU_ID}

# 2. MAPPO v4 对照组（1 seed, 50K 步）
echo ""
echo "[2/2] 运行 mappo_v4 seed1 ..."
python -u src/train.py \
    --algo mappo \
    --env mpe_spread \
    --env_config configs/env/mpe_spread.yaml \
    --algo_config configs/algo/mappo_v4.yaml \
    --seed 1 \
    --n_timesteps 50000 \
    --eval_interval 5000 \
    --eval_episodes 5 \
    --log_dir ${LOG_DIR} \
    --gpu ${GPU_ID}

echo ""
echo "============================================"
echo "快速验证完成！"
echo ""
echo "关键指标检查："
echo "  1. entropy 是否维持在 0.05+ 以上（v3 降到 0.024）"
echo "  2. pbft_v4 的 reward 是否比 v3 的 -64.3 有改善"
echo "  3. pbft_v4 与 mappo_v4 的差距是否缩小"
echo ""
echo "结果目录: ${LOG_DIR}"
echo "============================================"
