
import sys, re

BASE = "/root/autodl-tmp/PBFT-CG-MARL"

def patch_separate_optimizer(filepath, is_pbft=True):
    with open(filepath, "r") as f:
        lines = f.readlines()
    
    new_lines = []
    i = 0
    changed = 0
    
    while i < len(lines):
        line = lines[i]
        
        # 1. Replace single optimizer init with dual optimizers
        if "self.optimizer = torch.optim.Adam(" in line and i+1 < len(lines) and "self.parameters()" in lines[i+1]:
            indent = len(line) - len(line.lstrip())
            sp = " " * indent
            new_lines.append(f"{sp}# v5: Separate optimizers - actor and critic
")
            new_lines.append(f"{sp}actor_params = list(self.actor.parameters()) if self.share_param else list(self.actors.parameters())
")
            new_lines.append(f"{sp}critic_params = list(self.critic.parameters())
")
            new_lines.append(f"{sp}self.actor_optimizer = torch.optim.Adam(actor_params, lr=self.lr, eps=1e-5)
")
            new_lines.append(f"{sp}self.critic_optimizer = torch.optim.Adam(critic_params, lr=self.lr, eps=1e-5)
")
            new_lines.append(f"{sp}self.optimizer = self.actor_optimizer  # compat for lr_scheduler
")
            # Skip the old 3 lines (optimizer = ..., self.parameters()..., ...)
            i += 3  # skip 3 lines
            changed += 1
            continue
        
        # 2. Replace combined loss + optimizer step with separate updates
        if is_pbft and "loss = (" in line and i+1 < len(lines) and "policy_loss" in lines[i+1]:
            # Found: loss = ( ... )
            # Collect all lines until the closing ) and optimizer.step()
            block_start = i
            block_lines = [line]
            j = i + 1
            while j < len(lines) and not ("self.optimizer.step()" in lines[j]):
                block_lines.append(lines[j])
                j += 1
            block_lines.append(lines[j])  # include the step line
            
            # Now find self.optimizer.zero_grad() before the loss
            # It should be 2-3 lines before the loss = (
            zero_grad_line = None
            for k in range(max(0, i-3), i):
                if "self.optimizer.zero_grad()" in lines[k]:
                    zero_grad_line = k
            
            indent = len(line) - len(line.lstrip())
            sp = " " * indent
            
            # Write new separate optimizer code
            new_lines.append(f"{sp}# v5: Separate actor/critic updates
")
            new_lines.append(f"{sp}actor_loss = (
")
            new_lines.append(f"{sp}    policy_loss
")
            new_lines.append(f"{sp}    - self.entropy_coef * mean_entropy
")
            new_lines.append(f"{sp}    + consensus_loss
")
            new_lines.append(f"{sp}    + entropy_floor_penalty
")
            new_lines.append(f"{sp}    + self.kl_consensus_coef * kl_consensus_loss
")
            new_lines.append(f"{sp})
")
            new_lines.append(f"{sp}critic_loss = self.value_loss_coef * value_loss
")
            new_lines.append(f"{sp}
")
            new_lines.append(f"{sp}self.actor_optimizer.zero_grad()
")
            new_lines.append(f"{sp}actor_loss.backward(retain_graph=True)
")
            new_lines.append(f"{sp}if self.share_param:
")
            new_lines.append(f"{sp}    nn.utils.clip_grad_norm_(self.actor.parameters(), self.max_grad_norm)
")
            new_lines.append(f"{sp}else:
")
            new_lines.append(f"{sp}    nn.utils.clip_grad_norm_(self.actors.parameters(), self.max_grad_norm)
")
            new_lines.append(f"{sp}self.actor_optimizer.step()
")
            new_lines.append(f"{sp}
")
            new_lines.append(f"{sp}self.critic_optimizer.zero_grad()
")
            new_lines.append(f"{sp}critic_loss.backward()
")
            new_lines.append(f"{sp}nn.utils.clip_grad_norm_(self.critic.parameters(), self.max_grad_norm)
")
            new_lines.append(f"{sp}self.critic_optimizer.step()
")
            
            # Skip the old block
            i = j + 1
            # Also skip clip_grad_norm and zero_grad if present
            changed += 1
            continue
        
        if not is_pbft and "loss = (" in line and i+1 < len(lines) and "policy_loss" in lines[i+1]:
            block_start = i
            block_lines = [line]
            j = i + 1
            while j < len(lines) and not ("self.optimizer.step()" in lines[j]):
                block_lines.append(lines[j])
                j += 1
            block_lines.append(lines[j])
            
            indent = len(line) - len(line.lstrip())
            sp = " " * indent
            
            new_lines.append(f"{sp}# v5: Separate actor/critic updates
")
            new_lines.append(f"{sp}actor_loss = policy_loss - self.entropy_coef * mean_entropy
")
            new_lines.append(f"{sp}critic_loss = self.value_loss_coef * value_loss
")
            new_lines.append(f"{sp}
")
            new_lines.append(f"{sp}self.actor_optimizer.zero_grad()
")
            new_lines.append(f"{sp}actor_loss.backward(retain_graph=True)
")
            new_lines.append(f"{sp}if self.share_param:
")
            new_lines.append(f"{sp}    nn.utils.clip_grad_norm_(self.actor.parameters(), self.max_grad_norm)
")
            new_lines.append(f"{sp}else:
")
            new_lines.append(f"{sp}    nn.utils.clip_grad_norm_(self.actors.parameters(), self.max_grad_norm)
")
            new_lines.append(f"{sp}self.actor_optimizer.step()
")
            new_lines.append(f"{sp}
")
            new_lines.append(f"{sp}self.critic_optimizer.zero_grad()
")
            new_lines.append(f"{sp}critic_loss.backward()
")
            new_lines.append(f"{sp}nn.utils.clip_grad_norm_(self.critic.parameters(), self.max_grad_norm)
")
            new_lines.append(f"{sp}self.critic_optimizer.step()
")
            
            i = j + 1
            changed += 1
            continue
        
        # 3. Replace zero_grad (if not already handled in the block above)
        if "self.optimizer.zero_grad()" in line:
            # Skip - already handled in the new block above
            i += 1
            continue
        
        # 4. Replace clip_grad_norm after backward
        if "nn.utils.clip_grad_norm_(self.parameters()" in line:
            # Skip - already handled
            i += 1
            continue
        
        # 5. Fix save
        if '"optimizer_state_dict": self.optimizer.state_dict(),' in line:
            indent = len(line) - len(line.lstrip())
            sp = " " * indent
            new_lines.append(f'{sp}"actor_optimizer_state_dict": self.actor_optimizer.state_dict(),
')
            new_lines.append(f'{sp}"critic_optimizer_state_dict": self.critic_optimizer.state_dict(),
')
            new_lines.append(f'{sp}"optimizer_state_dict": self.actor_optimizer.state_dict(),  # compat
')
            i += 1
            changed += 1
            continue
        
        # 6. Fix load
        if 'self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])' in line:
            indent = len(line) - len(line.lstrip())
            sp = " " * indent
            new_lines.append(f'{sp}# v5: Load separate optimizers
')
            new_lines.append(f'{sp}if "actor_optimizer_state_dict" in checkpoint:
')
            new_lines.append(f'{sp}    self.actor_optimizer.load_state_dict(checkpoint["actor_optimizer_state_dict"])
')
            new_lines.append(f'{sp}    self.critic_optimizer.load_state_dict(checkpoint["critic_optimizer_state_dict"])
')
            new_lines.append(f'{sp}else:
')
            new_lines.append(f'{sp}    self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
')
            i += 1
            changed += 1
            continue
        
        new_lines.append(line)
        i += 1
    
    with open(filepath, "w") as f:
        f.writelines(new_lines)
    
    print(f"Patched {filepath}: {changed} changes")

patch_separate_optimizer(f"{BASE}/src/algorithms/pbft_cg_mappo.py", is_pbft=True)
patch_separate_optimizer(f"{BASE}/src/algorithms/mappo.py", is_pbft=False)
print("Done!")
