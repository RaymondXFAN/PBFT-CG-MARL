#!/bin/bash
# Phase 1: 跨环境对比实验
# 用途：在3个环境上对比4种算法（Additive / Mult-Matched / Mult-Mismatched / MAPPO），每个5 seeds
# GPU要求：1卡
# 预计耗时：~6小时（3 envs × 4 algos × 5 seeds × ~6min/seed）
# 监控命令：tail -f results/phase1_cross_env/progress.log
set -e
GPU=${1:-0}
N_TIMESTEPS=${2:-300000}
EVAL_INTERVAL=${3:-10000}
EVAL_EPISODES=10
SEEDS="1 2 3 4 5"
LOG_DIR=results/phase1_cross_env
PROGRESS_LOG=$LOG_DIR/progress.log

# 算法 × 配置映射
declare -A ALGO_MAP=(
    ["pbft_additive"]="configs/algo/pbft_additive_v5.yaml"
    ["pbft_mult_matched"]="configs/algo/pbft_mult_matched_v5.yaml"
    ["pbft_mult_mismatched"]="configs/algo/pbft_mult_mismatched_v5.yaml"
    ["mappo"]="configs/algo/mappo_v5.yaml"
)

# 环境 × 配置映射
declare -A ENV_MAP=(
    ["mpe_spread"]="configs/env/mpe_spread.yaml"
    ["smaclite_5m_vs_6m"]="configs/env/smaclite_5m_vs_6m.yaml"
    ["vmas_uav_coverage"]="configs/env/vmas_uav_coverage.yaml"
)

mkdir -p $LOG_DIR

echo "=== Phase 1: 跨环境对比实验 ===" | tee $PROGRESS_LOG
echo "GPU: $GPU" | tee -a $PROGRESS_LOG
echo "n_timesteps: $N_TIMESTEPS, eval_interval: $EVAL_INTERVAL" | tee -a $PROGRESS_LOG
echo "算法: ${!ALGO_MAP[@]}" | tee -a $PROGRESS_LOG
echo "环境: ${!ENV_MAP[@]}" | tee -a $PROGRESS_LOG
echo "Seeds: $SEEDS" | tee -a $PROGRESS_LOG
echo "" | tee -a $PROGRESS_LOG

TOTAL=$((${#ALGO_MAP[@]} * ${#ENV_MAP[@]} * 5))
CURRENT=0

for env_name in "${!ENV_MAP[@]}"; do
    env_config=${ENV_MAP[$env_name]}
    for algo_name in "${!ALGO_MAP[@]}"; do
        algo_config=${ALGO_MAP[$algo_name]}
        # 确定 algo 参数
        if [ "$algo_name" = "mappo" ]; then
            ALGO_FLAG="--algo mappo"
        else
            ALGO_FLAG="--algo pbft_cg_mappo"
        fi
        for seed in $SEEDS; do
            CURRENT=$((CURRENT + 1))
            RUN_DIR=$LOG_DIR/${env_name}_${algo_name}_seed${seed}
            mkdir -p $RUN_DIR
            echo "[$CURRENT/$TOTAL] env=$env_name algo=$algo_name seed=$seed" | tee -a $PROGRESS_LOG
            nohup python -u src/train.py \
                $ALGO_FLAG \
                --env $env_name \
                --env_config $env_config \
                --algo_config $algo_config \
                --seed $seed \
                --n_timesteps $N_TIMESTEPS \
                --eval_interval $EVAL_INTERVAL \
                --eval_episodes $EVAL_EPISODES \
                --log_dir $RUN_DIR \
                --gpu $GPU \
                > $RUN_DIR/train.log 2>&1 &
            # 每 4 个任务暂停一下，避免GPU OOM
            if [ $((CURRENT % 4)) -eq 0 ]; then
                wait
                echo "  [batch done] waiting for next batch..." | tee -a $PROGRESS_LOG
            fi
        done
    done
done

# 等待所有后台任务完成
wait
echo "" | tee -a $PROGRESS_LOG
echo "=== Phase 1 完成 ===" | tee -a $PROGRESS_LOG
echo "结果目录: $LOG_DIR" | tee -a $PROGRESS_LOG
