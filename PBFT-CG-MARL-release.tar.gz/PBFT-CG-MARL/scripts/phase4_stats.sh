#!/bin/bash
# Phase 4: 补跑 MPE seed 4,5 统计显著性实验
# 用途：为 MPE 环境补跑 seed 4 和 seed 5（4种算法），以便做 t-test
# GPU要求：1卡
# 预计耗时：~40分钟（4 algos × 2 seeds × ~5min/run）
# 监控命令：tail -f results/phase1_cross_env/progress_phase4.log
set -e
GPU=${1:-0}
N_TIMESTEPS=${2:-300000}
EVAL_INTERVAL=${3:-10000}
EVAL_EPISODES=10
SEEDS="4 5"
ENV_NAME="mpe_spread"
ENV_CONFIG="configs/env/mpe_spread.yaml"
LOG_DIR=results/phase1_cross_env
PROGRESS_LOG=$LOG_DIR/progress_phase4.log

declare -A ALGO_MAP=(
    ["pbft_additive"]="configs/algo/pbft_additive_v5.yaml"
    ["pbft_mult_matched"]="configs/algo/pbft_mult_matched_v5.yaml"
    ["pbft_mult_mismatched"]="configs/algo/pbft_mult_mismatched_v5.yaml"
    ["mappo"]="configs/algo/mappo_v5.yaml"
)

mkdir -p $LOG_DIR

echo "=== Phase 4: 补跑 MPE seed 4,5 ===" | tee $PROGRESS_LOG
echo "GPU: $GPU" | tee -a $PROGRESS_LOG

TOTAL=$((${#ALGO_MAP[@]} * 2))
CURRENT=0

for algo_name in "${!ALGO_MAP[@]}"; do
    algo_config=${ALGO_MAP[$algo_name]}
    if [ "$algo_name" = "mappo" ]; then
        ALGO_FLAG="--algo mappo"
    else
        ALGO_FLAG="--algo pbft_cg_mappo"
    fi
    for seed in $SEEDS; do
        CURRENT=$((CURRENT + 1))
        RUN_DIR=$LOG_DIR/${ENV_NAME}_${algo_name}_seed${seed}
        mkdir -p $RUN_DIR
        echo "[$CURRENT/$TOTAL] algo=$algo_name seed=$seed" | tee -a $PROGRESS_LOG
        nohup python -u src/train.py \
            $ALGO_FLAG \
            --env $ENV_NAME \
            --env_config $ENV_CONFIG \
            --algo_config $algo_config \
            --seed $seed \
            --n_timesteps $N_TIMESTEPS \
            --eval_interval $EVAL_INTERVAL \
            --eval_episodes $EVAL_EPISODES \
            --log_dir $RUN_DIR \
            --gpu $GPU \
            > $RUN_DIR/train.log 2>&1 &
        if [ $((CURRENT % 4)) -eq 0 ]; then
            wait
            echo "  [batch done]" | tee -a $PROGRESS_LOG
        fi
    done
done

wait
echo "" | tee -a $PROGRESS_LOG
echo "=== Phase 4 完成 ===" | tee -a $PROGRESS_LOG
echo "结果目录: $LOG_DIR" | tee -a $PROGRESS_LOG
