#!/bin/bash
# Phase 3: 敏感性分析 + 消融实验
# 用途：α 敏感性（5个α值 × 3seeds）+ entropy floor 消融（1变体 × 3seeds），环境 MPE
# GPU要求：1卡
# 预计耗时：~1.5小时（6 runs × 3 seeds × ~5min/run）
# 监控命令：tail -f results/phase3_sensitivity/progress.log
set -e
GPU=${1:-0}
N_TIMESTEPS=${2:-300000}
EVAL_INTERVAL=${3:-10000}
EVAL_EPISODES=10
SEEDS="1 2 3"
ENV_NAME="mpe_spread"
ENV_CONFIG="configs/env/mpe_spread.yaml"
LOG_DIR=results/phase3_sensitivity
PROGRESS_LOG=$LOG_DIR/progress.log

# α 敏感性变体
declare -A ALPHA_MAP=(
    ["alpha_001"]="configs/algo/pbft_alpha_001.yaml"
    ["alpha_005"]="configs/algo/pbft_alpha_005.yaml"
    ["alpha_01"]="configs/algo/pbft_alpha_01.yaml"
    ["alpha_05"]="configs/algo/pbft_alpha_05.yaml"
    ["alpha_1"]="configs/algo/pbft_alpha_1.yaml"
)

mkdir -p $LOG_DIR

echo "=== Phase 3: 敏感性分析 + 消融实验 ===" | tee $PROGRESS_LOG
echo "GPU: $GPU" | tee -a $PROGRESS_LOG
echo "环境: $ENV_NAME" | tee -a $PROGRESS_LOG
echo "" | tee -a $PROGRESS_LOG

# --- Part A: α 敏感性 ---
echo "--- Part A: α 敏感性 ---" | tee -a $PROGRESS_LOG
TOTAL_A=$((${#ALPHA_MAP[@]} * 3))
CURRENT=0

for variant_name in "${!ALPHA_MAP[@]}"; do
    algo_config=${ALPHA_MAP[$variant_name]}
    for seed in $SEEDS; do
        CURRENT=$((CURRENT + 1))
        RUN_DIR=$LOG_DIR/alpha_${variant_name}_seed${seed}
        mkdir -p $RUN_DIR
        echo "[A: $CURRENT/$TOTAL_A] variant=$variant_name seed=$seed" | tee -a $PROGRESS_LOG
        nohup python -u src/train.py \
            --algo pbft_cg_mappo \
            --env $ENV_NAME \
            --env_config $ENV_CONFIG \
            --algo_config $algo_config \
            --seed $seed \
            --n_timesteps $N_TIMESTEPS \
            --eval_interval $EVAL_INTERVAL \
            --eval_episodes $EVAL_EPISODES \
            --log_dir $RUN_DIR \
            --gpu $GPU \
            > $RUN_DIR/train.log 2>&1 &
        if [ $((CURRENT % 4)) -eq 0 ]; then
            wait
            echo "  [batch done]" | tee -a $PROGRESS_LOG
        fi
    done
done
wait

# --- Part B: Entropy Floor 消融 ---
echo "--- Part B: Entropy Floor 消融 ---" | tee -a $PROGRESS_LOG
FLOOR_CONFIG="configs/algo/pbft_additive_no_floor_v5.yaml"
for seed in $SEEDS; do
    RUN_DIR=$LOG_DIR/no_floor_seed${seed}
    mkdir -p $RUN_DIR
    echo "[B] no_floor seed=$seed" | tee -a $PROGRESS_LOG
    nohup python -u src/train.py \
        --algo pbft_cg_mappo \
        --env $ENV_NAME \
        --env_config $ENV_CONFIG \
        --algo_config $FLOOR_CONFIG \
        --seed $seed \
        --n_timesteps $N_TIMESTEPS \
        --eval_interval $EVAL_INTERVAL \
        --eval_episodes $EVAL_EPISODES \
        --log_dir $RUN_DIR \
        --gpu $GPU \
        > $RUN_DIR/train.log 2>&1 &
done

wait
echo "" | tee -a $PROGRESS_LOG
echo "=== Phase 3 完成 ===" | tee -a $PROGRESS_LOG
echo "结果目录: $LOG_DIR" | tee -a $PROGRESS_LOG
