#!/bin/bash
set -e
cd /root/autodl-tmp/PBFT-CG-MARL
PYTHON=/root/miniconda3/bin/python3
GPU_ID=0
LOG_DIR=results/mappo_byzantine_baseline
mkdir -p $LOG_DIR
echo "MAPPO Byzantine Baseline - Start: $(date)"
for ATTACK in random adversarial; do
    for SEED in 1 2 3; do
        RUN_DIR=$LOG_DIR/mpe_spread_mappo_${ATTACK}_seed${SEED}
        mkdir -p $RUN_DIR
        echo "[MPE] mappo ${ATTACK} seed=${SEED} at $(date)"
        $PYTHON -u src/train.py --algo mappo --env mpe_spread --env_config configs/env/mpe_spread.yaml --algo_config configs/algo/mappo_v5.yaml --seed ${SEED} --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $RUN_DIR --byzantine_n 1 --byzantine_type ${ATTACK} --gpu ${GPU_ID}
    done
done
for ATTACK in random adversarial; do
    for SEED in 1 2 3; do
        RUN_DIR=$LOG_DIR/smaclite_5m_vs_6m_mappo_${ATTACK}_seed${SEED}
        mkdir -p $RUN_DIR
        echo "[SMAClite] mappo ${ATTACK} seed=${SEED} at $(date)"
        $PYTHON -u src/train.py --algo mappo --env smaclite_5m_vs_6m --env_config configs/env/smaclite_5m_vs_6m.yaml --algo_config configs/algo/mappo_v5.yaml --seed ${SEED} --n_timesteps 1000000 --eval_interval 20000 --eval_episodes 10 --log_dir $RUN_DIR --byzantine_n 1 --byzantine_type ${ATTACK} --gpu ${GPU_ID}
    done
done
for ATTACK in random adversarial; do
    for SEED in 1 2 3; do
        RUN_DIR=$LOG_DIR/vmas_uav_coverage_mappo_${ATTACK}_seed${SEED}
        mkdir -p $RUN_DIR
        echo "[VMAS] mappo ${ATTACK} seed=${SEED} at $(date)"
        $PYTHON -u src/train.py --algo mappo --env vmas_uav_coverage --env_config configs/env/vmas_uav_coverage.yaml --algo_config configs/algo/mappo_v5.yaml --seed ${SEED} --n_timesteps 500000 --eval_interval 10000 --eval_episodes 10 --log_dir $RUN_DIR --byzantine_n 1 --byzantine_type ${ATTACK} --gpu ${GPU_ID}
    done
done
echo "ALL DONE at $(date)"
