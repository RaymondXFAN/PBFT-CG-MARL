#!/bin/bash
# ============================================================
# PBFT-CG-MARL v3 实验矩阵
# 修复审稿意见后的完整实验方案
#
# 实验分4个Phase：
#   Phase 0: Clean基线（无攻击）—— 证明过滤器不添乱
#   Phase 1: 消息级攻击（核心！）—— PBFT真正能防御的攻击
#   Phase 2: 动作级攻击（对照组）—— 保留旧版数据
#   Phase 3: EIR-MAPPO基线 —— Related Work里写了的对比方法
#
# 每个 (env, attack_type, algorithm) 跑 5 seeds
# 总计: 3 envs × 7 conditions × 5 seeds × 2 algos = 210 runs
# 但很多已有数据可以复用，实际新跑约 60-80 runs
# ============================================================

set -e

GPU_ID=${1:-0}
LOG_BASE="results/v3_final"
SEEDS="1 2 3 4 5"

echo "============================================"
echo "PBFT-CG-MARL v3 完整实验矩阵"
echo "GPU: ${GPU_ID}"
echo "Seeds: ${SEEDS}"
echo "============================================"

# ============================================================
# Phase 0: Clean Baseline（无攻击）
# 审稿意见：没有clean条件无法证明"过滤器在无攻击时不添乱"
# ============================================================
echo ""
echo "=== Phase 0: Clean Baseline ==="

# MAPPO clean (3 envs × 5 seeds = 15 runs)
for ENV in mpe_spread smaclite_5m_vs_6m vmas_uav_coverage; do
    for SEED in ${SEEDS}; do
        echo "[Phase0] mappo ${ENV} seed=${SEED}"
        python -u src/train.py \
            --algo mappo --env ${ENV} \
            --env_config configs/env/${ENV}.yaml \
            --algo_config configs/algo/mappo_v5.yaml \
            --seed ${SEED} --n_timesteps 300000 \
            --eval_interval 10000 --eval_episodes 10 \
            --log_dir ${LOG_BASE}/clean/${ENV}_mappo_seed${SEED} \
            --gpu ${GPU_ID}
    done
done

# PBFT-CG-MAPPO clean (3 envs × 5 seeds = 15 runs)
for ENV in mpe_spread smaclite_5m_vs_6m vmas_uav_coverage; do
    for SEED in ${SEEDS}; do
        echo "[Phase0] pbft ${ENV} seed=${SEED}"
        python -u src/train.py \
            --algo pbft_cg_mappo --env ${ENV} \
            --env_config configs/env/${ENV}.yaml \
            --algo_config configs/algo/pbft_cg_mappo_v5.yaml \
            --seed ${SEED} --n_timesteps 300000 \
            --eval_interval 10000 --eval_episodes 10 \
            --log_dir ${LOG_BASE}/clean/${ENV}_pbft_seed${SEED} \
            --gpu ${GPU_ID}
    done
done

# ============================================================
# Phase 1: 消息级攻击（核心！修复攻击面错位）
# 这些攻击真正经过PBFT共识过滤
# ============================================================
echo ""
echo "=== Phase 1: Message-Level Attacks ==="

MSG_ATTACKS="message_forge message_conflict message_silent"

for ENV in mpe_spread smaclite_5m_vs_6m vmas_uav_coverage; do
    for ATTACK in ${MSG_ATTACKS}; do
        # PBFT-CG-MAPPO with message attack (3 envs × 3 attacks × 5 seeds = 45 runs)
        for SEED in ${SEEDS}; do
            echo "[Phase1] pbft ${ENV} ${ATTACK} seed=${SEED}"
            python -u src/train.py \
                --algo pbft_cg_mappo --env ${ENV} \
                --env_config configs/env/${ENV}.yaml \
                --algo_config configs/algo/pbft_cg_mappo_v5.yaml \
                --seed ${SEED} --n_timesteps 300000 \
                --eval_interval 10000 --eval_episodes 10 \
                --log_dir ${LOG_BASE}/msg_attack/${ENV}_pbft_${ATTACK}_seed${SEED} \
                --byzantine_n 1 --byzantine_type ${ATTACK} \
                --gpu ${GPU_ID}
        done
        
        # MAPPO with message attack (对照组: 无保护下消息级攻击的效果)
        for SEED in ${SEEDS}; do
            echo "[Phase1] mappo ${ENV} ${ATTACK} seed=${SEED}"
            python -u src/train.py \
                --algo mappo --env ${ENV} \
                --env_config configs/env/${ENV}.yaml \
                --algo_config configs/algo/mappo_v5.yaml \
                --seed ${SEED} --n_timesteps 300000 \
                --eval_interval 10000 --eval_episodes 10 \
                --log_dir ${LOG_BASE}/msg_attack/${ENV}_mappo_${ATTACK}_seed${SEED} \
                --byzantine_n 1 --byzantine_type ${ATTACK} \
                --gpu ${GPU_ID}
        done
    done
done

# ============================================================
# Phase 2: 动作级攻击（保留旧版数据作为对比）
# 这些攻击不经过PBFT过滤（审稿人已指出的问题）
# 数据可复用 v2 的 18 runs，但需要扩展到 5 seeds
# ============================================================
echo ""
echo "=== Phase 2: Action-Level Attacks (对照组) ==="

ACT_ATTACKS="random adversarial"

for ENV in mpe_spread smaclite_5m_vs_6m vmas_uav_coverage; do
    for ATTACK in ${ACT_ATTACKS}; do
        for SEED in 4 5; do  # 只跑seed4,5（seed1-3已有v2数据）
            echo "[Phase2] mappo ${ENV} ${ATTACK} seed=${SEED}"
            python -u src/train.py \
                --algo mappo --env ${ENV} \
                --env_config configs/env/${ENV}.yaml \
                --algo_config configs/algo/mappo_v5.yaml \
                --seed ${SEED} --n_timesteps 300000 \
                --eval_interval 10000 --eval_episodes 10 \
                --log_dir ${LOG_BASE}/act_attack/${ENV}_mappo_${ATTACK}_seed${SEED} \
                --byzantine_n 1 --byzantine_type ${ATTACK} \
                --gpu ${GPU_ID}
        done
    done
done

echo ""
echo "============================================"
echo "全部实验完成！"
echo "结果目录: ${LOG_BASE}"
echo "============================================"
