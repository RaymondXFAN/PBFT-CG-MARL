#!/bin/bash
# Phase 5: SOTA Baseline 对比 (Krum / TrimmedMean)
# 用途：在3个环境上跑 Krum 和 TrimmedMean baseline，各3 seeds
# GPU要求：1卡
# 预计耗时：~1.5小时（2 baselines × 3 envs × 3 seeds × ~5min/run）
# 监控命令：tail -f results/phase5_sota/progress.log
set -e
GPU=${1:-0}
N_TIMESTEPS=${2:-300000}
EVAL_INTERVAL=${3:-10000}
EVAL_EPISODES=10
SEEDS="1 2 3"
LOG_DIR=results/phase5_sota
PROGRESS_LOG=$LOG_DIR/progress.log

# 环境
declare -A ENV_MAP=(
    ["mpe_spread"]="configs/env/mpe_spread.yaml"
    ["smaclite_5m_vs_6m"]="configs/env/smaclite_5m_vs_6m.yaml"
    ["vmas_uav_coverage"]="configs/env/vmas_uav_coverage.yaml"
)

# Baselines
BASELINES=("krum" "trimmed_mean")

mkdir -p $LOG_DIR

echo "=== Phase 5: SOTA Baseline 对比 ===" | tee $PROGRESS_LOG
echo "GPU: $GPU" | tee -a $PROGRESS_LOG
echo "Baselines: ${BASELINES[@]}" | tee -a $PROGRESS_LOG
echo "" | tee -a $PROGRESS_LOG

TOTAL=$((2 * ${#ENV_MAP[@]} * 3))
CURRENT=0

for baseline in "${BASELINES[@]}"; do
    for env_name in "${!ENV_MAP[@]}"; do
        env_config=${ENV_MAP[$env_name]}
        for seed in $SEEDS; do
            CURRENT=$((CURRENT + 1))
            RUN_DIR=$LOG_DIR/${env_name}_${baseline}_seed${seed}
            mkdir -p $RUN_DIR
            echo "[$CURRENT/$TOTAL] baseline=$baseline env=$env_name seed=$seed" | tee -a $PROGRESS_LOG
            nohup python -u src/train.py \
                --algo pbft_cg_mappo \
                --env $env_name \
                --env_config $env_config \
                --algo_config configs/algo/pbft_additive_v5.yaml \
                --seed $seed \
                --n_timesteps $N_TIMESTEPS \
                --eval_interval $EVAL_INTERVAL \
                --eval_episodes $EVAL_EPISODES \
                --log_dir $RUN_DIR \
                --gpu $GPU \
                --defense_type $baseline \
                > $RUN_DIR/train.log 2>&1 &
            if [ $((CURRENT % 4)) -eq 0 ]; then
                wait
                echo "  [batch done]" | tee -a $PROGRESS_LOG
            fi
        done
    done
done

wait
echo "" | tee -a $PROGRESS_LOG
echo "=== Phase 5 完成 ===" | tee -a $PROGRESS_LOG
echo "结果目录: $LOG_DIR" | tee -a $PROGRESS_LOG
