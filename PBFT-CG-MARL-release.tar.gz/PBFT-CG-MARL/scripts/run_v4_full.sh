#!/bin/bash
# ============================================================
# PBFT-CG-MARL v4 完整实验脚本
# Phase 1-v4: 3 seeds × 2 algorithms × 300K 步
# 预计耗时：约 2-3 小时
# ============================================================

set -e

GPU_ID=${1:-0}
LOG_DIR="results/v4_full"
SEEDS="1 2 3"
N_TIMESTEPS=300000
EVAL_INTERVAL=10000
EVAL_EPISODES=10

echo "============================================"
echo "PBFT-CG-MARL v4 完整实验"
echo "GPU: ${GPU_ID}"
echo "日志目录: ${LOG_DIR}"
echo "Seeds: ${SEEDS}"
echo "============================================"

# PBFT-CG-MAPPO v4
for SEED in ${SEEDS}; do
    echo ""
    echo "=== pbft_cg_mappo_v4 seed=${SEED} ==="
    python -u src/train.py \
        --algo pbft_cg_mappo \
        --env mpe_spread \
        --env_config configs/env/mpe_spread.yaml \
        --algo_config configs/algo/pbft_cg_mappo_v4.yaml \
        --seed ${SEED} \
        --n_timesteps ${N_TIMESTEPS} \
        --eval_interval ${EVAL_INTERVAL} \
        --eval_episodes ${EVAL_EPISODES} \
        --log_dir ${LOG_DIR} \
        --gpu ${GPU_ID}
done

# MAPPO v4 对照组
for SEED in ${SEEDS}; do
    echo ""
    echo "=== mappo_v4 seed=${SEED} ==="
    python -u src/train.py \
        --algo mappo \
        --env mpe_spread \
        --env_config configs/env/mpe_spread.yaml \
        --algo_config configs/algo/mappo_v4.yaml \
        --seed ${SEED} \
        --n_timesteps ${N_TIMESTEPS} \
        --eval_interval ${EVAL_INTERVAL} \
        --eval_episodes ${EVAL_EPISODES} \
        --log_dir ${LOG_DIR} \
        --gpu ${GPU_ID}
done

echo ""
echo "============================================"
echo "v4 完整实验完成！"
echo "结果目录: ${LOG_DIR}"
echo ""
echo "下一步：运行诊断脚本"
echo "  python scripts/diagnose_v4.py --log_dir ${LOG_DIR}"
echo "============================================"
