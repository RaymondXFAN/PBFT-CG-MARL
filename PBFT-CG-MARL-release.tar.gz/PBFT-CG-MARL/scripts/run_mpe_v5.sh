#!/bin/bash
set -e
PYTHON="/root/miniconda3/bin/python"
BASE="/root/autodl-tmp/PBFT-CG-MARL"
LOG="/root/autodl-tmp/PBFT-CG-MARL/results/v5_formal"
ACFG_P="$BASE/configs/algo/pbft_cg_mappo_v4.yaml"
ACFG_M="$BASE/configs/algo/mappo_v4_clean.yaml"

echo "=== v5 Formal MPE (separate optimizer, 4-way parallel) === $(date)"
mkdir -p $LOG

run_one() {
    local TAG=$1 ALGO=$2 ACFG=$3 S=$4 EXTRA=$5
    local DIR="$LOG/mpe_$(echo $TAG | tr '+' '_' | tr '[:upper:]' '[:lower:]')_seed$S"
    if [ -f "$DIR/$ALGO/seed_$S/metrics.json" ]; then
        echo "[SKIP] $TAG s=$S"
        return
    fi
    echo "[$TAG s=$S] start $(date +%H:%M:%S)"
    $PYTHON -u $BASE/src/train.py --algo $ALGO --env mpe_spread \
        --env_config $BASE/configs/env/mpe_spread.yaml --algo_config $ACFG \
        --seed $S --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 \
        --log_dir $DIR $EXTRA --gpu 0
    echo "[$TAG s=$S] done $(date +%H:%M:%S)"
}

# Phase 1: PBFT+forge
for S in 1 2 3 4; do
    run_one "PBFT+forge" pbft_cg_mappo $ACFG_P $S "--byzantine_n 1 --byzantine_type message_forge" &
done
wait
run_one "PBFT+forge" pbft_cg_mappo $ACFG_P 5 "--byzantine_n 1 --byzantine_type message_forge"
echo "=== PBFT+forge done === $(date)"

# Phase 2: MAPPO+forge
for S in 1 2 3 4; do
    run_one "MAPPO+forge" mappo $ACFG_M $S "--byzantine_n 1 --byzantine_type message_forge" &
done
wait
run_one "MAPPO+forge" mappo $ACFG_M 5 "--byzantine_n 1 --byzantine_type message_forge"
echo "=== MAPPO+forge done === $(date)"

# Phase 3: PBFT+clean
for S in 1 2 3 4; do
    run_one "PBFT+clean" pbft_cg_mappo $ACFG_P $S "" &
done
wait
run_one "PBFT+clean" pbft_cg_mappo $ACFG_P 5 ""
echo "=== PBFT+clean done === $(date)"

# Phase 4: MAPPO+clean
for S in 1 2 3 4; do
    run_one "MAPPO+clean" mappo $ACFG_M $S "" &
done
wait
run_one "MAPPO+clean" mappo $ACFG_M 5 ""
echo "=== MAPPO+clean done === $(date)"

echo "=== ALL v5 EXPERIMENTS COMPLETE === $(date)"
