#!/bin/bash
# N=5 安全并行实验 - 每批4个进程，跑完再启动下一批
# 总共16个seed待跑（PBFT+forge s5 已完成s1-4）

set -e
PYTHON="/root/miniconda3/bin/python"
BASE="/root/autodl-tmp/PBFT-CG-MARL"
LOG="$BASE/results/v5_n5"
ACFG_P="$BASE/configs/algo/pbft_cg_mappo_v4.yaml"
ACFG_M="$BASE/configs/algo/mappo_v4_clean.yaml"
ECFG="$BASE/configs/env/mpe_spread_n5.yaml"
PARALLEL=4  # 每批4个进程

echo "=== N=5 SAFE PARALLEL (4-way) === $(date)"
mkdir -p $LOG

run_one() {
    local TAG=$1 ALGO=$2 ACFG=$3 S=$4 EXTRA=$5
    local DIR="$LOG/mpe_$(echo $TAG | tr '+' '_' | tr '[:upper:]' '[:lower:]')_seed$S"
    # 跳过已完成（>1000 episodes = 完整300K）
    if [ -f "$DIR/$ALGO/seed_$S/metrics.json" ]; then
        local REW_LEN=$($PYTHON -c "import json; m=json.load(open('$DIR/$ALGO/seed_$S/metrics.json')); print(len(m.get('episode/episode_reward',[])))" 2>/dev/null || echo 0)
        if [ "$REW_LEN" -gt 1000 ]; then
            echo "[SKIP] $TAG s=$S (done)"
            return 0
        fi
        echo "[DEL] $TAG s=$S (incomplete $REW_LEN ep, redo)"
        rm -rf "$DIR"
    fi
    echo "[$TAG s=$S] start $(date +%H:%M:%S)"
    $PYTHON -u $BASE/src/train.py --algo $ALGO --env mpe_spread         --env_config $ECFG --algo_config $ACFG         --seed $S --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10         --log_dir $DIR $EXTRA --gpu 0
    echo "[$TAG s=$S] done $(date +%H:%M:%S)"
}

# 定义所有待跑任务（TAG ALGO ACFG SEED EXTRA）
TASKS=(
    "PBFT+forge pbft_cg_mappo $ACFG_P 5 --byzantine_n 1 --byzantine_type message_forge"
    "MAPPO+forge mappo $ACFG_M 1 --byzantine_n 1 --byzantine_type message_forge"
    "MAPPO+forge mappo $ACFG_M 2 --byzantine_n 1 --byzantine_type message_forge"
    "MAPPO+forge mappo $ACFG_M 3 --byzantine_n 1 --byzantine_type message_forge"
    "MAPPO+forge mappo $ACFG_M 4 --byzantine_n 1 --byzantine_type message_forge"
    "MAPPO+forge mappo $ACFG_M 5 --byzantine_n 1 --byzantine_type message_forge"
    "PBFT+clean pbft_cg_mappo $ACFG_P 1"
    "PBFT+clean pbft_cg_mappo $ACFG_P 2"
    "PBFT+clean pbft_cg_mappo $ACFG_P 3"
    "PBFT+clean pbft_cg_mappo $ACFG_P 4"
    "PBFT+clean pbft_cg_mappo $ACFG_P 5"
    "MAPPO+clean mappo $ACFG_M 1"
    "MAPPO+clean mappo $ACFG_M 2"
    "MAPPO+clean mappo $ACFG_M 3"
    "MAPPO+clean mappo $ACFG_M 4"
    "MAPPO+clean mappo $ACFG_M 5"
)

# 分批执行
TOTAL=${#TASKS[@]}
BATCH=0
DONE=0
while [ $DONE -lt $TOTAL ]; do
    BATCH=$((BATCH+1))
    echo ""
    echo "=== BATCH $BATCH (tasks $DONE-$((DONE+PARALLEL-1)) of $TOTAL) === $(date +%H:%M:%S)"
    PIDS=()
    COUNT=0
    for i in $(seq $DONE $((DONE+PARALLEL-1))); do
        [ $i -ge $TOTAL ] && break
        # 解析任务（空格分隔，EXTRA可能是多个参数）
        TASK_LINE="${TASKS[$i]}"
        # 用bash数组解析
        eval "TASK_ARR=($TASK_LINE)"
        TAG="${TASK_ARR[0]}"
        ALGO="${TASK_ARR[1]}"
        ACFG="${TASK_ARR[2]}"
        SEED="${TASK_ARR[3]}"
        # EXTRA = 第5个参数起
        EXTRA="${TASK_ARR[*]:4}"
        
        run_one "$TAG" "$ALGO" "$ACFG" "$SEED" "$EXTRA" &
        PIDS+=($!)
        COUNT=$((COUNT+1))
    done
    
    # 等当前批次全部完成
    for PID in "${PIDS[@]}"; do
        wait $PID 2>/dev/null || true
    done
    
    DONE=$((DONE+COUNT))
    echo "=== BATCH $BATCH done, progress: $DONE/$TOTAL === $(date +%H:%M:%S)"
done

echo ""
echo "=== ALL N=5 EXPERIMENTS COMPLETE ($TOTAL tasks) === $(date)"
