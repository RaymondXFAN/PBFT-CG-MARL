#!/bin/bash
# N=5并行实验 - 4条件同时跑，每条件4seed并行+1seed串行
# 无依赖关系，所有条件同时启动

set -e
PYTHON="/root/miniconda3/bin/python"
BASE="/root/autodl-tmp/PBFT-CG-MARL"
LOG="$BASE/results/v5_n5"
ACFG_P="$BASE/configs/algo/pbft_cg_mappo_v4.yaml"
ACFG_M="$BASE/configs/algo/mappo_v4_clean.yaml"
ECFG="$BASE/configs/env/mpe_spread_n5.yaml"

echo "=== N=5 PARALLEL ALL CONDITIONS === $(date)"
mkdir -p $LOG

run_one() {
    local TAG=$1 ALGO=$2 ACFG=$3 S=$4 EXTRA=$5
    local DIR="$LOG/mpe_$(echo $TAG | tr '+' '_' | tr '[:upper:]' '[:lower:]')_seed$S"
    # 防覆盖：已完成的metrics.json存在就跳过
    if [ -f "$DIR/$ALGO/seed_$S/metrics.json" ]; then
        # 检查是否是完整实验（episode_reward长度>1000 = 300K步）
        local REW_LEN=$($PYTHON -c "import json; m=json.load(open('$DIR/$ALGO/seed_$S/metrics.json')); print(len(m.get('episode/episode_reward',[])))" 2>/dev/null || echo 0)
        if [ "$REW_LEN" -gt 1000 ]; then
            echo "[SKIP] $TAG s=$S (complete, $REW_LEN episodes)"
            return
        else
            echo "[DELETE] $TAG s=$S (incomplete, $REW_LEN episodes, re-running)"
            rm -rf "$DIR"
        fi
    fi
    echo "[$TAG s=$S] start $(date +%H:%M:%S)"
    $PYTHON -u $BASE/src/train.py --algo $ALGO --env mpe_spread         --env_config $ECFG --algo_config $ACFG         --seed $S --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10         --log_dir $DIR $EXTRA --gpu 0
    echo "[$TAG s=$S] done $(date +%H:%M:%S)"
}

# ============ 全部4条件同时启动 ============

# PBFT+forge: s1-4已完成，只跑s5
run_one "PBFT+forge" pbft_cg_mappo $ACFG_P 5 "--byzantine_n 1 --byzantine_type message_forge" &
PIDs_pf="$!"

# MAPPO+forge: 全部5个seed
for S in 1 2 3 4; do
    run_one "MAPPO+forge" mappo $ACFG_M $S "--byzantine_n 1 --byzantine_type message_forge" &
done
run_one "MAPPO+forge" mappo $ACFG_M 5 "--byzantine_n 1 --byzantine_type message_forge" &
PIDs_mf="$!"

# PBFT+clean: 全部5个seed
for S in 1 2 3 4; do
    run_one "PBFT+clean" pbft_cg_mappo $ACFG_P $S "" &
done
run_one "PBFT+clean" pbft_cg_mappo $ACFG_P 5 "" &
PIDs_pc="$!"

# MAPPO+clean: 全部5个seed
for S in 1 2 3 4; do
    run_one "MAPPO+clean" mappo $ACFG_M $S "" &
done
run_one "MAPPO+clean" mappo $ACFG_M 5 "" &
PIDs_mc="$!"

# 等所有完成
wait
echo "=== ALL N=5 EXPERIMENTS COMPLETE === $(date)"
