#!/bin/bash
set -e
cd /root/autodl-tmp/PBFT-CG-MARL
PYTHON=/root/miniconda3/bin/python3
GPU=0
LOG=results/mappo_byzantine_baseline
mkdir -p $LOG
echo "MAPPO Byzantine Baseline (with env-level attack) - Start: $(date)"

run_mpe_vmas() {
  for ATTACK in random adversarial; do
    for SEED in 1 2 3; do
      D=$LOG/mpe_spread_mappo_${ATTACK}_seed${SEED}
      mkdir -p $D
      echo "[MPE] ${ATTACK} s${SEED} $(date)"
      $PYTHON -u src/train.py --algo mappo --env mpe_spread --env_config configs/env/mpe_spread.yaml --algo_config configs/algo/mappo_v5.yaml --seed ${SEED} --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 --log_dir $D --byzantine_n 1 --byzantine_type ${ATTACK} --gpu ${GPU}
    done
  done
  for ATTACK in random adversarial; do
    for SEED in 1 2 3; do
      D=$LOG/vmas_uav_coverage_mappo_${ATTACK}_seed${SEED}
      mkdir -p $D
      echo "[VMAS] ${ATTACK} s${SEED} $(date)"
      $PYTHON -u src/train.py --algo mappo --env vmas_uav_coverage --env_config configs/env/vmas_uav_coverage.yaml --algo_config configs/algo/mappo_v5.yaml --seed ${SEED} --n_timesteps 500000 --eval_interval 10000 --eval_episodes 10 --log_dir $D --byzantine_n 1 --byzantine_type ${ATTACK} --gpu ${GPU}
    done
  done
}

run_smaclite() {
  for ATTACK in random adversarial; do
    for SEED in 1 2 3; do
      D=$LOG/smaclite_5m_vs_6m_mappo_${ATTACK}_seed${SEED}
      mkdir -p $D
      echo "[SMAClite] ${ATTACK} s${SEED} $(date)"
      $PYTHON -u src/train.py --algo mappo --env smaclite_5m_vs_6m --env_config configs/env/smaclite_5m_vs_6m.yaml --algo_config configs/algo/mappo_v5.yaml --seed ${SEED} --n_timesteps 1000000 --eval_interval 20000 --eval_episodes 10 --log_dir $D --byzantine_n 1 --byzantine_type ${ATTACK} --gpu ${GPU}
    done
  done
}

run_smaclite &
PID_SMAC=$!
run_mpe_vmas
wait $PID_SMAC

echo "ALL DONE at $(date)"
