#!/bin/bash
# 自动监控：SMAClite adv s1+s2 完成后自动启动 s3，s3 完成后启动 VMAS s3
cd /root/autodl-tmp/PBFT-CG-MARL
PYTHON=/root/miniconda3/bin/python3
LOG=results/mappo_byzantine_baseline

echo "[Monitor] Start: $(date)"

# 等待 seed1 完成
while ! test -f $LOG/smaclite_5m_vs_6m_mappo_adversarial_seed1/mappo/seed_1/metrics.json; do
    sleep 60
done
echo "[Monitor] SMAClite adv seed1 DONE at $(date)"

# 启动 seed3
echo "[Monitor] Launching SMAClite adv seed3..."
mkdir -p $LOG/smaclite_5m_vs_6m_mappo_adversarial_seed3
$PYTHON -u src/train.py --algo mappo --env smaclite_5m_vs_6m --env_config configs/env/smaclite_5m_vs_6m.yaml --algo_config configs/algo/mappo_v5.yaml --seed 3 --n_timesteps 1000000 --eval_interval 20000 --eval_episodes 10 --log_dir $LOG/smaclite_5m_vs_6m_mappo_adversarial_seed3 --byzantine_n 1 --byzantine_type adversarial --gpu 0
echo "[Monitor] SMAClite adv seed3 DONE at $(date)"

# 启动 VMAS adv seed3
echo "[Monitor] Launching VMAS adv seed3..."
mkdir -p $LOG/vmas_uav_coverage_mappo_adversarial_seed3
$PYTHON -u src/train.py --algo mappo --env vmas_uav_coverage --env_config configs/env/vmas_uav_coverage.yaml --algo_config configs/algo/mappo_v5.yaml --seed 3 --n_timesteps 500000 --eval_interval 10000 --eval_episodes 10 --log_dir $LOG/vmas_uav_coverage_mappo_adversarial_seed3 --byzantine_n 1 --byzantine_type adversarial --gpu 0
echo "[Monitor] VMAS adv seed3 DONE at $(date)"

echo "[Monitor] ALL DONE at $(date)"
