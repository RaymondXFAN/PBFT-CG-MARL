#!/root/miniconda3/bin/python3
"""终极修复 train.py - 硬编码4空格缩进"""
path = "/root/autodl-tmp/PBFT-CG-MARL/src/train.py"

with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

# 目标替换块（原始代码，无缩进，各种变体都试）
variants = [
    # 变体1：无缩进
    """# 注入拜占庭Agent (v4.5)
if args.byzantine_n > 0:
if hasattr(algorithm, "inject_proposal_byzantine"):
byz_ids = list(range(args.byzantine_n))
algorithm.inject_proposal_byzantine(byz_ids, args.byzantine_type)
elif hasattr(algorithm, "inject_byzantine"):
algorithm.inject_byzantine(args.byzantine_n, args.byzantine_type)
print(f"[v4.5] injected {args.byzantine_n} byzantine agents (type: {args.byzantine_type})")""",
    # 变体2：原始v3代码
    """    if args.byzantine_n > 0 and hasattr(algorithm, "inject_byzantine"):
        algorithm.inject_byzantine(args.byzantine_n, args.byzantine_type)
        print(f"已注入 {args.byzantine_n} 个拜占庭Agent (类型: {args.byzantine_type})")""",
    # 变体3：原始v3代码带注释
    """# 注入拜占庭Agent
    if args.byzantine_n > 0 and hasattr(algorithm, "inject_byzantine"):
        algorithm.inject_byzantine(args.byzantine_n, args.byzantine_type)
        print(f"已注入 {args.byzantine_n} 个拜占庭Agent (类型: {args.byzantine_type})")""",
]

# 正确的新代码（4空格缩进）
new_code = """    # 注入拜占庭Agent (v4.5: 优先提案层注入)
    if args.byzantine_n > 0:
        if hasattr(algorithm, "inject_proposal_byzantine"):
            byz_ids = list(range(args.byzantine_n))
            algorithm.inject_proposal_byzantine(byz_ids, args.byzantine_type)
        elif hasattr(algorithm, "inject_byzantine"):
            algorithm.inject_byzantine(args.byzantine_n, args.byzantine_type)
        print(f"[v4.5] injected {args.byzantine_n} byzantine agents (type: {args.byzantine_type})")"""

replaced = False
for v in variants:
    if v in content:
        content = content.replace(v, new_code)
        replaced = True
        print(f"OK - replaced variant")
        break

if not replaced:
    # 终极方案：按行搜索替换
    lines = content.split('\n')
    new_lines = []
    skip_until_packet_loss = False
    for line in lines:
        if skip_until_packet_loss:
            if '注入丢包模型' in line or 'packet_loss_model' in line:
                skip_until_packet_loss = False
                new_lines.append(line)
            continue
        if '注入拜占庭Agent' in line or ('byzantine_n' in line and 'inject_byzantine' in line and 'if' in line and 'inject_proposal' not in line):
            skip_until_packet_loss = True
            new_lines.append('    # 注入拜占庭Agent (v4.5: 优先提案层注入)')
            new_lines.append('    if args.byzantine_n > 0:')
            new_lines.append('        if hasattr(algorithm, "inject_proposal_byzantine"):')
            new_lines.append('            byz_ids = list(range(args.byzantine_n))')
            new_lines.append('            algorithm.inject_proposal_byzantine(byz_ids, args.byzantine_type)')
            new_lines.append('        elif hasattr(algorithm, "inject_byzantine"):')
            new_lines.append('            algorithm.inject_byzantine(args.byzantine_n, args.byzantine_type)')
            new_lines.append('        print(f"[v4.5] injected {args.byzantine_n} byzantine agents (type: {args.byzantine_type}")')
            continue
        if 'inject_proposal_byzantine' in line or 'inject_byzantine' in line or 'byzantine_type' in line:
            if 'packet_loss' not in line and 'parser' not in line and 'add_argument' not in line:
                continue  # 跳过残留的旧行
        new_lines.append(line)
    content = '\n'.join(new_lines)
    replaced = True
    print("OK - line-by-line fix")

with open(path, 'w', encoding='utf-8') as f:
    f.write(content)

# 验证
import py_compile
try:
    py_compile.compile(path, doraise=True)
    print("✅ 语法OK")
except py_compile.PyCompileError as e:
    print(f"❌ 语法错误: {e}")
