#!/bin/bash
# ============================================================
# PBFT-CG-MARL 过夜实验脚本
# 3 条件 × 2 算法 × 3 seeds × 300K步 = 18 个实验
# 预计耗时：约 5-6 小时
# ============================================================

set -e

GPU_ID=${1:-0}
PYTHON=/root/miniconda3/bin/python3
N_TIMESTEPS=300000
EVAL_INTERVAL=10000
EVAL_EPISODES=10
SEEDS="1 2 3"

echo "============================================"
echo "PBFT-CG-MARL 过夜实验"
echo "GPU: ${GPU_ID}"
echo "Python: ${PYTHON}"
echo "开始时间: $(date)"
echo "============================================"

# ============================================
# Phase 1: 干净环境（无拜占庭攻击）
# ============================================
echo ""
echo "========== Phase 1: 干净环境 =========="
echo "开始时间: $(date)"

# PBFT v4.2 干净环境
for SEED in ${SEEDS}; do
    echo ""
    echo "[1/18] PBFT v4.2 clean seed=${SEED}"
    ${PYTHON} -u src/train.py \
        --algo pbft_cg_mappo --env mpe_spread \
        --env_config configs/env/mpe_spread.yaml \
        --algo_config configs/algo/pbft_cg_mappo_v42.yaml \
        --seed ${SEED} --n_timesteps ${N_TIMESTEPS} \
        --eval_interval ${EVAL_INTERVAL} --eval_episodes ${EVAL_EPISODES} \
        --log_dir results/v42_full_clean --gpu ${GPU_ID}
done

# MAPPO v4.2 干净环境
for SEED in ${SEEDS}; do
    echo ""
    echo "[2/18] MAPPO v4.2 clean seed=${SEED}"
    ${PYTHON} -u src/train.py \
        --algo mappo --env mpe_spread \
        --env_config configs/env/mpe_spread.yaml \
        --algo_config configs/algo/mappo_v42.yaml \
        --seed ${SEED} --n_timesteps ${N_TIMESTEPS} \
        --eval_interval ${EVAL_INTERVAL} --eval_episodes ${EVAL_EPISODES} \
        --log_dir results/v42_full_clean --gpu ${GPU_ID}
done

echo "Phase 1 完成: $(date)"

# ============================================
# Phase 2: 对抗性拜占庭攻击（adversarial, 1 agent）
# ============================================
echo ""
echo "========== Phase 2: 对抗性拜占庭攻击 =========="
echo "开始时间: $(date)"

# PBFT v4.2 + adversarial
for SEED in ${SEEDS}; do
    echo ""
    echo "[3/18] PBFT v4.2 adversarial seed=${SEED}"
    ${PYTHON} -u src/train.py \
        --algo pbft_cg_mappo --env mpe_spread \
        --env_config configs/env/mpe_spread.yaml \
        --algo_config configs/algo/pbft_cg_mappo_v42.yaml \
        --seed ${SEED} --n_timesteps ${N_TIMESTEPS} \
        --eval_interval ${EVAL_INTERVAL} --eval_episodes ${EVAL_EPISODES} \
        --byzantine_n 1 --byzantine_type adversarial \
        --log_dir results/v42_full_adv --gpu ${GPU_ID}
done

# MAPPO + adversarial
for SEED in ${SEEDS}; do
    echo ""
    echo "[4/18] MAPPO adversarial seed=${SEED}"
    ${PYTHON} -u src/train.py \
        --algo mappo --env mpe_spread \
        --env_config configs/env/mpe_spread.yaml \
        --algo_config configs/algo/mappo_v42.yaml \
        --seed ${SEED} --n_timesteps ${N_TIMESTEPS} \
        --eval_interval ${EVAL_INTERVAL} --eval_episodes ${EVAL_EPISODES} \
        --byzantine_n 1 --byzantine_type adversarial \
        --log_dir results/v42_full_adv --gpu ${GPU_ID}
done

echo "Phase 2 完成: $(date)"

# ============================================
# Phase 3: 随机拜占庭攻击（random, 1 agent）
# ============================================
echo ""
echo "========== Phase 3: 随机拜占庭攻击 =========="
echo "开始时间: $(date)"

# PBFT v4.2 + random
for SEED in ${SEEDS}; do
    echo ""
    echo "[5/18] PBFT v4.2 random seed=${SEED}"
    ${PYTHON} -u src/train.py \
        --algo pbft_cg_mappo --env mpe_spread \
        --env_config configs/env/mpe_spread.yaml \
        --algo_config configs/algo/pbft_cg_mappo_v42.yaml \
        --seed ${SEED} --n_timesteps ${N_TIMESTEPS} \
        --eval_interval ${EVAL_INTERVAL} --eval_episodes ${EVAL_EPISODES} \
        --byzantine_n 1 --byzantine_type random \
        --log_dir results/v42_full_random --gpu ${GPU_ID}
done

# MAPPO + random
for SEED in ${SEEDS}; do
    echo ""
    echo "[6/18] MAPPO random seed=${SEED}"
    ${PYTHON} -u src/train.py \
        --algo mappo --env mpe_spread \
        --env_config configs/env/mpe_spread.yaml \
        --algo_config configs/algo/mappo_v42.yaml \
        --seed ${SEED} --n_timesteps ${N_TIMESTEPS} \
        --eval_interval ${EVAL_INTERVAL} --eval_episodes ${EVAL_EPISODES} \
        --byzantine_n 1 --byzantine_type random \
        --log_dir results/v42_full_random --gpu ${GPU_ID}
done

echo "Phase 3 完成: $(date)"

# ============================================
# 汇总
# ============================================
echo ""
echo "============================================"
echo "全部实验完成！"
echo "结束时间: $(date)"
echo ""
echo "结果目录："
echo "  干净环境:   results/v42_full_clean/"
echo "  对抗攻击:   results/v42_full_adv/"
echo "  随机攻击:   results/v42_full_random/"
echo ""
echo "提取指标命令："
echo "  python3 -c \""
echo "  import json, numpy as np"
echo "  for cond in ['clean', 'adv', 'random']:"
echo "    for algo in ['pbft_cg_mappo', 'mappo']:"
echo "      rewards = []"
echo "      for s in [1,2,3]:"
echo "        p = f'results/v42_full_{cond}/{algo}/seed_{s}/metrics.json'"
echo "        try:"
echo "          m = json.load(open(p))"
echo "          r = m.get('episode/episode_reward', [])"
echo "          if r: rewards.append(np.mean(r[-50:]))"
echo "        except: pass"
echo "      if rewards: print(f'{cond}/{algo}: {np.mean(rewards):.1f} ± {np.std(rewards):.1f}')"
echo "  \""
echo "============================================"
