#!/usr/bin/env python3
"""
v4.2 精确补丁 - 基于行号的精确修改
修复上次补丁把代码插入 loss 表达式内部的语法错误
"""
import os, shutil

filepath = os.path.join(os.getcwd(), "src/algorithms/pbft_cg_mappo.py")

with open(filepath, 'r', encoding='utf-8') as f:
    lines = f.readlines()

print(f"文件总行数: {len(lines)}")

# 找关键行号
for i, line in enumerate(lines, 1):
    stripped = line.strip()
    if 'consensus_blend_ratio' in stripped and 'self.pbft_consensus' in stripped:
        print(f"  L{i}: {stripped}")
    if 'self._consensus_step_counter += 1' in stripped:
        print(f"  L{i}: {stripped}")
    if '总损失' in stripped or '总loss' in stripped:
        print(f"  L{i}: {stripped}")
    if 'loss = (' in stripped and 'policy_loss' not in stripped:
        print(f"  L{i}: {stripped}")
    if '- self.entropy_coef * mean_entropy' in stripped:
        print(f"  L{i}: {stripped}")
    if '+ consensus_loss' in stripped and ')' in stripped:
        print(f"  L{i}: {stripped}")
    if 'self._training_step += 1' in stripped:
        print(f"  L{i}: {stripped}")
    if '"entropy": total_entropy' in stripped:
        print(f"  L{i}: {stripped}")
    if '"entropy_coef"' in stripped:
        print(f"  L{i}: {stripped}")
