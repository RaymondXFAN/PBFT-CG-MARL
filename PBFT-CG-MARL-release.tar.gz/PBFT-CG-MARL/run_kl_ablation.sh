#!/bin/bash
# ============================================================
# KL 权重消融实验
# kl_consensus_coef ∈ {0.0, 0.01, 0.1, 0.5, 1.0}
# 每组 1 seed 快速验证，50K 步
# 预计总耗时：约 50 分钟
# ============================================================

set -e
GPU=${1:-0}
BASE_LOG="results/kl_ablation"

KL_VALUES="0.0 0.01 0.1 0.5 1.0"

echo "============================================"
echo "KL 权重消融实验"
echo "KL values: $KL_VALUES"
echo "GPU: $GPU"
echo "============================================"

for KL in $KL_VALUES; do
    LOG_DIR="${BASE_LOG}/kl_${KL}"
    echo ""
    echo "=== kl_consensus_coef=${KL} ==="
    
    # 生成临时配置文件（基于 v42 配置，只改 kl_consensus_coef）
    CONFIG_FILE="configs/algo/pbft_cg_mappo_kl_ablation_${KL}.yaml"
    sed "s/kl_consensus_coef: .*/kl_consensus_coef: ${KL}/" \
        configs/algo/pbft_cg_mappo_v42.yaml > "$CONFIG_FILE"
    
    # 特殊处理：kl=0 时关闭 soft_consensus_mode（无KL等于无软共识）
    if [ "$KL" = "0.0" ]; then
        sed -i 's/soft_consensus_mode: true/soft_consensus_mode: false/' "$CONFIG_FILE"
        echo "  (kl=0.0: soft_consensus_mode=false, 等价于纯MAPPO+PBFT结构但无共识引导)"
    fi
    
    /root/miniconda3/bin/python3 -u src/train.py \
        --algo pbft_cg_mappo \
        --env mpe_spread \
        --env_config configs/env/mpe_spread.yaml \
        --algo_config "$CONFIG_FILE" \
        --seed 1 \
        --n_timesteps 50000 \
        --eval_interval 5000 \
        --eval_episodes 5 \
        --log_dir "$LOG_DIR" \
        --gpu "$GPU"
    
    echo "  kl=${KL} 完成"
done

echo ""
echo "============================================"
echo "KL 消融全部完成！"
echo ""
echo "提取指标："
echo 'cd /root/autodl-tmp/PBFT-CG-MARL'
echo '/root/miniconda3/bin/python3 -c "
import json, numpy as np
print(\"kl_coef | reward | entropy | consensus_rate | kl_loss | ecof\")
print(\"-\" * 65)
for kl in [0.0, 0.01, 0.1, 0.5, 1.0]:
    p = f\"results/kl_ablation/kl_{kl}/pbft_cg_mappo/seed_1/metrics.json\"
    try:
        m = json.load(open(p))
        rew = np.array(m.get(\"episode/episode_reward\",[])[-50:])
        ent = m.get(\"train/entropy\",[])
        cr = m.get(\"train/consensus_rate\",[])
        kl_loss = m.get(\"train/kl_consensus_loss\",[])
        ecof = m.get(\"train/entropy_coef\",[])
        print(f\"{kl:6.2f} | {rew.mean():7.1f} | {ent[-1]:7.4f} | {cr[-1]:14.4f} | {kl_loss[-1]:7.4f} | {ecof[-1]:.4f}\")
    except:
        print(f\"{kl:6.2f} | FAILED\")
"'
echo "============================================"
