#!/usr/bin/env python3
"""
PBFT-CG-MARL v3 补丁：消息级 Byzantine 攻击
修复审稿意见 #1：攻击面与防御面错位

核心改动：
1. 在 PBFTConsensusLayer 中实现消息级攻击（forge/conflict/silent）
2. 区分 "消息级攻击"（经过共识过滤）和 "动作级攻击"（不经过）
3. 消息级攻击直接篡改 Byzantine agent 的 proposal 内容

使用方法：
    cd /root/autodl-tmp/PBFT-CG-MARL
    python patch_v3_msg_attack.py
"""

import os
import sys
import shutil

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))


def patch_pbft_py_msg_attack():
    """修改 pbft.py，实现消息级 Byzantine 攻击"""
    filepath = os.path.join(PROJECT_ROOT, "src", "consensus", "pbft.py")
    
    if not os.path.exists(filepath):
        print(f"[ERROR] 找不到 {filepath}")
        return False
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 检查是否已打过补丁
    if 'message_forge' in content:
        print("[SKIP] pbft.py 已包含消息级攻击，跳过")
        return True
    
    # 1. 修改 _byzantine_prepare_vote 以支持消息级攻击
    old_byz_vote = '''    def _byzantine_prepare_vote(
        self,
        agent_id: int,
        leader_proposal: torch.Tensor,
        agent_proposal: torch.Tensor,
        action_type: str = "discrete",
    ) -> bool:
        """拜占庭Agent的Prepare投票策略"""
        if self.byzantine_type == "random":
            return bool(np.random.randint(0, 2))  # 随机投票
        elif self.byzantine_type == "adversarial":
            return False  # 总是反对
        elif self.byzantine_type == "silence":
            return False  # 不投票
        else:
            return bool(np.random.randint(0, 2))'''
    
    new_byz_vote = '''    def _byzantine_prepare_vote(
        self,
        agent_id: int,
        leader_proposal: torch.Tensor,
        agent_proposal: torch.Tensor,
        action_type: str = "discrete",
    ) -> bool:
        """拜占庭Agent的Prepare投票策略
        
        v3新增消息级攻击类型：
        - message_forge: 发送伪造proposal（但投票时配合伪造内容投票True）
        - message_conflict: 发送冲突proposal + 投票True（试图通过quorum）
        - message_silent: 不发送proposal（超时），投票False
        """
        if self.byzantine_type == "random":
            return bool(np.random.randint(0, 2))  # 随机投票
        elif self.byzantine_type == "adversarial":
            return False  # 总是反对
        elif self.byzantine_type == "silence":
            return False  # 不投票
        elif self.byzantine_type == "message_forge":
            return True  # 伪造者投True以尝试让伪造内容通过quorum
        elif self.byzantine_type == "message_conflict":
            return True  # 冲突者投True以尝试通过
        elif self.byzantine_type == "message_silent":
            return False  # 沉默，不参与
        else:
            return bool(np.random.randint(0, 2))'''
    
    if old_byz_vote in content:
        content = content.replace(old_byz_vote, new_byz_vote, 1)
    else:
        print("[WARN] 未找到 _byzantine_prepare_vote，尝试其他方式")
    
    # 2. 新增方法：篡改 Byzantine agent 的 proposal（核心！）
    # 在 inject_byzantine 方法之后添加
    new_method = '''
    def corrupt_proposals(
        self,
        proposals: List[Tuple[torch.Tensor, torch.Tensor]],
        obs: Optional[torch.Tensor] = None,
        action_type: str = "discrete",
    ) -> List[Tuple[torch.Tensor, torch.Tensor]]:
        """
        v3: 消息级攻击——篡改Byzantine agent的proposal
        
        这是修复"攻击面与防御面错位"的核心方法。
        之前byzantine攻击只改变agent的执行动作，不改变发给共识层的消息。
        现在byzantine agent的proposal本身被篡改，使得PBFT quorum真正需要过滤。
        
        攻击类型：
        - message_forge: Byzantine agent发送随机/对抗的伪造proposal
        - message_conflict: Byzantine agent发送与其他agent故意冲突的proposal
        - message_silent: Byzantine agent发送零值proposal（模拟timeout）
        - random/adversarial/silence: 旧版行为，不修改proposal（动作级攻击）
        """
        if not self.byzantine_agents:
            return proposals
        
        corrupted = []
        for i, (action, log_prob) in enumerate(proposals):
            if i in self.byzantine_agents:
                if self.byzantine_type == "message_forge":
                    # 伪造proposal：发送一个随机/对抗动作作为proposal
                    if action_type == "discrete":
                        # 离散：随机选一个不同于leader的动作
                        n_actions = self.action_dim
                        forged = torch.randint(0, n_actions, action.shape, 
                                             device=action.device, dtype=action.dtype)
                        # 确保伪造动作不同于原始（对抗性）
                        if forged.item() == action.item():
                            forged = (forged + 1) % n_actions
                    else:
                        # 连续：添加大幅噪声
                        noise = torch.randn_like(action) * 2.0
                        forged = action + noise
                    corrupted.append((forged, log_prob))
                    
                elif self.byzantine_type == "message_conflict":
                    # 冲突proposal：发送与当前leader提案相反的值
                    if action_type == "discrete":
                        n_actions = self.action_dim
                        # 选择离leader最远的动作
                        conflict = (action + n_actions // 2) % n_actions
                        conflict_tensor = torch.tensor(conflict, device=action.device, 
                                                      dtype=action.dtype)
                        if conflict_tensor.shape != action.shape:
                            conflict_tensor = conflict_tensor.reshape(action.shape)
                        corrupted.append((conflict_tensor, log_prob))
                    else:
                        # 连续：发送负值（最大偏差）
                        conflict = -action * 2.0
                        corrupted.append((conflict, log_prob))
                    
                elif self.byzantine_type == "message_silent":
                    # 沉默：发送零值proposal（模拟通信超时/丢包）
                    silent = torch.zeros_like(action)
                    corrupted.append((silent, log_prob))
                    
                else:
                    # 旧版攻击类型（random/adversarial/silence）不修改proposal
                    # 这些是动作级攻击，proposal保持诚实
                    corrupted.append((action, log_prob))
            else:
                corrupted.append((action, log_prob))
        
        return corrupted
'''
    
    # 在 inject_byzantine 方法之后插入
    inject_marker = '    def inject_byzantine('
    if inject_marker in content:
        # 找到 inject_byzantine 方法的结尾
        idx = content.find(inject_marker)
        # 找下一个 def 的位置（方法结束）
        next_def = content.find('\n    def ', idx + 1)
        if next_def > 0:
            content = content[:next_def] + new_method + content[next_def:]
            print("[OK] 已在 inject_byzantine 之后插入 corrupt_proposals 方法")
        else:
            # 在类末尾插入
            content = content.rstrip() + "\n" + new_method
            print("[OK] 已在类末尾插入 corrupt_proposals 方法")
    else:
        content = content.rstrip() + "\n" + new_method
        print("[OK] 已在类末尾插入 corrupt_proposals 方法")
    
    # 3. 修改 forward() 方法，在 pre_prepare 之前调用 corrupt_proposals
    old_forward_start = '''        self._total_consensus_calls += 1

        # ===== Phase 1: Pre-prepare =====
        leader_proposal, leader_id = self.pre_prepare(agent_proposals, step)'''
    
    new_forward_start = '''        self._total_consensus_calls += 1

        # ===== v3: 消息级攻击 =====
        # 在共识之前，篡改Byzantine agent的proposal
        # 这使得攻击真正经过共识过滤（修复"攻击面与防御面错位"）
        agent_proposals = self.corrupt_proposals(agent_proposals, obs, action_type)

        # ===== Phase 1: Pre-prepare =====
        leader_proposal, leader_id = self.pre_prepare(agent_proposals, step)'''
    
    if old_forward_start in content:
        content = content.replace(old_forward_start, new_forward_start, 1)
        print("[OK] 已在 forward() 中插入 corrupt_proposals 调用")
    else:
        print("[WARN] 未找到 forward() 中的 pre-prepare 调用点")
    
    # 备份原文件
    shutil.copy2(filepath, filepath + ".pre_v3.bak")
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"[OK] pbft.py 已修改（备份: pbft.py.pre_v3.bak）")
    return True


def patch_train_py_msg_attack():
    """修改 train.py，支持新的消息级攻击类型"""
    filepath = os.path.join(PROJECT_ROOT, "src", "train.py")
    
    if not os.path.exists(filepath):
        print(f"[ERROR] 找不到 {filepath}")
        return False
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 1. 扩展 byzantine_type 的 choices
    old_choices = '''choices=["random", "adversarial", "silence"], help="拜占庭类型"'''
    new_choices = '''choices=["random", "adversarial", "silence", "message_forge", "message_conflict", "message_silent"], help="拜占庭类型"'''
    
    if old_choices in content:
        content = content.replace(old_choices, new_choices, 1)
        print("[OK] train.py: 已扩展 byzantine_type choices")
    else:
        print("[WARN] 未找到 byzantine_type choices")
    
    # 备份
    shutil.copy2(filepath, filepath + ".pre_v3.bak")
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"[OK] train.py 已修改（备份: train.py.pre_v3.bak）")
    return True


def main():
    print("=" * 60)
    print("PBFT-CG-MARL v3 补丁：消息级 Byzantine 攻击")
    print("修复审稿意见 #1：攻击面与防御面错位")
    print("=" * 60)
    
    results = []
    
    print("\n[1/2] 修改 pbft.py ...")
    results.append(("pbft.py", patch_pbft_py_msg_attack()))
    
    print("\n[2/2] 修改 train.py ...")
    results.append(("train.py", patch_train_py_msg_attack()))
    
    print("\n" + "=" * 60)
    print("补丁结果：")
    for name, ok in results:
        status = "✅ 成功" if ok else "❌ 失败"
        print(f"  {name}: {status}")
    
    all_ok = all(ok for _, ok in results)
    if all_ok:
        print("\n🎉 补丁成功！")
        print("\n新增攻击类型：")
        print("  - message_forge:   Byzantine agent 发送伪造 proposal（随机/对抗动作）")
        print("  - message_conflict: Byzantine agent 发送冲突 proposal（最大偏差）")
        print("  - message_silent:  Byzantine agent 发送零值 proposal（模拟超时）")
        print("\n旧版攻击类型（保留作为对照组）：")
        print("  - random:     动作级攻击，agent 执行随机动作")
        print("  - adversarial: 动作级攻击，agent 执行对抗动作")
        print("  - silence:    动作级攻击，agent 不执行动作")
    else:
        print("\n⚠️ 部分补丁失败")
    
    return all_ok


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
