#!/bin/bash
cd /root/autodl-tmp/PBFT-CG-MARL

run_seed() {
  local s=$1
  echo "=== Starting seed $s at $(date) ==="
  python -u src/train.py --algo pbft_cg_mappo --env vmas_uav_coverage \
    --env_config configs/env/vmas_uav_coverage.yaml \
    --algo_config configs/algo/pbft_mult_matched_v5.yaml \
    --seed $s --n_timesteps 500000 --eval_interval 25000 \
    --eval_episodes 10 --log_dir results/phase1_fix_vmas --gpu 0
  echo "=== Finished seed $s at $(date) ==="
}

# 并行跑 seed 1+2，然后 3+4，最后 5
run_seed 1 & run_seed 2 & wait
run_seed 3 & run_seed 4 & wait
run_seed 5
echo "ALL DONE at $(date)"
