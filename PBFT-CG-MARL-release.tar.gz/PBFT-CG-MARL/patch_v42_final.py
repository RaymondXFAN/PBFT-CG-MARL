#!/usr/bin/env python3
"""
v4.2 最终修复 - 基于精确行号的一次性修改
绝不用字符串替换，直接按行号操作
"""
import os, shutil

filepath = "src/algorithms/pbft_cg_mappo.py"

with open(filepath, 'r', encoding='utf-8') as f:
    lines = f.readlines()

shutil.copy2(filepath, filepath + ".v42final.bak")

# 行号（0-indexed）来自扫描结果
# L67: consensus_blend_ratio (index 66)
# L186: consensus_step_counter (index 185)
# L189: consensus_call (index 188)
# L194: skip_consensus (index 193)
# L197: step3 (index 196)
# L199: ref_shape (index 198)
# L332: evaluate_action actor (index 331)
# L336: evaluate_action actors (index 335)
# L340: entropies_append (index 339)
# L366: consensus_loss init (index 365)
# L376: loss start (index 375)
# L416: entropy_coef metric (index 415)

# 因为插入会改变后续行号，我们从后往前改

# === 修改 6: metrics 返回中添加新指标 (index 415) ===
i = 415
lines.insert(i + 1, '            "kl_consensus_loss": self._kl_consensus_loss_val,\n')
lines.insert(i + 2, '            "entropy_floor_penalty": self._entropy_floor_penalty_val,\n')
print("修改6: metrics 添加新指标")

# === 修改 5: 替换 loss 计算区域 (index 375-380) ===
# 先看看 loss 区域的完整内容
loss_start = 375  # "loss = ("
# 找到 loss 的右括号
loss_end = None
for j in range(375, 385):
    if j < len(lines) and ')' in lines[j] and '+' in lines[j-1]:
        loss_end = j
        break
if loss_end is None:
    # 找 ")\n" 单独一行
    for j in range(375, 385):
        if j < len(lines) and lines[j].strip() == ')':
            loss_end = j
            break

if loss_end is None:
    # 最后手段：找包含 consensus_loss 的行
    for j in range(375, 385):
        if j < len(lines) and 'consensus_loss' in lines[j]:
            loss_end = j
            break

print(f"loss 区域: L{loss_start+1}-L{loss_end+1 if loss_end else '?'}")

# 替换整个 loss 计算区域（从 consensus_loss init 到 loss 的右括号）
# 先找到 consensus_loss = torch.tensor(0.0) 的位置
cons_loss_start = 365  # index 365

# 替换从 consensus_loss 到 loss_end 的所有内容
new_loss_block = """        # v4.2: 共识损失（保留原有逻辑）
        consensus_loss = torch.tensor(0.0, device=self.device)
        if hasattr(self, "_last_consensus_info") and self._last_consensus_info is not None:
            consensus_rate = self._last_consensus_info.get("consensus_rate", 0.0)
            consensus_loss = torch.tensor(
                (1.0 - consensus_rate) * self.consensus_loss_coef,
                device=self.device,
            )

        # v4.2: 最小熵底线惩罚（确保是 tensor，与 loss 类型一致）
        entropy_floor_penalty = torch.tensor(0.0, device=self.device)
        if hasattr(self, "entropy_floor") and mean_entropy < self.entropy_floor:
            deficit = self.entropy_floor - mean_entropy
            entropy_floor_penalty = torch.tensor(10.0 * deficit.item(), device=self.device, requires_grad=False)

        # v4.2: 软共识交叉熵损失（使用 batch 中累积的交叉熵）
        kl_consensus_loss = torch.tensor(0.0, device=self.device)
        if self.soft_consensus_mode and hasattr(self, "_batch_ce_losses") and self._batch_ce_losses:
            kl_consensus_loss = torch.stack(self._batch_ce_losses).mean()
            self._batch_ce_losses = []

        # 记录用于 metrics
        self._kl_consensus_loss_val = kl_consensus_loss.item()
        self._entropy_floor_penalty_val = entropy_floor_penalty.item()

        # 总损失（所有项都是 tensor，确保 backward 不出问题）
        loss = (
            policy_loss
            + self.value_loss_coef * value_loss
            - self.entropy_coef * mean_entropy
            + consensus_loss
            + entropy_floor_penalty
            + self.kl_consensus_coef * kl_consensus_loss
        )
"""

if loss_end is not None:
    lines[cons_loss_start:loss_end + 1] = [new_loss_block]
    print(f"修改5: 替换 loss 区域 L{cons_loss_start+1}-L{loss_end+1}")
else:
    print("修改5: FAILED - 找不到 loss_end")

# === 修改 4: 在 entropies.append(entropy) 后添加交叉熵计算 (index 339) ===
i = 339  # entropies.append(entropy)
ce_code = """                # v4.2: 计算与共识动作的交叉熵损失
                if self.soft_consensus_mode and hasattr(self, "_last_consensus_actions") and self._last_consensus_actions is not None:
                    try:
                        cons_a = self._last_consensus_actions[agent_id]
                        if isinstance(cons_a, int):
                            ca_tensor = torch.tensor(cons_a, device=self.device)
                        else:
                            ca_tensor = cons_a.detach().clone().to(self.device)
                        ce_loss = -action_dist.log_prob(ca_tensor)
                        if not hasattr(self, "_batch_ce_losses"):
                            self._batch_ce_losses = []
                        self._batch_ce_losses.append(ce_loss.mean())
                    except Exception as e:
                        pass  # 交叉熵计算失败不影响主流程
"""
lines.insert(i + 1, ce_code)
print("修改4: 在 entropies.append 后添加交叉熵计算")

# === 修改 3: 保存 action_dist (index 331, 335) ===
# 改 _ 为 action_dist
lines[331] = lines[331].replace('log_prob, entropy, _ =', 'log_prob, entropy, action_dist =')
lines[335] = lines[335].replace('log_prob, entropy, _ =', 'log_prob, entropy, action_dist =')
print("修改3: 保存 action_dist")

# === 修改 2: act() 方法 - 软共识模式 ===
# 替换从 L183("v4: 动态设置 blend_ratio") 到 L194("skipped") 的块
# 找到 "v4: 动态设置" 或 "blend_ratio" 注释行
act_start = None
for j in range(183, 200):
    if j < len(lines) and ('v4: 动态设置' in lines[j] or 'blend_ratio' in lines[j]) and 'self.pbft_consensus' in lines[j]:
        act_start = j
        break
if act_start is None:
    # 找 "步骤2：PBFT共识层"
    for j in range(180, 200):
        if j < len(lines) and '步骤2' in lines[j]:
            act_start = j
            break

# 找到 skip 块的结束行
act_end = None
for j in range(act_start, act_start + 20):
    if j < len(lines) and '"skipped": True' in lines[j]:
        # 找到这一行所在的 dict 的结束 }
        act_end = j
        break

if act_start is not None and act_end is not None:
    new_act_block = """        # 步骤2：PBFT共识层（v4.2: 支持软共识模式）
        self._consensus_step_counter += 1
        if self.soft_consensus_mode:
            # V42_SOFT_CONSENSUS: 计算共识但不修改动作
            consensus_actions, consensus_info = self.pbft_consensus(
                proposals, obs, step=self._training_step, action_type=self.action_type
            )
            self._last_consensus_actions = consensus_actions
            self._last_consensus_info = consensus_info
            # 不修改动作！agent 自由选择
            final_actions = [a for a, _ in proposals]
        elif self.consensus_freq <= 1 or self._consensus_step_counter % self.consensus_freq == 0:
            # 硬共识模式
            if hasattr(self, "pbft_consensus") and hasattr(self, "consensus_blend_ratio"):
                self.pbft_consensus.blend_ratio = self.consensus_blend_ratio
            consensus_actions, consensus_info = self.pbft_consensus(
                proposals, obs, step=self._training_step, action_type=self.action_type
            )
            final_actions = consensus_actions
        else:
            # 跳过共识
            final_actions = [a for a, _ in proposals]
            consensus_info = {"consensus_rate": 1.0, "consensus_achieved": True, "skipped": True}
"""
    lines[act_start:act_end + 1] = [new_act_block]
    print(f"修改2: act() 软共识模式（替换 L{act_start+1}-L{act_end+1}）")
else:
    print(f"修改2: FAILED - act_start={act_start}, act_end={act_end}")

# === 修改 2b: 把步骤3中的 consensus_actions 替换为 final_actions ===
for j in range(len(lines)):
    if '步骤3' in lines[j] and j > 180:
        # 从这里开始，把所有 consensus_actions 替换为 final_actions
        for k in range(j, min(j + 30, len(lines))):
            if 'consensus_actions[0]' in lines[k] and 'final_actions' not in lines[k]:
                lines[k] = lines[k].replace('consensus_actions[0]', 'final_actions[0]')
            if 'consensus_actions' in lines[k] and 'final_actions' not in lines[k] and 'last_consensus' not in lines[k]:
                lines[k] = lines[k].replace('consensus_actions', 'final_actions')
        break
print("修改2b: consensus_actions → final_actions")

# === 修改 1: __init__ 添加 v4.2 参数 (index 66) ===
i = 66  # consensus_blend_ratio 行
new_params = """        self.consensus_blend_ratio = config.get("consensus_blend_ratio", 0.3)

        # v4.2: 软共识参数
        self.soft_consensus_mode = config.get("soft_consensus_mode", False)
        self.kl_consensus_coef = config.get("kl_consensus_coef", 0.1)
        self.entropy_floor = config.get("entropy_floor", 0.05)
        # v4.2: 用于 metrics 的临时变量
        self._kl_consensus_loss_val = 0.0
        self._entropy_floor_penalty_val = 0.0
"""
lines[i] = new_params
print("修改1: __init__ 添加 v4.2 参数")

# 写入文件
with open(filepath, 'w', encoding='utf-8') as f:
    f.writelines(lines)

# 验证语法
import py_compile
try:
    py_compile.compile(filepath, doraise=True)
    print("\n✅ 语法检查通过！")
except py_compile.PyCompileError as e:
    print(f"\n❌ 语法错误: {e}")
    print("恢复备份...")
    shutil.copy2(filepath + ".v42final.bak", filepath)
    print("已恢复")
