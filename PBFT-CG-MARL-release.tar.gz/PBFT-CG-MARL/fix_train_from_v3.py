#!/root/miniconda3/bin/python3
"""从 v3 备份恢复 train.py + 只加 v4.5 提案层注入"""
import shutil

path = "/root/autodl-tmp/PBFT-CG-MARL/src/train.py"
bak = "/root/autodl-tmp/PBFT-CG-MARL/src/train.py.v3.bak"

# 1. 从干净备份恢复
shutil.copy2(bak, path)
print("1. 已从 v3 备份恢复")

# 2. 只修改拜占庭注入部分（原 L980-983）
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

old = """    # 注入拜占庭Agent
    if args.byzantine_n > 0 and hasattr(algorithm, "inject_byzantine"):
        algorithm.inject_byzantine(args.byzantine_n, args.byzantine_type)
        print(f"已注入 {args.byzantine_n} 个拜占庭Agent (类型: {args.byzantine_type})")"""

new = """    # 注入拜占庭Agent (v4.5: 优先提案层注入)
    if args.byzantine_n > 0:
        if hasattr(algorithm, "inject_proposal_byzantine"):
            byz_ids = list(range(args.byzantine_n))
            algorithm.inject_proposal_byzantine(byz_ids, args.byzantine_type)
        elif hasattr(algorithm, "inject_byzantine"):
            algorithm.inject_byzantine(args.byzantine_n, args.byzantine_type)
        print(f"[v4.5] injected {args.byzantine_n} byzantine agents (type: {args.byzantine_type})")"""

if old in content:
    content = content.replace(old, new)
    print("2. OK - 替换拜占庭注入代码")
else:
    print("2. FAIL - 未找到原始代码，尝试宽松匹配...")
    # 可能缩进不同，逐行搜索
    lines = content.split('\n')
    for i, line in enumerate(lines):
        if '注入拜占庭Agent' in line and 'v4.5' not in line:
            # 找到了，获取缩进
            indent = line[:len(line) - len(line.lstrip())]
            # 替换 4 行
            lines[i] = indent + '# 注入拜占庭Agent (v4.5: 优先提案层注入)'
            lines[i+1] = indent + 'if args.byzantine_n > 0:'
            lines[i+2] = indent + '    if hasattr(algorithm, "inject_proposal_byzantine"):'
            lines[i+3] = indent + '        byz_ids = list(range(args.byzantine_n))'
            # 插入剩余行
            insert_lines = [
                indent + '        algorithm.inject_proposal_byzantine(byz_ids, args.byzantine_type)',
                indent + '    elif hasattr(algorithm, "inject_byzantine"):',
                indent + '        algorithm.inject_byzantine(args.byzantine_n, args.byzantine_type)',
                indent + '    print(f"[v4.5] injected {args.byzantine_n} byzantine agents (type: {args.byzantine_type})")',
            ]
            for j, il in enumerate(insert_lines):
                lines.insert(i + 4 + j, il)
            content = '\n'.join(lines)
            print("2. OK - 宽松匹配替换")
            break

with open(path, 'w', encoding='utf-8') as f:
    f.write(content)

# 3. 验证
import py_compile
try:
    py_compile.compile(path, doraise=True)
    print("3. ✅ 语法OK")
except py_compile.PyCompileError as e:
    print(f"3. ❌ 语法错误: {e}")
