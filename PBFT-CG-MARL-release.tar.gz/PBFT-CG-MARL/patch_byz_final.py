#!/usr/bin/env python3
"""Fix: 给 train.py 添加环境层 Byzantine 攻击（对 MAPPO 等无共识算法生效）"""
import sys

filepath = "/root/autodl-tmp/PBFT-CG-MARL/src/train.py"

with open(filepath, "r") as f:
    lines = f.readlines()

# 1. 在第一个 def 之前插入辅助函数
func_lines = [
    "def _apply_byzantine_attack(actions_np, n_byzantine, byz_type, action_type, n_agents):\n",
    '    """Byzantine attack for algorithms without consensus layer (e.g. MAPPO)"""\n',
    "    import numpy as np\n",
    "    modified = actions_np.copy()\n",
    "    byz_ids = list(range(min(n_byzantine, n_agents)))\n",
    "    for aid in byz_ids:\n",
    "        if aid >= len(modified):\n",
    "            continue\n",
    '        if byz_type == "random":\n',
    '            if action_type == "discrete":\n',
    "                n_acts = max(6, int(modified[aid]) + 2)\n",
    "                modified[aid] = np.random.randint(0, n_acts)\n",
    "            else:\n",
    "                modified[aid] = np.random.uniform(-1.0, 1.0, size=modified[aid].shape)\n",
    '        elif byz_type == "adversarial":\n',
    '            if action_type == "discrete":\n',
    "                n_acts = max(6, int(modified[aid]) + 2)\n",
    "                modified[aid] = (n_acts - 1 - int(modified[aid])) % n_acts\n",
    "            else:\n",
    "                noise = np.random.randn(*modified[aid].shape) * 0.1\n",
    "                modified[aid] = np.clip(-modified[aid] + noise, -1.0, 1.0)\n",
    '        elif byz_type == "silence":\n',
    '            if action_type == "discrete":\n',
    "                modified[aid] = 0\n",
    "            else:\n",
    "                modified[aid] = np.zeros_like(modified[aid])\n",
    "    return modified\n",
    "\n",
]

# 找第一个 def
insert_idx = 0
for i, line in enumerate(lines):
    if line.startswith("def "):
        insert_idx = i
        break

if "_apply_byzantine_attack" not in "".join(lines[:insert_idx+5]):
    for j, fl in enumerate(func_lines):
        lines.insert(insert_idx + j, fl)
    print(f"Inserted _apply_byzantine_attack at line {insert_idx}")
else:
    print("_apply_byzantine_attack already exists, skipping")

# 2. 在 env.step(actions_np) 前插入攻击检查
# 找所有 env.step(actions_np) 的位置
modified_count = 0
for i in range(len(lines)):
    if "env.step(actions_np)" in lines[i] and "_apply_byzantine_attack" not in lines[i]:
        # 检查前面是否已插入
        prev_lines = "".join(lines[max(0,i-3):i])
        if "_apply_byzantine_attack" in prev_lines:
            continue
        
        # 获取缩进
        indent = ""
        for c in lines[i]:
            if c == " ":
                indent += " "
            else:
                break
        
        check = f'{indent}if args.byzantine_n > 0 and not hasattr(algorithm, "inject_proposal_byzantine") and not hasattr(algorithm, "inject_byzantine"):\n'
        call = f'{indent}    actions_np = _apply_byzantine_attack(actions_np, args.byzantine_n, args.byzantine_type, action_type, n_agents)\n'
        
        lines.insert(i, check)
        lines.insert(i, call)
        modified_count += 1
        print(f"Inserted byzantine check at line {i} (indent='{indent[:4]}...')")

print(f"Total modifications: {modified_count}")

with open(filepath, "w") as f:
    f.writelines(lines)

print("✅ train.py patched successfully")
