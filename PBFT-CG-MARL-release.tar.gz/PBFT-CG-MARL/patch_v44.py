#!/usr/bin/env python3
"""
v4.4 补丁 - 在环境层注入真正的拜占庭行为
核心修改：在 train.py 的训练循环中，所有算法计算出动作后，
统一替换 byzantine agent 的动作，让 PBFT 和 MAPPO 都面临真正的拜占庭攻击

使用方法：
    cd /root/autodl-tmp/PBFT-CG-MARL
    python patch_v44.py
"""
import os, shutil

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__)) if not os.getenv("AUTODL") else "."

def patch_train_py():
    """在 train.py 中添加环境层拜占庭行为注入"""
    filepath = os.path.join(PROJECT_ROOT, "src", "train.py")
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 检查是否已打过补丁
    if 'V44_ENV_BYZANTINE' in content:
        print("[SKIP] train.py 已包含 v4.4 修改")
        return True
    
    changes = []
    
    # 1. 在文件中添加拜占庭动作替换函数（在 import 区域之后）
    import_end = "from src.algorithms import ALGORITHM_REGISTRY"
    if import_end not in content:
        import_end = "import numpy as np"
    
    byzantine_func = '''

# V44_ENV_BYZANTINE: 环境层拜占庭行为注入
# 所有算法（PBFT、MAPPO等）计算出动作后，统一替换 byzantine agent 的动作
_env_byzantine_agents = []
_env_byzantine_type = "random"
_env_action_space = None

def setup_env_byzantine(n_byzantine, byzantine_type, n_agents, action_space):
    """设置环境层拜占庭 agent"""
    global _env_byzantine_agents, _env_byzantine_type, _env_action_space
    _env_byzantine_type = byzantine_type
    _env_action_space = action_space
    if n_byzantine > 0:
        import numpy as np
        _env_byzantine_agents = list(np.random.choice(n_agents, size=n_byzantine, replace=False).tolist())
        print(f"[v4.4] 环境层拜占庭注入: agents={_env_byzantine_agents}, type={byzantine_type}")
    else:
        _env_byzantine_agents = []

def apply_env_byzantine(actions, step=0):
    """在环境执行前替换 byzantine agent 的动作"""
    if not _env_byzantine_agents:
        return actions
    
    import numpy as np
    modified = list(actions)
    for agent_id in _env_byzantine_agents:
        if agent_id < len(modified):
            if _env_byzantine_type == "random":
                # 随机动作
                if _env_action_space is not None:
                    modified[agent_id] = _env_action_space.sample()
                else:
                    modified[agent_id] = np.random.randint(0, 5)  # 默认5个动作
            elif _env_byzantine_type == "adversarial":
                # 对抗动作：选择与 leader 相反的动作
                # 策略：选择最常见的动作之外的动作
                if _env_action_space is not None:
                    n_actions = _env_action_space.n
                else:
                    n_actions = 5
                # 统计其他 agent 的动作，选择最不常见的
                other_actions = [a for i, a in enumerate(actions) if i != agent_id]
                if other_actions:
                    from collections import Counter
                    counts = Counter(other_actions)
                    least_common = counts.most_common()[-1][0] if counts else 0
                    # 选一个不同的动作
                    modified[agent_id] = (least_common + n_actions // 2) % n_actions
                else:
                    modified[agent_id] = 0
            elif _env_byzantine_type == "silence":
                # 不动作（选择动作0）
                modified[agent_id] = 0
    return modified
'''
    
    if import_end in content:
        content = content.replace(import_end, import_end + byzantine_func, 1)
        changes.append("添加环境层拜占庭函数")
    
    # 2. 在注入拜占庭agent的地方，同时设置环境层拜占庭
    old_inject = '''        algorithm.inject_byzantine(args.byzantine_n, args.byzantine_type)
        print(f"已注入 {args.byzantine_n} 个拜占庭Agent (类型: {args.byzantine_type})")'''
    
    new_inject = '''        # v4.4: 算法层注入（PBFT专用）
        if hasattr(algorithm, "inject_byzantine"):
            algorithm.inject_byzantine(args.byzantine_n, args.byzantine_type)
            print(f"已注入 {args.byzantine_n} 个拜占庭Agent (类型: {args.byzantine_type}) [算法层]")
        
        # v4.4: 环境层注入（所有算法通用，包括MAPPO）
        env_info_for_byz = env.get_env_info() if hasattr(env, 'get_env_info') else {}
        action_space = env.get_action_space() if hasattr(env, 'get_action_space') else None
        n_agents_byz = env_info_for_byz.get('n_agents', 3)
        setup_env_byzantine(args.byzantine_n, args.byzantine_type, n_agents_byz, action_space)'''
    
    if old_inject in content:
        content = content.replace(old_inject, new_inject, 1)
        changes.append("修改拜占庭注入逻辑（同时设置环境层）")
    else:
        # 尝试更宽松的匹配
        old_inject2 = 'algorithm.inject_byzantine(args.byzantine_n, args.byzantine_type)'
        if old_inject2 in content:
            old_line = content[content.index(old_inject2)-8:content.index(old_inject2)+len(old_inject2)+100]
            # 找到这一行并替换
            content = content.replace(
                old_inject2,
                '''# v4.4: 算法层注入（PBFT专用）
        if hasattr(algorithm, "inject_byzantine"):
            algorithm.inject_byzantine(args.byzantine_n, args.byzantine_type)
            print(f"[算法层] 已注入 {args.byzantine_n} 个拜占庭Agent (类型: {args.byzantine_type})")
        # v4.4: 环境层注入（所有算法通用）
        env_info_for_byz = env.get_env_info() if hasattr(env, 'get_env_info') else {}
        action_space = env.get_action_space() if hasattr(env, 'get_action_space') else None
        n_agents_byz = env_info_for_byz.get('n_agents', 3)
        setup_env_byzantine(args.byzantine_n, args.byzantine_type, n_agents_byz, action_space)'''
            )
            changes.append("修改拜占庭注入逻辑（宽松匹配）")
    
    # 3. 在训练循环中，env.step() 之前，替换 byzantine agent 的动作
    # 找到 env.step 的调用位置
    old_step = 'env.step(actions)'
    if old_step in content:
        new_step = 'env.step(apply_env_byzantine(actions, step=step))'
        content = content.replace(old_step, new_step)
        changes.append("在 env.step() 前注入拜占庭行为")
    
    # 4. 添加 get_action_space 方法到环境（如果不存在）
    # 先检查环境是否支持
    if 'get_action_space' not in content:
        # 在环境创建后添加
        old_env_create = 'env = ENV_REGISTRY'
        if old_env_create not in content:
            old_env_create = 'env ='
        # 不修改环境，直接在 apply_env_byzantine 中用默认值
    
    if changes:
        shutil.copy2(filepath, filepath + ".v43.bak")
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"[OK] train.py v4.4 修改: {changes}")
    else:
        print("[WARN] train.py 无匹配修改项")
        return False
    
    return True


def main():
    print("=" * 60)
    print("v4.4 补丁 - 环境层拜占庭行为注入")
    print("让 PBFT 和 MAPPO 都面临真正的拜占庭攻击！")
    print("=" * 60)
    
    result = patch_train_py()
    
    if result:
        print("\n✅ v4.4 补丁完成！")
        print("\n下一步：跑决定性实验")
        print("  # adversarial byzantine")
        print("  python -u src/train.py --algo pbft_cg_mappo --env mpe_spread \\")
        print("    --env_config configs/env/mpe_spread.yaml \\")
        print("    --algo_config configs/algo/pbft_cg_mappo_v43.yaml \\")
        print("    --seed 1 --n_timesteps 50000 --eval_interval 5000 \\")
        print("    --eval_episodes 5 --byzantine_n 1 --byzantine_type adversarial \\")
        print("    --log_dir results/v44_adv_quick --gpu 0")
    else:
        print("⚠️ 补丁失败，需要手动修改")
    
    return result


if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)
