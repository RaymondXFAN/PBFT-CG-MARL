# PBFT-CG-MARL v3 修复方案（审稿意见逐条销号）

## 🔴 致命问题修复

### ① 攻击面与防御面错位（全文最大结构性硬伤）

**问题**：§4.2把Byzantine攻击定义在动作层面（随机/对抗性选动作），§3.2的PBFT过滤器防御的是消息层面。攻击注入的破坏根本不经过过滤通道。

**修复方案**：
1. ✅ 新增三种**消息级攻击**（patch_v3_msg_attack.py）：
   - `message_forge`：Byzantine agent 发送伪造的 proposal（随机/对抗动作作为 proposal）
   - `message_conflict`：Byzantine agent 发送与其他 agent 冲突的 proposal
   - `message_silent`：Byzantine agent 发送零值 proposal（模拟超时/丢包）
2. ✅ 在 `PBFTConsensusLayer.forward()` 中，pre-prepare 之前调用 `corrupt_proposals()`
3. ✅ 保留旧版动作级攻击作为对照组
4. ✅ 补跑 clean 无攻击条件（证明过滤器不添乱）

**预期效果**：
- 消息级攻击下，PBFT reward **应该 >** MAPPO reward（PBFT 能防御！）
- Clean 条件下，PBFT reward ≈ MAPPO reward（不添乱）
- 旧版动作级攻击下，PBFT 可能 ≤ MAPPO（攻击面确实错位，诚实承认）

**论文文本修改**：
- §4.2 攻击模型重写：消息级攻击为主，动作级攻击为对照
- §5.1 Table 1 重构：消息级攻击行放在前面，动作级攻击行放在后面标注"reference"
- Discussion 新增段落：对比消息级和动作级攻击下 PBFT 的效果差异

---

### ② 参考文献层整体崩坏

**问题**：正文引用号与文献表大面积错位

**修复方案**：重建参考文献表，逐条对齐

| 正文引用 | 应指 | v2实际指 | 修复 |
|---------|------|---------|------|
| CommNet → [4] | Sukhbaatar 2016 | Castro & Liskov (PBFT) | → [10] |
| TarMAC → [5] | Das 2019 | Li et al. (Byzantine Bayesian) | → [11] |
| Byzantine nodes → [3] | Lamport 1982 | Lowe et al. (MADDPG) | → [1] |
| PBFT → [4] | Castro & Liskov 1999 | (正确) | 保持 |
| MPE → [2] | Lowe et al. 2017 | Mordatch & Abbeel | → [3] |
| MAPPO → [9] | Yu et al. 2022 | (正确) | 保持 |
| PPO → [8] | Schulman 2017 | (正确) | 保持 |
| GAE → [20] | Schulman 2016 | 未编号 | 需加入文献表 |
| HoneyBadgerBFT | Miller et al. 2016 | 无引用 | 需加入 |
| EIR-MAPPO | Related Work提到 | 不在文献表 | 需加入 |

完整重建后重新编号，确保正文每个 `[n]` 对应正确文献。

---

### ③ 均值回退无解释 + 零统计检验

**问题**：SMAClite random 攻击下 return 砍半（189.6→83.6），全文无解释；零 CI/检验

**修复方案**：
1. ✅ 补统计检验框架（statistical_analysis.py）：
   - Per-seed 原始值
   - Bootstrap 95% CI（10000 resamples）
   - Levene's test
   - Two-sample t-test
   - Cohen's d
2. ✅ Seeds 从 3 扩展到 5
3. ✅ 补 clean 条件作为锚点
4. 📝 论文中解释均值回退：
   - "consensus filter constrains the agent's effective action space, preventing it from exploiting idiosyncratic high-reward trajectories that some MAPPO seeds discover"
   - 这是 variance-return tradeoff 的代价
   - **关键**：消息级攻击下，PBFT 应该在均值上也有优势，改变了 narrative

---

## 🟡 方法论修复

### Theorem 1 与 fallback 矛盾

**问题**：Theorem 1 声称"fault-free"，但 fallback 复用 m_{t'}，不同 honest agent 的"上次状态"可能不同

**修复**：
- 将 "fault-free" 改为 "validation-passing"
- 定理范围限定为 "when quorum is achieved"
- 新增 Remark：当 quorum 失败时，fallback 不保证一致性，但保证 liveness
- 删除过度声称 "the policy's input m_t is guaranteed to be free of Byzantine corruption"
- 改为 "when quorum is achieved, m_t is guaranteed to contain only messages that passed validation by ≥2f+1 honest agents"

### c₃(1−CR)·λ_cons 对 θ 梯度为零

**问题**：CR 由协议决定，不可微，此项是装饰品

**修复方案（二选一）**：
- **方案 A**：直接删掉 consensus loss 项，论文中说明 "we find that the consensus loss term provides no measurable improvement (see ablation in §5.6), so we remove it from the final formulation"
- **方案 B**：替换为可微代理，如预测 CR 的辅助头：$\hat{CR}_t = \sigma(\mathbf{w}^\top \mathbf{h}_t)$，其中 h_t 是 critic 的隐藏状态

**推荐方案 A**：更诚实，且 ablation 已证明此项无效果

### mismatched conditioning 零实验

**问题**：贡献2列了 mismatched 但零实验

**修复**：
- 从贡献点中降级为纯理论分析
- 结论中 "empirically evaluated" 改为只覆盖 matched/additive
- 或补跑 mismatched 实验（优先级低）

### Gilbert-Elliott 模型死方法论

**修复**：删掉 §3.6 整个 GE 模型描述，或改为一段简短提及 "we note that the framework is compatible with burst-loss models such as Gilbert-Elliott, though we leave this for future work"

---

## 🟢 其他修复

| # | 问题 | 修复 |
|---|------|------|
| 数字一致性 | 5.8→6.0, 10.7→10.8, 132.5→135.3 | 全部用未舍入原值重算统一 |
| 补全参数 | K, τ_step, δ, λ_cons | 在 §4.5 给出具体数值及选择依据 |
| CR_t 实测值 | 从未报告 | 在 Table 1 中增加 CR_t 列 |
| 学习曲线 | 一张都没有 | 补 Figure 1-3（3个环境的训练曲线） |
| 代码声明 | v2 没有 | 补 "Code available at https://github.com/RaymondXFAN/PBFT-CG-MARL" |
| EIR-MAPPO | Related Work 提到但不进实验 | 补 EIR-MAPPO 基线（Phase 3 实验） |
| SMAClite 引用 | 未引用正文 | 补引用 [22]→Samvelyan et al. |
| Bettini et al. | 混用未编号 | 加入文献表 |

---

## 📊 实验矩阵（修复后）

| Phase | 条件 | Env数 | Attack数 | Algo数 | Seeds | 新跑 |
|-------|------|-------|----------|--------|-------|------|
| 0 | Clean | 3 | 0 | 2 (MAPPO/PBFT) | 5 | 30 |
| 1 | 消息级攻击 | 3 | 3 (forge/conflict/silent) | 2 | 5 | 90 |
| 2 | 动作级攻击 | 3 | 2 (random/adversarial) | 2 | 补4,5 | 12 |
| 3 | EIR-MAPPO基线 | 3 | 3 (forge+random+clean) | 1 | 5 | 45 |
| **合计** | | | | | | **~177 new runs** |

**已复用数据**：
- Phase 2 动作级攻击 seed1-3 已有（18 runs from v2）
- Clean 条件部分可能已有

**时间估算**（2路并行，RTX 4090）：
- MPE 300K步 × 5seeds × 2algos ≈ 6h/条件
- SMAClite 1M步 ≈ 20h/条件
- VMAS 500K步 ≈ 10h/条件
- 总计约 50-60 GPU小时 → 2路并行约 25-30h

---

## 🔄 论文叙事重构

**v2 叙事**："方差缩减"（均值更差但方差更小）

**v3 叙事**："Byzantine 鲁棒性"（消息级攻击下 PBFT 在均值和方差上都更优）

这是根本性的叙事升级！因为：
- 消息级攻击下，PBFT **应该比 MAPPO 好**（均值和方差都好）
- 这才是 PBFT 真正能防御的攻击类型
- Clean 条件下 PBFT ≈ MAPPO（不添乱）
- 动作级攻击下 PBFT 可能 ≤ MAPPO（攻击面错位，诚实承认）

**Table 1 重构为**：

| Env | Condition | MAPPO | PBFT-CG-MAPPO | σ Reduction |
|-----|-----------|-------|---------------|-------------|
| MPE | Clean | −29.7±2.2 | −29.5±2.0 | ≈1× |
| MPE | msg_forge | −XX±YY | −XX±YY | ?× |
| MPE | msg_conflict | −XX±YY | −XX±YY | ?× |
| MPE | msg_silent | −XX±YY | −XX±YY | ?× |
| MPE | action_random | −39.6±6.6 | −43.8±1.1 | 5.8× |
| SMAClite | Clean | ... | ... | ... |
| SMAClite | msg_forge | ... | ... | ... |
| ... | ... | ... | ... | ... |

**关键**：消息级攻击行放在前面作为核心结果，动作级攻击行放在后面标注 "action-level (reference)"
