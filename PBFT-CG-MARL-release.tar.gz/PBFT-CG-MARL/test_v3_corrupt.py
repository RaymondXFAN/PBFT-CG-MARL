#!/usr/bin/env python3
import torch
import sys
sys.path.insert(0, ".")
from src.consensus.pbft import PBFTConsensusLayer

layer = PBFTConsensusLayer(n_agents=4, f=1, action_dim=5)
layer.inject_byzantine(1, "message_forge")
print(f"Byzantine agents: {layer.byzantine_agents}")

proposals = []
for i in range(4):
    action = torch.tensor(i)
    log_prob = torch.tensor(-0.5)
    proposals.append((action, log_prob))

print(f"Original proposals: {[a.item() for a, _ in proposals]}")

corrupted = layer.corrupt_proposals(proposals, action_type="discrete")
print(f"After message_forge: {[a.item() for a, _ in corrupted]}")

byz_id = layer.byzantine_agents[0]
orig = proposals[byz_id][0].item()
corrupt_val = corrupted[byz_id][0].item()
print(f"Byzantine agent {byz_id}: original={orig}, corrupted={corrupt_val}, modified={orig != corrupt_val}")

layer2 = PBFTConsensusLayer(n_agents=4, f=1, action_dim=5)
layer2.inject_byzantine(1, "message_silent")
corrupted2 = layer2.corrupt_proposals(proposals, action_type="discrete")
print(f"After message_silent: {[a.item() for a, _ in corrupted2]}")

layer3 = PBFTConsensusLayer(n_agents=4, f=1, action_dim=5)
layer3.inject_byzantine(1, "random")
corrupted3 = layer3.corrupt_proposals(proposals, action_type="discrete")
print(f"After random (old): {[a.item() for a, _ in corrupted3]}")

print("PATCH VERIFIED!")
