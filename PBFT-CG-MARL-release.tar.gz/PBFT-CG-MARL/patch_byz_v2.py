#!/usr/bin/env python3
"""Fix: 给 train.py 添加环境层 Byzantine 攻击（仅修改 on-policy 和 off-policy 主训练循环）"""
import sys

filepath = "/root/autodl-tmp/PBFT-CG-MARL/src/train.py"

with open(filepath, "r") as f:
    lines = f.readlines()

# 1. 在第一个 def 之前插入辅助函数（但要在所有import之后）
func_lines = [
    "\n",
    "def _apply_byzantine_attack(actions_np, n_byzantine, byz_type, action_type, n_agents):\n",
    '    """Byzantine attack for algorithms without consensus layer (e.g. MAPPO)"""\n',
    "    import numpy as np\n",
    "    modified = actions_np.copy()\n",
    "    byz_ids = list(range(min(n_byzantine, n_agents)))\n",
    "    for aid in byz_ids:\n",
    "        if aid >= len(modified):\n",
    "            continue\n",
    '        if byz_type == "random":\n',
    '            if action_type == "discrete":\n',
    "                n_acts = max(6, int(modified[aid]) + 2)\n",
    "                modified[aid] = np.random.randint(0, n_acts)\n",
    "            else:\n",
    "                modified[aid] = np.random.uniform(-1.0, 1.0, size=modified[aid].shape)\n",
    '        elif byz_type == "adversarial":\n',
    '            if action_type == "discrete":\n',
    "                n_acts = max(6, int(modified[aid]) + 2)\n",
    "                modified[aid] = (n_acts - 1 - int(modified[aid])) % n_acts\n",
    "            else:\n",
    "                noise = np.random.randn(*modified[aid].shape) * 0.1\n",
    "                modified[aid] = np.clip(-modified[aid] + noise, -1.0, 1.0)\n",
    '        elif byz_type == "silence":\n',
    '            if action_type == "discrete":\n',
    "                modified[aid] = 0\n",
    "            else:\n",
    "                modified[aid] = np.zeros_like(modified[aid])\n",
    "    return modified\n",
    "\n",
]

if "_apply_byzantine_attack" not in "".join(lines[:200]):
    # 找 "class TrainEnvWrapper:" 行
    for i, line in enumerate(lines):
        if "class TrainEnvWrapper:" in line:
            for j, fl in enumerate(func_lines):
                lines.insert(i + j, fl)
            print(f"Inserted helper at line {i}")
            break
else:
    print("Helper already exists, skipping")

# 2. 找 on-policy 主训练循环中的 env.step（12空格缩进）
#    标识：前面一行应该是 "actions_np = actions.cpu().numpy()"
#    且缩进为12个空格
on_policy_done = False
for i, line in enumerate(lines):
    if (line == "            next_obs, next_state, rewards, dones, infos = env.step(actions_np)\n"
        and not on_policy_done):
        # 确认这是主训练循环（不是TrainEnvWrapper的方法）
        # 检查前后几行有没有 "algorithm.act" 
        context = "".join(lines[max(0,i-10):i])
        if "algorithm.act" in context or "algorithm.get_value" in context:
            check = '            if args.byzantine_n > 0 and not hasattr(algorithm, "inject_proposal_byzantine") and not hasattr(algorithm, "inject_byzantine"):\n'
            call = '                actions_np = _apply_byzantine_attack(actions_np, args.byzantine_n, args.byzantine_type, action_type, n_agents)\n'
            lines.insert(i, check)
            lines.insert(i, call)
            on_policy_done = True
            print(f"Inserted on-policy byzantine at line {i}")

# 3. 找 off-policy 主训练循环中的 env.step（8空格缩进）
off_policy_done = False
for i, line in enumerate(lines):
    if (line == "        next_obs, next_state, rewards, dones, infos = env.step(actions_np)\n"
        and not off_policy_done):
        context = "".join(lines[max(0,i-10):i])
        if "algorithm.act" in context:
            check = '        if args.byzantine_n > 0 and not hasattr(algorithm, "inject_proposal_byzantine") and not hasattr(algorithm, "inject_byzantine"):\n'
            call = '            actions_np = _apply_byzantine_attack(actions_np, args.byzantine_n, args.byzantine_type, action_type, n_agents)\n'
            lines.insert(i, check)
            lines.insert(i, call)
            off_policy_done = True
            print(f"Inserted off-policy byzantine at line {i}")

with open(filepath, "w") as f:
    f.writelines(lines)

print(f"✅ Patch done: on_policy={on_policy_done}, off_policy={off_policy_done}")
