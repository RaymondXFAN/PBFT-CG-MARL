#!/usr/bin/env python3
"""过夜实验结果汇总脚本"""
import json
import numpy as np
import os

CONDITIONS = ['clean', 'adv', 'random']
ALGOS = ['pbft_cg_mappo', 'mappo']
SEEDS = [1, 2, 3]

def load_results(cond, algo, seed):
    p = f'results/v42_full_{cond}/{algo}/seed_{seed}/metrics.json'
    if not os.path.exists(p):
        return None
    with open(p) as f:
        return json.load(f)

def extract_last_n(m, key, n=50):
    if m is None or key not in m:
        return None
    vals = m[key]
    if not vals:
        return None
    return np.mean(vals[-n:])

print("=" * 70)
print("PBFT-CG-MARL v4.2 过夜实验结果汇总")
print("=" * 70)

# 主表
print(f"\n{'条件':<12} {'算法':<18} {'Reward':<16} {'Entropy':<12} {'KL Loss':<12}")
print("-" * 70)

for cond in CONDITIONS:
    for algo in ALGOS:
        rewards = []
        entropies = []
        kl_losses = []
        for seed in SEEDS:
            m = load_results(cond, algo, seed)
            r = extract_last_n(m, 'episode/episode_reward', 50)
            e = extract_last_n(m, 'train/entropy', 50)
            k = extract_last_n(m, 'train/kl_consensus_loss', 50)
            if r is not None: rewards.append(r)
            if e is not None: entropies.append(e)
            if k is not None: kl_losses.append(k)
        
        r_str = f"{np.mean(rewards):.1f} ± {np.std(rewards):.1f}" if rewards else "N/A"
        e_str = f"{np.mean(entropies):.4f}" if entropies else "N/A"
        k_str = f"{np.mean(kl_losses):.4f}" if kl_losses else "N/A"
        
        algo_name = "PBFT-Soft" if "pbft" in algo else "MAPPO"
        print(f"{cond:<12} {algo_name:<18} {r_str:<16} {e_str:<12} {k_str:<12}")
    print()

# 对比表
print("=" * 70)
print("PBFT vs MAPPO 对比")
print("=" * 70)
print(f"\n{'条件':<12} {'PBFT':<16} {'MAPPO':<16} {'PBFT优势':<12}")
print("-" * 56)

for cond in CONDITIONS:
    pbft_rewards = []
    mappo_rewards = []
    for seed in SEEDS:
        m = load_results(cond, 'pbft_cg_mappo', seed)
        r = extract_last_n(m, 'episode/episode_reward', 50)
        if r is not None: pbft_rewards.append(r)
        
        m = load_results(cond, 'mappo', seed)
        r = extract_last_n(m, 'episode/episode_reward', 50)
        if r is not None: mappo_rewards.append(r)
    
    if pbft_rewards and mappo_rewards:
        pbft_mean = np.mean(pbft_rewards)
        mappo_mean = np.mean(mappo_rewards)
        # reward 越大越好（负数越接近0越好）
        advantage = (pbft_mean - mappo_mean) / abs(mappo_mean) * 100
        sign = "✅ PBFT赢" if advantage > 0 else "❌ MAPPO赢"
        print(f"{cond:<12} {pbft_mean:<16.1f} {mappo_mean:<16.1f} {advantage:+.1f}% {sign}")
    else:
        print(f"{cond:<12} 数据不完整")

print("\n" + "=" * 70)
