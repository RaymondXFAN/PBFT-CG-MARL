#!/bin/bash
cd /root/autodl-tmp/PBFT-CG-MARL
run_seed() {
  local s=$1
  echo "=== MPE matched seed $s at $(date) ==="
  python -u src/train.py --algo pbft_cg_mappo --env mpe_spread \
    --env_config configs/env/mpe_spread.yaml \
    --algo_config configs/algo/pbft_mult_matched_v5.yaml \
    --seed $s --n_timesteps 300000 --eval_interval 10000 \
    --eval_episodes 10 --log_dir results/phase1_matched_v2 --gpu 0
}
run_seed 1 & run_seed 2 & wait
run_seed 3 & run_seed 4 & wait
run_seed 5
echo "MPE MATCHED V2 DONE at $(date)"
