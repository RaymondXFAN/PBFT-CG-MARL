#!/usr/bin/env python3
"""
v4.2 修复 KL 散度 - 正确方案
evaluate_action 返回 (log_prob, entropy, hidden_state)
需要调用 self.actor.forward() 获取真正的 action_dist
"""
import os, shutil

filepath = "src/algorithms/pbft_cg_mappo.py"

with open(filepath, 'r', encoding='utf-8') as f:
    content = f.read()

shutil.copy2(filepath, filepath + ".v42kl2.bak")

changes = []

# === 修改 1: 还原 evaluate_action 的返回值变量名 ===
# 之前错误地把 hidden_state 命名为 action_dist
content = content.replace(
    'log_prob, entropy, action_dist = self.actor.evaluate_action(',
    'log_prob, entropy, _ = self.actor.evaluate_action('
)
content = content.replace(
    'log_prob, entropy, action_dist = self.actors[agent_id].evaluate_action(',
    'log_prob, entropy, _ = self.actors[agent_id].evaluate_action('
)
changes.append("还原 evaluate_action 返回值变量名")

# === 修改 2: 替换旧的交叉熵计算代码（用 action_dist.log_prob 的那个） ===
# 找到旧的交叉熵计算块并替换
old_ce_block = '''                # v4.2: 计算与共识动作的交叉熵损失（软共识引导）
                if self.soft_consensus_mode and hasattr(self, "_last_consensus_actions") and self._last_consensus_actions is not None:
                    try:
                        cons_a = self._last_consensus_actions[agent_id]
                        if isinstance(cons_a, int):
                            ca_tensor = torch.tensor(cons_a, device=self.device)
                        else:
                            ca_tensor = cons_a.detach().clone().to(self.device)
                        # 交叉熵 = -log_prob(consensus_action)，鼓励 agent 向共识靠拢
                        ce_loss = -action_dist.log_prob(ca_tensor)
                        if not hasattr(self, "_batch_ce_losses"):
                            self._batch_ce_losses = []
                        self._batch_ce_losses.append(ce_loss.mean())
                    except Exception as e:
                        print(f"[v4.2 KL ERROR] {e}")'''

new_ce_block = '''                # v4.2: 计算与共识动作的交叉熵损失（软共识引导）
                if self.soft_consensus_mode and hasattr(self, "_last_consensus_actions") and self._last_consensus_actions is not None:
                    try:
                        cons_a = self._last_consensus_actions[agent_id]
                        # 调用 forward() 获取真正的 action_dist
                        if self.share_param:
                            real_action_dist, _ = self.actor.forward(agent_obs)
                        else:
                            real_action_dist, _ = self.actors[agent_id].forward(agent_obs)
                        # 离散动作：共识动作是整数
                        if isinstance(cons_a, int):
                            ca_tensor = torch.tensor(cons_a, dtype=torch.long, device=self.device)
                        elif hasattr(cons_a, 'item'):
                            ca_tensor = torch.tensor(int(cons_a.item()), dtype=torch.long, device=self.device)
                        else:
                            ca_tensor = torch.tensor(int(cons_a), dtype=torch.long, device=self.device)
                        # 交叉熵 = -log_prob(consensus_action)
                        ce_loss = -real_action_dist.log_prob(ca_tensor)
                        if not hasattr(self, "_batch_ce_losses"):
                            self._batch_ce_losses = []
                        self._batch_ce_losses.append(ce_loss.mean())
                    except Exception as e:
                        print(f"[v4.2 KL ERROR] {e}")'''

if old_ce_block in content:
    content = content.replace(old_ce_block, new_ce_block, 1)
    changes.append("替换旧的交叉熵计算代码")
else:
    # 尝试宽松匹配
    import re
    # 找到从 "# v4.2: 计算与共识动作" 到 "except Exception as e" 的块
    pattern = r'(# v4.2: 计算与共识动作.*?except Exception as e:.*?print\(f"\[v4\.2 KL ERROR\].*?\))'
    match = re.search(pattern, content, re.DOTALL)
    if match:
        content = content.replace(match.group(1), new_ce_block)
        changes.append("替换旧的交叉熵计算代码（宽松匹配）")
    else:
        print("[WARN] 未找到旧的交叉熵计算代码")

# === 修改 3: 替换外层的 placeholder KL 散度代码 ===
old_kl_block = '''        # v4.2: 软共识引导损失（使用 batch 中累积的交叉熵）
        kl_consensus_loss = torch.tensor(0.0, device=self.device)
        if self.soft_consensus_mode and hasattr(self, "_batch_ce_losses") and self._batch_ce_losses:
            kl_consensus_loss = torch.stack(self._batch_ce_losses).mean()
            self._batch_ce_losses = []  # 清空'''

new_kl_block = '''        # v4.2: 软共识引导损失（使用 batch 中累积的交叉熵）
        kl_consensus_loss = torch.tensor(0.0, device=self.device)
        if self.soft_consensus_mode and hasattr(self, "_batch_ce_losses") and self._batch_ce_losses:
            kl_consensus_loss = torch.stack(self._batch_ce_losses).mean()
            self._batch_ce_losses = []  # 清空
            print(f"[v4.2] kl_consensus_loss={kl_consensus_loss.item():.4f}, n_losses={len(self._batch_ce_losses)+1}")'''

if old_kl_block in content:
    content = content.replace(old_kl_block, new_kl_block, 1)
    changes.append("替换外层 KL 散度代码，添加调试打印")

with open(filepath, 'w', encoding='utf-8') as f:
    f.write(content)

print(f"修改: {changes}")

# 验证语法
import py_compile
try:
    py_compile.compile(filepath, doraise=True)
    print("✅ 语法检查通过！")
except py_compile.PyCompileError as e:
    print(f"❌ 语法错误: {e}")
    print("恢复备份...")
    shutil.copy2(filepath + ".v42kl2.bak", filepath)
