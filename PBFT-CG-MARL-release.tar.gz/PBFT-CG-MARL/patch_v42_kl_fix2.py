#!/usr/bin/env python3
"""
v4.2 KL 散度修复 - evaluate_action 返回 hidden_state 不是 action_dist
需要单独调用 self.actor.forward() 获取 action_dist
"""
import os, shutil

filepath = "src/algorithms/pbft_cg_mappo.py"

with open(filepath, 'r', encoding='utf-8') as f:
    lines = f.readlines()

shutil.copy2(filepath, filepath + ".v42kl2.bak")

changes = []

# === 修改 1: 把 evaluate_action 的返回值改回 _ ===
for i, line in enumerate(lines):
    if 'log_prob, entropy, action_dist = self.actor.evaluate_action(' in line:
        lines[i] = line.replace('log_prob, entropy, action_dist =', 'log_prob, entropy, _ =')
        changes.append(f"L{i+1}: evaluate_action 返回值改回 _")
    elif 'log_prob, entropy, action_dist = self.actors[agent_id].evaluate_action(' in line:
        lines[i] = line.replace('log_prob, entropy, action_dist =', 'log_prob, entropy, _ =')
        changes.append(f"L{i+1}: evaluate_action 返回值改回 _")

# === 修改 2: 在交叉熵计算中，用 self.actor.forward() 获取 action_dist ===
# 找到 "if self.soft_consensus_mode and hasattr(self, "_last_consensus_actions")" 在 agent 循环里的位置
# 替换整个 try 块
for i, line in enumerate(lines):
    if 'v4.2: 计算与共识动作的交叉熵损失' in line:
        # 找到这个块的结束位置（except 后的 pass/print）
        start = i
        end = None
        for j in range(i, min(i + 25, len(lines))):
            if 'except Exception as e:' in lines[j]:
                # 找到下一行的 pass 或 print
                end = j + 1
                break
            elif 'except Exception:' in lines[j]:
                end = j + 1
                break
        
        if end is not None:
            indent = '                '
            new_code = [
                f'{indent}# v4.2: 计算与共识动作的交叉熵损失（软共识引导）\n',
                f'{indent}if self.soft_consensus_mode and hasattr(self, "_last_consensus_actions") and self._last_consensus_actions is not None:\n',
                f'{indent}    try:\n',
                f'{indent}        cons_a = self._last_consensus_actions[agent_id]\n',
                f'{indent}        # 调用 forward 获取真正的 action_dist（Categorical 分布）\n',
                f'{indent}        if self.share_param:\n',
                f'{indent}            ad, _ = self.actor(agent_obs)\n',
                f'{indent}        else:\n',
                f'{indent}            ad, _ = self.actors[agent_id](agent_obs)\n',
                f'{indent}        if isinstance(cons_a, int):\n',
                f'{indent}            ca_tensor = torch.tensor(cons_a, dtype=torch.long, device=self.device)\n',
                f'{indent}        elif hasattr(cons_a, "item"):\n',
                f'{indent}            ca_tensor = torch.tensor(int(cons_a.item()), dtype=torch.long, device=self.device)\n',
                f'{indent}        else:\n',
                f'{indent}            ca_tensor = cons_a.detach().clone().long().to(self.device)\n',
                f'{indent}        # 交叉熵 = -log_prob(consensus_action)，鼓励 agent 向共识靠拢\n',
                f'{indent}        ce_loss = -ad.log_prob(ca_tensor)\n',
                f'{indent}        if not hasattr(self, "_batch_ce_losses"):\n',
                f'{indent}            self._batch_ce_losses = []\n',
                f'{indent}        self._batch_ce_losses.append(ce_loss.mean())\n',
                f'{indent}    except Exception as e:\n',
                f'{indent}        print(f"[v4.2 KL ERROR] {{e}}")\n',
            ]
            lines[start:end + 1] = new_code
            changes.append(f"替换交叉熵计算块（L{start+1}-L{end+1}）")
        break

# 写入文件
with open(filepath, 'w', encoding='utf-8') as f:
    f.writelines(lines)

print(f"修改: {changes}")

# 验证语法
import py_compile
try:
    py_compile.compile(filepath, doraise=True)
    print("✅ 语法检查通过！")
except py_compile.PyCompileError as e:
    print(f"❌ 语法错误: {e}")
    shutil.copy2(filepath + ".v42kl2.bak", filepath)
