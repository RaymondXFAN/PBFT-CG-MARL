#!/usr/bin/env python3
import sys
sys.argv = ["test", "--byzantine_type", "message_forge", "--byzantine_n", "1", "--algo", "pbft_cg_mappo", "--env", "mpe_spread"]
from src.train import parse_args
args = parse_args()
print(f"byzantine_type={args.byzantine_type}, byzantine_n={args.byzantine_n}")
print("参数解析成功！")
