"""
Krum 动作聚合防御 — 作为 Byzantine-robust baseline
思路：每步收集所有 agent 的 proposal，计算两两距离，
选距离和最小的 agent 的动作作为共识输出（最接近几何中位数的 agent）
"""
import numpy as np
import torch
from typing import Dict, List, Tuple, Any

class KrumAggregator:
    """Krum aggregation for action-space defense"""
    def __init__(self, n_agents: int, f: int = 1):
        self.n_agents = n_agents
        self.f = f  # 最大拜占庭数
    
    def aggregate(self, actions: List[np.ndarray]) -> np.ndarray:
        """
        从 n 个 agent 的动作中选 Krum 动作
        args:
            actions: list of n agent actions, each shape (action_dim,)
        returns:
            selected action (shape same as one action)
        """
        n = len(actions)
        m = n - self.f - 2  # Krum 的近邻数
        
        if m <= 0:
            # fallback: 选距离中位数最近的
            if actions[0].ndim == 0:
                # 离散动作：选众数
                from collections import Counter
                counter = Counter(actions)
                return counter.most_common(1)[0][0]
            else:
                median = np.median(actions, axis=0)
                dists = [np.linalg.norm(a - median) for a in actions]
                return actions[np.argmin(dists)]
        
        # 计算两两距离
        dists = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                if actions[i].ndim == 0:
                    dists[i, j] = 0.0 if actions[i] == actions[j] else 1.0
                else:
                    dists[i, j] = np.linalg.norm(np.array(actions[i]) - np.array(actions[j]))
        
        # 对每个 agent，取最近的 m+1 个距离之和（含自身为0）
        scores = np.zeros(n)
        for i in range(n):
            sorted_dists = np.sort(dists[i])
            scores[i] = np.sum(sorted_dists[:m+1])
        
        # 选分数最小的（最"正常"的 agent）
        return actions[np.argmin(scores)]


class TrimmedMeanAggregator:
    """Trimmed Mean aggregation for action-space defense"""
    def __init__(self, n_agents: int, f: int = 1):
        self.n_agents = n_agents
        self.f = f
    
    def aggregate(self, actions: List[np.ndarray]) -> np.ndarray:
        """
        去掉 f 个最高和 f 个最低值后取平均
        """
        n = len(actions)
        if actions[0].ndim == 0:
            # 离散动作：排序后取中间部分
            sorted_actions = sorted(actions)
            trim = self.f
            if 2 * trim >= n:
                return sorted_actions[n // 2]  # fallback: 取中位数
            trimmed = sorted_actions[trim:n-trim]
            # 离散情况取众数
            from collections import Counter
            counter = Counter(trimmed)
            return counter.most_common(1)[0][0]
        else:
            # 连续动作：按维度 trim
            actions_arr = np.array(actions)
            n_dim = actions_arr.shape[1]
            result = np.zeros(n_dim)
            for d in range(n_dim):
                sorted_vals = np.sort(actions_arr[:, d])
                trim = self.f
                if 2 * trim >= n:
                    result[d] = np.median(actions_arr[:, d])
                else:
                    result[d] = np.mean(sorted_vals[trim:n-trim])
            return result
