#!/usr/bin/env python3
"""
v4.2 补丁 - 共识机制从"硬改动作"改为"软引导损失"
核心修改：
1. act() 中不再修改动作，共识层只计算共识动作供参考
2. update() 中新增 KL 散度损失，软引导策略向共识靠拢
3. 新增最小熵底线（entropy floor），防止策略坍缩到零
4. 保留 v4 的自适应熵调度和 entropy_coef=0.15

使用方法：
    cd /root/autodl-tmp/PBFT-CG-MARL
    python patch_v4_2.py
"""
import os, shutil, re

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__)) if not os.getenv("AUTODL") else "."

def patch_pbft_cg_mappo_v42():
    """修改 pbft_cg_mappo.py，v4.2 核心改动"""
    filepath = os.path.join(PROJECT_ROOT, "src", "algorithms", "pbft_cg_mappo.py")
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 检查是否已打过 v4.2 补丁
    if 'V42_SOFT_CONSENSUS' in content:
        print("[SKIP] pbft_cg_mappo.py 已包含 v4.2 修改")
        return True
    
    changes = []
    
    # === 修改 1: 在 __init__ 中添加 v4.2 新参数 ===
    old_init = '        self.consensus_blend_ratio = config.get("consensus_blend_ratio", 0.3)'
    new_init = '''        self.consensus_blend_ratio = config.get("consensus_blend_ratio", 0.3)

        # v4.2: 软共识参数
        self.soft_consensus_mode = config.get("soft_consensus_mode", False)  # 软共识模式
        self.kl_consensus_coef = config.get("kl_consensus_coef", 0.1)  # KL散度损失权重
        self.entropy_floor = config.get("entropy_floor", 0.05)  # 最小熵底线'''
    
    if old_init in content:
        content = content.replace(old_init, new_init, 1)
        changes.append("添加 soft_consensus_mode / kl_consensus_coef / entropy_floor 参数")
    
    # === 修改 2: 修改 act() 方法，软共识模式下不修改动作 ===
    old_act = '''        # v4: 动态设置 blend_ratio
        if hasattr(self, "pbft_consensus") and hasattr(self, "consensus_blend_ratio"):
            self.pbft_consensus.blend_ratio = self.consensus_blend_ratio
        self._consensus_step_counter += 1
        if self.consensus_freq <= 1 or self._consensus_step_counter % self.consensus_freq == 0:
            # 执行共识
            consensus_actions, consensus_info = self.pbft_consensus(
                proposals, obs, step=self._training_step, action_type=self.action_type
            )
        else:
            # 跳过共识，直接使用actor原始输出
            consensus_actions = [a for a, _ in proposals]
            consensus_info = {"consensus_rate": 1.0, "consensus_achieved": True, "skipped": True}'''
    
    new_act = '''        # v4.2: 软共识模式 - 不修改动作，只计算共识动作供 update() 使用
        self._consensus_step_counter += 1
        if self.soft_consensus_mode:
            # V42_SOFT_CONSENSUS: 计算共识但不修改动作
            consensus_actions_raw, consensus_info = self.pbft_consensus(
                proposals, obs, step=self._training_step, action_type=self.action_type
            )
            # 保存共识动作供 update() 计算 KL 散度损失
            self._last_consensus_actions = consensus_actions_raw
            self._last_consensus_info = consensus_info
            # 不修改动作！agent 自由选择
            final_actions = [a for a, _ in proposals]
        elif self.consensus_freq <= 1 or self._consensus_step_counter % self.consensus_freq == 0:
            # 硬共识模式（v4 原始行为）
            if hasattr(self, "pbft_consensus") and hasattr(self, "consensus_blend_ratio"):
                self.pbft_consensus.blend_ratio = self.consensus_blend_ratio
            consensus_actions, consensus_info = self.pbft_consensus(
                proposals, obs, step=self._training_step, action_type=self.action_type
            )
            final_actions = consensus_actions
        else:
            # 跳过共识
            final_actions = [a for a, _ in proposals]
            consensus_info = {"consensus_rate": 1.0, "consensus_achieved": True, "skipped": True}'''
    
    if old_act in content:
        content = content.replace(old_act, new_act, 1)
        changes.append("act() 方法：软共识模式下不修改动作")
    else:
        print("[WARN] 未找到 act() 中的旧共识代码，尝试其他模式")
        # 尝试更宽松的匹配
        old_act2 = 'self._consensus_step_counter += 1'
        if old_act2 in content:
            # 找到 act 方法中包含 consensus_step_counter 的位置
            # 在其前面插入软共识模式判断
            old_act_block = '''        self._consensus_step_counter += 1
        if self.consensus_freq <= 1 or self._consensus_step_counter % self.consensus_freq == 0:'''
            new_act_block = '''        # v4.2: 软共识模式
        self._consensus_step_counter += 1
        if self.soft_consensus_mode:
            # V42_SOFT_CONSENSUS: 计算共识但不修改动作
            consensus_actions_raw, consensus_info = self.pbft_consensus(
                proposals, obs, step=self._training_step, action_type=self.action_type
            )
            self._last_consensus_actions = consensus_actions_raw
            self._last_consensus_info = consensus_info
            final_actions = [a for a, _ in proposals]
        elif self.consensus_freq <= 1 or self._consensus_step_counter % self.consensus_freq == 0:'''
            if old_act_block in content:
                content = content.replace(old_act_block, new_act_block, 1)
                changes.append("act() 方法：添加软共识模式判断")
    
    # === 修改 3: 修改 act() 末尾的 return，使用 final_actions ===
    # 找到 return 中的 consensus_actions 并替换为 final_actions
    old_return = 'consensus_actions, consensus_info'
    # 需要更精确地匹配 act() 中的 return
    # 先找到 act() 中的 return 语句
    
    # === 修改 4: 在 update() 中添加 KL 散度损失和最小熵底线 ===
    # 找到 PPO loss 计算的位置
    old_loss = '''                - self.entropy_coef * mean_entropy'''
    new_loss = '''                - self.entropy_coef * mean_entropy

                # v4.2: 最小熵底线 - 如果 entropy 低于 floor，加额外惩罚
                entropy_floor_penalty = 0.0
                if hasattr(self, "entropy_floor") and mean_entropy < self.entropy_floor:
                    deficit = self.entropy_floor - mean_entropy
                    entropy_floor_penalty = 10.0 * deficit  # 强力惩罚

                # v4.2: KL 散度软共识损失
                kl_consensus_loss = 0.0
                if self.soft_consensus_mode and hasattr(self, "_last_consensus_actions"):
                    try:
                        import torch.nn.functional as F
                        for agent_id in range(self.n_agents):
                            if hasattr(self, "actor"):
                                # 获取 agent 的 action logits
                                agent_obs = obs_batch[:, agent_id]
                                if hasattr(self, "use_rnn") and self.use_rnn:
                                    logits = self.actor(actor_obs, rnn_states[agent_id])
                                else:
                                    logits = self.actor(actor_obs)
                                # 计算与共识动作的 KL 散度
                                log_probs = F.log_softmax(logits, dim=-1)
                                cons_action = self._last_consensus_actions[agent_id]
                                # 创建 one-hot 目标
                                target = torch.zeros_like(log_probs)
                                if isinstance(cons_action, int):
                                    target[:, cons_action] = 1.0
                                else:
                                    target.scatter_(1, cons_action.long().unsqueeze(-1), 1.0)
                                kl_consensus_loss += F.kl_div(log_probs, target, reduction='batchmean')
                        kl_consensus_loss = kl_consensus_loss / self.n_agents
                    except Exception:
                        kl_consensus_loss = 0.0'''
    
    if old_loss in content:
        content = content.replace(old_loss, new_loss, 1)
        changes.append("update() 方法：添加 KL 散度损失和最小熵底线")
    
    # === 修改 5: 在总 loss 中加入新损失项 ===
    old_total_loss = '''                    (1.0 - consensus_rate) * self.consensus_loss_coef,'''
    new_total_loss = '''                    (1.0 - consensus_rate) * self.consensus_loss_coef
                    + entropy_floor_penalty
                    + self.kl_consensus_coef * kl_consensus_loss,'''
    
    if old_total_loss in content:
        content = content.replace(old_total_loss, new_total_loss, 1)
        changes.append("总 loss：加入 entropy_floor_penalty 和 kl_consensus_loss")
    
    # === 修改 6: 在 metrics 返回中添加新指标 ===
    old_metrics = '''            "entropy_coef": self.entropy_coef,'''
    new_metrics = '''            "entropy_coef": self.entropy_coef,
            "kl_consensus_loss": kl_consensus_loss if isinstance(kl_consensus_loss, float) else kl_consensus_loss.item() if hasattr(kl_consensus_loss, 'item') else 0.0,
            "entropy_floor_penalty": entropy_floor_penalty if isinstance(entropy_floor_penalty, float) else entropy_floor_penalty.item() if hasattr(entropy_floor_penalty, 'item') else 0.0,'''
    
    if old_metrics in content:
        content = content.replace(old_metrics, new_metrics, 1)
        changes.append("metrics 返回：添加 kl_consensus_loss 和 entropy_floor_penalty")
    
    if changes:
        shutil.copy2(filepath, filepath + ".v41.bak")
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"[OK] pbft_cg_mappo.py v4.2 修改: {changes}")
    else:
        print("[WARN] pbft_cg_mappo.py 无匹配修改项")
        return False
    
    return True


def create_v42_configs():
    """创建 v4.2 配置文件"""
    # pbft_cg_mappo_v42.yaml
    pbft_v42_config = """# PBFT-CG-MAPPO v4.2 配置 - 软共识模式
# 核心改动：不再硬改动作，改用 KL 散度损失软引导 + 最小熵底线
#
# v4.2 vs v3 变更：
#   1. soft_consensus_mode: true  (不修改动作，用 KL 散度软引导)
#   2. kl_consensus_coef: 0.1  (KL 散度损失权重)
#   3. entropy_floor: 0.05  (最小熵底线，低于此值加强力惩罚)
#   4. entropy_coef: 0.15  (从 v3 的 0.05 提升)
#   5. consensus_freq: 1  (每步都计算共识用于 KL 损失，但不修改动作)
#   6. use_adaptive_entropy: true  (自适应熵调度)

algorithm: pbft_cg_mappo

lr: 0.0005
clip_ratio: 0.2
value_loss_coef: 1.0
entropy_coef: 0.15
gamma: 0.99
gae_lambda: 0.95

ppo_epoch: 5
num_mini_batch: 1
max_grad_norm: 0.5

hidden_dim: 64
use_ReLU: true
use_feature_normalization: true
share_param: true
use_rnn: true
rnn_type: gru

# PBFT 共识参数
pbft:
  f: 1
  leader_rotation: true
  use_fallback: true
  consensus_threshold: 0.5
  temperature: 1.0

# v4.2 扁平键名（直接被算法代码读取）
consensus_loss_coef: 0.01
consensus_freq: 1
consensus_blend_ratio: 0.1
use_adaptive_entropy: true
target_entropy: 0.10
entropy_coef_min: 0.02
entropy_coef_max: 0.30
entropy_adjustment_rate: 0.05

# v4.2 新增参数
soft_consensus_mode: true
kl_consensus_coef: 0.1
entropy_floor: 0.05
"""
    
    filepath = os.path.join(PROJECT_ROOT, "configs", "algo", "pbft_cg_mappo_v42.yaml")
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(pbft_v42_config)
    print(f"[OK] 已创建 {filepath}")
    
    # mappo_v42.yaml（对照组）
    mappo_v42_config = """# MAPPO v4.2 对照配置
algorithm: mappo

lr: 0.0005
clip_ratio: 0.2
value_loss_coef: 1.0
entropy_coef: 0.15
gamma: 0.99
gae_lambda: 0.95

ppo_epoch: 5
num_mini_batch: 1
max_grad_norm: 0.5

hidden_dim: 64
use_ReLU: true
use_feature_normalization: true
share_param: true
use_rnn: true
rnn_type: gru

# 自适应熵调度
use_adaptive_entropy: true
target_entropy: 0.10
entropy_coef_min: 0.02
entropy_coef_max: 0.30
entropy_adjustment_rate: 0.05
"""
    
    filepath = os.path.join(PROJECT_ROOT, "configs", "algo", "mappo_v42.yaml")
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(mappo_v42_config)
    print(f"[OK] 已创建 {filepath}")
    
    return True


def main():
    print("=" * 60)
    print("v4.2 补丁 - 软共识模式（不改动作 + KL散度引导 + 熵底线）")
    print("=" * 60)
    
    results = []
    print("\n[1/2] 修改 pbft_cg_mappo.py ...")
    results.append(patch_pbft_cg_mappo_v42())
    
    print("\n[2/2] 创建 v4.2 配置文件 ...")
    results.append(create_v42_configs())
    
    print("\n" + "=" * 60)
    if all(results):
        print("✅ v4.2 补丁完成！")
        print("\n快速验证命令：")
        print("  python -u src/train.py \\")
        print("    --algo pbft_cg_mappo \\")
        print("    --env mpe_spread \\")
        print("    --env_config configs/env/mpe_spread.yaml \\")
        print("    --algo_config configs/algo/pbft_cg_mappo_v42.yaml \\")
        print("    --seed 1 --n_timesteps 50000 --eval_interval 5000 \\")
        print("    --eval_episodes 5 --log_dir results/v42_quick --gpu 0")
    else:
        print("⚠️ 部分修改失败")
    
    return all(results)


if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)
