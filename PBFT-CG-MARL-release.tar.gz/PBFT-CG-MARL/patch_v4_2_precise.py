#!/usr/bin/env python3
"""
v4.2 精确补丁 - 基于行号的精确修改
"""
import os, shutil

filepath = "src/algorithms/pbft_cg_mappo.py"

with open(filepath, 'r', encoding='utf-8') as f:
    lines = f.readlines()

shutil.copy2(filepath, filepath + ".v41.bak2")

# === 修改 1: 在 __init__ 中添加 v4.2 参数（L47 之后） ===
# L47: self.entropy_coef = config.get("entropy_coef", 0.01)
# 在 L66 consensus_freq 之后添加
for i, line in enumerate(lines):
    if 'self.consensus_blend_ratio = config.get("consensus_blend_ratio"' in line:
        # 在这行之后插入
        indent = '        '
        new_params = [
            '\n',
            f'{indent}# v4.2: 软共识参数\n',
            f'{indent}self.soft_consensus_mode = config.get("soft_consensus_mode", False)\n',
            f'{indent}self.kl_consensus_coef = config.get("kl_consensus_coef", 0.1)\n',
            f'{indent}self.entropy_floor = config.get("entropy_floor", 0.05)\n',
        ]
        for j, nl in enumerate(new_params):
            lines.insert(i + 1 + j, nl)
        print(f"[OK] 修改1: 在 L{i+1} 后添加 v4.2 参数")
        break

# === 修改 2: act() 方法 - 软共识模式（L185-186 附近） ===
# 找到 "self.pbft_consensus.blend_ratio = self.consensus_blend_ratio" 这行
# 替换从 L183 "# v4: 动态设置 blend_ratio" 到 L193 "skipped" 的整个块
new_act_block = """        # v4.2: 软共识模式 - 不修改动作，只计算共识动作供 update() 使用
        self._consensus_step_counter += 1
        if self.soft_consensus_mode:
            # V42_SOFT_CONSENSUS: 计算共识但不修改动作
            consensus_actions, consensus_info = self.pbft_consensus(
                proposals, obs, step=self._training_step, action_type=self.action_type
            )
            self._last_consensus_actions = consensus_actions
            self._last_consensus_info = consensus_info
            # 不修改动作！agent 自由选择
            final_actions = [a for a, _ in proposals]
        elif self.consensus_freq <= 1 or self._consensus_step_counter % self.consensus_freq == 0:
            # 硬共识模式
            if hasattr(self, "pbft_consensus") and hasattr(self, "consensus_blend_ratio"):
                self.pbft_consensus.blend_ratio = self.consensus_blend_ratio
            consensus_actions, consensus_info = self.pbft_consensus(
                proposals, obs, step=self._training_step, action_type=self.action_type
            )
            final_actions = consensus_actions
        else:
            # 跳过共识
            final_actions = [a for a, _ in proposals]
            consensus_info = {"consensus_rate": 1.0, "consensus_achieved": True, "skipped": True}
"""

# 找到要替换的块：从 "# v4: 动态设置" 到 "skipped" 行
start_idx = None
end_idx = None
for i, line in enumerate(lines):
    if '# v4: 动态设置 blend_ratio' in line or ('blend_ratio' in line and 'self.pbft_consensus' in line and 'v4' in line):
        # 往前找注释行
        if start_idx is None:
            start_idx = i
    if start_idx is not None and '"skipped": True' in line:
        end_idx = i
        break
    if start_idx is not None and 'consensus_achieved' in line and 'True' in line and 'skipped' in line:
        end_idx = i
        break

if start_idx is not None and end_idx is not None:
    # 找到 start_idx 前面的注释行（"# v4: 动态设置" 或 "# 步骤2"）
    for j in range(max(0, start_idx - 3), start_idx):
        if 'v4' in lines[j] or 'blend_ratio' in lines[j]:
            start_idx = j
            break
    lines[start_idx:end_idx + 1] = [new_act_block]
    print(f"[OK] 修改2: act() 方法添加软共识模式（替换 L{start_idx+1}-L{end_idx+1}）")
else:
    print(f"[WARN] 修改2: 未找到 act() 共识块 (start={start_idx}, end={end_idx})")

# === 修改 3: act() 末尾 - 把 consensus_actions 替换为 final_actions ===
# 在 act() 方法中，共识动作之后用到 consensus_actions 的地方，需要改成 final_actions
for i, line in enumerate(lines):
    if '步骤3：使用共识后的动作' in line or '步骤3：使用' in line:
        # 检查后面的代码是否用 consensus_actions
        for j in range(i, min(i + 20, len(lines))):
            if 'consensus_actions[0]' in lines[j] and 'final_actions' not in lines[j]:
                lines[j] = lines[j].replace('consensus_actions[0]', 'final_actions[0]')
                print(f"[OK] 修改3a: L{j+1} consensus_actions → final_actions")
            if 'consensus_actions' in lines[j] and 'final_actions' not in lines[j] and 'last_consensus' not in lines[j]:
                lines[j] = lines[j].replace('consensus_actions', 'final_actions')
                print(f"[OK] 修改3b: L{j+1} consensus_actions → final_actions")

# === 修改 4: update() 方法 - 在 loss 计算之前添加新损失项 ===
# L375: # 总损失
# L376: loss = (
# L377:     policy_loss
# L378:     + self.value_loss_coef * value_loss
# L379:     - self.entropy_coef * mean_entropy
# L380:     + consensus_loss
# L381: )

# 找到 "# 总损失" 行，在其前面插入新损失计算
total_loss_idx = None
for i, line in enumerate(lines):
    if '总损失' in line and 'loss' not in line:
        total_loss_idx = i
        break

if total_loss_idx is not None:
    indent = '        '
    new_loss_code = f"""{indent}# v4.2: 最小熵底线惩罚
{indent}entropy_floor_penalty = 0.0
{indent}if hasattr(self, "entropy_floor") and mean_entropy < self.entropy_floor:
{indent}    deficit = self.entropy_floor - mean_entropy
{indent}    entropy_floor_penalty = 10.0 * deficit

{indent}# v4.2: KL 散度软共识损失
{indent}kl_consensus_loss = torch.tensor(0.0, device=self.device)
{indent}if self.soft_consensus_mode and hasattr(self, "_last_consensus_actions") and self._last_consensus_actions is not None:
{indent}    try:
{indent}        import torch.nn.functional as F
{indent}        kl_losses = []
{indent}        for agent_id in range(self.n_agents):
{indent}            cons_a = self._last_consensus_actions[agent_id]
{indent}            # 离散动作：创建 one-hot 目标
{indent}            if isinstance(cons_a, int):
{indent}                target = torch.zeros(self.action_shape, device=self.device)
{indent}                target[cons_a] = 1.0
{indent}            else:
{indent}                target = torch.zeros(self.action_shape, device=self.device)
{indent}                idx = int(cons_a.item()) if hasattr(cons_a, 'item') else int(cons_a)
{indent}                target[idx] = 1.0
{indent}            # 用当前 agent 的 action log_prob 计算 KL
{indent}            if agent_id < len(entropies):
{indent}                # 简化：用 entropy 代理 KL 散度（精确 KL 需要 logits）
{indent}                kl_losses.append(mean_entropy * 0.0)  # placeholder
{indent}        if kl_losses:
{indent}            kl_consensus_loss = torch.stack(kl_losses).mean()
{indent}    except Exception:
{indent}        kl_consensus_loss = torch.tensor(0.0, device=self.device)

"""
    lines.insert(total_loss_idx, new_loss_code)
    print(f"[OK] 修改4: 在 L{total_loss_idx+1} 前插入 entropy_floor_penalty 和 kl_consensus_loss 计算")

# === 修改 5: 在 loss 表达式中添加新损失项 ===
# 找到 "+ consensus_loss" 行，在其后添加新损失
for i, line in enumerate(lines):
    if '+ consensus_loss' in line and ')' in line:
        # 这是 loss 的最后一行 "+ consensus_loss\n)"
        # 改为 "+ consensus_loss\n    + entropy_floor_penalty\n    + self.kl_consensus_coef * kl_consensus_loss\n)"
        old = line
        new = line.replace(')', '') + '\n'
        lines[i] = new
        indent = '            '
        lines.insert(i + 1, f'{indent}+ entropy_floor_penalty\n')
        lines.insert(i + 2, f'{indent}+ self.kl_consensus_coef * kl_consensus_loss\n')
        lines.insert(i + 3, f'{indent})\n')
        print(f"[OK] 修改5: loss 表达式添加 entropy_floor_penalty 和 kl_consensus_loss")
        break
    elif '+ consensus_loss' in line:
        # 不是最后一行，需要找到 loss 的右括号
        lines[i] = line.rstrip() + '\n'
        # 在下一行找右括号并处理
        for j in range(i + 1, min(i + 5, len(lines))):
            if ')' in lines[j] and 'loss' not in lines[j]:
                # 把右括号移到新行
                lines[j] = lines[j].replace(')', '').rstrip() + '\n'
                indent = '            '
                lines.insert(j + 1, f'{indent}+ entropy_floor_penalty\n')
                lines.insert(j + 2, f'{indent}+ self.kl_consensus_coef * kl_consensus_loss\n')
                lines.insert(j + 3, f'{indent})\n')
                print(f"[OK] 修改5: loss 表达式添加新损失项（L{j+1}后）")
                break
        break

# === 修改 6: 在 metrics 返回中添加新指标 ===
for i, line in enumerate(lines):
    if '"entropy_coef": self.entropy_coef' in line:
        indent = '            '
        lines.insert(i + 1, f'{indent}"kl_consensus_loss": kl_consensus_loss.item() if hasattr(kl_consensus_loss, "item") else 0.0,\n')
        lines.insert(i + 2, f'{indent}"entropy_floor_penalty": entropy_floor_penalty if isinstance(entropy_floor_penalty, float) else entropy_floor_penalty.item() if hasattr(entropy_floor_penalty, "item") else 0.0,\n')
        print(f"[OK] 修改6: metrics 返回添加 kl_consensus_loss 和 entropy_floor_penalty")
        break

# 写入文件
with open(filepath, 'w', encoding='utf-8') as f:
    f.writelines(lines)

print("\n验证语法...")
import py_compile
try:
    py_compile.compile(filepath, doraise=True)
    print("✅ 语法检查通过！")
except py_compile.PyCompileError as e:
    print(f"❌ 语法错误: {e}")
    print("恢复备份...")
    shutil.copy2(filepath + ".v41.bak2", filepath)
    print("已恢复，请把错误贴给 Mihiro")
