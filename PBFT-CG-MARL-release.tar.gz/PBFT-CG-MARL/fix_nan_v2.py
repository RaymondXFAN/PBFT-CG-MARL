#!/usr/bin/env python3
"""
VMAS NaN 综合修复
三重防护：1. value_loss 截断 2. NaN梯度跳步 3. 输入NaN跳步
"""
filepath = "src/algorithms/pbft_cg_mappo.py"

with open(filepath, 'r') as f:
    content = f.read()

import shutil
shutil.copy2(filepath, filepath + ".pre_nan_v2.bak")

changes = []

# === 修复1: value_loss 截断 ===
old_vl = '        value_loss = F.mse_loss(returns.squeeze(-1), value)'
new_vl = '        value_loss = F.mse_loss(returns.squeeze(-1), value)\n        value_loss = torch.clamp(value_loss, max=5000.0)  # v5.1: 防止value梯度爆炸'
if old_vl in content:
    content = content.replace(old_vl, new_vl, 1)
    changes.append("value_loss 截断 max=5000")

# === 修复2: 梯度更新加NaN检测 ===
old_grad = '''        # 梯度更新（v5.1: NaN 保护）
        self.optimizer.zero_grad()
        loss.backward()
        # NaN 梯度检测
        has_nan = False
        for p in self.parameters():
            if p.grad is not None and torch.isnan(p.grad).any():
                has_nan = True
                break
        if has_nan:
            self.optimizer.zero_grad()  # 清空梯度，跳过此步更新
        else:
            nn.utils.clip_grad_norm_(self.parameters(), self.max_grad_norm)
            self.optimizer.step()'''

new_grad = '''        # 梯度更新（v5.1: NaN 保护）
        self.optimizer.zero_grad()
        # 检测 loss 是否 NaN
        if torch.isnan(loss) or torch.isinf(loss):
            self.optimizer.zero_grad()
            return {
                "policy_loss": 0.0, "value_loss": 0.0,
                "entropy": 0.0, "consensus_loss": 0.0,
                "kl_consensus_loss": 0.0, "entropy_floor_penalty": 0.0,
                "entropy_coef": self.entropy_coef,
            }
        loss.backward()
        # NaN 梯度检测
        has_nan = False
        for p in self.parameters():
            if p.grad is not None and (torch.isnan(p.grad).any() or torch.isinf(p.grad).any()):
                has_nan = True
                break
        if has_nan:
            self.optimizer.zero_grad()  # 跳过此步
        else:
            nn.utils.clip_grad_norm_(self.parameters(), self.max_grad_norm)
            self.optimizer.step()'''

if old_grad in content:
    content = content.replace(old_grad, new_grad, 1)
    changes.append("loss NaN 检测 + 提前返回")
else:
    # 尝试更宽松匹配
    old_grad2 = '''        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.parameters(), self.max_grad_norm)
        self.optimizer.step()'''
    new_grad2 = '''        # v5.1: NaN 保护
        self.optimizer.zero_grad()
        if torch.isnan(loss) or torch.isinf(loss):
            self.optimizer.zero_grad()
            return {"policy_loss": 0.0, "value_loss": 0.0, "entropy": 0.0,
                    "consensus_loss": 0.0, "kl_consensus_loss": 0.0,
                    "entropy_floor_penalty": 0.0, "entropy_coef": self.entropy_coef}
        loss.backward()
        has_nan = False
        for p in self.parameters():
            if p.grad is not None and (torch.isnan(p.grad).any() or torch.isinf(p.grad).any()):
                has_nan = True
                break
        if has_nan:
            self.optimizer.zero_grad()
        else:
            nn.utils.clip_grad_norm_(self.parameters(), self.max_grad_norm)
            self.optimizer.step()'''
    if old_grad2 in content:
        content = content.replace(old_grad2, new_grad2, 1)
        changes.append("loss NaN 检测（宽松匹配）")

# === 修复3: evaluate_action 前检测输入 NaN ===
old_eval = '''            if self.share_param:
                log_prob, entropy, action_dist = self.actor.evaluate_action(
                    agent_obs, actions[:, agent_id]
                )
            else:
                log_prob, entropy, action_dist = self.actors[agent_id].evaluate_action(
                    agent_obs, actions[:, agent_id]
                )'''

new_eval = '''            # v5.1: 输入NaN检测
            if torch.isnan(agent_obs).any() or torch.isnan(actions[:, agent_id]).any():
                new_log_probs.append(torch.zeros(1, device=self.device))
                entropies.append(torch.zeros(1, device=self.device))
                continue
            if self.share_param:
                log_prob, entropy, action_dist = self.actor.evaluate_action(
                    agent_obs, actions[:, agent_id]
                )
            else:
                log_prob, entropy, action_dist = self.actors[agent_id].evaluate_action(
                    agent_obs, actions[:, agent_id]
                )'''

if old_eval in content:
    content = content.replace(old_eval, new_eval, 1)
    changes.append("evaluate_action 前输入NaN检测")
else:
    # 宽松匹配
    old_eval2 = '''            if self.share_param:
                log_prob, entropy, _ = self.actor.evaluate_action(
                    agent_obs, actions[:, agent_id]
                )
            else:
                log_prob, entropy, _ = self.actors[agent_id].evaluate_action(
                    agent_obs, actions[:, agent_id]
                )'''
    new_eval2 = '''            # v5.1: 输入NaN检测
            if torch.isnan(agent_obs).any() or torch.isnan(actions[:, agent_id]).any():
                new_log_probs.append(torch.zeros(1, device=self.device))
                entropies.append(torch.zeros(1, device=self.device))
                continue
            if self.share_param:
                log_prob, entropy, _ = self.actor.evaluate_action(
                    agent_obs, actions[:, agent_id]
                )
            else:
                log_prob, entropy, _ = self.actors[agent_id].evaluate_action(
                    agent_obs, actions[:, agent_id]
                )'''
    if old_eval2 in content:
        content = content.replace(old_eval2, new_eval2, 1)
        changes.append("evaluate_action 前输入NaN检测（宽松匹配）")

with open(filepath, 'w') as f:
    f.write(content)

import py_compile
try:
    py_compile.compile(filepath, doraise=True)
    print(f"修改: {changes}")
    print("✅ 语法检查通过！")
except py_compile.PyCompileError as e:
    print(f"❌ 语法错误: {e}")
    shutil.copy2(filepath + ".pre_nan_v2.bak", filepath)
