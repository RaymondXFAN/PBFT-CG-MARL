#!/usr/bin/env python3
"""
v4.2 最终修复 - 从后往前改，避免行号偏移
"""
import os, shutil

filepath = "src/algorithms/pbft_cg_mappo.py"

with open(filepath, 'r', encoding='utf-8') as f:
    lines = f.readlines()

shutil.copy2(filepath, filepath + ".v42g.bak")

indent = '        '
indent2 = '            '
indent3 = '                '

# ===== 修改 6: metrics 添加新指标（从后往前第1个） =====
for i, line in enumerate(lines):
    if '"entropy_coef": self.entropy_coef' in line:
        lines.insert(i + 1, f'{indent2}"kl_consensus_loss": self._kl_consensus_loss_val,\n')
        lines.insert(i + 2, f'{indent2}"entropy_floor_penalty": self._entropy_floor_penalty_val,\n')
        print(f"修改6: L{i+1} 后添加 metrics")
        break

# ===== 修改 5: 替换 loss 区域（从后往前第2个） =====
# 找到 "consensus_loss = torch.tensor(0.0, device=self.device)" 行
cons_loss_idx = None
for i, line in enumerate(lines):
    if 'consensus_loss = torch.tensor(0.0, device=self.device)' in line:
        cons_loss_idx = i
        break

# 找到 loss 的右括号行（从 consensus_loss 开始往后找）
loss_end_idx = None
for i in range(cons_loss_idx + 1, cons_loss_idx + 30):
    if i < len(lines) and lines[i].strip() == ')' and 'policy_loss' not in lines[i]:
        loss_end_idx = i
        break

print(f"loss 区域: L{cons_loss_idx+1}-L{loss_end_idx+1}")

# 打印替换前的内容，方便调试
print("替换前:")
for j in range(cons_loss_idx, loss_end_idx + 1):
    print(f"  L{j+1}: {lines[j].rstrip()}")

new_loss = [
    f'{indent}# v4.2: 共识损失\n',
    f'{indent}consensus_loss = torch.tensor(0.0, device=self.device)\n',
    f'{indent}if hasattr(self, "_last_consensus_info") and self._last_consensus_info is not None:\n',
    f'{indent}    consensus_rate = self._last_consensus_info.get("consensus_rate", 0.0)\n',
    f'{indent}    consensus_loss = torch.tensor(\n',
    f'{indent}        (1.0 - consensus_rate) * self.consensus_loss_coef,\n',
    f'{indent}        device=self.device,\n',
    f'{indent}    )\n',
    f'{indent}\n',
    f'{indent}# v4.2: 最小熵底线惩罚（确保是 tensor）\n',
    f'{indent}entropy_floor_penalty = torch.tensor(0.0, device=self.device)\n',
    f'{indent}if hasattr(self, "entropy_floor") and mean_entropy < self.entropy_floor:\n',
    f'{indent}    deficit = self.entropy_floor - mean_entropy\n',
    f'{indent}    entropy_floor_penalty = torch.tensor(10.0 * deficit.item(), device=self.device)\n',
    f'{indent}\n',
    f'{indent}# v4.2: 软共识交叉熵损失\n',
    f'{indent}kl_consensus_loss = torch.tensor(0.0, device=self.device)\n',
    f'{indent}if self.soft_consensus_mode and hasattr(self, "_batch_ce_losses") and self._batch_ce_losses:\n',
    f'{indent}    kl_consensus_loss = torch.stack(self._batch_ce_losses).mean()\n',
    f'{indent}    self._batch_ce_losses = []\n',
    f'{indent}\n',
    f'{indent}# 记录用于 metrics\n',
    f'{indent}self._kl_consensus_loss_val = kl_consensus_loss.item()\n',
    f'{indent}self._entropy_floor_penalty_val = entropy_floor_penalty.item()\n',
    f'{indent}\n',
    f'{indent}# 总损失（所有项都是 tensor）\n',
    f'{indent}loss = (\n',
    f'{indent2}policy_loss\n',
    f'{indent2}+ self.value_loss_coef * value_loss\n',
    f'{indent2}- self.entropy_coef * mean_entropy\n',
    f'{indent2}+ consensus_loss\n',
    f'{indent2}+ entropy_floor_penalty\n',
    f'{indent2}+ self.kl_consensus_coef * kl_consensus_loss\n',
    f'{indent})\n',
]

lines[cons_loss_idx:loss_end_idx + 1] = new_loss
print(f"修改5: 替换 loss 区域")

# ===== 修改 4: 在 entropies.append 后添加交叉熵（从后往前第3个） =====
for i, line in enumerate(lines):
    if 'entropies.append(entropy)' in line:
        new_ce = [
            line,
            f'{indent3}# v4.2: 计算与共识动作的交叉熵损失\n',
            f'{indent3}if self.soft_consensus_mode and hasattr(self, "_last_consensus_actions") and self._last_consensus_actions is not None:\n',
            f'{indent3}    try:\n',
            f'{indent3}        cons_a = self._last_consensus_actions[agent_id]\n',
            f'{indent3}        if isinstance(cons_a, int):\n',
            f'{indent3}            ca_tensor = torch.tensor(cons_a, device=self.device)\n',
            f'{indent3}        else:\n',
            f'{indent3}            ca_tensor = cons_a.detach().clone().to(self.device)\n',
            f'{indent3}        ce_loss = -action_dist.log_prob(ca_tensor)\n',
            f'{indent3}        if not hasattr(self, "_batch_ce_losses"):\n',
            f'{indent3}            self._batch_ce_losses = []\n',
            f'{indent3}        self._batch_ce_losses.append(ce_loss.mean())\n',
            f'{indent3}    except Exception:\n',
            f'{indent3}        pass\n',
        ]
        lines[i:i+1] = new_ce
        print(f"修改4: L{i+1} 后添加交叉熵计算")
        break

# ===== 修改 3: 保存 action_dist（从后往前第4个） =====
for i, line in enumerate(lines):
    if 'log_prob, entropy, _ = self.actor.evaluate_action(' in line:
        lines[i] = line.replace('log_prob, entropy, _ =', 'log_prob, entropy, action_dist =')
        print(f"修改3a: L{i+1}")
    elif 'log_prob, entropy, _ = self.actors[agent_id].evaluate_action(' in line:
        lines[i] = line.replace('log_prob, entropy, _ =', 'log_prob, entropy, action_dist =')
        print(f"修改3b: L{i+1}")

# ===== 修改 2: act() 软共识模式（从后往前第5个） =====
# 找到 "步骤2" 行
step2_idx = None
for i, line in enumerate(lines):
    if '步骤2' in line and 'PBFT' in line:
        step2_idx = i
        break

# 找到 "skipped": True" 行
skipped_idx = None
for i in range(step2_idx, step2_idx + 20):
    if i < len(lines) and '"skipped": True' in lines[i]:
        skipped_idx = i
        break

print(f"act() 区域: L{step2_idx+1}-L{skipped_idx+1}")

# 打印替换前的内容
print("替换前:")
for j in range(step2_idx, skipped_idx + 1):
    print(f"  L{j+1}: {lines[j].rstrip()}")

new_act = [
    f'{indent}# 步骤2：PBFT共识层（v4.2: 支持软共识模式）\n',
    f'{indent}self._consensus_step_counter += 1\n',
    f'{indent}if self.soft_consensus_mode:\n',
    f'{indent2}# V42_SOFT_CONSENSUS: 计算共识但不修改动作\n',
    f'{indent2}consensus_actions, consensus_info = self.pbft_consensus(\n',
    f'{indent3}proposals, obs, step=self._training_step, action_type=self.action_type\n',
    f'{indent2})\n',
    f'{indent2}self._last_consensus_actions = consensus_actions\n',
    f'{indent2}self._last_consensus_info = consensus_info\n',
    f'{indent2}# 不修改动作！agent 自由选择\n',
    f'{indent2}final_actions = [a for a, _ in proposals]\n',
    f'{indent}elif self.consensus_freq <= 1 or self._consensus_step_counter % self.consensus_freq == 0:\n',
    f'{indent2}# 硬共识模式\n',
    f'{indent2}if hasattr(self, "pbft_consensus") and hasattr(self, "consensus_blend_ratio"):\n',
    f'{indent3}self.pbft_consensus.blend_ratio = self.consensus_blend_ratio\n',
    f'{indent2}consensus_actions, consensus_info = self.pbft_consensus(\n',
    f'{indent3}proposals, obs, step=self._training_step, action_type=self.action_type\n',
    f'{indent2})\n',
    f'{indent2}final_actions = consensus_actions\n',
    f'{indent}else:\n',
    f'{indent2}# 跳过共识\n',
    f'{indent2}final_actions = [a for a, _ in proposals]\n',
    f'{indent2}consensus_info = {{"consensus_rate": 1.0, "consensus_achieved": True, "skipped": True}}\n',
]

lines[step2_idx:skipped_idx + 1] = new_act
print(f"修改2: act() 软共识模式")

# ===== 修改 2b: consensus_actions → final_actions =====
step3_idx = None
for i, line in enumerate(lines):
    if '步骤3' in line and '共识' in line:
        step3_idx = i
        break

if step3_idx is not None:
    for j in range(step3_idx, min(step3_idx + 30, len(lines))):
        if 'consensus_actions[0]' in lines[j] and 'final_actions' not in lines[j]:
            lines[j] = lines[j].replace('consensus_actions[0]', 'final_actions[0]')
        if 'consensus_actions' in lines[j] and 'final_actions' not in lines[j] and 'last_consensus' not in lines[j]:
            lines[j] = lines[j].replace('consensus_actions', 'final_actions')
    print("修改2b: consensus_actions → final_actions")

# ===== 修改 1: __init__ 添加 v4.2 参数（从后往前第6个，最后改） =====
for i, line in enumerate(lines):
    if 'self.consensus_blend_ratio = config.get("consensus_blend_ratio"' in line:
        new_params = [
            line,
            f'{indent}\n',
            f'{indent}# v4.2: 软共识参数\n',
            f'{indent}self.soft_consensus_mode = config.get("soft_consensus_mode", False)\n',
            f'{indent}self.kl_consensus_coef = config.get("kl_consensus_coef", 0.1)\n',
            f'{indent}self.entropy_floor = config.get("entropy_floor", 0.05)\n',
            f'{indent}self._kl_consensus_loss_val = 0.0\n',
            f'{indent}self._entropy_floor_penalty_val = 0.0\n',
        ]
        lines[i:i+1] = new_params
        print(f"修改1: L{i+1} 后添加 v4.2 参数")
        break

# 写入文件
with open(filepath, 'w', encoding='utf-8') as f:
    f.writelines(lines)

# 验证语法
import py_compile
try:
    py_compile.compile(filepath, doraise=True)
    print("\n✅ 语法检查通过！")
except py_compile.PyCompileError as e:
    print(f"\n❌ 语法错误: {e}")
    # 打印错误位置附近的内容
    err_line = int(str(e).split('line ')[1].split(',')[0]) if 'line ' in str(e) else -1
    if err_line > 0:
        print(f"\n错误位置附近（L{err_line-3}-L{err_line+3}）:")
        with open(filepath, 'r') as f:
            all_lines = f.readlines()
        for j in range(max(0, err_line-4), min(len(all_lines), err_line+3)):
            print(f"  L{j+1}: {all_lines[j].rstrip()}")
    shutil.copy2(filepath + ".v42g.bak", filepath)
    print("\n已恢复备份")
