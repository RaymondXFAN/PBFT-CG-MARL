#!/root/miniconda3/bin/python3
"""终极修复 train.py 缩进"""
import sys

path = "/root/autodl-tmp/PBFT-CG-MARL/src/train.py"
with open(path, 'rb') as f:
    raw = f.read()

lines = raw.split(b'\n')

# 找到 algorithm = algorithm_cls 那行，检测它的缩进
base_indent = b''
for i, line in enumerate(lines):
    if b'algorithm = algorithm_cls' in line:
        stripped = line.lstrip()
        base_indent = line[:len(line) - len(stripped)]
        print(f"L{i+1} 缩进: [{base_indent}] ({len(base_indent)} bytes)")
        print(f"L{i+1} 内容: {stripped[:60]}")
        break

b = base_indent
b2 = base_indent + b'    '
b3 = base_indent + b'        '

# 新代码块（精确缩进）
new_block = [
    b + b'# \xe6\xb3\xa8\xe5\x85\xa5\xe6\x8b\x9c\xe5\x8d\xa0\xe5\xba\xadAgent (v4.5)',  # 注入拜占庭Agent (v4.5)
    b + b'if args.byzantine_n > 0:',
    b2 + b'if hasattr(algorithm, "inject_proposal_byzantine"):',
    b3 + b'byz_ids = list(range(args.byzantine_n))',
    b3 + b'algorithm.inject_proposal_byzantine(byz_ids, args.byzantine_type)',
    b2 + b'elif hasattr(algorithm, "inject_byzantine"):',
    b3 + b'algorithm.inject_byzantine(args.byzantine_n, args.byzantine_type)',
    b2 + b'print(f"[v4.5] injected {args.byzantine_n} byzantine agents (type: {args.byzantine_type})")',
]

# 找到要替换的行范围
start = None
end = None
for i, line in enumerate(lines):
    if b'\xe6\xb3\xa8\xe5\x85\xa5\xe6\x8b\x9c\xe5\x8d\xa0\xe5\xba\xadAgent' in line and start is None:
        start = i
    if b'\xe6\xb3\xa8\xe5\x85\xa5\xe4\xb8\xa2\xe5\x8c\x85\xe6\xa8\xa1\xe5\x9e\x8b' in line and start is not None:
        # 注入丢包模型 - 这是下一节的开始，停在这行之前
        end = i
        break
    if b'packet_loss_model' in line and start is not None and end is None:
        end = i
        break

if start is not None and end is not None:
    new_lines = lines[:start] + new_block + lines[end:]
    with open(path, 'wb') as f:
        f.write(b'\n'.join(new_lines))
    print(f"OK - replaced L{start+1}-L{end} with {len(new_block)} new lines")
else:
    print(f"FAIL - start={start}, end={end}")
    sys.exit(1)
