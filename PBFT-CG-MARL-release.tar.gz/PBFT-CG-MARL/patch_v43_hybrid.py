#!/usr/bin/env python3
"""
v4.3 混合共识补丁 - 核心逻辑：
- agent 同意共识 → 不改动作（软共识，防熵崩塌）
- agent 不同意共识 → 替换动作（硬共识，排除拜占庭）
- KL 散度损失训练正常 agent 主动同意共识
  → 随训练推进，正常 agent 越来越少被替换
  → 只有拜占庭 agent 被替换 → 既防熵崩塌又容错！
"""
import os, shutil

filepath = "src/algorithms/pbft_cg_mappo.py"

with open(filepath, 'r', encoding='utf-8') as f:
    content = f.read()

shutil.copy2(filepath, filepath + ".v42.bak")
changes = []

# === 修改 1: act() 方法 - 混合共识模式 ===
old_soft = """        if self.soft_consensus_mode:
            # V42_SOFT_CONSENSUS: 计算共识但不修改动作
            consensus_actions, consensus_info = self.pbft_consensus(
                proposals, obs, step=self._training_step, action_type=self.action_type
            )
            self._last_consensus_actions = consensus_actions
            self._last_consensus_info = consensus_info
            # 不修改动作！agent 自由选择
            final_actions = [a for a, _ in proposals]"""

new_hybrid = """        if self.soft_consensus_mode:
            # V43_HYBRID_CONSENSUS: 混合共识
            # 计算共识动作
            consensus_actions, consensus_info = self.pbft_consensus(
                proposals, obs, step=self._training_step, action_type=self.action_type
            )
            self._last_consensus_actions = consensus_actions
            self._last_consensus_info = consensus_info
            # 混合策略：同意共识的agent不改动作，不同意的替换为共识动作
            final_actions = []
            for i, (agent_action, _) in enumerate(proposals):
                if i < len(consensus_actions):
                    cons_a = consensus_actions[i]
                    # 判断 agent 是否同意共识（动作是否相同）
                    if self.action_type == "discrete":
                        agent_agrees = (int(agent_action.item()) == int(cons_a.item())) if hasattr(agent_action, 'item') else (int(agent_action) == int(cons_a))
                    else:
                        agent_agrees = torch.allclose(agent_action, cons_a, atol=0.1)
                    if agent_agrees:
                        # 同意共识 → 不改动作（防熵崩塌）
                        final_actions.append(agent_action)
                    else:
                        # 不同意共识 → 替换为共识动作（排除拜占庭/错误动作）
                        final_actions.append(cons_a)
                else:
                    final_actions.append(agent_action)"""

if old_soft in content:
    content = content.replace(old_soft, new_hybrid, 1)
    changes.append("act() 方法：纯软共识 → 混合共识")
else:
    print("[WARN] 未找到旧软共识代码，尝试宽松匹配")
    # 尝试更宽松的匹配
    if 'V42_SOFT_CONSENSUS' in content:
        # 找到 V42_SOFT_CONSENSUS 块并替换
        start = content.find('V42_SOFT_CONSENSUS')
        # 找到这一行的开头
        line_start = content.rfind('\n', 0, start) + 1
        # 找到 "final_actions = [a for a, _ in proposals]" 这行
        end_marker = "final_actions = [a for a, _ in proposals]"
        end_pos = content.find(end_marker, start)
        if end_pos > 0:
            # 找到这行的末尾
            end_line = content.find('\n', end_pos) + 1
            old_block = content[line_start:end_line]
            content = content.replace(old_block, new_hybrid)
            changes.append("act() 方法：纯软共识 → 混合共识（宽松匹配）")

# === 修改 2: 配置文件名提示 ===
# 不需要改代码，只改配置文件名

with open(filepath, 'w', encoding='utf-8') as f:
    f.write(content)

# 验证语法
import py_compile
try:
    py_compile.compile(filepath, doraise=True)
    print(f"修改: {changes}")
    print("✅ 语法检查通过！")
except py_compile.PyCompileError as e:
    print(f"❌ 语法错误: {e}")
    shutil.copy2(filepath + ".v42.bak", filepath)
    print("已恢复备份")
