#!/bin/bash
cd "$(dirname "$0")"
LOG_DIR="results/planA_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$LOG_DIR"
echo "日志目录: $LOG_DIR"
SEEDS=3
N_STEPS=500000
ENV_CFG=configs/env/mpe_spread.yaml

run_one() {
    local exp_id=$1 algo=$2
    for seed in $(seq 1 $SEEDS); do
        local tag="${algo}_mpe_spread_seed${seed}"
        echo ">>> [$(date +%H:%M:%S)] [Exp $exp_id] $algo seed $seed 开始"
        python -u src/train.py \
            --algo "$algo" --env mpe_spread \
            --env_config "$ENV_CFG" \
            --algo_config "configs/algo/$algo.yaml" \
            --seed "$seed" --n_timesteps "$N_STEPS" \
            --eval_interval 10000 --eval_episodes 10 \
            --log_dir "$LOG_DIR/$tag" --gpu 0
        echo ">>> [$(date +%H:%M:%S)] [Exp $exp_id] $algo seed $seed 完成"
    done
}

run_one 1 pbft_cg_mappo
run_one 2 mappo
run_one 3 qmix
run_one 4 maddpg
run_one 5 commnet
run_one 6 tarmac

echo "===== Plan A (mpe_spread) 全部完成 $(date) ====="
