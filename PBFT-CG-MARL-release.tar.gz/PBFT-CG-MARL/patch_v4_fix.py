#!/usr/bin/env python3
"""
v4 补丁修正脚本 - 修复键名不匹配 + 添加 entropy_coef 日志
在 AutoDL 上运行：cd /root/autodl-tmp/PBFT-CG-MARL && python patch_v4_fix.py
"""
import os, shutil

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__)) if not os.getenv("AUTODL") else "."

def get_path(rel_path):
    return os.path.join(PROJECT_ROOT, rel_path)


def fix_pbft_cg_mappo_py():
    """修复 pbft_cg_mappo.py:
    1. 读取 consensus_blend_ratio 从 config
    2. 在 metrics 返回中添加 entropy_coef
    3. 在 act() 中设置 consensus 层的 blend_ratio
    """
    filepath = get_path("src/algorithms/pbft_cg_mappo.py")
    
    with open(filepath, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    # 找到所有需要修改的位置
    new_lines = []
    i = 0
    changes = []
    
    while i < len(lines):
        line = lines[i]
        
        # Fix 1: 在 self.consensus_freq 之后添加 consensus_blend_ratio 读取
        if 'self.consensus_freq = config.get("consensus_freq"' in line:
            new_lines.append(line)
            # 检查下一行是否已经有 consensus_blend_ratio
            if i + 1 < len(lines) and 'consensus_blend_ratio' not in lines[i + 1]:
                new_lines.append('        self.consensus_blend_ratio = config.get("consensus_blend_ratio", 0.3)\n')
                changes.append("添加 consensus_blend_ratio 读取")
            i += 1
            continue
        
        # Fix 2: 在 act() 中设置 consensus 层的 blend_ratio
        # 找到 "self._consensus_step_counter += 1" 之前，添加 blend_ratio 设置
        if 'self._consensus_step_counter += 1' in line:
            # 在这行之前插入 blend_ratio 设置
            new_lines.append('        # v4: 动态设置 blend_ratio\n')
            new_lines.append('        if hasattr(self, "pbft_consensus") and hasattr(self, "consensus_blend_ratio"):\n')
            new_lines.append('            self.pbft_consensus.blend_ratio = self.consensus_blend_ratio\n')
            new_lines.append(line)
            changes.append("在 act() 中添加 blend_ratio 动态设置")
            i += 1
            continue
        
        # Fix 3: 在 metrics 返回中添加 entropy_coef
        # 找到 "entropy": total_entropy / self.ppo_epoch 这行
        if '"entropy": total_entropy / self.ppo_epoch' in line:
            new_lines.append(line)
            new_lines.append('            "entropy_coef": self.entropy_coef,\n')
            changes.append("在 metrics 返回中添加 entropy_coef")
            i += 1
            continue
        
        new_lines.append(line)
        i += 1
    
    if changes:
        shutil.copy2(filepath, filepath + ".v4fix.bak")
        with open(filepath, 'w', encoding='utf-8') as f:
            f.writelines(new_lines)
        print(f"[OK] pbft_cg_mappo.py 修改: {changes}")
    else:
        print("[SKIP] pbft_cg_mappo.py 无需修改")
    
    return True


def fix_train_py():
    """修复 train.py:
    1. 在 default_config 中添加扁平键名
    2. 在算法创建后设置 blend_ratio
    """
    filepath = get_path("src/train.py")
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    changes = []
    
    # Fix 1: 在 default_config 中添加扁平键名
    if '"consensus_freq": 1' not in content:
        # 找到 consensus_loss_coef 并在其后添加
        if '"consensus_loss_coef": 0.1' in content:
            content = content.replace(
                '"consensus_loss_coef": 0.1,',
                '"consensus_loss_coef": 0.1,\n        "consensus_freq": 1,\n        "consensus_blend_ratio": 0.3,',
                1
            )
            changes.append("添加 consensus_freq/blend_ratio 默认值")
    
    # Fix 2: 在 default_config 中添加自适应熵参数
    if '"use_adaptive_entropy":' not in content:
        # 找到 entropy_coef 并在其后添加
        if '"entropy_coef":' in content:
            content = content.replace(
                '"entropy_coef": 0.01,',
                '"entropy_coef": 0.01,\n        "use_adaptive_entropy": False,\n        "target_entropy": 0.10,\n        "entropy_coef_min": 0.02,\n        "entropy_coef_max": 0.30,\n        "entropy_adjustment_rate": 0.05,',
                1
            )
            changes.append("添加自适应熵参数默认值")
    
    # Fix 3: 在算法创建后设置 blend_ratio
    if 'consensus_blend_ratio' not in content or 'algorithm.pbft_consensus' not in content:
        # 找到 "algorithm = algorithm_cls" 之后
        if 'algorithm = algorithm_cls(config, env_info)' in content:
            insert_after = 'algorithm = algorithm_cls(config, env_info)'
            insert_code = '''

    # v4: 设置共识层参数
    if hasattr(algorithm, "pbft_consensus"):
        if "consensus_freq" in config:
            algorithm.pbft_consensus.consensus_freq = config["consensus_freq"]
            print(f"[v4] 共识频率: 每 {config['consensus_freq']} 步")
        if "consensus_blend_ratio" in config:
            algorithm.pbft_consensus.blend_ratio = config["consensus_blend_ratio"]
            print(f"[v4] 共识混合比例: {config['consensus_blend_ratio']}")
    if hasattr(algorithm, "use_adaptive_entropy"):
        if config.get("use_adaptive_entropy", False):
            algorithm.use_adaptive_entropy = True
            algorithm.target_entropy = config.get("target_entropy", 0.10)
            algorithm.entropy_coef_min = config.get("entropy_coef_min", 0.02)
            algorithm.entropy_coef_max = config.get("entropy_coef_max", 0.30)
            algorithm.entropy_adjustment_rate = config.get("entropy_adjustment_rate", 0.05)
            print(f"[v4] 自适应熵调度: target={algorithm.target_entropy}, range=[{algorithm.entropy_coef_min}, {algorithm.entropy_coef_max}]")'''
            content = content.replace(insert_after, insert_after + insert_code, 1)
            changes.append("添加算法创建后参数注入")
    
    if changes:
        shutil.copy2(filepath, filepath + ".v4fix.bak")
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"[OK] train.py 修改: {changes}")
    else:
        print("[SKIP] train.py 无需修改")
    
    return True


def main():
    print("=" * 60)
    print("v4 补丁修正 - 修复键名不匹配 + 添加 entropy_coef 日志")
    print("=" * 60)
    
    results = []
    print("\n[1/2] 修复 pbft_cg_mappo.py ...")
    results.append(fix_pbft_cg_mappo_py())
    
    print("\n[2/2] 修复 train.py ...")
    results.append(fix_train_py())
    
    print("\n" + "=" * 60)
    if all(results):
        print("✅ 修正完成！")
        print("\n重要：请使用扁平键名配置文件：")
        print("  pbft_cg_mappo_v4_flat.yaml（而非 pbft_cg_mappo_v4.yaml）")
        print("  mappo_v4_flat.yaml（而非 mappo_v4.yaml）")
        print("\n下一步：重新跑快速验证")
        print("  python -u src/train.py \\")
        print("    --algo pbft_cg_mappo \\")
        print("    --env mpe_spread \\")
        print("    --env_config configs/env/mpe_spread.yaml \\")
        print("    --algo_config configs/algo/pbft_cg_mappo_v4_flat.yaml \\")
        print("    --seed 1 --n_timesteps 50000 --eval_interval 5000 \\")
        print("    --eval_episodes 5 --log_dir results/v4_quick2 --gpu 0")
    else:
        print("⚠️ 部分修改失败，请检查日志")
    
    return all(results)


if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)
