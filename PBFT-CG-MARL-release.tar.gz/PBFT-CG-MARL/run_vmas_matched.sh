#!/bin/bash
cd /root/autodl-tmp/PBFT-CG-MARL
for s in 1 2 3 4 5; do
  echo "=== Starting VMAS matched seed $s at $(date) ==="
  python -u src/train.py --algo pbft_cg_mappo --env vmas_uav_coverage \
    --env_config configs/env/vmas_uav_coverage.yaml \
    --algo_config configs/algo/pbft_mult_matched_v5.yaml \
    --seed $s --n_timesteps 500000 --eval_interval 25000 \
    --eval_episodes 10 --log_dir results/phase1_fix_vmas --gpu 0
  echo "=== Finished seed $s at $(date) ==="
done
echo "ALL DONE"
