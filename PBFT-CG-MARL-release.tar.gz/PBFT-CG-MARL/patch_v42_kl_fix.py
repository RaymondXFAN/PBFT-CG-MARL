#!/usr/bin/env python3
"""
v4.2 修复 KL 散度 - 替换 placeholder 为真正的交叉熵共识损失
核心思路：在 PPO update 循环中，用 action_dist.log_prob(consensus_action)
计算交叉熵损失，鼓励 agent 向共识动作靠拢
"""
import os, shutil

filepath = "src/algorithms/pbft_cg_mappo.py"

with open(filepath, 'r', encoding='utf-8') as f:
    lines = f.readlines()

shutil.copy2(filepath, filepath + ".v42kl.bak")

changes = []

# === 修改 1: 在 PPO update 循环中，保存 action_dist 并计算交叉熵 ===
# 找到 "log_prob, entropy, _ = self.actor.evaluate_action" 和 "log_prob, entropy, _ = self.actors[agent_id].evaluate_action"
# 改为保存 action_dist，并在后面计算交叉熵

for i, line in enumerate(lines):
    # 修改1a: 保存 action_dist 而不是丢弃
    if 'log_prob, entropy, _ = self.actor.evaluate_action(' in line:
        lines[i] = line.replace('log_prob, entropy, _ =', 'log_prob, entropy, action_dist =')
        changes.append(f"L{i+1}: 保存 action_dist (self.actor)")
    elif 'log_prob, entropy, _ = self.actors[agent_id].evaluate_action(' in line:
        lines[i] = line.replace('log_prob, entropy, _ =', 'log_prob, entropy, action_dist =')
        changes.append(f"L{i+1}: 保存 action_dist (self.actors[agent_id])")

# === 修改 2: 在 entropies.append(entropy) 之后，添加交叉熵共识损失计算 ===
for i, line in enumerate(lines):
    if 'entropies.append(entropy)' in line:
        indent = '                '
        new_code = [
            line,
            f'{indent}# v4.2: 计算与共识动作的交叉熵损失（软共识引导）\n',
            f'{indent}if self.soft_consensus_mode and hasattr(self, "_last_consensus_actions") and self._last_consensus_actions is not None:\n',
            f'{indent}    try:\n',
            f'{indent}        cons_a = self._last_consensus_actions[agent_id]\n',
            f'{indent}        if isinstance(cons_a, int):\n',
            f'{indent}            ca_tensor = torch.tensor(cons_a, device=self.device)\n',
            f'{indent}        else:\n',
            f'{indent}            ca_tensor = cons_a.detach().clone().to(self.device)\n',
            f'{indent}        # 交叉熵 = -log_prob(consensus_action)，鼓励 agent 向共识靠拢\n',
            f'{indent}        ce_loss = -action_dist.log_prob(ca_tensor)\n',
            f'{indent}        if not hasattr(self, "_batch_ce_losses"):\n',
            f'{indent}            self._batch_ce_losses = []\n',
            f'{indent}        self._batch_ce_losses.append(ce_loss.mean())\n',
            f'{indent}    except Exception:\n',
            f'{indent}        pass\n',
        ]
        lines[i:i+1] = new_code
        changes.append(f"L{i+1}: 在 entropies.append 后添加交叉熵计算")
        break  # 只修改第一个匹配

# === 修改 3: 替换 placeholder KL 散度代码 ===
# 找到整个 placeholder 块并替换
placeholder_start = None
placeholder_end = None
for i, line in enumerate(lines):
    if 'v4.2: KL 散度软共识损失' in line and 'placeholder' not in line:
        placeholder_start = i
    if placeholder_start is not None and 'kl_consensus_loss = torch.tensor(0.0, device=self.device)' in line and i > placeholder_start:
        placeholder_end = i
        break

if placeholder_start is not None and placeholder_end is not None:
    indent = '        '
    new_kl_code = [
        f'{indent}# v4.2: 软共识引导损失（使用 batch 中累积的交叉熵）\n',
        f'{indent}kl_consensus_loss = torch.tensor(0.0, device=self.device)\n',
        f'{indent}if self.soft_consensus_mode and hasattr(self, "_batch_ce_losses") and self._batch_ce_losses:\n',
        f'{indent}    kl_consensus_loss = torch.stack(self._batch_ce_losses).mean()\n',
        f'{indent}    self._batch_ce_losses = []  # 清空\n',
    ]
    lines[placeholder_start:placeholder_end + 1] = new_kl_code
    changes.append(f"替换 placeholder KL 散度代码（L{placeholder_start+1}-L{placeholder_end+1}）")

# 写入文件
with open(filepath, 'w', encoding='utf-8') as f:
    f.writelines(lines)

print(f"修改: {changes}")

# 验证语法
import py_compile
try:
    py_compile.compile(filepath, doraise=True)
    print("✅ 语法检查通过！")
except py_compile.PyCompileError as e:
    print(f"❌ 语法错误: {e}")
    print("恢复备份...")
    shutil.copy2(filepath + ".v42kl.bak", filepath)
