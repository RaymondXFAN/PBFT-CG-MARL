#!/usr/bin/env python3
"""
v4.2 最终修复 - 逐行写入，不用多行字符串
"""
import os, shutil

filepath = "src/algorithms/pbft_cg_mappo.py"

with open(filepath, 'r', encoding='utf-8') as f:
    lines = f.readlines()

shutil.copy2(filepath, filepath + ".v42f.bak")

# ===== 修改 1: __init__ 添加 v4.2 参数 =====
# 在 L67 (index 66) consensus_blend_ratio 行后插入
for i, line in enumerate(lines):
    if 'self.consensus_blend_ratio = config.get("consensus_blend_ratio"' in line:
        indent = '        '
        new_lines = [
            line,  # 保留原来的 consensus_blend_ratio 行
            f'{indent}\n',
            f'{indent}# v4.2: 软共识参数\n',
            f'{indent}self.soft_consensus_mode = config.get("soft_consensus_mode", False)\n',
            f'{indent}self.kl_consensus_coef = config.get("kl_consensus_coef", 0.1)\n',
            f'{indent}self.entropy_floor = config.get("entropy_floor", 0.05)\n',
            f'{indent}self._kl_consensus_loss_val = 0.0\n',
            f'{indent}self._entropy_floor_penalty_val = 0.0\n',
        ]
        lines[i:i+1] = new_lines
        print(f"修改1: L{i+1} 后添加 v4.2 参数")
        break

# ===== 修改 2: act() 软共识模式 =====
# 找到 "步骤2：PBFT共识层" 行
step2_idx = None
for i, line in enumerate(lines):
    if '步骤2' in line and 'PBFT' in line:
        step2_idx = i
        break

# 找到 "skipped": True" 行
skipped_idx = None
for i in range(step2_idx, step2_idx + 20):
    if i < len(lines) and '"skipped": True' in lines[i]:
        skipped_idx = i
        break

if step2_idx is not None and skipped_idx is not None:
    indent = '        '
    indent2 = '            '
    indent3 = '                '
    new_act = [
        f'{indent}# 步骤2：PBFT共识层（v4.2: 支持软共识模式）\n',
        f'{indent}self._consensus_step_counter += 1\n',
        f'{indent}if self.soft_consensus_mode:\n',
        f'{indent2}# V42_SOFT_CONSENSUS: 计算共识但不修改动作\n',
        f'{indent2}consensus_actions, consensus_info = self.pbft_consensus(\n',
        f'{indent3}proposals, obs, step=self._training_step, action_type=self.action_type\n',
        f'{indent2})\n',
        f'{indent2}self._last_consensus_actions = consensus_actions\n',
        f'{indent2}self._last_consensus_info = consensus_info\n',
        f'{indent2}# 不修改动作！agent 自由选择\n',
        f'{indent2}final_actions = [a for a, _ in proposals]\n',
        f'{indent}elif self.consensus_freq <= 1 or self._consensus_step_counter % self.consensus_freq == 0:\n',
        f'{indent2}# 硬共识模式\n',
        f'{indent2}if hasattr(self, "pbft_consensus") and hasattr(self, "consensus_blend_ratio"):\n',
        f'{indent3}self.pbft_consensus.blend_ratio = self.consensus_blend_ratio\n',
        f'{indent2}consensus_actions, consensus_info = self.pbft_consensus(\n',
        f'{indent3}proposals, obs, step=self._training_step, action_type=self.action_type\n',
        f'{indent2})\n',
        f'{indent2}final_actions = consensus_actions\n',
        f'{indent}else:\n',
        f'{indent2}# 跳过共识\n',
        f'{indent2}final_actions = [a for a, _ in proposals]\n',
        f'{indent2}consensus_info = {{"consensus_rate": 1.0, "consensus_achieved": True, "skipped": True}}\n',
    ]
    lines[step2_idx:skipped_idx + 1] = new_act
    print(f"修改2: act() 软共识模式（L{step2_idx+1}-L{skipped_idx+1}）")
else:
    print(f"修改2: FAILED step2={step2_idx} skipped={skipped_idx}")

# ===== 修改 2b: consensus_actions → final_actions =====
step3_idx = None
for i, line in enumerate(lines):
    if '步骤3' in line and '共识' in line:
        step3_idx = i
        break

if step3_idx is not None:
    for j in range(step3_idx, min(step3_idx + 30, len(lines))):
        if 'consensus_actions[0]' in lines[j] and 'final_actions' not in lines[j]:
            lines[j] = lines[j].replace('consensus_actions[0]', 'final_actions[0]')
        if 'consensus_actions' in lines[j] and 'final_actions' not in lines[j] and 'last_consensus' not in lines[j]:
            lines[j] = lines[j].replace('consensus_actions', 'final_actions')
    print("修改2b: consensus_actions → final_actions")

# ===== 修改 3: 保存 action_dist =====
for i, line in enumerate(lines):
    if 'log_prob, entropy, _ = self.actor.evaluate_action(' in line:
        lines[i] = line.replace('log_prob, entropy, _ =', 'log_prob, entropy, action_dist =')
        print(f"修改3a: L{i+1} 保存 action_dist (actor)")
    elif 'log_prob, entropy, _ = self.actors[agent_id].evaluate_action(' in line:
        lines[i] = line.replace('log_prob, entropy, _ =', 'log_prob, entropy, action_dist =')
        print(f"修改3b: L{i+1} 保存 action_dist (actors)")

# ===== 修改 4: 在 entropies.append 后添加交叉熵 =====
for i, line in enumerate(lines):
    if 'entropies.append(entropy)' in line:
        indent = '                '
        new_ce = [
            line,
            f'{indent}# v4.2: 计算与共识动作的交叉熵损失\n',
            f'{indent}if self.soft_consensus_mode and hasattr(self, "_last_consensus_actions") and self._last_consensus_actions is not None:\n',
            f'{indent}    try:\n',
            f'{indent}        cons_a = self._last_consensus_actions[agent_id]\n',
            f'{indent}        if isinstance(cons_a, int):\n',
            f'{indent}            ca_tensor = torch.tensor(cons_a, device=self.device)\n',
            f'{indent}        else:\n',
            f'{indent}            ca_tensor = cons_a.detach().clone().to(self.device)\n',
            f'{indent}        ce_loss = -action_dist.log_prob(ca_tensor)\n',
            f'{indent}        if not hasattr(self, "_batch_ce_losses"):\n',
            f'{indent}            self._batch_ce_losses = []\n',
            f'{indent}        self._batch_ce_losses.append(ce_loss.mean())\n',
            f'{indent}    except Exception:\n',
            f'{indent}        pass\n',
        ]
        lines[i:i+1] = new_ce
        print(f"修改4: L{i+1} 后添加交叉熵计算")
        break

# ===== 修改 5: 替换 loss 计算区域 =====
# 找到 "consensus_loss = torch.tensor(0.0, device=self.device)" 行
cons_loss_idx = None
for i, line in enumerate(lines):
    if 'consensus_loss = torch.tensor(0.0, device=self.device)' in line:
        cons_loss_idx = i
        break

# 找到 loss 的右括号 ")" 行
loss_end_idx = None
for i in range(cons_loss_idx, cons_loss_idx + 30):
    if i < len(lines) and lines[i].strip() == ')' and i > cons_loss_idx + 5:
        loss_end_idx = i
        break

if cons_loss_idx is not None and loss_end_idx is not None:
    indent = '        '
    indent2 = '            '
    new_loss = [
        f'{indent}# v4.2: 共识损失\n',
        f'{indent}consensus_loss = torch.tensor(0.0, device=self.device)\n',
        f'{indent}if hasattr(self, "_last_consensus_info") and self._last_consensus_info is not None:\n',
        f'{indent}    consensus_rate = self._last_consensus_info.get("consensus_rate", 0.0)\n',
        f'{indent}    consensus_loss = torch.tensor(\n',
        f'{indent}        (1.0 - consensus_rate) * self.consensus_loss_coef,\n',
        f'{indent}        device=self.device,\n',
        f'{indent}    )\n',
        f'{indent}\n',
        f'{indent}# v4.2: 最小熵底线惩罚（确保是 tensor）\n',
        f'{indent}entropy_floor_penalty = torch.tensor(0.0, device=self.device)\n',
        f'{indent}if hasattr(self, "entropy_floor") and mean_entropy < self.entropy_floor:\n',
        f'{indent}    deficit = self.entropy_floor - mean_entropy\n',
        f'{indent}    entropy_floor_penalty = torch.tensor(10.0 * deficit.item(), device=self.device)\n',
        f'{indent}\n',
        f'{indent}# v4.2: 软共识交叉熵损失\n',
        f'{indent}kl_consensus_loss = torch.tensor(0.0, device=self.device)\n',
        f'{indent}if self.soft_consensus_mode and hasattr(self, "_batch_ce_losses") and self._batch_ce_losses:\n',
        f'{indent}    kl_consensus_loss = torch.stack(self._batch_ce_losses).mean()\n',
        f'{indent}    self._batch_ce_losses = []\n',
        f'{indent}\n',
        f'{indent}# 记录用于 metrics\n',
        f'{indent}self._kl_consensus_loss_val = kl_consensus_loss.item()\n',
        f'{indent}self._entropy_floor_penalty_val = entropy_floor_penalty.item()\n',
        f'{indent}\n',
        f'{indent}# 总损失（所有项都是 tensor）\n',
        f'{indent}loss = (\n',
        f'{indent2}policy_loss\n',
        f'{indent2}+ self.value_loss_coef * value_loss\n',
        f'{indent2}- self.entropy_coef * mean_entropy\n',
        f'{indent2}+ consensus_loss\n',
        f'{indent2}+ entropy_floor_penalty\n',
        f'{indent2}+ self.kl_consensus_coef * kl_consensus_loss\n',
        f'{indent})\n',
    ]
    lines[cons_loss_idx:loss_end_idx + 1] = new_loss
    print(f"修改5: 替换 loss 区域 L{cons_loss_idx+1}-L{loss_end_idx+1}")
else:
    print(f"修改5: FAILED cons_loss={cons_loss_idx} loss_end={loss_end_idx}")

# ===== 修改 6: metrics 添加新指标 =====
for i, line in enumerate(lines):
    if '"entropy_coef": self.entropy_coef' in line:
        indent = '            '
        lines.insert(i + 1, f'{indent}"kl_consensus_loss": self._kl_consensus_loss_val,\n')
        lines.insert(i + 2, f'{indent}"entropy_floor_penalty": self._entropy_floor_penalty_val,\n')
        print(f"修改6: L{i+1} 后添加 metrics")
        break

# 写入文件
with open(filepath, 'w', encoding='utf-8') as f:
    f.writelines(lines)

# 验证语法
import py_compile
try:
    py_compile.compile(filepath, doraise=True)
    print("\n✅ 语法检查通过！")
except py_compile.PyCompileError as e:
    print(f"\n❌ 语法错误: {e}")
    shutil.copy2(filepath + ".v42f.bak", filepath)
    print("已恢复备份")
