#!/usr/bin/env python3
"""Fix v4: 环境层 Byzantine 攻击（使用 env_info 中的 n_actions）"""
import sys

filepath = "/root/autodl-tmp/PBFT-CG-MARL/src/train.py"

with open(filepath, "r") as f:
    lines = f.readlines()

# 恢复原始（去掉之前加的函数和check）
new_lines = []
skip_helper = False
for i, line in enumerate(lines):
    if "_apply_byzantine_attack" in line and "def " in line:
        skip_helper = True
        continue
    if skip_helper:
        if line.strip() == "" or line.startswith("    ") and not line.startswith("def "):
            # 还在函数体内
            if "return modified" in line:
                skip_helper = False
            continue
        else:
            skip_helper = False
    if "_apply_byzantine_attack" in line and "def " not in line:
        # 跳过 call 和 check 行
        continue
    if 'inject_proposal_byzantine' in line and 'inject_byzantine' in line and 'if args.byzantine_n' in line:
        continue
    new_lines.append(line)

lines = new_lines

# 重新插入正确的函数（使用n_actions参数而非硬编码6）
func_lines = [
    "\n",
    "def _apply_byzantine_attack(actions_np, n_byzantine, byz_type, action_type, n_agents, n_actions=5):\n",
    '    """Byzantine attack for algorithms without consensus layer"""\n',
    "    import numpy as np\n",
    "    modified = actions_np.copy()\n",
    "    byz_ids = list(range(min(n_byzantine, n_agents)))\n",
    "    for aid in byz_ids:\n",
    "        if aid >= len(modified):\n",
    "            continue\n",
    '        if byz_type == "random":\n',
    '            if action_type == "discrete":\n',
    "                modified[aid] = np.random.randint(0, n_actions)\n",
    "            else:\n",
    "                modified[aid] = np.random.uniform(-1.0, 1.0, size=modified[aid].shape)\n",
    '        elif byz_type == "adversarial":\n',
    '            if action_type == "discrete":\n',
    "                modified[aid] = (n_actions - 1 - int(modified[aid])) % n_actions\n",
    "            else:\n",
    "                noise = np.random.randn(*modified[aid].shape) * 0.1\n",
    "                modified[aid] = np.clip(-modified[aid] + noise, -1.0, 1.0)\n",
    '        elif byz_type == "silence":\n',
    '            if action_type == "discrete":\n',
    "                modified[aid] = 0\n",
    "            else:\n",
    "                modified[aid] = np.zeros_like(modified[aid])\n",
    "    return modified\n",
    "\n",
]

# 插入函数
for i, line in enumerate(lines):
    if "class TrainEnvWrapper:" in line:
        for j, fl in enumerate(func_lines):
            lines.insert(i + j, fl)
        print(f"Inserted helper at line {i}")
        break

# on-policy: env.step前插入（传n_actions）
on_policy_done = False
for i, line in enumerate(lines):
    if (line == "            next_obs, next_state, rewards, dones, infos = env.step(actions_np)\n"
        and not on_policy_done):
        context = "".join(lines[max(0,i-10):i])
        if "algorithm.act" in context or "algorithm.get_value" in context:
            call = '                actions_np = _apply_byzantine_attack(actions_np, args.byzantine_n, args.byzantine_type, action_type, n_agents, n_actions=env_info["action_shape"])\n'
            check = '            if args.byzantine_n > 0 and not hasattr(algorithm, "inject_proposal_byzantine") and not hasattr(algorithm, "inject_byzantine"):\n'
            lines.insert(i, call)
            lines.insert(i, check)
            on_policy_done = True
            print(f"Inserted on-policy at line {i}")

# off-policy
off_policy_done = False
for i, line in enumerate(lines):
    if (line == "        next_obs, next_state, rewards, dones, infos = env.step(actions_np)\n"
        and not off_policy_done):
        context = "".join(lines[max(0,i-10):i])
        if "algorithm.act" in context:
            call = '            actions_np = _apply_byzantine_attack(actions_np, args.byzantine_n, args.byzantine_type, action_type, n_agents, n_actions=env_info["action_shape"])\n'
            check = '        if args.byzantine_n > 0 and not hasattr(algorithm, "inject_proposal_byzantine") and not hasattr(algorithm, "inject_byzantine"):\n'
            lines.insert(i, call)
            lines.insert(i, check)
            off_policy_done = True
            print(f"Inserted off-policy at line {i}")

with open(filepath, "w") as f:
    f.writelines(lines)

print(f"✅ Patch done: on={on_policy_done}, off={off_policy_done}")
