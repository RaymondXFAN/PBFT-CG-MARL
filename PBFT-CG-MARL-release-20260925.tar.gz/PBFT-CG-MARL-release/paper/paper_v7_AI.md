# Diagnosing Entropy Collapse in Consensus-Guided Multi-Agent Reinforcement Learning: Failure Modes and Design Guidelines

**[Author Name]**¹, **[Co-author Name]**¹  
¹*[Department, Institution, City, Country]*  
*Corresponding author: [name@institution.edu]*

---

## Abstract

Deploying cooperative multi-agent reinforcement learning (MARL) where some participants may be compromised calls for Byzantine fault-tolerant consensus, and the Practical Byzantine Fault Tolerance (PBFT) protocol is a natural building block. How the agreed action should enter the learning update, however, has no established answer.

The most intuitive choice—replacing each agent's executed action with the agreed one and computing the policy gradient at that action (matched log-probability)—conceals a failure mode: policy entropy collapses to near-determinism while episode reward remains statistically indistinguishable from a variant free of the problem. The damage is confined to the training path, so nothing in standard reward-based evaluation flags it.

We trace the collapse to an unbounded agreement–diversity loop: reinforcing the agreed action raises the consensus rate, which narrows the proposal distribution and reduces diversity further. The loop is self-reinforcing and does not yield to entropy-coefficient tuning, which rules out a hyperparameter explanation.

From this diagnosis we derive three design guidelines for consensus-guided MARL and instantiate one of them: additive loss conditioning, which moves the consensus signal out of the execution path and into the loss as an additive term whose influence is zero-weighted at $\alpha = 0$ and self-limiting, restoring entropy without violating gradient consistency.

Across 8 seeds at $n = 5$, matched conditioning ends at entropy $0.045 \pm 0.015$ versus $0.110 \pm 0.050$ for the mismatched variant ($p = 0.0071$, $d = -1.78$), while additive conditioning returns to the MAPPO baseline ($p = 0.76$). Raising the fault ratio to $f = 2$ at $n = 7$ reverses which design wins—execution-time consensus gains $14$ reward units over MAPPO ($p = 0.014$)—so the guidelines are conditioned on the fault ratio rather than offered as a single prescription. A second task reproduces the collapse with a sharper contrast (honest-agent entropy $0.014 \pm 0.017$ vs. $0.075 \pm 0.016$, $p = 0.0004$). The results turn a hidden training pathology into an actionable checklist for practitioners who deploy consensus-guided MARL under partial compromise.

**Keywords:** cooperative multi-agent reinforcement learning; Byzantine fault tolerance; PBFT consensus; policy entropy collapse; failure-mode diagnosis; design guidelines

---

## 1. Introduction

Cooperative multi-agent reinforcement learning (MARL) has produced reliable decentralized controllers for coverage, resource allocation, and formation tasks [1, 2]. MAPPO [3] is a common substrate for this work: a centralized critic estimates global value while each agent executes its own policy, which has proven competitive on standard benchmarks [4].

Deployments that involve untrusted participants break this setting. A compromised agent can deviate from the agreed strategy at will, and the Practical Byzantine Fault Tolerance (PBFT) protocol [6] was designed for exactly this regime, tolerating up to $f < n/3$ faulty participants [5]. Marrying PBFT to MARL training is therefore natural. What is not obvious is how the consensus outcome should enter the learning update.

We study this question on a concrete configuration: PBFT consensus layered on MAPPO, where the consensus action $a^*$ either replaces the agent's sampled action at execution time (**multiplicative conditioning**) or enters the objective as an additive penalty term (**additive conditioning**). The first configuration, when paired with matched log-probability PPO updates, collapses policy entropy from 1.61 to 0.045 within 300K steps. The collapse survives increases to the entropy coefficient, which rules out a tuning explanation, and reproduces across all 8 seeds we ran.

The mechanism is a feedback loop rather than a hyperparameter effect. Replacing $a_i$ with $a^*$ and then computing the PPO gradient at $\log \pi_{\theta_i}(a^* \mid o_i)$ rewards policies that already agree with the leader. Agreement raises the consensus rate on subsequent batches, which in turn narrows the proposal distribution, so entropy falls monotonically: PPO reinforces $a^*$ $\rightarrow$ agents learn to agree $\rightarrow$ consensus rate rises $\rightarrow$ policy diversity contracts. Computing the gradient at $\log \pi_{\theta_i}(a_i \mid o_i)$ instead breaks the loop—entropy stays at 0.110 rather than 0.045—but the gradient no longer corresponds to the action that was executed, which violates the Policy Gradient Theorem [9].

**Scope.** This paper is a failure-mode analysis that yields design rules; the conditioning scheme we report is one instantiation of those rules, not the paper's headline claim. We do not claim that it beats baselines on task reward: in the clean setting, and with 8 seeds, reward differences among all four variants fall inside noise. What we establish is that matched log-probability is the causal trigger for entropy collapse (Section 4.3), that additive conditioning removes the collapse without violating gradient consistency (Section 4.2), and that the value of consensus is contingent on the fault ratio in a way that earlier work has not characterized (Section 5.4).

Our contributions:

1. **Failure-mode diagnosis.** Holding every other variable fixed, matched conditioning ends at 59% lower entropy than the mismatched one ($0.045 \pm 0.015$ vs. $0.110 \pm 0.050$, $p = 0.0071$, $d = -1.78$) and 55% lower than plain MAPPO ($p < 0.0001$, $d = -3.37$), while reward differences stay inside noise (Table 2). We trace the effect to a self-reinforcing agreement–diversity loop that entropy-coefficient tuning does not break (Section 5.1).
2. **Fault-ratio contingency.** Increasing $f/n$ from $1/5$ to $2/7$ changes which conditioning wins. Hard mismatched consensus reaches $-55.2 \pm 5.0$ versus $-69.2 \pm 12.2$ for MAPPO ($p = 0.014$, $d = -1.51$), while soft consensus stays at the MAPPO level ($-68.5 \pm 15.4$, $p = 0.92$). Execution-time consensus buys robustness once the faulty minority is large enough to matter; loss-level guidance does not. The value of consensus is therefore conditional on the fault ratio rather than monotone.
3. **Design guidelines.** The diagnosis and the contingency together yield three rules: never pair action replacement with matched log-probability updates; prefer additive loss conditioning with an influence zero-weighted at the outset; enforce entropy floors as defense-in-depth.
4. **A guideline-compliant implementation.** Soft Consensus—additive loss conditioning with an influence that is zero-weighted at $\alpha = 0$ and self-limiting ($\alpha = 0.1$)—satisfies guidelines (i)–(ii): it restores entropy to the MAPPO baseline ($0.097 \pm 0.029$ vs. $0.101 \pm 0.018$, $p = 0.76$) while preserving gradient consistency (Section 3.2), and sits 2.2$\times$ above the collapsed variant ($p = 0.0009$, $d = 2.29$).

5. **Cross-task replication.** A second discrete task (MPE simple\_line, 5 seeds) reproduces the fault-time collapse with a sharper contrast: honest-agent entropy $0.014 \pm 0.017$ under mismatched conditioning against $0.075 \pm 0.016$ under additive conditioning ($p = 0.0004$, $d = -3.72$; Section 4.6).

---

## 2. Related Work

### 2.1 Multi-Agent Reinforcement Learning

CTDE is the working paradigm for cooperative MARL. MAPPO [3] applies PPO [10] with a centralized critic; QMIX [11] factorizes the joint action-value function monotonically; MADDPG [12] extends DDPG to multi-agent domains. CommNet [13] and TarMAC [14] learn differentiable communication channels, and DIAL [8] learns the channel jointly with the policies that use it, but none of these provides fault-tolerance guarantees. Entropy regularization is standard in single-agent RL [15] and has been adapted for multi-agent use: Kim and Sung [16] adjust the entropy coefficient online (ADER) to improve exploration efficiency. Their objective is sample efficiency, not the structural collapse that consensus conditioning can produce. Forkel et al. [17] show that high entropy regularization drives symmetry-equivariant policies in Dec-POMDPs, which implies that maintaining entropy is a precondition for policy compatibility—a point that becomes relevant once consensus starts compressing the policy space.

### 2.2 Byzantine Fault Tolerance in Distributed Learning

PBFT [6] gives deterministic $f < n/3$ tolerance through pre-prepare, prepare, and commit phases. In federated learning, gradient-level aggregation rules such as Krum [18], trimmed mean [19], and Bulyan [20] filter malicious updates before averaging, but they assume a parameter-server topology and do not transfer to on-policy MARL, where the agreement target is a joint action rather than a parameter vector and must be produced within an episode.

Work that does target MARL under Byzantine participants has moved in several directions. Li et al. [7] cast Byzantine-robust cooperative MARL as a Bayesian game over teammate types and prove convergence under stated conditions. Jordan et al. [21] give a decentralized federated policy-gradient method with sample-complexity guarantees, though for federated rather than CTDE settings. Lin and Ling [22] study robust reward-free actor–critic under Byzantine corruption. Wu et al. [23] use RL to reconfigure BFT consensus protocols at runtime, Rizk et al. [27] apply a hierarchical consensus layer to robot task allocation, and He et al. [28] study policy agreement among cooperative agents in the offline setting. Across these, the consensus mechanism is treated as a component whose output is either trusted or filtered; none examines how injecting that output reshapes the training dynamics of the policy network itself, which is where we locate the failure.

### 2.3 Adversarial Robustness in MARL

Attacks on cooperative MARL take the form of observation perturbation, action manipulation, or communication corruption. Yu et al. [24] defend against message manipulation in communicative MARL; Ma et al. [25] learn adversarial policies against partially observed systems; Li et al. [26] derive convergence bounds for resilient multi-agent RL with function approximation. The shared assumption is that the adversary is external to the learning process and that the goal is to bound its effect. Our setting differs: the adversary participates in consensus, and the harm we identify is inflicted on the policy's own entropy by the conditioning mechanism, not by the attack.

### 2.4 Conditioning in Deep Learning

The multiplicative/additive distinction has a long history. FiLM [30] scales and shifts features, and multiplicative scaling can amplify activations without bound whereas additive shifting cannot. Zhang et al. [31] show that KL-constrained trust regions keep multi-agent policy updates stable for safe MARL, and Shek et al. [29] extend the trust region to a constraint shared across agents. The same intuition appears in residual networks [32], where an additive skip path with identity initialization guarantees that the deeper model is no worse than its shallower counterpart at the start of training. Consensus conditioning inherits this structure: replacing the action is multiplicative and irreversible, while adding a penalty term is additive and starts at zero influence. That correspondence has not been made explicit for consensus-guided MARL, and we show it to be the deciding factor between stable and collapsed training.

---

## 3. Method

### 3.1 Preliminaries

We consider a cooperative multi-agent MDP $\langle \mathcal{N}, \mathcal{S}, \mathcal{A}, \mathcal{T}, \mathcal{R}, \gamma \rangle$ with agent set $\mathcal{N} = \{1, \ldots, n\}$, state space $\mathcal{S}$, joint action space $\mathcal{A}$, transition kernel $\mathcal{T}$, shared reward $\mathcal{R}$, and discount factor $\gamma \in [0, 1)$. Agent $i$ carries a stochastic policy $\pi_{\theta_i}(a_i \mid o_i)$ and a centralized value function $V_\phi(s)$ estimates global state value. We write the PPO objective for agent $i$ as (1):

$$L_i^{\text{PPO}}(\theta_i) = \hat{\mathbb{E}}_t \left[ \min\left( r_t^i(\theta_i) \hat{A}_t^i, \; \text{clip}(r_t^i(\theta_i), 1-\epsilon, 1+\epsilon) \hat{A}_t^i \right) \right]$$

with importance ratio $r_t^i(\theta_i) = \pi_{\theta_i}(a_t^i \mid o_t^i) / \pi_{\theta_{i,\text{old}}}(a_t^i \mid o_t^i)$ and GAE advantage $\hat{A}_t^i$ [33]. The total loss is $L_i = L_i^{\text{PPO}} + c_v L_i^{\text{value}} - c_e H(\pi_{\theta_i})$.

PBFT [6] reaches agreement among $n$ agents with $f < n/3$ faults through pre-prepare, prepare, and commit phases; leader rotation removes the single point of failure, and a fallback path drops back to independent execution when a quorum cannot be reached.

Integrating consensus into MAPPO raises a design question we treat as the core of this paper: **how should the consensus action $a^*$ enter agent $i$'s update?** Two answers appear in the literature and in existing implementations:

- **Multiplicative conditioning.** $a_i$ is overwritten by $a^*$, so the policy's own output is discarded at execution time.
- **Additive conditioning.** $a^*$ enters the objective as an additive term; the policy's output is preserved.

The same dichotomy governs FiLM layers [30] and residual skip connections [32]: multiplicative paths can destabilize training, additive paths with identity initialization cannot make the model worse than its baseline at initialization.

### 3.2 Multiplicative Conditioning: Hard Action Replacement

The original PBFT-CG-MAPPO architecture applies multiplicative conditioning in four steps:

1. Each agent $i$ samples its own proposal $a_i^{\text{self}} \sim \pi_{\theta_i}(\cdot \mid o_i)$.
2. PBFT selects the leader's action $a^*$.
3. Hard replacement sets the executed action $\tilde{a}_i = a^*$ for disagreeing agents.
4. The PPO gradient is computed either at the consensus action, $\log \pi_{\theta_i}(a^* \mid o_i)$ (matched), or at the agent's own proposal, $\log \pi_{\theta_i}(a_i^{\text{self}} \mid o_i)$ (mismatched).

Step 4 is where the two variants diverge, and only step 4 differs between them in our controlled comparison.

**Failure mode 1: matched log-probability feeds back.** Computing the gradient at the consensus action's log-probability rewards policies that already agree with the leader:

$$\text{PPO reinforces } a^* \;\xrightarrow{}\; \text{agents learn to agree} \;\xrightarrow{}\; \text{consensus rate} \uparrow \;\xrightarrow{}\; H(\pi) \to 0$$

Every pass through this loop shrinks the proposal distribution. Because agreement is rewarded regardless of whether the consensus action was a good one, the process has no restoring force.

**Failure mode 2: mismatched log-probability breaks the gradient.** Using $\log \pi_{\theta_i}(a_i^{\text{self}} \mid o_i)$ while executing $\tilde{a}_i = a^*$ keeps entropy healthy but makes the update inconsistent with the action actually taken, violating the Policy Gradient Theorem [9]. The two available options are therefore a collapse mode and a correctness violation—which is the gap additive conditioning is meant to fill.

### 3.3 Additive Conditioning: Soft Consensus

Soft consensus keeps step 3 out of the pipeline entirely.

**Action selection.** Each agent executes $a_i \sim \pi_{\theta_i}(\cdot \mid o_i)$; nothing is replaced.

**KL-divergence guidance.** A penalty (2) nudges the policy toward $a^*$:

$$L_i^{\text{KL}} = -\log \pi_{\theta_i}(a^* \mid o_i) + \text{const}$$

**Entropy floor.** A quadratic penalty (3) activates only below the floor:

$$L^{\text{floor}} = \lambda \cdot \max\left(0, \; \theta - \bar{H}\right)^2$$

with $\lambda = 10$ and $\theta = 0.05$.

**Total loss.** Combining the terms above, the per-agent objective (4) is

$$L_i = L_i^{\text{PPO}} + c_v L_i^{\text{value}} - c_e H(\pi_{\theta_i}) + \alpha L_i^{\text{KL}} + L^{\text{floor}} + c_c (1 - r^{\text{cons}})$$

with $\alpha = 0.1$ and $c_c = 0.01$.

**On the consensus-rate bonus.** Here $r^{\text{cons}} \in [0, 1]$ is the fraction of proposals in the batch that agree with the committed action. The final term, $c_c(1 - r^{\text{cons}})$, is present in *all* consensus variants, not only in soft consensus, and it rewards proposals that agree with the committed action. It is not a candidate explanation for the collapse, for two reasons. Practically, the logged consensus rate is $1.0$ in every consensus run we report (Table 1), so the term evaluates to approximately zero and its gradient vanishes. Structurally, and more decisively, the term is identical in hard matched and hard mismatched consensus—the two variants are trained from the same code path and differ only in the log-probability used for the PPO gradient—yet one collapses ($0.045$) and the other does not ($0.110$). A term common to both cannot explain a difference between them. We did not run a dedicated $c_c = 0$ ablation; Limitation 5 records this.

### 3.4 Non-Degradation Guarantee

At $\alpha = 0$ the objective collapses to vanilla MAPPO, so soft consensus is the baseline plus a perturbation whose influence is zero-weighted at initialization: the only quantity that grows during training is the weight $\alpha$, and the perturbation vanishes as $\alpha \to 0$. This mirrors identity initialization in residual networks [32], where a zero-weighted additive path leaves the shallow model intact at initialization and guarantees that the conditioned model starts out no worse. Multiplicative conditioning has no analogue of this guarantee—the action replacement is applied unconditionally, and the perturbation it induces is neither bounded nor reversible.

---

## 4. Experiments and Results

### 4.1 Experimental Setup

**Environment.** MPE simple\_spread [4] with $n = 5$ cooperative agents, 3 landmarks, discrete actions of size 5 ($H_{\max} = \ln 5 \approx 1.609$), and 25-step episodes. At $f = 1$ the PBFT bound $n \geq 3f+1$ holds from $n = 4$ upward; we use $n = 5$ so that one faulty agent still leaves a four-agent honest majority, and to match the population of the second task (Section 4.6).

**Variants.** (i) MAPPO baseline; (ii) Hard Consensus, mismatched log-prob; (iii) Hard Consensus, matched log-prob; (iv) Soft Consensus (ours). Figure 1 contrasts the two conditioning paths: multiplicative replacement versus additive loss conditioning.

**Hyperparameters.** $\eta = 5 \times 10^{-4}$, $\epsilon = 0.2$, $c_v = 1.0$, $c_e = 0.05$, $\gamma = 0.99$, $\lambda_{\text{GAE}} = 0.95$, 5 PPO epochs, hidden width 64, GRU recurrent layer. Soft consensus uses $\alpha = 0.1$, $\theta = 0.05$, $\lambda_{\text{floor}} = 10$. PBFT runs with $f = 1$, leader rotation, and fallback enabled.

**Training and statistics.** 300K steps, evaluation every 10K steps over 10 episodes, **8 seeds**. We report Welch's $t$-tests (unequal variances), Cohen's $d$ with pooled SD, Hedges' $g$, and Mann–Whitney $U$; full output is in Appendix A. The 4-seed subset of the same protocol is included in the 8-seed aggregate rather than reported separately, since we found the 4-seed reward effect sizes to be unstable at this noise level. Seeds 1–4 were run in the main batch and seeds 5–8 in a supplementary batch using the same training code path; the only later code change was the addition of per-agent entropy logging, which touches the logger and not the loss, the optimizer or the networks.

**Entropy accounting.** All entropy values in this paper are the **mean over all $n$ agents**, taken over the last 10 evaluation points. This matters when faulty agents are present and we return to it in Section 4.4: a faulty agent with a near-uniform policy contributes $\ln 5 \approx 1.609$ nats, so its inclusion shifts the reported mean by roughly 0.32 nats at $n = 5$ independently of what honest agents do. Honest-agent-only entropy requires per-agent logging; we report it for the $f = 1$ study (Table 3) and mark it unavailable for the $f = 2$ study, which predates the instrumentation.

### 4.2 E1: Clean Setting Comparison

**Table 1.** Performance on MPE simple\_spread ($n=5$, 300K steps, 8 seeds). Entropy is the mean over all agents $\pm$ std. See Figure 2.

| Method | Reward $\uparrow$ | Entropy (all-agent) $\uparrow$ | Consensus Rate | KL Loss |
|--------|:-----------------:|:------------------------------:|:--------------:|:-------:|
| MAPPO Baseline | $-66.2 \pm 19.4$ | $0.101 \pm 0.018$ | — | 0 |
| Hard Cons. (Mismatched) | $-57.3 \pm 15.5$ | $0.110 \pm 0.050$ | 1.0 | 0 |
| **Soft Cons. (Ours)** | $-57.9 \pm 16.8$ | $0.097 \pm 0.029$ | 1.0 | 0.031 |
| Hard Cons. (Matched) | $-63.4 \pm 19.8$ | $0.045 \pm 0.015$ | 1.0 | 0 |

Reward does not separate these four variants at 8 seeds. The largest gap is soft consensus against MAPPO ($-57.9$ vs. $-66.2$, $d = 0.45$), which carries $p = 0.38$; hard matched against hard mismatched is smaller still ($d = -0.34$, $p = 0.51$). With the spread we observe—standard deviations of 15 to 20 reward units and no consistent ordering across seeds—resolving reward differences of this size would require roughly an order of magnitude more seeds. The consensus variants do cluster above MAPPO in the mean (all three between $-57$ and $-63$ versus $-66$), but we treat that as a trend rather than a result.

Entropy, by contrast, separates in the mean, in the direction the mechanism predicts. Hard matched consensus sits at $0.045 \pm 0.015$, roughly 2.2$\times$ below soft consensus ($0.097 \pm 0.029$, $p = 0.0009$, $d = 2.29$) and 2.4$\times$ below hard mismatched ($0.110 \pm 0.050$, $p = 0.0071$, $d = -1.78$). It is also 2.2$\times$ below the MAPPO baseline ($p < 0.0001$, $d = -3.37$)—a comparison worth noting because it shows the collapse is not an artifact of adding consensus at all, but of adding it in the matched configuration specifically.

Soft consensus recovers to the MAPPO level: $0.097$ versus $0.101$, $p = 0.76$, $d = -0.16$. The KL guidance is empirically active (mean loss $0.031$), and the resulting policy distribution is indistinguishable from an unconditioned one on this metric.

### 4.3 E2: Causal Analysis — Matched vs. Mismatched Log-Prob

**Table 2.** Causal analysis. The two rows differ only in the log-probability used for the PPO gradient ($n=5$, 8 seeds). See Figure 3.

| Variant | Reward | Entropy (all-agent) | $\Delta$ Reward | $\Delta$ Entropy | $d$ (reward) | $d$ (entropy) |
|---------|:------:|:-------------------:|:---------------:|:----------------:|:------------:|:-------------:|
| Hard + Mismatched | $-57.3 \pm 15.5$ | $0.110 \pm 0.050$ | — | — | — | — |
| Hard + Matched | $-63.4 \pm 19.8$ | $0.045 \pm 0.015$ | $-10.6\%$ | $-59.2\%$ | 0.34 | 1.78 |

Both variants replace the action at execution time and both reach a consensus rate of 1.0. The single difference—whether the PPO gradient is evaluated at the executed consensus action or at the agent's own proposal—moves entropy by 59% ($p = 0.0071$, $d = -1.78$; Mann–Whitney $p = 0.002$). Per-seed values make the separation concrete: the mismatched variant ranges from 0.049 to 0.207 with no seed below 0.049, while the matched variant never exceeds 0.059 and five of eight seeds fall below 0.045.

The reward column shows why the entropy result should be the headline. Matched consensus is 10.6% worse in the mean, but with $p = 0.51$ and $d = -0.34$ that gap is consistent with sampling noise. The 4-seed subset of this same comparison had put the gap at 24.8% with $|d| = 0.7$, which we initially read as a moderate effect; doubling the seed count halved the apparent gap and erased the effect size. That subset is part of the aggregate above, so the two are not independent replications. The entropy collapse, in contrast, strengthened with more seeds.

A second control points the same way. Matched consensus also ends 55% below plain MAPPO ($0.101 \pm 0.018$, $p < 0.0001$, $d = -3.37$), so the collapse is specific to consensus *plus* matched log-probability rather than to consensus as such.

### 4.4 E3: Byzantine Fault Tolerance

The faulty agent is active from the first step and throughout training. We evaluate two fault behaviors at $f = 1$: an **adversarial** agent that maximizes collective penalty, and a **random** agent that samples uniformly.

**Table 3.** Byzantine faults on MPE simple\_spread ($n=5$, $f=1$, 300K steps, 4 seeds). Entropy is reported twice: as the mean over all 5 agents (including the faulty one) and as the mean over the 4 honest agents only. Both $\pm$ std over seeds. See Figure 4(a,b).

| Method | Fault | Reward $\uparrow$ | Entropy (all-agent) | Entropy (honest only) | Consensus Rate |
|--------|:-----:|:-----------------:|:-------------------:|:---------------------:|:--------------:|
| MAPPO Baseline | Random | $-44.9 \pm 7.1$ | $0.379 \pm 0.025$ | $0.071 \pm 0.032$ | — |
| MAPPO Baseline | Adversarial | $-65.3 \pm 16.8$ | $0.187 \pm 0.068$ | $0.117 \pm 0.141$ | — |
| Hard Cons. (Mismatched) | Random | $-48.1 \pm 7.5$ | $0.353 \pm 0.098$ | $0.097 \pm 0.053$ | 1.0 |
| Hard Cons. (Mismatched) | Adversarial | $-52.5 \pm 6.7$ | $0.367 \pm 0.042$ | $0.062 \pm 0.054$ | 1.0 |
| Soft Cons. (Ours) | Random | $-48.0 \pm 4.5$ | $0.070 \pm 0.020$ | $0.088 \pm 0.025$ | 1.0 |
| Soft Cons. (Ours) | Adversarial | $-56.8 \pm 5.5$ | $0.204 \pm 0.225$ | $0.255 \pm 0.281$ | 1.0 |

**The two entropy columns measure different things, and only one of them concerns the honest population.** Under MAPPO with random faults the all-agent mean is $0.379$ while the honest agents sit at $0.071$; solving $5(0.379) - 4(0.071)$ leaves $1.61$ nats for the faulty agent, which matches $\ln 5$ to two decimals—the value a uniform-sampling fault prescribes. Hard mismatched consensus shows the same bookkeeping ($0.353$ all-agent against $0.097$ honest). The implied faulty-agent contribution there is $5(0.353) - 4(0.097) = 1.38$ rather than $1.61$, which we read as that run's faulty policy being close to, but not exactly, uniform; the direction of the effect is unaffected. Soft consensus inverts the pattern: its all-agent mean ($0.070$) falls *below* its honest mean ($0.088$), because the faulty agent's policy under this variant is deterministic rather than uniform and a deterministic policy contributes nothing to the average. Comparing variants on the all-agent mean therefore reads out how the faulty agent behaves; we keep that column for continuity with the runs that predate per-agent logging.

**Honest-agent entropy under $f = 1$ faults is flat.** With per-agent logging in place, the honest-only column can be read directly rather than inferred. Across four seeds it runs $0.071 \pm 0.032$ (MAPPO, random), $0.117 \pm 0.141$ (MAPPO, adversarial), $0.097 \pm 0.053$ (hard mismatched, random), $0.062 \pm 0.054$ (hard mismatched, adversarial), $0.088 \pm 0.025$ (soft, random) and $0.255 \pm 0.281$ (soft, adversarial). All six bracket the clean-setting values of Section 4.2, and no pairwise Welch test separates them ($p = 0.26$–$0.77$; $|d| \leq 0.95$). The one nominal gap—soft consensus under adversarial faults, $0.255$ against $0.062$ for hard mismatched—is carried by a single seed ($0.674$, against $0.086$–$0.156$ for the other three); removing it moves the mean to $0.116$ and the contrast stays non-significant. We record it as unexplained seed variance rather than as an effect.

The measurement also retires an earlier shortcut. A first pass inferred honest-agent entropy by subtracting $\ln 5$ from the aggregate, which presupposes an exactly uniform faulty policy. That presupposition fails wherever the faulty agent's action is committed rather than sampled: the subtraction returns negative values for both soft-consensus rows, and it overstates honest entropy under adversarial faults. The all-agent column is accordingly not a proxy for the honest population in either direction.

**Fault strength at $f = 1$.** The adversarial fault harms MAPPO ($-65.3 \pm 16.8$ against $-44.9 \pm 7.1$ under random faults, and $-66.2$ clean) but leaves hard mismatched consensus roughly where it was ($-52.5 \pm 6.7$, against $-57.3$ clean). At this fault ratio the environment's redundancy absorbs a single faulty agent, so reward differences among methods stay within the noise bounds established in Section 4.2. The fault model is not strong enough to test consensus value at $n = 5$; Section 4.5 raises the ratio.

### 4.5 E3b: Higher Fault Ratio ($n = 7$, $f = 2$)

Raising both the population and the fault count to $n = 7$, $f = 2$ keeps the ratio at PBFT's tolerance bound ($f = \lfloor (n-1)/3 \rfloor = 2$, i.e. $f < n/3$) while making the faulty minority harder to absorb.

**Table 4.** Higher fault ratio ($n=7$, $f=2$, adversarial, 300K steps, 8 seeds). Entropy: all-agent mean $\pm$ std. See Figure 4(c).

| Method | Reward $\uparrow$ | Entropy (all-agent) | Consensus Rate | vs. MAPPO |
|--------|:-----------------:|:-------------------:|:--------------:|:---------:|
| MAPPO Baseline | $-69.2 \pm 12.2$ | $0.199 \pm 0.045$ | — | — |
| Soft Cons. (Ours) | $-68.5 \pm 15.4$ | $0.112 \pm 0.083$ | 1.0 | $p = 0.92$, $d = -0.05$ |
| Hard Cons. (Mismatched) | $-55.2 \pm 5.0$ | $0.518 \pm 0.049$ | 1.0 | $p = 0.014$, $d = -1.51$ |
| Hard Cons. (Matched) | $-61.5 \pm 11.1$ | $0.167 \pm 0.155$ | 1.0 | $p = 0.21$, $d = -0.66$ |

At $f = 2$ the reward ordering finally separates. Hard mismatched consensus holds $-55.2$ with a standard deviation of 5.0, against $-69.2 \pm 12.2$ for MAPPO ($p = 0.014$, $d = -1.51$; Mann–Whitney $p = 0.015$) and $-68.5 \pm 15.4$ for soft consensus ($p = 0.047$, $d = -1.16$). The variance difference is itself informative: hard consensus is both better on average and roughly 2.4$\times$ tighter in standard deviation across seeds (about $6\times$ in variance).

Soft consensus lands on top of MAPPO ($p = 0.92$, $d = -0.05$), which is the outcome its mechanism predicts. When the consensus target is contaminated by two faulty agents out of seven, a bounded KL penalty provides too weak a correction to change behavior, whereas replacing the action outright still performs a majority vote over the agents' proposals. Section 5.4 takes up what this implies for the design guidelines.

The fourth cell of the $2\times2$ design closes the causal comparison. Hard matched consensus—identical to the mismatched variant except for the log-probability used in the PPO gradient—reaches entropy $0.167 \pm 0.155$, far below the mismatched variant ($0.518 \pm 0.049$; $p = 0.0002$, $d = -3.06$) and statistically level with MAPPO ($p = 0.59$). The collapse is therefore not an artifact of the fault ratio: matched conditioning drives entropy down at $f = 1$ and again at $f = 2$. The two conditions differ in character, however. At $f = 1$ every seed collapses ($0.045 \pm 0.015$), whereas at $f = 2$ the collapse is probabilistic—two of eight seeds fall below $0.01$, five remain above $0.10$, and the remaining seed sits at $0.05$—so the distribution is bimodal rather than shifted. Reward again fails to separate: matched consensus ($-61.5 \pm 11.1$) sits between the mismatched variant ($-55.2 \pm 5.0$; $p = 0.17$) and MAPPO ($-69.2 \pm 12.2$; $p = 0.21$), with neither difference significant.

As in Section 4.4, the all-agent entropy column is dominated by the faulty agents' contributions (two uniform policies at $\ln 5$ each). Per-agent logging was added after these runs, so no honest-only decomposition is available for them and we do not interpret the $0.518$ figure as evidence about honest-agent diversity.

### 4.6 E4: Transfer to a Second Task (MPE simple\_line)

The design guidelines of Section 5.3 are worth little if they hold only on the coverage task. We therefore repeat the comparison on MPE simple\_line, where five agents must arrange themselves along a line. Population size and discrete action space (five actions) match Section 4.4; the objective, the observation dimension (8 against 30) and the reward scale differ. Algorithm configurations are reused unchanged, and the fault is again one randomly acting agent at $f = 1$. Figure 5(a) compares honest-agent entropy across the two tasks, and Figure 5(b) collects the resulting design guidelines.

**Table 5.** Second task, MPE simple\_line ($n=5$, 300K steps, 5 seeds). Entropy: all-agent and honest-only means over the last 10 evaluation points.

| Method | Fault | Reward $\uparrow$ | Entropy (all-agent) | Entropy (honest only) | Consensus Rate |
|--------|:-----:|:-----------------:|:-------------------:|:---------------------:|:--------------:|
| MAPPO Baseline | none | $-35.1 \pm 2.5$ | $0.041 \pm 0.050$ | $0.049 \pm 0.060$ | — |
| Hard Cons. (Mismatched) | none | $-34.2 \pm 3.8$ | $0.066 \pm 0.060$ | $0.064 \pm 0.065$ | 1.0 |
| Soft Cons. (Ours) | none | $-33.4 \pm 3.6$ | $0.102 \pm 0.037$ | $0.067 \pm 0.054$ | 1.0 |
| MAPPO Baseline | random | $-29.6 \pm 1.6$ | $0.352 \pm 0.041$ | $0.039 \pm 0.050$ | — |
| Hard Cons. (Mismatched) | random | $-29.2 \pm 1.3$ | $0.331 \pm 0.014$ | $0.014 \pm 0.017$ | 1.0 |
| Soft Cons. (Ours) | random | $-29.8 \pm 1.9$ | $0.120 \pm 0.123$ | $0.075 \pm 0.016$ | 1.0 |

**The fault-time collapse reproduces, and this task resolves it more sharply than the first.** In the clean condition soft consensus holds the highest all-agent entropy ($0.102 \pm 0.037$, against $0.066 \pm 0.060$ for hard mismatched and $0.041 \pm 0.050$ for MAPPO), though five seeds leave the gap to MAPPO short of significance ($p = 0.06$, $d = 1.39$). One faulty agent then separates the honest populations. Hard mismatched consensus loses 78% of its honest-agent entropy, from $0.064 \pm 0.065$ clean to $0.014 \pm 0.017$ under faults. That within-method drop is not significant on its own ($p = 0.16$), because the clean condition is itself the noisy one; the between-method contrast under faults is decisive, at $0.014$ against $0.075 \pm 0.016$ for soft consensus ($t = -5.88$, $p = 0.0004$, $d = -3.72$). Soft consensus holds its clean-condition level ($0.067 \rightarrow 0.075$, $p = 0.75$). Plain MAPPO lands between the two ($0.039 \pm 0.050$): level with soft consensus ($p = 0.19$) and nominally contracted to the same order as the collapsed variant ($p = 0.33$).

Two features of this task matter for reading the result. First, simple\_line is the tighter coordination problem—the agents' targets are mutually constrained, so one agent acting at random perturbs the others' learning signal more than it does in coverage. That is why the collapse is visible at $f = 1$ here, whereas Section 4.4 found honest-agent entropy flat across methods at the same fault ratio: the failure mode is present in both settings, but only the harder task resolves it with a single faulty agent. Second, MAPPO's contraction has a different origin. It has no consensus target to agree with, so its honest agents contract under a corrupted reward signal rather than under agreement pressure. The guideline this paper derives targets the agreement-pressure route, and soft consensus is the only variant of the three that closes it.

**Reward carries no signal here, and one anomaly remains open.** Neither clean nor faulted reward separates the methods beyond noise, and the faulted condition nominally *improves* all three ($-29$ to $-30$ against $-33$ to $-35$ clean; significant for MAPPO at $p = 0.005$). We did not anticipate this. The reward definition bounds how much a single agent can contribute: the shared reward is the negative mean distance from optimally matched line positions with each distance clipped at 2, so one agent can shift the per-step mean by at most $2/5 = 0.4$, which is 10 units over a 25-step episode—twice the gap we observe. The effect is therefore consistent with a single-agent perturbation rather than a change in team behavior, and it has no reason to carry a positive sign. Our working hypothesis exploits the assignment: the faulty agent is matched to an extreme line position at that bounded cost, leaving one fewer honest agent assigned to an extreme position, while the honest agents observe only their own pose and the two landmarks, so the global assignment is not locally observable and their policies converge toward the interior of the segment. The environment exposes per-agent distances, so a single diagnostic run would confirm or refute this in minutes; we did not run it and therefore make no claim. No result in this paper depends on reward in this environment.

---

## 5. Discussion

### 5.1 Why the Loop Has No Restoring Force

Reinforcing the consensus action is not a strong preference but an unbounded one. Every update raises $\pi_{\theta_i}(a^*)$, which makes $a^*$ more likely to be the majority proposal on the next batch, which in turn raises the reward credited to that action. Nothing in the objective counteracts the resulting loss of diversity: the entropy bonus is a fixed push, whereas the agreement pressure grows with the same policy distribution, so the process has no equilibrium short of determinism. That is also why the collapse resists tuning. Raising $c_e$ scales a term that competes against a force acting on the same quantity, and the loop reasserts itself. The only lever that works is changing what the gradient is computed against, which is what soft consensus does. An external check supports this reading. Consensus on its own does not compress the policy: hard mismatched consensus also replaces actions at execution time, yet it ends at $0.110 \pm 0.050$, slightly *above* the MAPPO baseline of $0.101 \pm 0.018$. What separates the collapsed variant is therefore the gradient it is trained against rather than the presence of consensus: matched consensus ends 59% below the mismatched variant and 55% below MAPPO.

### 5.2 Soft Consensus Restores Baseline Entropy

Soft consensus is statistically indistinguishable from an unconditioned policy on entropy (Table 1: $p = 0.76$, $d = -0.16$), so restoration of baseline entropy is the accurate description rather than partial mitigation—the collapse is removed without a diversity deficit of its own. Our earlier 4-seed run put soft consensus at $0.072$, below MAPPO, which prompted the weaker "mitigation, not prevention" framing; the additional seeds show that gap to be sampling variation.

This also sharpens the residual-network analogy from Section 3.4. The KL penalty enters with zero weight at $\alpha = 0$ and is self-limiting in practice, and the measured outcome matches this prediction: at $\alpha = 0.1$ the conditioned policy behaves like the baseline on the diversity metric while still receiving consensus signal (mean KL loss $0.031$).

**The entropy floor never engaged.** Honest-agent entropy stayed above $\theta = 0.05$ throughout, so $L^{\text{floor}}$ contributed nothing to any run reported here. We keep it as a defense-in-depth term and make no empirical claim for it; validating the floor requires either a smaller action space or stronger consensus pressure than simple\_spread provides. Reported results would be unchanged if the term were deleted.

### 5.3 When Guidance Hurts: Soft Consensus Under Faults

Under $f = 1$ faults (Table 3) all three methods sit inside the noise bounds of Section 4.2, with the nominal ordering reversing between fault types: MAPPO leads under random faults ($-44.9$ against $-48.0$ for soft and $-48.1$ for hard mismatched), while hard mismatched leads under adversarial faults ($-52.5$ against $-56.8$ for soft and $-65.3$ for MAPPO). Soft consensus never gains from the fault setting, and at $f = 2$ (Table 4) it falls to the MAPPO level outright ($p = 0.92$).

The mechanism is over-contraction. The KL term pulls honest agents toward $a^*$ whether or not $a^*$ is trustworthy, so when the consensus target is perturbed by faulty proposals, the guidance transfers the perturbation into honest agents' policies. Hard mismatched consensus is insulated at execution time—it still performs the vote—and MAPPO never consults consensus at all. Soft consensus occupies the worst position: it is influenced by the consensus signal without being able to override it.

The second task qualifies that verdict on a different axis. On diversity the ranking under faults reverses: in MPE simple\_line, hard mismatched consensus loses 78% of its honest-agent entropy ($0.064 \rightarrow 0.014$) while soft consensus holds its clean-condition level ($0.067 \rightarrow 0.075$; hard against soft $p = 0.0004$, $d = -3.72$; Section 4.6). Soft consensus is therefore weak rather than damaging: it fails to convert consensus into robustness, whereas hard mismatched consensus converts it into robustness at the cost of the honest population's diversity. Which trade is preferable depends on whether a deployment can retrain once a fault is detected, and our experiments do not settle that question.

One direction this suggests is a coefficient that tracks consensus quality—scaling $\alpha$ with observed proposal disagreement or with the length of the commit round, so that guidance weakens exactly when the signal is least reliable. We flag this as a direction rather than offering an implementation, since none of our runs tested an adaptive schedule.

### 5.4 What Makes Consensus Worth Having

Taken together, Tables 1–4 describe a contingency rather than a monotone benefit.

In the clean setting and at $f = 1$, consensus buys nothing measurable. Reward differences among MAPPO, hard mismatched, and soft consensus all sit inside noise (Section 4.2), and the clean comparison even puts MAPPO's entropy on par with soft consensus. Consensus is overhead when there is nothing to defend against.

At $f = 2$ the picture changes. Execution-time consensus is worth $14$ reward units ($-55.2$ vs. $-69.2$, $p = 0.014$) and reduces the across-seed standard deviation from $12.2$ to $5.0$ ($\approx 2.4\times$; variance $\approx 6\times$). The reason is that with two faulty agents out of seven, the leader's proposal carries information that individual policies lack—a majority vote over seven proposals filters two corrupted ones, while the underlying policy of an honest agent does not. Replacing the action at execution time captures that information; adding a penalty term to the objective merely asks the policy to acquire it through gradient descent, which at $\alpha = 0.1$ is too slow.

That last point is what forces a revision to our own guideline. The clean-setting result pushes toward "never replace the action", but the $f = 2$ result shows that action replacement is where the robustness comes from. The common factor in the harmful configuration is not replacement by itself—it is replacement *combined with* a gradient that reinforces the replacement. Hard mismatched consensus replaces actions and keeps entropy at $0.110$; hard matched consensus replaces actions and collapses to $0.045$. Guideline (i) below is narrowed accordingly.

The remaining question is where the crossover sits. We have two points—$f/n = 1/5$, where consensus does not pay, and $f/n = 2/7$, where it does—which is enough to establish that a crossover exists but not enough to locate it. Locating it would require scanning $f/n$ at fixed $n$, and the ratio is confounded with population size in our design ($5$ vs. $7$ agents). We note this as an open question rather than a boundary claim.

### 5.5 Limitations

1. **Reward comparisons are underpowered.** With 8 seeds, no clean-setting reward comparison reaches $p < 0.05$; observed effect sizes are $|d| = 0.04$–$0.45$. Anything beyond 8–10 seeds is out of reach for our compute budget, so the reward claims in this paper are limited to the $f = 2$ condition, where effect sizes are large enough to detect.
2. **Honest-agent entropy is measured only at $f = 1$.** Per-agent logging was added after the main runs, so Table 3 ($n = 5$, $f = 1$) carries a measured honest-only column while the $f = 2$ study in Section 4.5 is reported as an all-agent mean only. At $f = 1$ the honest-agent values are statistically indistinguishable across methods ($p \geq 0.26$), so this study constrains the honest population weakly, and the four-seed budget is the binding limitation. We never infer honest-agent entropy by subtraction, since that presupposes an exactly uniform faulty policy and returns negative values for several rows.
3. **Discrete actions only.** Every result here uses discrete action spaces. A continuous-action control (VMAS) failed in a way that is informative rather than incidental: consensus commits almost never (rate $0.098$ under faults), because agreement on continuous actions with a $0.5$ tolerance threshold is nearly unattainable, and the KL term must be replaced by an MSE proxy whose magnitude drifted to $19.7$ against $0.03$ on MPE, with one of eight seeds diverging to NaN. The method as specified is a discrete-domain method.
4. **Entropy floor unvalidated.** See Section 5.2—the floor never triggered, so its defense-in-depth role is stated on structural grounds only.

5. **Consensus-rate bonus not ablated.** The $c_c(1 - r^{\text{cons}})$ term is present in every consensus variant we report and was not ablated. Section 3.3 argues from invariance rather than measurement that it cannot drive the collapse: it is identical in the matched and mismatched variants, one of which collapses and the other of which does not.

6. **One diagnostic not run.** In simple\_line the faulted reward nominally exceeds the clean reward for all three methods (Section 4.6). The reward definition bounds a single agent's contribution to $0.4$ per step, and we offer an assignment-based explanation, but the per-agent distance diagnostic that would test it was not run; no claim in this paper rests on reward in that environment.
7. **Fixed guidance strength.** Soft consensus uses a constant $\alpha$; Section 5.3 argues that adaptive guidance is the natural fix for its behavior under faults, but we did not test such a schedule.
8. **Two environments, one fault model.** The cross-task evidence in Section 4.6 rests on MPE simple\_line. Two further candidate domains were dropped for incompatibility: the SMAClite reimplementation is not installable from the sources available to us, and the Level-Based Foraging package exposes an interface incompatible with our parallel wrapper. Both environments we do report are particle tasks, so the transfer evidence spans two objectives rather than two simulators. The fault model is also narrow: we sample the faulty agent's actions uniformly and study the adversarial fault only at $n = 5$ (Table 3). One anomaly is left unexplained—faulted reward in simple\_line nominally exceeds clean reward for all three methods (Section 4.6)—and no claim here depends on that quantity.

---

## 6. Conclusion

Consensus-guided MARL has a failure mode that is easy to miss because it does not show up in task reward. Pairing hard action replacement with matched log-probability PPO updates drives policy entropy down by 59% relative to the mismatched variant at $n = 5$ and 8 seeds ($0.045 \pm 0.015$ vs. $0.110 \pm 0.050$, $p = 0.0071$, $d = -1.78$), while the reward gap between the two—10.6% in the mean—stays inside sampling noise ($p = 0.51$). We originally read a larger 24.8% gap from a 4-seed run; doubling the seeds removed it, which is a reminder that underpowered reward comparisons in MARL can be misleading in both directions.

The guidelines are realizable, not merely principled. Additive loss conditioning—guideline (ii)—removes the collapse by relocating the consensus signal from the execution path to the loss. It holds entropy at $0.097 \pm 0.029$, statistically level with MAPPO's $0.101 \pm 0.018$ ($p = 0.76$) and 2.2$\times$ above the collapsed variant ($p = 0.0009$), without violating the Policy Gradient Theorem.

Testing at a higher fault ratio changed our conclusions about when consensus helps. At $f = 2$, $n = 7$, hard mismatched consensus reaches $-55.2 \pm 5.0$ against $-69.2 \pm 12.2$ for MAPPO ($p = 0.014$) and $-68.5 \pm 15.4$ for soft consensus ($p = 0.047$), so replacing actions at execution time does deliver robustness—precisely the operation our clean-setting results argued against. Reconciling the two conditions yields three guidelines:

(i) **Never pair action replacement with matched log-probability updates.** Replacement itself is defensible, as the $f = 2$ result shows, and the matched cell of that same $2\times2$ design locates the harm precisely: swapping only the gradient target, while leaving replacement in place, restores the collapse ($p = 0.0002$, $d = -3.06$). What has no defensible version is training PPO to reinforce an action the policy did not choose.

(ii) **Prefer additive loss conditioning whose influence is zero-weighted at the outset.** It admits a non-degradation guarantee at $\alpha = 0$ and, empirically, restores baseline entropy without a diversity penalty.

(iii) **Enforce entropy floors as defense-in-depth.** In our runs they never engaged, so this remains a structural safeguard rather than a validated one.

A second task confirms the diagnosis, not only the remedy. In MPE simple\_line, one randomly acting agent out of five leaves honest-agent entropy at $0.014 \pm 0.017$ under hard mismatched consensus but at $0.075 \pm 0.016$ under soft consensus ($p = 0.0004$, $d = -3.72$), while plain MAPPO also contracts ($0.039 \pm 0.050$). The failure mode is therefore not an artifact of the coverage task, and it survives a change of objective with the algorithm configurations held fixed.

Two things follow for future work. The crossover in $f/n$ where consensus starts to pay is bounded between $1/5$ and $2/7$ but not located; scanning the ratio at fixed population would settle it. And because soft consensus's weakness is that its guidance strength is fixed, a coefficient that adapts to observed consensus quality is the most direct repair for its behavior under faults.

---

## Appendix A: Statistical Tests

Welch's $t$-tests, Cohen's $d$ (pooled SD), Hedges' $g$ (small-sample correction), Mann–Whitney $U$, and—in Tables A.1 and A.2—95% confidence intervals on the mean difference. $s_{\text{pooled}} = \sqrt{[(n_1-1)s_1^2 + (n_2-1)s_2^2] / (n_1+n_2-2)}$; degrees of freedom follow Welch–Satterthwaite.

**A.1 Entropy ($n = 8$)**

| Comparison | A | B | $t$ | $df$ | $p$ | $d$ | $g$ | 95% CI of diff. | MWU $p$ |
|:-----------|:--:|:--:|:---:|:----:|:---:|:---:|:---:|:---------------:|:-------:|
| Matched vs. Mismatched | $0.0449 \pm 0.0148$ | $0.1100 \pm 0.0496$ | $-3.56$ | 8.2 | **0.0071** | $-1.78$ | $-1.68$ | $[-0.1071, -0.0231]$ | 0.002 |
| Matched vs. MAPPO | $0.0449 \pm 0.0148$ | $0.1008 \pm 0.0183$ | $-6.73$ | 13.4 | **<0.0001** | $-3.37$ | $-3.18$ | $[-0.0738, -0.0380]$ | 0.000 |
| Soft vs. Matched | $0.0970 \pm 0.0286$ | $0.0449 \pm 0.0148$ | $4.57$ | 10.5 | **0.0009** | $2.29$ | $2.16$ | $[0.0269, 0.0774]$ | 0.000 |
| Soft vs. Mismatched | $0.0970 \pm 0.0286$ | $0.1100 \pm 0.0496$ | $-0.64$ | 11.2 | 0.5341 | $-0.32$ | $-0.30$ | $[-0.0575, 0.0315]$ | 0.645 |
| Soft vs. MAPPO | $0.0970 \pm 0.0286$ | $0.1008 \pm 0.0183$ | $-0.31$ | 11.9 | 0.7588 | $-0.16$ | $-0.15$ | $[-0.0300, 0.0224]$ | 0.442 |
| $f{=}2$: MAPPO vs. Hard | $0.1988 \pm 0.0448$ | $0.5176 \pm 0.0485$ | $-13.66$ | 13.9 | **<0.0001** | $-6.83$ | $-6.46$ | $[-0.3688, -0.2687]$ | 0.000 |
| $f{=}2$: MAPPO vs. Soft | $0.1988 \pm 0.0448$ | $0.1122 \pm 0.0829$ | $2.60$ | 10.8 | **0.0251** | $1.30$ | $1.23$ | $[0.0131, 0.1601]$ | 0.050 |
| $f{=}2$: Soft vs. Hard | $0.1122 \pm 0.0829$ | $0.5176 \pm 0.0485$ | $-11.94$ | 11.3 | **<0.0001** | $-5.97$ | $-5.64$ | $[-0.4799, -0.3309]$ | 0.000 |
| $f{=}2$: MAPPO vs. Hard-Matched | $0.1988 \pm 0.0448$ | $0.1669 \pm 0.1545$ | $0.56$ | 8.2 | 0.5896 | $0.28$ | $0.27$ | $[-0.0988, 0.1627]$ | 0.505 |
| $f{=}2$: Hard-Mismatched vs. Hard-Matched | $0.5176 \pm 0.0485$ | $0.1669 \pm 0.1545$ | $6.12$ | 8.4 | **0.0002** | $3.06$ | $2.90$ | $[0.2196, 0.4818]$ | 0.000 |
| $f{=}2$: Soft vs. Hard-Matched | $0.1122 \pm 0.0829$ | $0.1669 \pm 0.1545$ | $-0.88$ | 10.7 | 0.3973 | $-0.44$ | $-0.42$ | $[-0.1916, 0.0822]$ | 0.878 |

**A.2 Reward ($n = 8$)**

| Comparison | A | B | $t$ | $df$ | $p$ | $d$ | $g$ | 95% CI of diff. | MWU $p$ |
|:-----------|:--:|:--:|:---:|:----:|:---:|:---:|:---:|:---------------:|:-------:|
| Matched vs. Mismatched | $-63.36 \pm 19.82$ | $-57.29 \pm 15.46$ | $-0.68$ | 13.2 | 0.5069 | $-0.34$ | $-0.32$ | $[-25.23, 13.10]$ | 0.599 |
| Matched vs. MAPPO | $-63.36 \pm 19.82$ | $-66.15 \pm 19.37$ | $0.29$ | 14.0 | 0.7791 | $0.14$ | $0.14$ | $[-18.20, 23.80]$ | 0.834 |
| Soft vs. Matched | $-57.92 \pm 16.79$ | $-63.36 \pm 19.82$ | $0.59$ | 13.6 | 0.5645 | $0.30$ | $0.28$ | $[-14.33, 25.18]$ | 0.344 |
| Soft vs. Mismatched | $-57.92 \pm 16.79$ | $-57.29 \pm 15.46$ | $-0.08$ | 13.9 | 0.9382 | $-0.04$ | $-0.04$ | $[-17.96, 16.68]$ | 0.959 |
| Soft vs. MAPPO | $-57.92 \pm 16.79$ | $-66.15 \pm 19.37$ | $0.91$ | 13.7 | 0.3795 | $0.45$ | $0.43$ | $[-11.24, 27.69]$ | 0.293 |
| $f{=}2$: MAPPO vs. Hard | $-69.23 \pm 12.18$ | $-55.21 \pm 4.98$ | $-3.01$ | 9.3 | **0.0142** | $-1.51$ | $-1.42$ | $[-24.45, -3.52]$ | 0.015 |
| $f{=}2$: MAPPO vs. Soft | $-69.23 \pm 12.18$ | $-68.54 \pm 15.40$ | $-0.10$ | 13.3 | 0.9225 | $-0.05$ | $-0.05$ | $[-15.64, 14.26]$ | 0.753 |
| $f{=}2$: Soft vs. Hard | $-68.54 \pm 15.40$ | $-55.21 \pm 4.98$ | $-2.33$ | 8.4 | **0.0469** | $-1.16$ | $-1.10$ | $[-26.37, -0.23]$ | 0.050 |
| $f{=}2$: MAPPO vs. Hard-Matched | $-69.23 \pm 12.18$ | $-61.54 \pm 11.15$ | $-1.32$ | 13.9 | 0.2095 | $-0.66$ | $-0.62$ | $[-20.21, 4.85]$ | 0.279 |
| $f{=}2$: Hard-Mismatched vs. Hard-Matched | $-55.21 \pm 4.98$ | $-61.54 \pm 11.15$ | $1.47$ | 9.7 | 0.1738 | $0.73$ | $0.69$ | $[-3.32, 16.00]$ | 0.195 |
| $f{=}2$: Soft vs. Hard-Matched | $-68.54 \pm 15.40$ | $-61.54 \pm 11.15$ | $-1.04$ | 12.8 | 0.3173 | $-0.52$ | $-0.49$ | $[-21.54, 7.55]$ | 0.328 |

**Table A.3.** Honest-agent-only entropy at $n = 5$, $f = 1$, measured with per-agent logging (`train/entropy_agent_i`, mean of the last 10 evaluation points, 4 seeds).

| Method | Fault | Honest-agent entropy | Per-seed values |
|--------|:-----:|:--------------------:|-----------------|
| MAPPO Baseline | Random | $0.071 \pm 0.032$ | $0.036$, $0.104$, $0.053$, $0.090$ |
| MAPPO Baseline | Adversarial | $0.117 \pm 0.141$ | $0.327$, $0.041$, $0.068$, $0.030$ |
| Hard Cons. (Mismatched) | Random | $0.097 \pm 0.053$ | $0.084$, $0.081$, $0.051$, $0.173$ |
| Hard Cons. (Mismatched) | Adversarial | $0.062 \pm 0.054$ | $0.013$, $0.061$, $0.038$, $0.138$ |
| Soft Cons. (Ours) | Random | $0.088 \pm 0.025$ | $0.075$, $0.071$, $0.125$, $0.081$ |
| Soft Cons. (Ours) | Adversarial | $0.255 \pm 0.281$ | $0.086$, $0.105$, $0.156$, $0.674$ |

Pairwise Welch tests at 4 seeds, with $p$ from the $t$-distribution using Welch–Satterthwaite degrees of freedom (as elsewhere in this appendix): MAPPO against hard mismatched gives $p = 0.43$ (random) and $p = 0.52$ (adversarial); hard mismatched against soft gives $p = 0.77$ and $p = 0.26$; MAPPO against soft gives $p = 0.43$ and $p = 0.42$. Cohen's $d$ ranges from $-0.95$ to $0.51$. The corresponding all-agent values appear in Table 3; the two columns differ by the faulty agent's contribution, which is $1.61 \approx \ln 5$ under random faults with MAPPO and hard consensus, and $0.000$ under soft consensus.

**A.4 Second task (MPE simple\_line, $n = 5$, 5 seeds)**

| Comparison | A | B | $t$ | $df$ | $p$ | $d$ |
|:-----------|:--:|:--:|:---:|:----:|:---:|:---:|
| Honest entropy, hard vs. soft (random fault) | $0.0138 \pm 0.0170$ | $0.0754 \pm 0.0161$ | $-5.88$ | 8.0 | **0.0004** | $-3.72$ |
| Honest entropy, soft faulted vs. soft clean | $0.0754 \pm 0.0161$ | $0.0668 \pm 0.0543$ | $0.34$ | 4.7 | 0.7489 | $0.21$ |
| Honest entropy, hard clean vs. hard faulted | $0.0639 \pm 0.0646$ | $0.0138 \pm 0.0170$ | $1.68$ | 4.6 | 0.1601 | $1.06$ |
| Honest entropy, MAPPO vs. soft (random fault) | $0.0391 \pm 0.0502$ | $0.0754 \pm 0.0161$ | $-1.54$ | 4.8 | 0.1865 | $-0.97$ |
| Honest entropy, MAPPO vs. hard (random fault) | $0.0391 \pm 0.0502$ | $0.0138 \pm 0.0170$ | $1.07$ | 4.9 | 0.3355 | $0.68$ |
| All-agent entropy, soft vs. MAPPO (clean) | $0.1020 \pm 0.0368$ | $0.0410 \pm 0.0502$ | $2.19$ | 7.3 | 0.0628 | $1.39$ |
| All-agent entropy, soft vs. hard (clean) | $0.1020 \pm 0.0368$ | $0.0661 \pm 0.0597$ | $1.15$ | 6.7 | 0.2918 | $0.72$ |
| Reward, MAPPO clean vs. faulted | $-35.05 \pm 2.49$ | $-29.60 \pm 1.60$ | $-4.12$ | 6.8 | **0.0047** | $-2.60$ |

$t$ and $d$ follow the convention used throughout: the sign is that of A minus B for the groups as listed, and $p$ comes from the $t$-distribution with Welch–Satterthwaite degrees of freedom. The reward row is the anomaly discussed in Section 4.6.

---

## Data Availability

All simulation environments used in this study are publicly available through the PettingZoo, VMAS and Gymnasium libraries. Source code, configuration files, and the per-seed training logs underlying every figure and table reported here are available from the corresponding author upon reasonable request.

## References

[1] Buşoniu, L., Babuška, R., & De Schutter, B. (2008). A comprehensive survey of multiagent reinforcement learning. *IEEE Trans. SMC*, 38(2), 156–172.

[2] Zhang, K., Yang, Z., & Başar, T. (2021). Multi-agent reinforcement learning: A selective overview. *Handbook of RL and Control*, 321–384.

[3] Yu, C., Velu, A., Vinitsky, E., Gao, J., Wang, X., Bayen, A., & Wu, Y. (2022). The surprising effectiveness of PPO in cooperative multi-agent games. *NeurIPS*.

[4] Mordatch, I., & Abbeel, P. (2018). Emergence of grounded compositional language in multi-agent populations. *AAAI*.

[5] Lamport, L., Shostak, R., & Pease, M. (1982). The Byzantine generals problem. *ACM TOPLAS*, 4(3), 382–401.

[6] Castro, M., & Liskov, B. (1999). Practical Byzantine fault tolerance. *OSDI*.

[7] Li, S., Guo, J., Xiu, J., et al. (2024). Byzantine robust cooperative multi-agent reinforcement learning as a Bayesian game. *ICLR*.

[8] Foerster, J., Assael, I.A., de Freitas, N., & Whiteson, S. (2016). Learning to communicate with deep multi-agent reinforcement learning. *NeurIPS*.

[9] Sutton, R.S., McAllester, D., Singh, S., & Mansour, Y. (2000). Policy gradient methods for RL with function approximation. *NeurIPS*.

[10] Schulman, J., Wolski, F., Dhariwal, P., Radford, A., & Klimov, O. (2017). Proximal policy optimization algorithms. *arXiv:1707.06347*.

[11] Rashid, T., Samvelyan, M., de Witt, C.S., Farquhar, G., Foerster, J., & Whiteson, S. (2018). QMIX: Monotonic value function factorisation. *ICML*.

[12] Lowe, R., Wu, Y., Tamar, A., Harb, J., Abbeel, O., & Mordatch, I. (2017). Multi-agent actor-critic for mixed cooperative-competitive environments. *NIPS*.

[13] Sukhbaatar, S., Szlam, A., & Fergus, R. (2016). Learning multiagent communication with backpropagation. *NeurIPS*.

[14] Das, A., Gervet, T., Romoff, J., et al. (2019). TarMAC: Targeted multi-agent communication. *ICML*.

[15] Littman, M.L. (1996). Exploration in reinforcement learning. *NSF Workshop on RL*.

[16] Kim, W., & Sung, Y. (2023). An adaptive entropy-regularization framework for multi-agent reinforcement learning. *ICML*.

[17] Forkel, J., Ruhdorfer, C., Beukman, M., Bulling, A., & Foerster, J. (2025). High entropy regularization leads to symmetry equivariant policies in Dec-POMDPs. *arXiv:2511.22581*.

[18] Blanchard, P., El Mhamdi, E.M., Guerraoui, R., & Stainer, J. (2017). Machine learning with adversaries: Byzantine gradient descent. *NeurIPS*.

[19] Yin, D., Chen, Y., Kannan, R., & Bartlett, P. (2018). Byzantine-robust distributed learning. *ICML*.

[20] El Mhamdi, E.M., Guerraoui, R., & Rouault, S. (2018). The hidden vulnerability of distributed learning in Byzantium. *ICML*.

[21] Jordan, P., Grötschla, F., Fan, F.X., & Wattenhofer, R. (2024). Decentralized federated policy gradient with Byzantine fault-tolerance and provably fast convergence. *AAMAS*.

[22] Lin, Q., & Ling, Q. (2024). Robust reward-free actor–critic for cooperative multiagent reinforcement learning. *IEEE TNNLS*, 35(12), 17318–17329.

[23] Wu, C., Qin, H., Amiri, M.J., Loo, B.T., Malkhi, D., & Marcus, R. (2025). BFTBrain: Adaptive BFT consensus with reinforcement learning. *USENIX NSDI*, 1563–1583.

[24] Yu, L., Qiu, Y., Yao, Q., Shen, Y., Zhang, X., & Wang, J. (2024). Robust communicative MARL with active defense. *AAAI*, 17575–17582.

[25] Ma, O., Pu, Y., Du, L., Dai, Y., Wang, R., Liu, X., Wu, Y., & Ji, S. (2024). SUB-PLAY: Adversarial policies against partially observed multi-agent reinforcement learning systems. *arXiv:2402.03741*.

[26] Li, Y., et al. (2024). Resilient multiagent reinforcement learning with function approximation. *IEEE Trans. Autom. Control*.

[27] Rizk, Y., Said, A., & Rizk, M. (2024). Hierarchical consensus-based multi-agent reinforcement learning for robot task allocation. *IROS*.

[28] He, S., et al. (2025). Cooperative policy agreement in offline multi-agent reinforcement learning. *AAAI*.

[29] Shek, C.L., Shi, G., & Tokekar, P. (2026). Multi-agent trust region policy optimisation: A joint constraint approach. *AAMAS*.

[30] Perez, E., Strub, F., De Vries, H., Dumoulin, V., & Courville, A. (2018). FiLM: Visual reasoning with a general conditioning layer. *AAAI*.

[31] Zhang, L., Li, L., Wei, W., Song, H., Yang, Y., & Liang, J. (2024). Scalable constrained policy optimization for safe multi-agent reinforcement learning. *NeurIPS*.

[32] He, K., Zhang, X., Ren, S., & Sun, J. (2016). Deep residual learning for image recognition. *CVPR*.

[33] Schulman, J., Moritz, P., Levine, S., Jordan, M., & Abbeel, P. (2016). High-dimensional continuous control using generalized advantage estimation. *ICLR*.
