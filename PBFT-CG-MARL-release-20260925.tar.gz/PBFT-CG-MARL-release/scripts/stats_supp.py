#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""逐 seed 明细 + Welch t 检验 + Cohen's d（补充 + 主表 + 第二/三环境）"""
import json, glob, os
import numpy as np
try:
    from scipy import stats as st
except Exception:
    st = None

dirs = ["results/supplement", "results/n5_review", "results/env2_smac", "results/env3_lbf"]

ALIAS = {"reward":  ["episode/episode_reward", "episode_reward"],
         "entropy": ["train/entropy", "entropy"],
         "cr":      ["episode/consensus_rate", "train/consensus_rate"],
         "kl":      ["train/kl_consensus_loss", "kl_consensus_loss"]}


def pick(d, key):
    for k in ALIAS[key]:
        v = d.get(k)
        if isinstance(v, list) and len(v) > 0:
            return float(np.mean(v[-10:]))
    return None


def load_all(label):
    rows = {}
    for rd in dirs:
        for p in glob.glob(os.path.join(rd, label, "**", "metrics.json"), recursive=True):
            try:
                s = int(p.split(os.sep)[-2].split("_")[1])
            except (IndexError, ValueError):
                continue
            try:
                d = json.load(open(p))
            except Exception:
                continue
            if pick(d, "reward") is None:
                continue
            rows[s] = {k: pick(d, k) for k in ALIAS}
    return rows


LABS = ["E1_mappo", "E1_hard", "E1_soft", "E2_matched",
        "E3_mappo_rand", "E3_hard_rand", "E3_soft_rand", "E3_hard_adv", "E3_soft_adv",
        "E3_mappo_adv", "E3f2_mappo", "E3f2_soft", "E3f2_hard",
        "VMAS_mappo", "VMAS_hard", "VMAS_soft",
        "ENV2_mappo", "ENV2_hard", "ENV2_soft",
        "ENV3_mappo", "ENV3_hard", "ENV3_soft"]

DATA = {L: load_all(L) for L in LABS}


def arr(L, key):
    r = DATA[L]
    ss = sorted(r)
    return np.array([r[s][key] for s in ss if r[s][key] is not None]), ss


print("=" * 100)
print("【逐 seed 明细】")
for L in LABS:
    r = DATA[L]
    if not r:
        continue
    ss = sorted(r)
    print(f"  {L:<15} reward ={[round(r[s]['reward'], 1) for s in ss]}")
    print(f"  {'':<15} entropy={[round(r[s]['entropy'], 4) if r[s]['entropy'] is not None else None for s in ss]}")

print("=" * 100)
print("【关键对比：Welch t 检验 + Cohen's d (pooled)】")
print(f"{'comparison':<30}{'key':<9}{'n':>6}  {'A: mean±sd':>17}  {'B: mean±sd':>17}  {'t':>7} {'p':>9} {'d':>6}")


def cmp(A, B, key):
    a, _ = arr(A, key)
    b, _ = arr(B, key)
    if len(a) < 2 or len(b) < 2:
        print(f"{A+' vs '+B:<30}{key:<9}{'-':>6}   样本不足")
        return
    ma, mb = a.mean(), b.mean()
    sa, sb = a.std(ddof=1), b.std(ddof=1)
    sp = np.sqrt(((len(a) - 1) * sa ** 2 + (len(b) - 1) * sb ** 2) / (len(a) + len(b) - 2))
    d = (ma - mb) / sp if sp > 0 else 0.0
    t, p = (st.ttest_ind(a, b, equal_var=False) if st else (float('nan'), float('nan')))
    print(f"{A+' vs '+B:<30}{key:<9}{f'{len(a)}/{len(b)}':>6}  {f'{ma:.4f}±{sa:.4f}':>17}  "
          f"{f'{mb:.4f}±{sb:.4f}':>17}  {t:>7.2f} {p:>9.4f} {d:>6.2f}")


PAIRS = [("E2_matched", "E1_hard"), ("E1_soft", "E2_matched"), ("E1_soft", "E1_hard"),
         ("E1_mappo", "E2_matched"),
         ("E3f2_mappo", "E3f2_hard"), ("E3f2_soft", "E3f2_hard"), ("E3f2_mappo", "E3f2_soft"),
         ("ENV2_mappo", "ENV2_hard"), ("ENV2_soft", "ENV2_hard"),
         ("ENV3_mappo", "ENV3_hard"), ("ENV3_soft", "ENV3_hard")]
for A, B in PAIRS:
    for key in ["entropy", "reward"]:
        cmp(A, B, key)
print("=" * 100)
print("scipy 可用" if st else "!! scipy 不可用：t/p 为 nan，但 Cohen's d 仍有效（可用 d 判定效应量）")
