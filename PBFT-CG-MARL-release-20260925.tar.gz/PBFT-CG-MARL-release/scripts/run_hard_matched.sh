#!/bin/bash
# ============================================================
# 补实验：f=2, n=7, adversarial —— Hard MATCHED（补论文 Table 4 缺角）
# 独立脚本，不触碰现有 run_supplement.sh / Batch A-D
# ------------------------------------------------------------
# 用法:
#   bash run_hard_matched.sh verify   # 5 分钟预检（1 seed × 20K steps）
#   bash run_hard_matched.sh run      # 正式：8 seeds × 300K steps（4 路并发）
#   bash run_hard_matched.sh status   # 进度速查
#   bash run_hard_matched.sh collect  # 汇总 seed 级指标
# ============================================================
set -u
PROJECT=/root/autodl-tmp/PBFT-CG-MARL
PY=/root/miniconda3/bin/python
RESULTS=$PROJECT/results/supplement
LOGS=$PROJECT/logs/supplement
LABEL=E3f2_hard_matched
ALGO=pbft_cg_mappo
ENV=mpe_spread
ENVCFG=$PROJECT/configs/env/mpe_spread_n7.yaml
ACFG=$PROJECT/configs/algo/supp_hard_matched_byz2_adv_n7.yaml
BYZ="--byzantine_n 2 --byzantine_type adversarial"
PARALLEL=4
GPU=0
STEPS=300000
EVAL_INT=10000
EVAL_EP=10
SEEDS="1 2 3 4 5 6 7 8"

mkdir -p "$RESULTS" "$LOGS"
cd "$PROJECT" || exit 1

log() { echo "[$(date +%H:%M:%S)] $*"; }
throttle() { while [ "$(jobs -rp | wc -l)" -ge "$PARALLEL" ]; do sleep 10; done; }

case "${1:-run}" in
verify)
  log "=== 预检：1 seed × 20K steps（约 5 分钟）==="
  VD="$RESULTS/${LABEL}_verify/seed_1"; mkdir -p "$VD"
  $PY -u src/train.py --algo "$ALGO" --env "$ENV" \
      --env_config "$ENVCFG" --algo_config "$ACFG" \
      --seed 1 --n_timesteps 20000 --eval_interval 10000 --eval_episodes 3 \
      --gpu "$GPU" $BYZ --log_dir "$VD" 2>&1 | tail -25
  echo
  echo "--- 产出检查（应有 metrics.json）---"
  find "$RESULTS/${LABEL}_verify" -name metrics.json -exec ls -lh {} \;
  echo "--- 拜占庭是否生效（日志里应有注入痕迹）---"
  grep -ci "byzantine\|fault" "$LOGS/${LABEL}_s1.log" 2>/dev/null || echo "（看控制台输出）"
  ;;

run)
  LOCK=/tmp/run_hard_matched.lock
  if [ -e "$LOCK" ] && kill -0 "$(cat "$LOCK" 2>/dev/null)" 2>/dev/null; then
     echo "!! 已有实例在跑 (PID=$(cat "$LOCK"))，退出以避免并发失控"; exit 1
  fi
  echo $$ > "$LOCK"; trap 'rm -f "$LOCK"' EXIT
  log "=== 正式实验 $LABEL：8 seeds × 300K steps，并发 $PARALLEL ==="
  for S in $SEEDS; do
    OUTDIR=$RESULTS/$LABEL/seed_$S; mkdir -p "$OUTDIR"
    if [ -f "$OUTDIR/$ALGO/seed_$S/metrics.json" ]; then
      log "  [SKIP] seed=$S 已完成"; continue
    fi
    throttle
    nohup $PY -u src/train.py --algo "$ALGO" --env "$ENV" \
        --env_config "$ENVCFG" --algo_config "$ACFG" \
        --seed "$S" --n_timesteps "$STEPS" --eval_interval "$EVAL_INT" \
        --eval_episodes "$EVAL_EP" --gpu "$GPU" $BYZ \
        --log_dir "$OUTDIR" > "$LOGS/${LABEL}_s${S}.log" 2>&1 &
    log "  启动 seed=$S (PID=$!)"
  done
  wait
  log "=== 全部完成 ==="
  find "$RESULTS/$LABEL" -name metrics.json | sort
  ;;

status)
  echo "已完成：$(find "$RESULTS/$LABEL" -name metrics.json 2>/dev/null | wc -l) / 8"
  echo "运行中：$(pgrep -fc 'src/train.py' 2>/dev/null || echo 0) 个 train.py"
  nvidia-smi --query-gpu=utilization.gpu,memory.used --format=csv,noheader 2>/dev/null
  ;;

collect)
  $PY - <<'PYEOF'
import json, glob, os, statistics as st
rs = sorted(glob.glob("/root/autodl-tmp/PBFT-CG-MARL/results/supplement/E3f2_hard_matched/**/metrics.json", recursive=True))
rew, ent = [], []
for f in rs:
    d = json.load(open(f))
    e = d.get("episode/episode_reward") or d.get("episode_reward") or []
    h = d.get("episode/episode_length") or []
    k = d.get("train/entropy") or d.get("episode/entropy") or []
    if e: rew.append(sum(e[-10:]) / len(e[-10:]))
    if k: ent.append(sum(k[-10:]) / len(k[-10:]))
def ms(x): return (round(st.mean(x),3), round(st.stdev(x),3)) if len(x)>1 else (x[0] if x else None, None)
print("seed 数 :", len(rs))
print("reward  : mean=%.3f  std=%.3f  (n=%d)" % (st.mean(rew), st.stdev(rew), len(rew)) if len(rew)>1 else "reward: 数据不足")
print("entropy : mean=%.4f  std=%.4f  (n=%d)" % (st.mean(ent), st.stdev(ent), len(ent)) if len(ent)>1 else "entropy: 数据不足")
print("逐 seed reward:", [round(x,2) for x in rew])
print("逐 seed entropy:", [round(x,4) for x in ent])
PYEOF
  ;;

*)
  echo "用法: bash run_hard_matched.sh [verify|run|status|collect]";;
esac
