#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
汇总 PBFT-CG-MARL 补充实验 + 主表（n5_review）结果。

真实目录结构（train.py 实际写出）：
    <results_dir>/<label>/seed_<S>/<algo>/seed_<S>/metrics.json

用法：
    python scripts/collect_results.py \
        /root/autodl-tmp/PBFT-CG-MARL/results/supplement \
        /root/autodl-tmp/PBFT-CG-MARL/results/n5_review
（可传多个目录，同名 label 的 seeds 会合并，便于把补种 5-8 并进主表 1-4）
"""
import json
import os
import sys
import glob
import numpy as np

# 要汇总的 label（主表 + 补充）
LABELS = [
    # —— 主表 n5_review ——
    "E1_mappo", "E1_hard", "E1_soft", "E2_matched",
    "E3_mappo_rand", "E3_hard_rand", "E3_soft_rand",
    "E3_hard_adv", "E3_soft_adv",
    # —— 补充 ——
    "E3_mappo_adv",          # Batch A（E3 缺角）
    "E3f2_mappo", "E3f2_soft", "E3f2_hard",   # Batch D
]

KEY_ALIASES = {
    "reward":         ["episode/episode_reward", "episode_reward"],
    "entropy":        ["train/entropy", "entropy"],
    "consensus_rate": ["episode/consensus_rate", "train/consensus_rate", "consensus_rate"],
    "kl_loss":        ["train/kl_consensus_loss", "kl_consensus_loss"],
    "entropy_floor":  ["train/entropy_floor_penalty", "entropy_floor_penalty"],
}


def load_metrics(path):
    if not os.path.exists(path):
        return None
    try:
        with open(path) as f:
            d = json.load(f)
    except Exception:
        return None
    out = {}
    for name, aliases in KEY_ALIASES.items():
        for k in aliases:
            if k in d and isinstance(d[k], list) and len(d[k]) > 0:
                out[name] = float(np.mean(d[k][-10:]))
                break
    return out if "reward" in out else None


def collect(label, dirs):
    """跨多个 results_dir 合并同名 label 的 seeds"""
    data = {}
    for rd in dirs:
        pattern = os.path.join(rd, label, "seed_*", "*", "seed_*", "metrics.json")
        for mf in sorted(glob.glob(pattern)):
            try:
                seed = int(mf.split(os.sep)[-3].split("_")[1])
            except (IndexError, ValueError):
                continue
            m = load_metrics(mf)
            if m:
                data[seed] = m
    return data


def summarize(data, label):
    if not data:
        print(f"  {label:<16} : 无数据")
        return
    seeds = sorted(data)
    r = np.array([data[s]["reward"] for s in seeds])
    sd = r.std(ddof=1) if len(seeds) > 1 else 0.0
    line = f"  {label:<16} : n={len(seeds):<2} reward={r.mean():8.1f}±{sd:6.1f}"
    for metric in ("entropy", "consensus_rate", "kl_loss"):
        vals = [data[s][metric] for s in seeds if metric in data[s]]
        if vals:
            line += f" | {metric}={np.mean(vals):.4f}"
    print(line)
    print(f"       seeds={seeds}")


def main(dirs):
    print("=" * 80)
    print("汇总目录：" + "  +  ".join(dirs))
    print("=" * 80)
    for label in LABELS:
        summarize(collect(label, dirs), label)
    print("=" * 80)
    print("提示：把 seeds 数量、reward 均值±std、entropy 填进论文对应表格。")


if __name__ == "__main__":
    args = sys.argv[1:] or [
        "/root/autodl-tmp/PBFT-CG-MARL/results/supplement",
        "/root/autodl-tmp/PBFT-CG-MARL/results/n5_review",
    ]
    main(args)
