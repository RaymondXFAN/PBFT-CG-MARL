#!/usr/bin/env python3
# 补充实验 + 主表 合并汇总（修正版：兼容两种目录布局）
import json, glob, os
import numpy as np

dirs = ["results/supplement", "results/n5_review", "results/env2_smac", "results/env3_lbf"]
labels = ["E1_mappo", "E1_hard", "E1_soft", "E2_matched",
          "E3_mappo_rand", "E3_hard_rand", "E3_soft_rand", "E3_hard_adv", "E3_soft_adv",
          "E3_mappo_adv", "E3f2_mappo", "E3f2_soft", "E3f2_hard",
          "VMAS_mappo", "VMAS_hard", "VMAS_soft",
          "ENV2_mappo", "ENV2_hard", "ENV2_soft",
          "ENV3_mappo", "ENV3_hard", "ENV3_soft"]

ALIAS = {
    "reward":  ["episode/episode_reward", "episode_reward"],
    "entropy": ["train/entropy", "entropy"],
    "cr":      ["episode/consensus_rate", "train/consensus_rate"],
    "kl":      ["train/kl_consensus_loss", "kl_consensus_loss"],
}

def pick(d, key):
    for k in ALIAS[key]:
        v = d.get(k)
        if isinstance(v, list) and len(v) > 0:
            return float(np.mean(v[-10:]))
    return None

def load(p):
    try:
        d = json.load(open(p))
    except Exception:
        return None
    r = pick(d, "reward")
    if r is None:
        return None
    return {k: pick(d, k) for k in ALIAS}

# 兼容两种布局：
#   补充: <dir>/<label>/seed_N/<algo>/seed_N/metrics.json
#   主表: <dir>/<label>/<algo>/seed_N/metrics.json
res = {}
for L in labels:
    rows = {}
    for rd in dirs:
        for p in glob.glob(os.path.join(rd, L, "**", "metrics.json"), recursive=True):
            try:
                s = int(p.split(os.sep)[-2].split("_")[1])
            except (IndexError, ValueError):
                continue
            m = load(p)
            if m:
                rows[s] = m
    res[L] = rows

print("=" * 96)
print(f"{'label':<16}{'n':>3}   {'reward (mean±std)':>20}  {'entropy':>8} {'CR':>7} {'kl':>8}   seeds")
print("-" * 96)
for L in labels:
    r = res[L]
    if not r:
        print(f"{L:<16}{0:>3}   无数据")
        continue
    ss = sorted(r)
    rw = np.array([r[s]["reward"] for s in ss])
    sd = rw.std(ddof=1) if len(ss) > 1 else 0.0
    def fmt(key):
        vals = [r[s][key] for s in ss if r[s][key] is not None]
        return f"{np.mean(vals):.4f}" if vals else "-"
    print(f"{L:<16}{len(ss):>3}   {rw.mean():9.1f} ± {sd:6.1f}   {fmt('entropy'):>8} {fmt('cr'):>7} {fmt('kl'):>8}   {ss}")
print("=" * 96)
