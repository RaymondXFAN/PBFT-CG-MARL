#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
N=5 实验结果收集脚本
===================
从 results/n5_review/*/metrics.json 提取关键指标，
生成汇总表格 (CSV + Markdown + 控制台输出)

用法:
  python scripts/collect_n5_results.py --log_dir results/n5_review
  python scripts/collect_n5_results.py --log_dir results/n5_review --format md
"""

import argparse
import json
import os
import numpy as np
from pathlib import Path
from collections import defaultdict


def load_metrics(log_dir: str) -> dict:
    """扫描所有实验目录，加载 metrics.json"""
    results = {}
    log_path = Path(log_dir)
    
    for exp_dir in sorted(log_path.iterdir()):
        if not exp_dir.is_dir():
            continue
        # 查找 metrics.json（可能在子目录中）
        for metrics_file in exp_dir.rglob("metrics.json"):
            try:
                with open(metrics_file) as f:
                    data = json.load(f)
                exp_name = exp_dir.name
                results[exp_name] = data
            except Exception as e:
                print(f"[WARN] 无法加载 {metrics_file}: {e}")
    
    return results


def extract_last_n(metrics: dict, key: str, n: int = 10) -> float:
    """取 metrics[key] 最后 n 个值的均值"""
    if key not in metrics:
        return float('nan')
    vals = metrics[key]
    if isinstance(vals, list):
        return float(np.mean(vals[-n:])) if len(vals) >= n else float(np.mean(vals))
    return float(vals)


def extract_final(metrics: dict, key: str) -> float:
    """取 metrics[key] 最后一个值"""
    if key not in metrics:
        return float('nan')
    vals = metrics[key]
    if isinstance(vals, list):
        return float(vals[-1])
    return float(vals)


def compute_summary(exp_name: str, metrics: dict) -> dict:
    """从 metrics.json 提取关键指标摘要"""
    return {
        "experiment": exp_name,
        "reward_last10": extract_last_n(metrics, "episode/episode_reward", 10),
        "reward_final": extract_final(metrics, "episode/episode_reward"),
        "entropy_final": extract_final(metrics, "train/entropy"),
        "consensus_rate_final": extract_final(metrics, "train/consensus_rate"),
        "value_loss_final": extract_final(metrics, "train/value_loss"),
        "policy_loss_final": extract_final(metrics, "train/policy_loss"),
        "kl_loss_final": extract_final(metrics, "train/kl_consensus_loss"),
    }


def collect_seeds(log_dir: str, exp_prefix: str) -> list:
    """收集同名实验（不同 seed）的结果"""
    log_path = Path(log_dir)
    summaries = []
    
    for exp_dir in sorted(log_path.iterdir()):
        if not exp_dir.is_dir() or not exp_dir.name.startswith(exp_prefix):
            continue
        for metrics_file in exp_dir.rglob("metrics.json"):
            try:
                with open(metrics_file) as f:
                    data = json.load(f)
                summaries.append(compute_summary(exp_dir.name, data))
            except:
                pass
    
    return summaries


def format_table(summaries: list, fmt: str = "md") -> str:
    """格式化输出表格"""
    if not summaries:
        return "(无数据)"
    
    # 按 experiment 分组
    by_exp = defaultdict(list)
    for s in summaries:
        by_exp[s["experiment"]].append(s)
    
    lines = []
    
    if fmt == "md":
        lines.append("| Experiment | Reward (last10) | Entropy (final) | CR (final) |")
        lines.append("|---|---|---|---|")
        for exp_name in sorted(by_exp.keys()):
            entries = by_exp[exp_name]
            rewards = [e["reward_last10"] for e in entries if not np.isnan(e["reward_last10"])]
            entropies = [e["entropy_final"] for e in entries if not np.isnan(e["entropy_final"])]
            crs = [e["consensus_rate_final"] for e in entries if not np.isnan(e["consensus_rate_final"])]
            
            if rewards:
                r_mean, r_std = np.mean(rewards), np.std(rewards)
                e_mean = np.mean(entropies) if entropies else float('nan')
                c_mean = np.mean(crs) if crs else float('nan')
                lines.append(f"| {exp_name} | {r_mean:.1f} ± {r_std:.1f} | {e_mean:.4f} | {c_mean:.2f} |")
            else:
                lines.append(f"| {exp_name} | — | — | — |")
    else:  # csv
        lines.append("experiment,seed,reward_last10,entropy_final,consensus_rate")
        for exp_name in sorted(by_exp.keys()):
            for i, entry in enumerate(by_exp[exp_name], 1):
                lines.append(f"{exp_name},{i},{entry['reward_last10']:.1f},{entry['entropy_final']:.4f},{entry['consensus_rate_final']:.2f}")
    
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="N=5 实验结果收集")
    parser.add_argument("--log_dir", type=str, default="results/n5_review")
    parser.add_argument("--format", type=str, default="md", choices=["md", "csv"])
    args = parser.parse_args()
    
    print(f"扫描目录: {args.log_dir}")
    results = load_metrics(args.log_dir)
    
    if not results:
        print("⚠️ 未找到任何 metrics.json")
        print("请确认实验已运行完毕，且 log_dir 正确")
        return
    
    # 逐实验摘要
    summaries = []
    for exp_name, data in sorted(results.items()):
        summaries.append(compute_summary(exp_name, data))
    
    # 输出表格
    output = format_table(summaries, args.format)
    print("\n" + "=" * 60)
    print("N=5 实验结果汇总")
    print("=" * 60)
    print(output)
    
    # 保存到文件
    out_file = os.path.join(args.log_dir, f"n5_results_summary.{args.format}")
    with open(out_file, "w") as f:
        f.write(output)
    print(f"\n已保存到: {out_file}")
    
    # 跨种子统计
    print("\n" + "=" * 60)
    print("跨种子统计（按实验前缀分组）")
    print("=" * 60)
    
    prefixes = sorted(set(s["experiment"].rsplit("_seed", 1)[0] if "_seed" in s["experiment"] 
                          else s["experiment"] for s in summaries))
    for prefix in prefixes:
        matching = [s for s in summaries if s["experiment"].startswith(prefix)]
        rewards = [s["reward_last10"] for s in matching if not np.isnan(s["reward_last10"])]
        if len(rewards) >= 2:
            print(f"  {prefix}: reward = {np.mean(rewards):.1f} ± {np.std(rewards):.1f} (n={len(rewards)})")
        elif rewards:
            print(f"  {prefix}: reward = {rewards[0]:.1f} (n=1)")


if __name__ == "__main__":
    main()
