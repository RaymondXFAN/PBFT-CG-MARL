#!/bin/bash
# ============================================================
# PBFT-CG-MARL 补充实验 —— 全自动串行编排（无人值守版）
# 顺序：A(E3缺角) → B(MPE补种) → D(n=7 f=2) → C(VMAS) → 汇总
# 无任何交互，可 nohup 后台跑一整晚。
#
# 启动：
#   cd /root/autodl-tmp/PBFT-CG-MARL
#   nohup bash run_all_serial.sh > logs/supplement/serial_master.log 2>&1 &
# 监控：
#   tail -f logs/supplement/serial_master.log
# ============================================================
PROJECT=/root/autodl-tmp/PBFT-CG-MARL
LOG=$PROJECT/logs/supplement
cd "$PROJECT" || exit 1
mkdir -p "$LOG"

MASTER=$LOG/serial_master.log
say() { echo "[$(date '+%F %T')] $*" | tee -a "$MASTER"; }

say "########## 串行编排开始 ##########"

# ---------------- 开跑前自检：拜占庭是否真的注入 ----------------
say "=====> 拜占庭注入自检（约 10 秒）"
PRE=$LOG/_preflight_byz.log
/root/miniconda3/bin/python -u src/train.py \
    --algo pbft_cg_mappo --env mpe_spread \
    --env_config "$PROJECT/configs/env/mpe_spread_n5.yaml" \
    --algo_config "$PROJECT/configs/algo/n5_soft_fair.yaml" \
    --seed 0 --n_timesteps 2000 --eval_interval 2000 --eval_episodes 1 \
    --gpu 0 --byzantine_n 1 --byzantine_type adversarial \
    --log_dir /tmp/_preflight_byz > "$PRE" 2>&1
if grep -qiE "inject|拜占庭" "$PRE"; then
    say "  拜占庭注入自检 ✅ 已看到注入痕迹"
    grep -iE "inject|拜占庭" "$PRE" | head -3 | tee -a "$MASTER"
else
    say "  ⚠️ 自检日志里没有注入痕迹（可能只是新版源码删了 print）"
    say "     已同时传命令行 --byzantine_n/--byzantine_type，攻击仍会生效；"
    say "     明早请核对 results/supplement/E3_mappo_adv 与 E1_mappo 的 reward 是否有差异。"
fi
say ""

for BATCH in mappo seeds f2 vmas; do
    say "=====> START  Batch $BATCH"
    bash run_supplement.sh "$BATCH" >> "$LOG/batch_${BATCH}.log" 2>&1
    RC=$?
    if [ $RC -ne 0 ]; then
        say "!!!!! Batch $BATCH 异常退出 (rc=$RC)，继续下一批（已完成的不受影响）"
    else
        say "=====> DONE   Batch $BATCH"
    fi
done

say "=====> 汇总结果"
bash run_supplement.sh results >> "$LOG/serial_results.log" 2>&1

# 收尾：打印完成统计
DONE_CNT=$(find "$PROJECT/results/supplement" -name metrics.json 2>/dev/null | wc -l)
say "########## 全部结束：共 $DONE_CNT 个 run 产出 metrics.json ##########"
say "汇总见：$LOG/serial_results.log"
