#!/bin/bash
# ============================================================
# PBFT-CG-MARL 补充实验 —— 5 分钟预检（对齐主表口径版 2026-09-10）
# ------------------------------------------------------------
# 主表口径：results/n5_review（scripts/run_n5_review.sh 生成）
#   E1_mappo  <- configs/algo/n5_mappo_fair.yaml
#   E1_hard   <- configs/algo/n5_hard_fair.yaml
#   E1_soft   <- configs/algo/n5_soft_fair.yaml
#   E2_matched<- configs/algo/n5_matched_logprob.yaml
#   环境      <- configs/env/mpe_spread_n5.yaml (n_agents=5)
#   拜占庭    <- YAML 里的 `byzantine:` 块（不是命令行参数！）
#
# 预检覆盖 6 条链路，任何一条 ❌ 都别开正式实验。
# 用法: bash scripts/verify_5min.sh 0
# ============================================================
PROJECT=/root/autodl-tmp/PBFT-CG-MARL
PY=/root/miniconda3/bin/python
GPU=${1:-0}
SHORT=5000
TMP=/tmp/pbft_verify

cd "$PROJECT" || { echo "找不到 $PROJECT"; exit 1; }
rm -rf "$TMP"; mkdir -p "$TMP"

echo "=========================================="
echo "  补充实验 5 分钟预检（对齐 n5_review 口径）"
echo "  PROJECT=$PROJECT  GPU=$GPU  步数=$SHORT"
echo "=========================================="

PASS=0; FAIL=0

# ---- 校验结果：真实路径 = <log_dir>/<algo>/seed_<N>/metrics.json ----
check() {
    local LABEL=$1 DIR=$2 ALGO=$3 SEED=$4
    local M="$DIR/$ALGO/seed_$SEED/metrics.json"
    if [ -f "$M" ]; then
        if $PY -c "import json,sys;d=json.load(open('$M'));k=[x for x in d if x.endswith('episode_reward')];sys.exit(0 if (k and len(d[k[0]])>0) else 1)" 2>/dev/null; then
            echo "  ✅ $LABEL    → $M"
            PASS=$((PASS+1)); return 0
        fi
        echo "  ❌ $LABEL —— metrics.json 里没有 episode_reward"
    else
        echo "  ❌ $LABEL —— 没生成 metrics.json"
        echo "     期望: $M"
    fi
    FAIL=$((FAIL+1)); return 1
}

# ---- 单次运行 ----
run() {   # $1=label $2=log_dir $3=algo $4=seed ; 其余 = train.py 参数
    local LABEL=$1 DIR=$2 ALGO=$3 SEED=$4
    shift 4
    local LOG=$TMP/${LABEL}.log
    echo "[$LABEL] 运行中 ..."
    rm -rf "$DIR"
    $PY -u src/train.py --algo "$ALGO" --seed "$SEED" \
        --n_timesteps $SHORT --eval_interval $SHORT --eval_episodes 3 \
        --gpu "$GPU" --log_dir "$DIR" "$@" > "$LOG" 2>&1
    tail -3 "$LOG" | sed 's/^/     /'
    check "$LABEL" "$DIR" "$ALGO" "$SEED"
    echo ""
}

echo "-------- [1/6] MPE n=5 + MAPPO（基线，主表 E1_mappo）--------"
run "MPE-mappo" $TMP/mappo mappo 99 \
    --env mpe_spread --env_config configs/env/mpe_spread_n5.yaml \
    --algo_config configs/algo/n5_mappo_fair.yaml

echo "-------- [2/6] MPE n=5 + Soft Consensus（主表 E1_soft）--------"
run "MPE-soft" $TMP/soft pbft_cg_mappo 99 \
    --env mpe_spread --env_config configs/env/mpe_spread_n5.yaml \
    --algo_config configs/algo/n5_soft_fair.yaml

echo "-------- [3/6] MPE n=5 + MAPPO + 拜占庭（Batch A，新配置）--------"
run "MPE-mappo-byz-adv" $TMP/byz mappo 99 \
    --env mpe_spread --env_config configs/env/mpe_spread_n5.yaml \
    --algo_config configs/algo/supp_mappo_byz_adv_n5.yaml

echo "   ↓ 拜占庭机制自检（YAML byzantine: 块是否真的被读取）"
if grep -qiE "byzantine|拜占庭|inject" "$TMP/MPE-mappo-byz-adv.log"; then
    echo "  ✅ 日志里出现拜占庭注入痕迹："
    grep -iE "byzantine|拜占庭|inject" "$TMP/MPE-mappo-byz-adv.log" | head -3 | sed 's/^/     /'
else
    echo "  ⚠️  日志里没有拜占庭注入痕迹！"
    echo "     说明 YAML 的 byzantine: 块可能没被读取，需要改用命令行 --byzantine_n/"
    echo "     --byzantine_type。请把这一行贴给 Mihiro。"
fi
echo ""

echo "-------- [4/6] VMAS uav_coverage（第二环境）--------"
run "VMAS-uav" $TMP/vmas pbft_cg_mappo 99 \
    --env vmas_uav_coverage --env_config configs/env/vmas_uav_coverage.yaml \
    --algo_config configs/algo/n5_hard_fair.yaml

echo "-------- [5/6] MPE n=7 + f=2 + 拜占庭（Batch D，新配置）--------"
run "MPE-n7-f2" $TMP/n7 pbft_cg_mappo 99 \
    --env mpe_spread --env_config configs/env/mpe_spread_n7.yaml \
    --algo_config configs/algo/supp_soft_byz2_adv_n7.yaml
echo "   ↓ 确认 f 读到了 2（应是 n=7, f=2）"
grep -o "f=[0-9]*" "$TMP/MPE-n7-f2.log" | head -3 | sed 's/^/     /'
echo ""

echo "-------- [6/6] MPE n=5 + Hard Mismatched（主表 E1_hard）--------"
run "MPE-hard" $TMP/hard pbft_cg_mappo 99 \
    --env mpe_spread --env_config configs/env/mpe_spread_n5.yaml \
    --algo_config configs/algo/n5_hard_fair.yaml

echo "=========================================="
echo "  预检结果:  ✅ $PASS   ❌ $FAIL"
echo "=========================================="
if [ "$FAIL" -eq 0 ]; then
    echo "全部通过，可以开跑正式实验。"
else
    echo "有失败项，请把 ❌ 那几行连同 6 段日志贴给 Mihiro。"
    echo "日志在: $TMP/*.log"
    exit 1
fi
