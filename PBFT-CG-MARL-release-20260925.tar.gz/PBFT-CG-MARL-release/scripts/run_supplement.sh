#!/bin/bash
# ============================================================
# PBFT-CG-MARL 补充实验 —— 统一启动脚本（对齐 n5_review 口径）
# v2 修正：拜占庭改为「YAML 块 + 命令行」双保险（预检发现 YAML 块没生效）
# ------------------------------------------------------------
# 用法:
#   bash run_supplement.sh verify   # 5 分钟预检
#   bash run_supplement.sh mappo    # Batch A: E3 缺角（MAPPO+adversarial, n=5）
#   bash run_supplement.sh seeds    # Batch B: MPE n=5 补种 5-8（4 方法）
#   bash run_supplement.sh f2       # Batch D: n=7 + f=2
#   bash run_supplement.sh vmas     # Batch C: VMAS 第二环境
#   bash run_supplement.sh results  # 汇总（补充 + 主表 n5_review）
#   bash run_all_serial.sh          # A→B→D→C 全自动串行（无人值守）
# ============================================================

PROJECT=/root/autodl-tmp/PBFT-CG-MARL
PY=/root/miniconda3/bin/python
RESULTS=$PROJECT/results/supplement
LOGS=$PROJECT/logs/supplement
mkdir -p "$RESULTS" "$LOGS"
cd "$PROJECT" || exit 1

# ---------------- 防重复启动（两个实例会让并发失控）----------------
LOCK=/tmp/run_supplement.lock
if [ -e "$LOCK" ] && kill -0 "$(cat "$LOCK" 2>/dev/null)" 2>/dev/null; then
    echo "!! 已有一个 run_supplement.sh 在运行 (PID=$(cat "$LOCK"))"
    echo "   同时开两个实例会让并发冲到 7-8，极易抢卡/OOM。"
    exit 1
fi
echo $$ > "$LOCK"
trap 'rm -f "$LOCK"' EXIT

# ---------------- 可调参数 ----------------
PARALLEL=4            # MPE 批并发（VMAS 批在 batch_c 里改成 2）
GPU=0
STEPS=300000          # 与主表一致
EVAL_INT=10000
EVAL_EP=10

SEEDS_A="1 2 3 4"                 # E3 缺角：与主表 4 seeds 对齐
SEEDS_MPE="5 6 7 8"               # MPE 补种（主表已有 1-4）
SEEDS_VMAS="1 2 3 4 5 6 7 8"      # 时间紧可改成 "1 2 3 4 5"
SEEDS_F2="1 2 3 4 5 6 7 8"

# ---------------- 拜占庭攻击（双保险：YAML 块 + 命令行）----------------
# 预检发现 YAML 的 byzantine: 块没有产生任何注入痕迹，故同时传命令行参数。
# 两条路径都指向同一批 agent，不会重复叠加。
BYZ1="--byzantine_n 1 --byzantine_type adversarial"
BYZ2="--byzantine_n 2 --byzantine_type adversarial"

# ---------------- 配置路径（全部复用主表 n5_review 口径）----------------
ENV_N5=configs/env/mpe_spread_n5.yaml
ENV_N7=configs/env/mpe_spread_n7.yaml
ENV_VMAS=configs/env/vmas_uav_coverage.yaml

CFG_MAPPO=configs/algo/n5_mappo_fair.yaml
CFG_SOFT=configs/algo/n5_soft_fair.yaml
CFG_HARD=configs/algo/n5_hard_fair.yaml
CFG_MATCHED=configs/algo/n5_matched_logprob.yaml

CFG_A_MAPPO=configs/algo/supp_mappo_byz_adv_n5.yaml
CFG_D_MAPPO=configs/algo/supp_mappo_byz2_adv_n7.yaml
CFG_D_SOFT=configs/algo/supp_soft_byz2_adv_n7.yaml
CFG_D_HARD=configs/algo/supp_hard_byz2_adv_n7.yaml

# ---------------- 工具函数 ----------------
log() { echo "[$(date +%H:%M:%S)] $*"; }

# 并发节流：按"当前实际在跑的 train.py 数量"控制，与方法数无关
throttle() { while [ "$(jobs -rp | wc -l)" -ge "$PARALLEL" ]; do sleep 10; done; }

run() {   # $1=algo $2=env $3=env_cfg $4=algo_cfg $5=seed $6=extra $7=label
    local ALGO=$1 ENV=$2 ENVCFG=$3 ACFG=$4 SEED=$5 EXTRA=$6 LABEL=$7
    local OUTDIR=$RESULTS/$LABEL/seed_$SEED
    mkdir -p "$OUTDIR"
    if [ -f "$OUTDIR/$ALGO/seed_$SEED/metrics.json" ]; then
        log "  [SKIP] $LABEL seed=$SEED（已完成）"
        return
    fi
    throttle
    nohup $PY -u src/train.py --algo "$ALGO" --env "$ENV" \
        --env_config "$PROJECT/$ENVCFG" \
        --algo_config "$PROJECT/$ACFG" \
        --seed "$SEED" --n_timesteps "$STEPS" --eval_interval "$EVAL_INT" \
        --eval_episodes "$EVAL_EP" --gpu "$GPU" $EXTRA \
        --log_dir "$OUTDIR" > "$LOGS/${LABEL}_s${SEED}.log" 2>&1 &
    log "  启动 $LABEL seed=$SEED (PID=$!)"
}

batch_verify() {
    log "=== 5 分钟预检 ==="
    bash "$PROJECT/scripts/verify_5min.sh" "$GPU"
    read -p "预检完成，继续正式实验？(y/n) " C
    [ "$C" = "y" ] || exit 0
}

# ---- Batch A：E3 缺角（MAPPO + adversarial, n=5, f=1）----
batch_a() {
    log "=== Batch A: MAPPO + adversarial（MPE n=5），seeds $SEEDS_A ==="
    local N=0
    for S in $SEEDS_A; do
        run mappo mpe_spread "$ENV_N5" "$CFG_A_MAPPO" $S "$BYZ1" "E3_mappo_adv"
        N=$((N+1)); (( N % PARALLEL == 0 )) && { wait; log "  [批次完成]"; }
    done
    wait
    log "Batch A 完成"
}

# ---- Batch B：MPE n=5 补种 5-8 ----
batch_b() {
    log "=== Batch B: MPE n=5 补种 $SEEDS_MPE（4 方法）==="
    for S in $SEEDS_MPE; do
        run mappo         mpe_spread "$ENV_N5" "$CFG_MAPPO" $S "" "E1_mappo"
        run pbft_cg_mappo mpe_spread "$ENV_N5" "$CFG_SOFT"  $S "" "E1_soft"
        run pbft_cg_mappo mpe_spread "$ENV_N5" "$CFG_HARD"  $S "" "E1_hard"
        wait; log "  [seed $S 三方法完成]"
        run pbft_cg_mappo mpe_spread "$ENV_N5" "$CFG_MATCHED" $S "" "E2_matched"
        wait; log "  [seed $S matched 完成]"
    done
    log "Batch B 完成"
}

# ---- Batch D：n=7 + f=2 ----
batch_d() {
    log "=== Batch D: MPE n=7 + f=2 + adversarial ==="
    local N=0
    for S in $SEEDS_F2; do
        run mappo         mpe_spread "$ENV_N7" "$CFG_D_MAPPO" $S "$BYZ2" "E3f2_mappo"
        run pbft_cg_mappo mpe_spread "$ENV_N7" "$CFG_D_SOFT"  $S "$BYZ2" "E3f2_soft"
        run pbft_cg_mappo mpe_spread "$ENV_N7" "$CFG_D_HARD"  $S "$BYZ2" "E3f2_hard"
        N=$((N+3)); (( N % PARALLEL == 0 )) && { wait; log "  [批次完成]"; }
    done
    wait
    log "Batch D 完成"
}

# ---- Batch C：VMAS 第二环境（并发降为 2）----
batch_c() {
    log "=== Batch C: VMAS uav_coverage（MAPPO / Hard / Soft）==="
    PARALLEL=2
    log "  [本批并发降为 $PARALLEL]"
    local N=0
    for S in $SEEDS_VMAS; do
        run mappo         vmas_uav_coverage "$ENV_VMAS" "$CFG_MAPPO" $S "" "VMAS_mappo"
        run pbft_cg_mappo vmas_uav_coverage "$ENV_VMAS" "$CFG_HARD"  $S "" "VMAS_hard"
        run pbft_cg_mappo vmas_uav_coverage "$ENV_VMAS" "$CFG_SOFT"  $S "" "VMAS_soft"
        N=$((N+3)); (( N % PARALLEL == 0 )) && { wait; log "  [批次完成]"; }
    done
    wait
    log "Batch C 完成"
}

batch_results() {
    log "=== 汇总（补充 + 主表 n5_review）==="
    $PY "$PROJECT/scripts/collect_results.py" \
        "$RESULTS" "$PROJECT/results/n5_review"
}

case "${1:-all}" in
    verify)  batch_verify ;;
    mappo)   batch_a ;;
    seeds)   batch_b ;;
    vmas)    batch_c ;;
    f2)      batch_d ;;
    results) batch_results ;;
    all)     batch_a; batch_b; batch_d; batch_c; batch_results ;;
    *)       echo "用法: bash run_supplement.sh {verify|mappo|seeds|f2|vmas|results|all}" ;;
esac
