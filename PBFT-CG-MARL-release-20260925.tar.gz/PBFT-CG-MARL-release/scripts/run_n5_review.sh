#!/bin/bash
# =============================================================
# PBFT-CG-MAPPO N=5 审稿回复实验（AutoDL, GPU）
# =============================================================
# 实验设计说明：
#   E1: 公平三路对比 (MAPPO / Hard / Soft, 统一 α=0.05)
#   E2: matched-logprob 因果对照 (审稿人1 致命缺陷#1)
#   E3: 拜占庭场景 (random + adversarial, f=1)
#
# 用法:
#   bash run_n5_review.sh 0            # 正式：4 seeds × 300K
#   bash run_n5_review.sh 0 --smoke    # 预检：1 seed × 50K（约8分钟）
#   bash run_n5_review.sh 0 E1         # 只跑 E1
#   bash run_n5_review.sh 0 E2         # 只跑 E2
#   bash run_n5_review.sh 0 E3         # 只跑 E3
# =============================================================
set -e

GPU_ID=${1:-0}
SMOKE=""
PHASE="ALL"

# 解析参数
shift 2>/dev/null || true
for arg in "$@"; do
  case $arg in
    --smoke) SMOKE="--smoke" ;;
    E1|E2|E3) PHASE=$arg ;;
  esac
done

if [ -n "$SMOKE" ]; then
  SEEDS="1"; N_STEPS=50000; EVAL_INT=5000; EVAL_EP=5
  echo ">>> 🧪 SMOKE 模式 (1 seed × 50K)"
else
  SEEDS="1 2 3 4"; N_STEPS=300000; EVAL_INT=10000; EVAL_EP=10
  echo ">>> 🏃 正式模式 (4 seeds × 300K)"
fi

# 目录设置
CODE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
LOG="${CODE_DIR}/results/n5_review"
ENV_CFG="${CODE_DIR}/configs/env/mpe_spread_n5.yaml"
ACFG="${CODE_DIR}/configs/algo"

mkdir -p "$LOG"

# ===== 通用运行函数 =====
run_exp() {
  local name=$1 algo=$2 algo_cfg=$3 extra=$4
  for S in $SEEDS; do
    echo ""
    echo "===== $name seed=$S ===== [$(date '+%H:%M:%S')]"
    python -u src/train.py \
      --algo $algo \
      --env mpe_spread \
      --env_config "$ENV_CFG" \
      --algo_config "$algo_cfg" \
      --seed $S \
      --n_timesteps $N_STEPS \
      --eval_interval $EVAL_INT \
      --eval_episodes $EVAL_EP \
      --log_dir "$LOG/$name" \
      --gpu $GPU_ID \
      $extra 2>&1 | tee "$LOG/${name}_seed${S}.log"
  done
}

# ===== E1: 公平三路对比 (α=0.05 固定) =====
if [ "$PHASE" = "ALL" ] || [ "$PHASE" = "E1" ]; then
  echo ""
  echo "########################################"
  echo "# E1: 公平三路对比 (N=5, α=0.05 固定)"
  echo "# 审稿人要求：所有方法统一熵系数配置"
  echo "########################################"
  run_exp "E1_mappo"  mappo           "$ACFG/n5_mappo_fair.yaml"
  run_exp "E1_hard"   pbft_cg_mappo   "$ACFG/n5_hard_fair.yaml"
  run_exp "E1_soft"   pbft_cg_mappo   "$ACFG/n5_soft_fair.yaml"
fi

# ===== E2: matched-logprob 因果对照 =====
if [ "$PHASE" = "ALL" ] || [ "$PHASE" = "E2" ]; then
  echo ""
  echo "########################################"
  echo "# E2: matched-logprob 因果对照"
  echo "# 审稿人1 致命缺陷#1: 核心因果论断缺乏关键对照"
  echo "# 假设: 若 matched 组熵崩塌缓解 → log-prob不匹配是根因 ✓"
  echo "#        若 matched 组仍崩塌 → 共识强约束本身致崩塌 ✗"
  echo "########################################"
  run_exp "E2_matched" pbft_cg_mappo "$ACFG/n5_matched_logprob.yaml"
fi

# ===== E3: 拜占庭场景 =====
if [ "$PHASE" = "ALL" ] || [ "$PHASE" = "E3" ]; then
  echo ""
  echo "########################################"
  echo "# E3: 拜占庭场景 (N=5, f=1)"
  echo "# 审稿人1 致命缺陷#3: 无拜占庭攻击实验验证"
  echo "# 5 agents, 1 Byzantine, 4 honest (PBFT n≥3f+1 → 5≥4 ✓)"
  echo "########################################"
  # Hard + Random Byzantine
  run_exp "E3_hard_rand" pbft_cg_mappo "$ACFG/n5_hard_byz_random.yaml"
  # Hard + Adversarial Byzantine
  run_exp "E3_hard_adv"  pbft_cg_mappo "$ACFG/n5_hard_byz_adversarial.yaml"
  # Soft + Random Byzantine
  run_exp "E3_soft_rand" pbft_cg_mappo "$ACFG/n5_soft_byz_random.yaml"
  # Soft + Adversarial Byzantine
  run_exp "E3_soft_adv"  pbft_cg_mappo "$ACFG/n5_soft_byz_adversarial.yaml"
  # MAPPO + Random Byzantine (no defense baseline)
  run_exp "E3_mappo_rand" mappo "$ACFG/n5_mappo_byz_random.yaml"
fi

# ===== 汇总 =====
echo ""
echo "========================================"
echo "✅ N=5 实验全部完成！"
echo "结果目录: $LOG"
echo ""
echo "运行结果收集:"
echo "  python scripts/collect_n5_results.py --log_dir $LOG"
echo "========================================"
