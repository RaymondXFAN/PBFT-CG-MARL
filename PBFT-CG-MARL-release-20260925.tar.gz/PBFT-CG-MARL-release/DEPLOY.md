# Deployment Guide — PBFT-CG-MARL

Step-by-step instructions for getting this repository running on a fresh GPU server.
Written for a Linux container (e.g. an AutoDL instance); adapt paths as needed.

---

## 0. TL;DR

```bash
# 1. Upload and extract the code
mkdir -p /root/autodl-tmp && tar -xzf PBFT-CG-MARL-release.tar.gz -C /root/autodl-tmp/
cd /root/autodl-tmp/PBFT-CG-MARL-release

# 2. Install dependencies
pip install -r requirements.txt

# 3. Pre-flight check (~5 min)
bash scripts/verify_5min.sh 0

# 4. Launch the main experiment set
nohup bash scripts/run_n5_review.sh > logs/n5_review.log 2>&1 &
```

---

## 1. Choose an instance

| Item | Recommendation |
|---|---|
| GPU | **RTX 4090 (24 GB)** — the configuration used for all reported results |
| Acceptable alternatives | Any CUDA GPU ≥ 8 GB (reduce concurrency accordingly) |
| Disk | ≥ 40 GB free on the data volume (`/root/autodl-tmp`) |
| Image | Any recent PyTorch image; **avoid reinstalling CUDA/torch** — the bundled versions already match |

> 💡 **Trick (AutoDL).** Start in *datacard-free (CPU) mode* to install the environment and
> download packages cheaply, then switch to *GPU mode* for training. Data survives the switch.

---

## 2. Set up the environment

```bash
conda create -n pbft python=3.10 -y
conda activate pbft

# PyTorch matching your driver (cu124 works with driver reporting CUDA 12.8)
pip install torch --index-url https://download.pytorch.org/whl/cu124

pip install numpy pyyaml tqdm matplotlib seaborn pandas wandb \
            "pettingzoo[mpe]>=1.24.0" gymnasium vmas
```

Check:

```bash
python -c "import torch; print(torch.__version__, torch.cuda.is_available())"
nvidia-smi   # should list your GPU
```

---

## 3. Upload the code

The archive has a single top-level directory, so extracting into the parent is safe:

```bash
mkdir -p /root/autodl-tmp
tar -xzf PBFT-CG-MARL-release.tar.gz -C /root/autodl-tmp/
cd /root/autodl-tmp/PBFT-CG-MARL-release
ls
```

**Always verify after copying** (silent failures are common):

```bash
ls -l src/train.py configs/env/mpe_spread_n5.yaml requirements.txt
```

---

## 4. Verify the installation

```bash
# Import check
python -c "import sys; sys.path.insert(0,'.'); from src.envs import ENV_REGISTRY; print(list(ENV_REGISTRY))"

# Tiny smoke run (~1 min, CPU is fine for this one)
python src/train.py --algo mappo --env mpe_spread \
    --env_config configs/env/mpe_spread_n5.yaml \
    --algo_config configs/algo/n5_mappo_fair.yaml \
    --seed 1 --n_timesteps 5000 --eval_interval 2500 --eval_episodes 2 \
    --log_dir results/_smoke

find results/_smoke -name metrics.json
```

A printed `metrics.json` path means the pipeline works end-to-end.

---

## 5. Pre-flight check (do not skip)

```bash
bash scripts/verify_5min.sh 0
# expected: "预检结果: ✅ N ❌ 0"
```

This covers data loading, a real forward/backward pass, and confirms that result files are
actually written — sparing you from discovering a broken run after hours.

Two lines deserve attention in the output:

- **Byzantine self-check** — should report that injection traces appear in the log.
- **`f` value check** — should read `f=2` for the `n=7` configs (if it reads `f=1`, the
  top-level `pbft_f` key was not picked up).

---

## 6. Run experiments

All launchers are **resumable** (completed seeds are skipped) and **throttled**
(concurrency is enforced by counting live `train.py` processes).

### Main review set (n = 5)

```bash
cd /root/autodl-tmp/PBFT-CG-MARL-release
nohup bash scripts/run_n5_review.sh > logs/n5_review.log 2>&1 &
```

### Supplemental + Table 4 (n = 7, f = 2)

```bash
nohup bash scripts/run_supplement.sh f2        > logs/supp_f2.log  2>&1 &   # 3 methods
nohup bash scripts/run_hard_matched.sh run     > logs/hard_matched.log 2>&1 &   # 4th cell
```

### Unattended full queue

```bash
nohup bash scripts/run_all_serial.sh > logs/serial_master.log 2>&1 &
```

| Batch | Typical wall-clock (4090, 4-way) |
|---|---|
| Main review set (n = 5, 300K steps, 8 seeds) | ≈ 3 h |
| Table 4, one method × 8 seeds | ≈ 1.5 h |
| VMAS batch (concurrency 2) | ≈ 7–8 h |

> ⚠️ **Run only one batch script at a time.** Each script locks `/tmp/<name>.lock`; two
> concurrent instances defeat throttling and can exhaust VRAM.

---

## 7. Monitor

```bash
# progress counters
find results -name metrics.json | wc -l
bash scripts/run_hard_matched.sh status

# live log (non-blocking)
tail -n 30 logs/hard_matched.log

# GPU
nvidia-smi --query-gpu=utilization.gpu,memory.used --format=csv

# running processes
pgrep -fa src/train.py

# stop everything
pkill -f "src/train.py"
```

---

## 8. Collect results

```bash
python scripts/collect_n5_results.py      # main tables
python scripts/collect_results.py         # supplemental
python scripts/statistical_analysis.py    # Welch t, Cohen's d, Hedges' g, MWU, 95% CI
```

Result files live at `<log_dir>/<algo>/seed_<N>/metrics.json` (note the double nesting).

---

## 9. Data

- **Simulation environments require no downloads** — `pettingzoo`, `vmas`, and
  `gymnasium` fetch everything at runtime.
- **`permafrost_monitoring`** uses real third-party data. If you enable it, obtain the
  dataset from the National Tibetan Plateau Data Center and pass credentials through
  **environment variables**:

  ```bash
  export TPDC_EMAIL="you@example.com"
  export TPDC_PWD="..."          # never write this into any file
  python scripts/download_tpdc.py
  unset TPDC_PWD
  ```

  Please also cite the data provider (see README §11).

---

## 10. Operational notes

- **Disk** — keep the data volume below ~85 %. Training logs and checkpoints accumulate
  quickly; purge `logs/` and stale `results/` before a long batch.
- **Shutdown vs. release** — *shutting down* an instance preserves the data volume;
  *releasing* it deletes everything. Never release a machine holding un-collected results.
- **Credentials** — passwords and tokens must go through environment variables only.
  They must never appear in source files, configs, shell history, or command lines.
- **Cross-machine moves** — migrate only what cannot be regenerated (code, configs,
  results). Model weights and caches can be re-downloaded.

---

## 11. Troubleshooting

| Symptom | Fix |
|---|---|
| `ModuleNotFoundError: src` | Run from the repository root, or add it to `PYTHONPATH` |
| `env_config` has no effect | Add `--env mpe_spread` (default `simple_spread` is unregistered) |
| `f` stuck at 1 | Put `pbft_f: 2` at the top level of the YAML, not nested |
| Results missing after "training complete" | Check `<log_dir>/<algo>/seed_<N>/metrics.json` |
| OOM / GPU thrashing | Reduce concurrency; ensure only one batch script is running |
| Byzantine injection not visible | Keep **both** the YAML `byzantine:` block and the CLI flags |
| `nvidia-smi` shows 0 % while running | Normal for MPE at small scale between eval points; confirm processes via `pgrep` |

---

*For project structure, algorithms, and configuration details, see
[`README.md`](README.md).*
