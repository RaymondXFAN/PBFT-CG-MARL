#!/bin/bash
# ============================================================
# E3 per-agent entropy 重跑（修复 Table 3 熵口径）
# ------------------------------------------------------------
# 目的：现有 metrics.json 只记 train/entropy（全体 agent 均值），无法还原
#       honest-only 熵（反推为负，见 STATS_2026-09-11.md 第 4 节）。
#       打上 patch_per_agent_entropy.py 后重跑 E3 六个条件，
#       得到 train/entropy_agent_0..N-1，即可精确算 honest-only 熵。
#
# 输出到 results/e3_peragent/，label 用 E3pa_* 前缀，
# 避免与 results/n5_review 的同名 label 冲突。
#
# 用法: bash run_e3_peragent.sh
# ============================================================
PROJECT=/root/autodl-tmp/PBFT-CG-MARL
PY=/root/miniconda3/bin/python
RESULTS=$PROJECT/results/e3_peragent
LOGS=$PROJECT/logs/e3_peragent
mkdir -p "$RESULTS" "$LOGS"
cd "$PROJECT" || exit 1

# ---- 并发守卫 ----
RUNNING=$(pgrep -fc "src/train.py" 2>/dev/null || echo 0)
if [ "$RUNNING" -gt 0 ]; then
    echo "!! 已有 $RUNNING 个 train.py 在运行，请等它结束后再执行（避免并发失控）。"
    exit 1
fi

PARALLEL=4
GPU=0
STEPS=${STEPS:-300000}
EVAL_INT=10000
EVAL_EP=10
SEEDS="1 2 3 4"     # 与论文 Table 3 的 4 seeds 对齐；想扩到 n=8 改成 "1 2 3 4 5 6 7 8"

ENV_CFG=configs/env/mpe_spread_n5.yaml

# label | algo | algo_config（逐字镜像主表 n5_review 的 E3 配置）
JOBS="
E3pa_hard_rand|pbft_cg_mappo|configs/algo/n5_hard_byz_random.yaml
E3pa_hard_adv|pbft_cg_mappo|configs/algo/n5_hard_byz_adversarial.yaml
E3pa_soft_rand|pbft_cg_mappo|configs/algo/n5_soft_byz_random.yaml
E3pa_soft_adv|pbft_cg_mappo|configs/algo/n5_soft_byz_adversarial.yaml
E3pa_mappo_rand|mappo|configs/algo/n5_mappo_byz_random.yaml
E3pa_mappo_adv|mappo|configs/algo/supp_mappo_byz_adv_n5.yaml
"

log() { echo "[$(date +%H:%M:%S)] $*"; }

# 并发节流：按"当前实际在跑的 train.py 数量"控制
throttle() { while [ "$(jobs -rp | wc -l)" -ge "$PARALLEL" ]; do sleep 10; done; }

run() {  # $1=algo $2=algo_cfg $3=seed $4=label
    local ALGO=$1 ACFG=$2 SEED=$3 LABEL=$4
    local OUTDIR=$RESULTS/$LABEL/seed_$SEED
    mkdir -p "$OUTDIR"
    if [ -f "$OUTDIR/$ALGO/seed_$SEED/metrics.json" ]; then
        log "  [SKIP] $LABEL seed=$SEED（已完成）"; return
    fi
    throttle
    nohup $PY -u src/train.py --algo "$ALGO" --env mpe_spread \
        --env_config "$PROJECT/$ENV_CFG" \
        --algo_config "$PROJECT/$ACFG" \
        --seed "$SEED" --n_timesteps "$STEPS" --eval_interval "$EVAL_INT" \
        --eval_episodes "$EVAL_EP" --gpu "$GPU" \
        --log_dir "$OUTDIR" > "$LOGS/${LABEL}_s${SEED}.log" 2>&1 &
    log "  启动 $LABEL seed=$SEED (PID=$!)"
}

log "=== E3 per-agent 重跑：6 条件 × seeds [$SEEDS] × ${STEPS} 步（并发 $PARALLEL）==="
N=0
for S in $SEEDS; do
    while IFS='|' read -r LBL ALGO ACFG; do
        [ -z "$LBL" ] && continue
        run "$ALGO" "$ACFG" "$S" "$LBL"
        N=$((N+1))
        (( N % PARALLEL == 0 )) && { wait; log "  [批次完成，累计 $N]"; }
    done <<< "$JOBS"
done
wait
log "E3 per-agent 重跑完成 → $RESULTS（共 $N 个 run）"
