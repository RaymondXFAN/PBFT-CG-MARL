#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PBFT-CG-MARL —— 实验结果逐 seed 导出脚本
=========================================
把 results/ 下所有 metrics.json 的关键指标提炼成小体积 CSV，
供代码仓库归档 / 论文附录核对 / 复现。

用法（在项目根目录，即能看到 src/ 和 results/ 的那一层）:

    python3 export_results.py                  # 默认：只出汇总表（很小）
    python3 export_results.py --full           # 额外导出每个 run 的最后 10 个原始点
    python3 export_results.py --root results   # 指定结果根目录（默认 results）

产出（脚本会在当前目录下新建 export_data/）:

    export_data/seeds_summary.csv      每个 run 一行：末 10 点均值
    export_data/per_agent_entropy.csv  每个 agent 一行（仅含 per-agent 日志的 run）
    export_data/seeds_tail10.csv       （--full）每个 run 的末 10 个原始点
    export_data/export_data.tar.gz     以上文件的打包（发这个给别人即可）

设计说明:
  * 只依赖 Python 标准库，不需要 numpy / pandas。
  * 遇到坏文件、缺字段自动跳过并在末尾汇总，不会中途崩。
  * 每个指标取「最后 10 个点」的均值 —— 与论文正文口径一致。
"""
import argparse
import csv
import glob
import json
import os
import shutil
import sys
import tarfile
from datetime import date

# ---- 需要提炼的指标（metrics.json 里的 key）----
SCALARS = [
    ("episode_reward",      "episode/episode_reward"),
    ("episode_length",      "episode/episode_length"),
    ("consensus_rate",      "episode/consensus_rate"),
    ("entropy_all",         "train/entropy"),
    ("consensus_loss",      "train/consensus_loss"),
    ("kl_consensus_loss",   "train/kl_consensus_loss"),
    ("policy_loss",         "train/policy_loss"),
    ("value_loss",          "train/value_loss"),
    ("entropy_coef",        "train/entropy_coef"),
    ("entropy_floor_pen",   "train/entropy_floor_penalty"),
    ("lr",                  "train/lr"),
]
TAIL = 10          # 最后 10 个点


def mean_last(v, n=TAIL):
    """末 n 点均值；不足 n 点则全用；非列表/空返回 None。"""
    if not isinstance(v, list) or not v:
        return None
    xs = [x for x in v[-n:] if isinstance(x, (int, float))]
    if not xs:
        return None
    return round(sum(xs) / len(xs), 6)


def parse_path(p, root):
    """从路径解析出 experiment / label / seed / algo。"""
    rel = os.path.relpath(p, root)
    segs = rel.replace("\\", "/").split("/")
    experiment = segs[0] if len(segs) > 1 else ""
    label = segs[1] if len(segs) > 2 else ""
    seed = ""
    for s in segs:
        if s.startswith("seed_"):
            try:
                seed = int(s.split("_", 1)[1]); break
            except ValueError:
                pass
    algo = segs[-3] if len(segs) >= 3 else ""
    return experiment, label, seed, algo


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="results", help="结果根目录（默认 results）")
    ap.add_argument("--full", action="store_true", help="额外导出末 10 个原始点")
    ap.add_argument("--out", default="export_data", help="输出目录（默认 export_data）")
    args = ap.parse_args()

    if not os.path.isdir(args.root):
        print(f"❌ 找不到结果目录: {args.root}")
        print("   请在项目根目录运行，或用 --root 指定正确路径。")
        sys.exit(1)

    files = sorted(glob.glob(os.path.join(args.root, "**", "metrics.json"), recursive=True))
    if not files:
        print(f"❌ {args.root} 下没有找到任何 metrics.json")
        sys.exit(1)
    print(f"发现 {len(files)} 个 metrics.json，开始解析…")

    os.makedirs(args.out, exist_ok=True)
    summary, agents, tails = [], [], []
    bad = []

    for p in files:
        try:
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
        except Exception as e:
            bad.append((p, str(e)[:60])); continue
        if not isinstance(d, dict):
            bad.append((p, "顶层不是 JSON 对象")); continue

        experiment, label, seed, algo = parse_path(p, args.root)
        row = {"experiment": experiment, "label": label, "seed": seed, "algo": algo,
               "n_episodes": len(d.get("episode/episode_reward") or [])}
        for name, key in SCALARS:
            row[name] = mean_last(d.get(key))
        # 逐 agent 熵（若有）
        ak = sorted([k for k in d if k.startswith("train/entropy_agent_")],
                    key=lambda k: int(k.rsplit("_", 1)[1]) if k.rsplit("_", 1)[1].isdigit() else 0)
        row["n_agents_logged"] = len(ak)
        if ak:
            vals = [mean_last(d[k]) for k in ak]
            vals = [v for v in vals if v is not None]
            row["entropy_honest_only"] = round(sum(vals[1:]) / len(vals[1:]), 6) if len(vals) > 1 else None
            for i, k in enumerate(ak):
                agents.append({"experiment": experiment, "label": label, "seed": seed,
                               "algo": algo, "agent_index": i, "entropy": mean_last(d[k])})
        else:
            row["entropy_honest_only"] = None
        row["path"] = p
        summary.append(row)

        if args.full:
            for name, key in SCALARS:
                v = d.get(key)
                if isinstance(v, list):
                    for j, x in enumerate(v[-TAIL:]):
                        tails.append({"experiment": experiment, "label": label, "seed": seed,
                                      "metric": name, "offset": j - len(v[-TAIL:]),
                                      "value": x})

    # ---- 写 CSV ----
    def write_csv(fname, rows):
        if not rows:
            return None
        fp = os.path.join(args.out, fname)
        cols = list(rows[0].keys())
        with open(fp, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=cols)
            w.writeheader(); w.writerows(rows)
        return fp

    made = [write_csv("seeds_summary.csv", summary)]
    if agents:
        made.append(write_csv("per_agent_entropy.csv", agents))
    if tails:
        made.append(write_csv("seeds_tail10.csv", tails))
    made = [m for m in made if m]

    # ---- 汇总 ----
    labels = sorted({(r["experiment"], r["label"]) for r in summary})
    print(f"\n✅ 解析成功 {len(summary)} 个 run，覆盖 {len(labels)} 个实验标签：")
    for e, l in labels:
        n = sum(1 for r in summary if r["experiment"] == e and r["label"] == l)
        print(f"     {e}/{l:<34} {n} seeds")
    if bad:
        print(f"\n⚠️  {len(bad)} 个文件解析失败（已跳过）：")
        for p, e in bad[:10]:
            print(f"     {p}  → {e}")
    if agents:
        print(f"\n   含 per-agent 熵日志的 run: {len({(r['experiment'],r['label'],r['seed']) for r in agents})}")

    # ---- 打包 ----
    tgz = os.path.join(args.out, "export_data.tar.gz")
    with tarfile.open(tgz, "w:gz") as t:
        for m in made:
            t.add(m, arcname=os.path.basename(m))
    size = os.path.getsize(tgz)
    print(f"\n📦 已打包: {tgz}  ({size/1024:.1f} KB)")
    for m in made:
        print(f"     {os.path.basename(m):<24} {os.path.getsize(m)/1024:.1f} KB")
    print("\n把 export_data.tar.gz 发回即可。")


if __name__ == "__main__":
    main()
