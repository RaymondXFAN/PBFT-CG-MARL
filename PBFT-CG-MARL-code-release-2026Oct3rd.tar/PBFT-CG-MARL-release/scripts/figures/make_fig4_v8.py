#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Figure 4（Byzantine tolerance）重绘 —— 加入 Hard Cons. (Matched)。
2×2 布局：
  (a) f=1, n=5  Episode reward（4 方法 × {Random, Adversarial}）
  (b) f=1, n=5  All-agent entropy
  (c) f=1, n=5  Honest-agent-only entropy
  (d) f=2, n=7  Episode reward
输出：Figure_4_Captain_Y.png (300 dpi) + .pdf
排版：所有文字 ≥12 pt；莫兰迪低饱和配色；图内不写总标题。
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["DejaVu Serif"],
    "mathtext.fontset": "dejavuserif",
    "font.size": 12,
    "axes.labelsize": 13,
    "axes.titlesize": 13,
    "xtick.labelsize": 12,
    "ytick.labelsize": 12,
    "legend.fontsize": 12,
    "axes.linewidth": 0.9,
    "axes.grid": False,
    "xtick.direction": "out",
    "ytick.direction": "out",
    "figure.dpi": 300,
    "savefig.dpi": 300,
})

METHODS = ["mappo", "mism", "matched", "soft"]
COLOR = {"mappo": "#8E7CC3", "mism": "#7FAF7F", "matched": "#C3A36B", "soft": "#4A7C96"}
LEGEND = {"mappo": "MAPPO", "mism": "Hard (Mismatched)",
          "matched": "Hard (Matched)", "soft": "Soft (Ours)"}
TICK = {"mappo": "MAPPO", "mism": "Hard\n(Mismatch.)",
        "matched": "Hard\n(Matched)", "soft": "Soft\n(Ours)"}
FAULTS = ["Random", "Adversarial"]

# ---------------- 数据（论文 Table 3 / Table 4，mean ± std） ----------------
rew_f1 = {
    "Random":      {"mappo": (-44.9, 7.1),  "mism": (-48.1, 7.5),  "matched": (-52.0, 8.2),  "soft": (-48.0, 4.5)},
    "Adversarial": {"mappo": (-65.3, 16.8), "mism": (-52.5, 6.7),  "matched": (-59.1, 24.0), "soft": (-56.8, 5.5)},
}
allent_f1 = {
    "Random":      {"mappo": (0.379, 0.025), "mism": (0.353, 0.098), "matched": (0.062, 0.010), "soft": (0.070, 0.020)},
    "Adversarial": {"mappo": (0.187, 0.068), "mism": (0.367, 0.042), "matched": (0.107, 0.066), "soft": (0.204, 0.225)},
}
honent_f1 = {
    "Random":      {"mappo": (0.071, 0.032), "mism": (0.097, 0.053), "matched": (0.058, 0.027), "soft": (0.088, 0.025)},
    "Adversarial": {"mappo": (0.117, 0.141), "mism": (0.062, 0.054), "matched": (0.134, 0.083), "soft": (0.255, 0.281)},
}
rew_f2 = {"mappo": (-69.2, 12.2), "mism": (-55.2, 5.0), "matched": (-61.5, 11.1), "soft": (-68.5, 15.4)}

W = 0.19          # 柱宽
OFF = np.array([-1.5, -0.5, 0.5, 1.5]) * W   # 4 根柱的偏移


def grouped(ax, data, ylabel, ylim, tag, zero_line=False):
    """data: {fault: {method: (mean, std)}}"""
    for i, f in enumerate(FAULTS):
        for j, m in enumerate(METHODS):
            mu, sd = data[f][m]
            ax.bar(i + OFF[j], mu, W, yerr=sd, color=COLOR[m], edgecolor="black",
                   linewidth=0.6, capsize=3, error_kw=dict(elinewidth=0.9, capthick=0.9),
                   label=LEGEND[m] if i == 0 else None, zorder=3)
    ax.set_xticks(range(len(FAULTS)))
    ax.set_xticklabels(FAULTS)
    ax.set_ylabel(ylabel)
    ax.set_ylim(*ylim)
    ax.axhline(0 if zero_line else 0, color="black", linewidth=0.8, zorder=2)
    if not zero_line:
        ax.set_ylim(bottom=0)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.text(-0.13, 1.02, tag, transform=ax.transAxes, fontsize=13, fontweight="bold",
            va="bottom", ha="left")


def single(ax, data, ylabel, ylim, tag):
    xs = range(len(METHODS))
    for j, m in enumerate(METHODS):
        mu, sd = data[m]
        ax.bar(j, mu, 0.62, yerr=sd, color=COLOR[m], edgecolor="black", linewidth=0.6,
               capsize=3, error_kw=dict(elinewidth=0.9, capthick=0.9), zorder=3)
    ax.set_xticks(list(xs))
    ax.set_xticklabels([TICK[m] for m in METHODS])
    ax.set_ylabel(ylabel)
    ax.set_ylim(*ylim)
    ax.axhline(0, color="black", linewidth=0.8, zorder=2)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.text(-0.13, 1.02, tag, transform=ax.transAxes, fontsize=13, fontweight="bold",
            va="bottom", ha="left")


fig, axes = plt.subplots(2, 2, figsize=(12.4, 8.6))
grouped(axes[0, 0], rew_f1, "Episode reward", (-105, 5), "(a)  $f=1$,  $n=5$", zero_line=True)
grouped(axes[0, 1], allent_f1, "Entropy (all agents)", (0, 0.47), "(b)  $f=1$,  $n=5$")
grouped(axes[1, 0], honent_f1, "Entropy (honest only)", (0, 0.62), "(c)  $f=1$,  $n=5$")
single(axes[1, 1], rew_f2, "Episode reward", (-95, 5), "(d)  $f=2$,  $n=7$")

h, l = axes[0, 0].get_legend_handles_labels()
fig.legend(h, l, loc="upper center", ncol=4, frameon=True, framealpha=0.95,
           bbox_to_anchor=(0.5, 1.0), borderpad=0.6, handlelength=1.6, columnspacing=2.0)
fig.tight_layout(rect=(0, 0, 1, 0.945))

import os
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
os.makedirs(OUT, exist_ok=True)
for ext in ("png", "pdf"):
    for name in (f"fig4_byzantine_v8.{ext}", f"Figure_4_Captain_Y.{ext}"):
        fig.savefig(os.path.join(OUT, name), bbox_inches="tight", facecolor="white")
        print("saved", os.path.join(OUT, name))
print("done")
