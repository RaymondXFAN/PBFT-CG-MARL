#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Figure 2 生成器 —— 读熵曲线 JSON，出「熵 vs 训练步数」图。

输入 JSON 形如:
  {"soft":{"n":8,"mean":[...30个数...],"sd":[...30个数...]},
   "mism":{...},"matched":{...},"mappo":{...}}

用法:  python3 fig2_from_series.py [series.json]
产出:  figures_paper/fig3_entropy_dynamics.{png,pdf}
"""
import json
import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.abspath(__file__))
SER = sys.argv[1] if len(sys.argv) > 1 else "entropy_series.json"
OUT = os.path.join(ROOT, "figures_paper")
os.makedirs(OUT, exist_ok=True)

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["DejaVu Serif"],
    "mathtext.fontset": "dejavuserif", "font.size": 9, "axes.linewidth": 0.8,
    "axes.grid": False, "xtick.direction": "out", "ytick.direction": "out",
    "legend.frameon": True, "legend.framealpha": 0.9, "figure.dpi": 300, "savefig.dpi": 300,
})
C = {"soft": "#4A7C96", "mism": "#7FAF7F", "matched": "#C3A36B", "mappo": "#8E7CC3"}
LS = {"soft": "-", "mism": (0, (6, 3)), "matched": (0, (7, 2, 1.5, 2)), "mappo": (0, (1, 1.5))}
NAME = {"soft": "Soft Consensus (Ours)", "mism": "Hard Cons. (Mismatched)",
        "matched": "Hard Cons. (Matched)", "mappo": "MAPPO Baseline"}
ORDER = ["soft", "mism", "mappo", "matched"]
STEPS = 300_000

d = json.load(open(SER if os.path.isabs(SER) else os.path.join(ROOT, SER)))
fig, ax = plt.subplots(figsize=(4.6, 3.2))
# 崩塌区 = 熵floor 以下（0 ~ 0.05）；健康变体稳定在 ~0.10，不应落在该区内
ax.axhspan(0, 0.05, color="#F3DCD8", alpha=0.6, zorder=0, label="below entropy floor")
ax.axhline(0.05, color="#A93226", lw=0.9, linestyle=(0, (4, 2)), zorder=1)
ax.annotate(r"entropy floor $\theta=0.05$", xy=(0.985, 0.05),
            xycoords=("axes fraction", "data"), ha="right", va="bottom",
            fontsize=7, color="#A93226", zorder=6)

HMAX = 1.6094          # ln 5 —— 5 个离散动作下的均匀策略熵（所有 run 的首值都是它）
for k in ORDER:
    if k not in d:
        print(f"  ⚠️ 缺少 {k}"); continue
    m = np.asarray(d[k]["mean"], float)
    s = np.asarray(d[k].get("sd") or np.zeros_like(m), float)
    nb = m.size
    x = (np.arange(nb) + 0.5) * (STEPS / 1000 / nb)   # 桶中心
    n = max(1, d[k].get("n", 1))
    ax.plot(x, m, color=C[k], ls=LS[k], lw=1.6, label=f"{NAME[k]} (n={d[k].get('n','?')})", zorder=3)
    ax.fill_between(x, m - 1.96 * s / np.sqrt(n), m + 1.96 * s / np.sqrt(n),
                    color=C[k], alpha=0.16, lw=0, zorder=2)

ax.axhline(HMAX, color="#7F7F7F", lw=0.8, linestyle=(0, (2, 2)), zorder=1)
ax.annotate(r"uniform policy: $\ln 5 = 1.61$", xy=(0.012, HMAX),
            xycoords=("axes fraction", "data"), ha="left", va="bottom",
            fontsize=6.5, color="#5A5A5A", zorder=6)

ax.set_xlabel("Training steps ($\\times 10^3$)")
ax.set_ylabel("Policy entropy (nats)")
ax.set_xlim(0, STEPS / 1000)
ax.set_ylim(0, HMAX * 1.12)
ax.legend(loc="upper right", fontsize=6.2, handlelength=1.9, borderpad=0.35, labelspacing=0.35)
fig.tight_layout()
fig.savefig(f"{OUT}/fig3_entropy_dynamics.pdf")
fig.savefig(f"{OUT}/fig3_entropy_dynamics.png")
plt.close(fig)
print(f"[OK] fig3_entropy_dynamics  →  {OUT}")
