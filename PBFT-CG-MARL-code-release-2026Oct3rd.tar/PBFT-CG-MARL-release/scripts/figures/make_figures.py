#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PBFT-CG-MARL 论文配图重绘（v7）—— 全部用真实实验数据。

用法（项目根目录）:
    python3 make_figures.py
输出:
    figures_v7/fig1..fig5 .pdf + .png   （PDF 投稿用，PNG 供预览）
    figures_v7/aggregates.json          （汇总数字，供核对）

图目录（与 paper_v6_3 正文引用一致）:
    Fig 1  条件化机制示意（multiplicative vs additive）—— 无数据
    Fig 2  干净设置熵曲线（4 方法 × 8 seeds，mean ± 95% CI）← 正文 Figure 2
    Fig 3  干净设置性能与熵（4 方法 × 8 seeds）           ← 正文 Figure 3
    Fig 4  拜占庭容错：f=1（Table 3）与 f=2（Table 4）
    Fig 5  跨任务迁移（Table 5）+ 三条设计准则           ← 正文 Figure 5

排版约定（v2 修正）：所有注释文字放在「预留行」里，不与方框/箭头重叠。
"""
import os
import json
import glob
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(ROOT, "figures_v7")
os.makedirs(OUT, exist_ok=True)
STEPS = 300_000

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["DejaVu Serif"],
    "mathtext.fontset": "dejavuserif",
    "font.size": 9,
    "axes.linewidth": 0.8,
    "axes.grid": False,
    "xtick.direction": "out",
    "ytick.direction": "out",
    "legend.frameon": True,
    "legend.framealpha": 0.9,
    "figure.dpi": 300, "savefig.dpi": 300,
})

C = {"mappo": "#8E7CC3", "mism": "#7FAF7F", "matched": "#C3A36B", "soft": "#4A7C96"}
LS = {"mappo": (0, (1, 1.5)), "mism": (0, (6, 3)), "matched": (0, (7, 2, 1.5, 2)), "soft": "-"}
NAME = {"mappo": "MAPPO Baseline", "mism": "Hard Cons. (Mismatched)",
        "matched": "Hard Cons. (Matched)", "soft": "Soft Consensus (Ours)"}
ORDER = ["soft", "mism", "matched", "mappo"]
SHORT = {"mappo": "MAPPO", "mism": "Hard\n(Mismatch.)", "soft": "Soft\n(Ours)"}
AGG = {}


# ---------------------------------------------------------------- 数据读取
def runs(label):
    """找到 label 的所有 seed run；兼容主表与补充包两种目录层级。"""
    out = {}
    for p in glob.glob(f"{ROOT}/results/**/{label}/**/metrics.json", recursive=True):
        seg = p.split(os.sep)[-2]
        if not seg.startswith("seed_"):
            continue
        try:
            s = int(seg.split("_")[1])
        except (IndexError, ValueError):
            continue
        out.setdefault(s, p)
    return out


def load(label):
    res = {}
    for s, p in sorted(runs(label).items()):
        try:
            res[s] = json.load(open(p))
        except Exception as e:
            print(f"  ⚠️ {label} seed {s} 读取失败: {e}")
    return res


def last10(d, key):
    v = d.get(key)
    if not isinstance(v, list) or not v:
        return None
    return float(np.mean(v[-10:]))


def honest(d, byz=1):
    ks = sorted([k for k in d if k.startswith("train/entropy_agent_")],
                key=lambda k: int(k.rsplit("_", 1)[1]))
    a = [last10(d, k) for k in ks]
    a = [x for x in a if x is not None][byz:]
    return float(np.mean(a)) if a else None


def curve(arr, nbin=40):
    a = np.asarray(arr, float)
    if a.size == 0:
        return None
    idx = np.linspace(0, a.size, nbin + 1).astype(int)
    return np.array([a[idx[i]:max(idx[i] + 1, idx[i + 1])].mean() for i in range(nbin)])


def ms(vals):
    a = np.array([v for v in vals if v is not None], float)
    if a.size == 0:
        return (None, None, 0)
    sd = a.std(ddof=1) if a.size > 1 else 0.0
    return (float(a.mean()), float(sd), a.size)


def bars(ax, xs, means, sds, colors, width=0.62):
    ax.bar(xs, means, width, color=colors, edgecolor="black", linewidth=0.6,
           yerr=sds, capsize=2.5, error_kw=dict(lw=0.7), zorder=2)


def dots(ax, x, vals, dx):
    a = np.array([v for v in vals if v is not None], float)
    if a.size == 0:
        return
    jit = np.linspace(-dx * 0.30, dx * 0.30, a.size)
    ax.scatter(x + jit, a, s=6, color="black", alpha=0.45, zorder=3, linewidths=0)


def finish(fig, name):
    if fig.get_layout_engine() is None:      # constrained 布局的图不要再调 tight_layout
        try:
            fig.tight_layout()
        except Exception:
            pass
    for ext in ("pdf", "png"):
        fig.savefig(f"{OUT}/{name}.{ext}")
    plt.close(fig)
    print(f"[OK] {name}")


# ================================================================ Fig 1 机制示意
def fig1():
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.0))
    for ax, kind in zip(axes, ["mult", "add"]):
        mult = (kind == "mult")
        tcol = "#B03A2E" if mult else "#1F618D"
        ax.set_xlim(0, 10); ax.set_ylim(0, 7.2); ax.axis("off")
        # —— 预留行：标题 / 副题（均在方框上方）——
        ax.text(5.0, 7.10, "(a) Multiplicative conditioning" if mult
                else "(b) Additive conditioning", ha="center", va="top", fontsize=9.5)
        ax.text(5.0, 6.52, "action replacement, irreversible" if mult
                else "action never replaced", ha="center", va="top", fontsize=8, color=tcol)
        # 上方两个方框 y ∈ [4.5, 6.0]
        ax.add_patch(FancyBboxPatch((0.5, 4.5), 3.6, 1.5, boxstyle="round,pad=0.10",
                                    fc="#E8F0F5", ec="black", lw=0.8))
        ax.text(2.3, 5.55, r"policy $\pi_\theta(a\mid o)$", ha="center", va="center", fontsize=8.5)
        ax.text(2.3, 4.95, r"sampled action $a_i$", ha="center", va="center", fontsize=7.5)
        ax.add_patch(FancyBboxPatch((5.9, 4.5), 3.6, 1.5, boxstyle="round,pad=0.10",
                                    fc="#F5F5F5", ec="black", lw=0.8))
        ax.text(7.7, 5.55, "PBFT consensus", ha="center", va="center", fontsize=8.5)
        ax.text(7.7, 4.95, r"agreed action $a^*$", ha="center", va="center", fontsize=7.5)
        ax.add_patch(FancyArrowPatch((4.25, 5.25), (5.75, 5.25), arrowstyle="->",
                                     mutation_scale=11, lw=0.9))
        # 下方方框 y ∈ [2.3, 3.6]
        ax.add_patch(FancyBboxPatch((3.0, 2.3), 4.0, 1.3, boxstyle="round,pad=0.10",
                                    fc="#FDF3F2" if mult else "#EAF3F8", ec=tcol, lw=0.9))
        ax.text(5.0, 3.32, r"executed action $:=a^*$" if mult
                else r"objective $+\;\alpha\,\mathrm{KL}(\pi_\theta \,\|\, a^*)$",
                ha="center", va="center", fontsize=8.5, color=tcol)
        ax.text(5.0, 2.62, "action replaced" if mult
                else "additive term, zero-initialized", ha="center", va="center", fontsize=7.5)
        ax.add_patch(FancyArrowPatch((7.0, 4.45), (6.0, 3.65), arrowstyle="->",
                                     mutation_scale=11, lw=0.9, color=tcol))
        if mult:   # 反馈环：从下方方框外侧回到 policy 方框
            ax.add_patch(FancyArrowPatch((3.0, 2.95), (1.25, 4.55), arrowstyle="->",
                                         mutation_scale=11, lw=1.3, color=tcol,
                                         connectionstyle="arc3,rad=0.35"))
        # —— 预留行：结论（y ≤ 1.8，远离所有图形）——
        ax.text(5.0, 1.78, r"PPO gradient at $\log\pi(a^*)$" if mult
                else r"PPO gradient at $\log\pi(a_i)$",
                ha="center", va="center", fontsize=8, color=tcol)
        ax.text(5.0, 1.05, "agreement pressure grows without bound" if mult
                else "bounded influence, gradient stays consistent",
                ha="center", va="center", fontsize=7.5, style="italic", color="#444444")
    finish(fig, "fig1_conditioning")


# ================================================================ Fig 2 熵曲线
def fig2():
    fig, ax = plt.subplots(figsize=(4.6, 3.2))
    ax.axhspan(0.05, 0.15, color="#F3DCD8", alpha=0.55, zorder=0,
               label="Entropy collapse zone")
    ax.axhline(0.05, color="#A93226", lw=0.9, linestyle=(0, (4, 2)), zorder=1)
    ax.text(STEPS * 0.985, 0.055, r"$\theta=0.05$ (floor)", ha="right", va="bottom",
            fontsize=7, color="#A93226")
    LAB = {"soft": "E1_soft", "mism": "E1_hard", "matched": "E2_matched", "mappo": "E1_mappo"}
    plotted, ymax = 0, 0.2
    for k in ORDER:
        d = load(LAB[k])
        cs = [curve(x.get("train/entropy")) for x in d.values()]
        cs = [c for c in cs if c is not None]
        if not cs:
            print(f"  ⚠️ fig2: {k} 无曲线数据")
            continue
        M = np.vstack(cs); m, n = M.mean(0), M.shape[0]
        se = M.std(0, ddof=1) / np.sqrt(n) if n > 1 else np.zeros_like(m)
        x = np.linspace(0, STEPS / 1000, m.size)
        ax.plot(x, m, color=C[k], ls=LS[k], lw=1.6, label=NAME[k], zorder=3)
        ax.fill_between(x, m - 1.96 * se, m + 1.96 * se, color=C[k], alpha=0.16, lw=0, zorder=2)
        plotted += 1
        ymax = max(ymax, float(np.max(m + 1.96 * se)))
        AGG.setdefault("fig2_initial_entropy", {})[k] = round(float(m[0]), 4)
        AGG.setdefault("fig2_final_entropy", {})[k] = round(float(m[-1]), 4)
        AGG.setdefault("fig2_nseeds", {})[k] = n
    if plotted == 0:
        print("  ❌ fig2 无数据，跳过"); plt.close(fig); return
    ax.set_xlabel("Training steps ($\\times 10^3$)")
    ax.set_ylabel("Policy entropy (nats)")
    ax.set_xlim(0, STEPS / 1000); ax.set_ylim(0, ymax * 1.12)
    ax.legend(loc="upper right", fontsize=7, handlelength=2.4)
    finish(fig, "fig2_entropy_dynamics")


# ================================================================ Fig 3 干净性能
def fig3():
    LAB = {"mappo": "E1_mappo", "mism": "E1_hard", "matched": "E2_matched", "soft": "E1_soft"}
    xs, rw, rs, ew, es, rv, ev = [], [], [], [], [], [], []
    for i, k in enumerate(ORDER):
        d = load(LAB[k])
        r = [last10(x, "episode/episode_reward") for x in d.values()]
        e = [last10(x, "train/entropy") for x in d.values()]
        rm, rsd, n = ms(r); em, esd, _ = ms(e)
        if rm is None:
            continue
        xs.append(i); rw.append(rm); rs.append(rsd); ew.append(em); es.append(esd)
        rv.append(r); ev.append(e)
        AGG.setdefault("fig3", {})[k] = dict(reward=[round(rm, 2), round(rsd, 2), n],
                                             entropy=[round(em, 4), round(esd, 4)])
    if not xs:
        print("  ❌ fig3 无数据，跳过"); return
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9), layout="constrained")
    cols = [C[ORDER[i]] for i in xs]
    for ax, w, s, v, ylab, ttl in [
            (axes[0], rw, rs, rv, "Episode reward", "(a) Task performance"),
            (axes[1], ew, es, ev, "Entropy (nats)", "(b) Final entropy")]:
        bars(ax, xs, w, s, cols)
        for x, vv in zip(xs, v):
            dots(ax, x, vv, 0.62)
        ax.set_xticks(xs)
        ax.set_xticklabels([NAME[ORDER[i]].replace(" (", "\n(") for i in xs], fontsize=6.5)
        ax.set_ylabel(ylab); ax.set_title(ttl, fontsize=9); ax.margins(y=0.20)
    finish(fig, "fig3_clean_performance")


# ================================================================ Fig 4 拜占庭
def fig4():
    keys = ["mappo", "mism", "soft"]
    groups = [("Random", "E3pa_mappo_rand", "E3pa_hard_rand", "E3pa_soft_rand"),
              ("Adversarial", "E3pa_mappo_adv", "E3pa_hard_adv", "E3pa_soft_adv")]
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.8), layout="constrained")
    xs = np.arange(len(groups))
    for j, (k, lab) in enumerate(zip(keys, keys)):
        m, s = [], []
        for _, lm, lh, ls in groups:
            d = load(dict(zip(keys, [lm, lh, ls]))[k])
            mm, sd, _ = ms([last10(x, "episode/episode_reward") for x in d.values()])
            m.append(mm if mm is not None else np.nan); s.append(sd or 0)
        bars(axes[0], xs + (j - 1) * 0.26, m, s, [C[lab]] * len(xs), width=0.24)
        AGG.setdefault("fig4_f1_reward", {})[lab] = [None if np.isnan(v) else round(v, 2) for v in m]
        m2, s2 = [], []
        for _, lm, lh, ls in groups:
            d = load(dict(zip(keys, [lm, lh, ls]))[k])
            mm, sd, _ = ms([honest(x) for x in d.values()])
            m2.append(mm if mm is not None else np.nan); s2.append(sd or 0)
        bars(axes[1], xs + (j - 1) * 0.26, m2, s2, [C[lab]] * len(xs), width=0.24)
        AGG.setdefault("fig4_f1_honest", {})[lab] = [None if np.isnan(v) else round(v, 4) for v in m2]
    for ax, ylab, ttl in [(axes[0], "Episode reward", "(a) $f=1$, $n=5$"),
                          (axes[1], "Honest entropy", "(b) $f=1$, honest agents")]:
        ax.set_xticks(xs); ax.set_xticklabels([g[0] for g in groups], fontsize=7)
        ax.set_ylabel(ylab); ax.set_title(ttl, fontsize=9); ax.margins(y=0.22)
    m, s = [], []
    for k, L in zip(keys, ["E3f2_mappo", "E3f2_hard", "E3f2_soft"]):
        d = load(L)
        mm, sd, n = ms([last10(x, "episode/episode_reward") for x in d.values()])
        m.append(mm if mm is not None else np.nan); s.append(sd or 0)
        AGG.setdefault("fig4_f2_reward", {})[k] = [None if mm is None else round(mm, 2),
                                                   None if sd is None else round(sd, 2), n]
    bars(axes[2], np.arange(3), m, s, [C[k] for k in keys], width=0.5)
    axes[2].set_xticks(np.arange(3)); axes[2].set_xticklabels([SHORT[k] for k in keys], fontsize=7)
    axes[2].set_ylabel("Episode reward"); axes[2].set_title("(c) $f=2$, $n=7$", fontsize=9)
    axes[2].margins(y=0.22)
    finish(fig, "fig4_byzantine")


# ================================================================ Fig 5 迁移 + 准则
def fig5():
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9),
                             gridspec_kw=dict(width_ratios=[1.15, 1]), layout="constrained")
    keys = ["mappo", "mism", "soft"]
    Lb = {"mappo": "ENV2L_mappo_byz", "mism": "ENV2L_hard_byz", "soft": "ENV2L_soft_byz"}
    Lc = {"mappo": "ENV2L_mappo_clean", "mism": "ENV2L_hard_clean", "soft": "ENV2L_soft_clean"}
    ax = axes[0]
    for j, k in enumerate(keys):
        cm, cs, n = ms([honest(x) for x in load(Lc[k]).values()])
        fm, fs, _ = ms([honest(x) for x in load(Lb[k]).values()])
        AGG.setdefault("fig5_env2_honest", {})[k] = dict(
            clean=[None if cm is None else round(cm, 4), None if cs is None else round(cs, 4)],
            faulted=[None if fm is None else round(fm, 4), None if fs is None else round(fs, 4)], n=n)
        bars(ax, [j - 0.17], [cm if cm is not None else np.nan], [cs or 0], ["#C9CDD4"], width=0.30)
        ax.bar([j + 0.17], [fm if fm is not None else np.nan], 0.30, color=C[k],
               edgecolor="black", linewidth=0.6, hatch="///",
               yerr=[fs or 0], capsize=2.5, error_kw=dict(lw=0.7), zorder=2)
    ax.set_xticks(np.arange(3)); ax.set_xticklabels([SHORT[k] for k in keys], fontsize=7)
    ax.set_ylabel("Honest entropy")
    ax.set_title("(a) Second task, MPE simple\\_line", fontsize=9)
    ax.legend(handles=[Rectangle((0, 0), 1, 1, fc="#C9CDD4", ec="black", lw=0.6),
                       Rectangle((0, 0), 1, 1, fc="white", ec="black", lw=0.6, hatch="///")],
              labels=["clean", "faulted ($f=1$; bars keep method colour)"],
              fontsize=6.5, loc="upper left")
    ax.margins(y=0.30)

    ax = axes[1]; ax.axis("off"); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.text(0.02, 0.96, "Design guidelines", fontsize=9.5, fontweight="bold", va="top")
    rules = [("(i)", "Never pair action replacement\nwith matched log-probability updates."),
             ("(ii)", "Prefer additive loss conditioning\nwith zero-initialized influence."),
             ("(iii)", "Enforce entropy floors\nas defense-in-depth.")]
    y = 0.76
    for tag, txt in rules:
        ax.text(0.02, y, tag, fontsize=8.5, color="#A93226", fontweight="bold", va="top")
        ax.text(0.15, y, txt, fontsize=8, va="top")
        y -= 0.23
    ax.text(0.02, 0.10, "Collapse is invisible in reward\nand in all-agent entropy.",
            fontsize=7.5, style="italic", color="#555555", va="top")
    finish(fig, "fig5_transfer_guidelines")


if __name__ == "__main__":
    print(f"=== 重绘配图 → {OUT} ===")
    for f in (fig1, fig2, fig3, fig4, fig5):
        try:
            f()
        except Exception as e:
            print(f"  ❌ {f.__name__}: {type(e).__name__}: {e}")
    with open(f"{OUT}/aggregates.json", "w") as fh:
        json.dump(AGG, fh, indent=2, ensure_ascii=False)
    print("\n[OK] 写出 aggregates.json —— 请把这个文件内容贴回给我核对数字")
    print("     并上传 figures_v7/*.png 供我审图")
