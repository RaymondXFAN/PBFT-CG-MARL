#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Table 3 完整版（8 行）：f=1, n=5, 300K steps, 4 seeds。
在既有 6 个条件（mappo/hard/soft × rand/adv）之上，补入
E3pa_matched_{rand,adv}（本次补跑）→ 2×2 因果设计闭合。

用法（项目根目录）:
    python3 scripts/table3_full.py                       # 默认 results/e3_peragent_v2
    python3 scripts/table3_full.py results/e3_peragent_v2
"""
import json
import os
import sys
import glob
import math
import numpy as np

RESULTS = sys.argv[1] if len(sys.argv) > 1 else "results/e3_peragent_v2"
BYZ = 1          # 注入的拜占庭 agent 数 = 前 BYZ 个（n=5, f=1）

# (label, 论文中的方法名, 故障类型)
CONDS = [
    ("E3pa_mappo_rand",    "MAPPO Baseline",           "Random"),
    ("E3pa_mappo_adv",     "MAPPO Baseline",           "Adversarial"),
    ("E3pa_hard_rand",     "Hard Cons. (Mismatched)",  "Random"),
    ("E3pa_hard_adv",      "Hard Cons. (Mismatched)",  "Adversarial"),
    ("E3pa_matched_rand",  "Hard Cons. (Matched)",     "Random"),      # ← 本次补
    ("E3pa_matched_adv",   "Hard Cons. (Matched)",     "Adversarial"), # ← 本次补
    ("E3pa_soft_rand",     "Soft Cons. (Ours)",        "Random"),
    ("E3pa_soft_adv",      "Soft Cons. (Ours)",        "Adversarial"),
]


def last10(v):
    return float(np.mean(v[-10:])) if isinstance(v, list) and v else None


def collect(label):
    rows = {}
    pat = os.path.join(RESULTS, label, "seed_*", "*", "seed_*", "metrics.json")
    for p in sorted(glob.glob(pat)):
        try:
            seed = int(p.split(os.sep)[-2].split("_")[1])
        except (IndexError, ValueError):
            continue
        try:
            d = json.load(open(p))
        except Exception:
            continue
        ks = sorted([k for k in d if k.startswith("train/entropy_agent_")],
                    key=lambda k: int(k.rsplit("_", 1)[1]))
        ag = [last10(d[k]) for k in ks]
        ag = [a for a in ag if a is not None]
        honest = ag[BYZ:] if len(ag) > BYZ else []
        rows[seed] = {
            "all": last10(d.get("train/entropy")),
            "honest": (float(np.mean(honest)) if honest else None),
            "reward": last10(d.get("episode/episode_reward") or d.get("episode_reward")),
            "cr": last10(d.get("episode/consensus_rate") or d.get("train/consensus_rate")),
            "per_seed_honest": honest,
        }
    return rows


def ms(vals):
    a = np.array([v for v in vals if v is not None], dtype=float)
    if len(a) == 0:
        return "-"
    if len(a) == 1:
        return f"{a[0]:.3f}"
    return f"{a.mean():.3f} $\\pm$ {a.std(ddof=1):.3f}"


def welch(a, b):
    """Welch t 检验（纯 numpy；p 用 t 分布 CDF 需 scipy，缺失时给正态近似）"""
    a = np.array([x for x in a if x is not None], float)
    b = np.array([x for x in b if x is not None], float)
    if len(a) < 2 or len(b) < 2:
        return None
    va, vb = a.var(ddof=1), b.var(ddof=1)
    se = math.sqrt(va / len(a) + vb / len(b))
    if se == 0:
        return (float("inf"), 0.0, float("nan"))
    t = (a.mean() - b.mean()) / se
    df = (va / len(a) + vb / len(b)) ** 2 / (
        (va / len(a)) ** 2 / (len(a) - 1) + (vb / len(b)) ** 2 / (len(b) - 1))
    p = 2 * (1 - 0.5 * (1 + math.erf(abs(t) / math.sqrt(2))))   # 正态近似
    sp = math.sqrt(((len(a) - 1) * va + (len(b) - 1) * vb) / (len(a) + len(b) - 2))
    d = (a.mean() - b.mean()) / sp if sp > 0 else float("nan")
    return (t, p, d, df)


DATA = {lbl: collect(lbl) for lbl, _, _ in CONDS}

print(f"<!-- 数据源: {RESULTS} | 拜占庭 agent = 前 {BYZ} 个 | honest = 其余 agent 均值 -->\n")

# ---------- 主表 ----------
print("**Table 3.** Byzantine faults on MPE simple\\_spread ($n=5$, $f=1$, 300K steps, 4 seeds).\n")
print("| Method | Fault | Reward $\\uparrow$ | Entropy (all-agent) | Entropy (honest only) | Consensus Rate |")
print("|--------|:-----:|:-----------------:|:-------------------:|:---------------------:|:--------------:|")
for lbl, method, fault in CONDS:
    r = DATA[lbl]
    if not r:
        print(f"| {method} | {fault} | *待补跑* | | | |")
        continue
    ss = sorted(r)
    g = lambda k: [r[s][k] for s in ss]
    print(f"| {method} | {fault} | {ms(g('reward'))} | {ms(g('all'))} | {ms(g('honest'))} | {ms(g('cr'))} |")

# ---------- 逐 seed honest（附录 A.3 用）----------
print("\n**Table A.3.** Honest-agent-only entropy, per seed.\n")
print("| Method | Fault | Honest-agent entropy | Per-seed values |")
print("|--------|:-----:|:--------------------:|-----------------|")
for lbl, method, fault in CONDS:
    r = DATA[lbl]
    if not r:
        print(f"| {method} | {fault} | *待补跑* | |")
        continue
    ss = sorted(r)
    vals = [r[s]["honest"] for s in ss]
    per = ", ".join(f"{v:.3f}" if v is not None else "NA" for v in vals)
    print(f"| {method} | {fault} | {ms(vals)} | ${per}$ |")

# ---------- 关键配对检验（Appendix A.1 用）----------
print("\n**Honest-only entropy, pairwise Welch tests (n=4).**\n")
print("| Comparison | A | B | t | p | Cohen d |")
print("|:----------|:--:|:--:|:-:|:-:|:-------:|")
PAIRS = [
    ("E3pa_matched_rand", "E3pa_hard_rand",   "Matched vs. Mismatched (random)"),
    ("E3pa_matched_adv",  "E3pa_hard_adv",    "Matched vs. Mismatched (adversarial)"),
    ("E3pa_matched_rand", "E3pa_mappo_rand",  "Matched vs. MAPPO (random)"),
    ("E3pa_matched_adv",  "E3pa_mappo_adv",   "Matched vs. MAPPO (adversarial)"),
    ("E3pa_soft_rand",    "E3pa_matched_rand","Soft vs. Matched (random)"),
    ("E3pa_soft_adv",     "E3pa_matched_adv", "Soft vs. Matched (adversarial)"),
]
for la, lb, name in PAIRS:
    if not DATA.get(la) or not DATA.get(lb):
        print(f"| {name} | | | *待补跑* | | |"); continue
    A = [DATA[la][s]["honest"] for s in sorted(DATA[la])]
    B = [DATA[lb][s]["honest"] for s in sorted(DATA[lb])]
    res = welch(A, B)
    if res is None:
        print(f"| {name} | | | 数据不足 | | |"); continue
    t, p, d, df = res
    print(f"| {name} | {np.mean(A):.3f} | {np.mean(B):.3f} | {t:.2f} | {p:.4f} | {d:.2f} |")
