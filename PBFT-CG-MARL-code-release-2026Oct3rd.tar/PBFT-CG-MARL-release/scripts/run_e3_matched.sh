#!/bin/bash
# ============================================================
# E3-matched 补跑脚本
# 目的：补齐论文 Table 3（§4.4 / f=1 / n=5 / 4 seeds）缺失的
#       「Hard Cons. (Matched) × {Random, Adversarial}」两行，
#       使 2×2（matched/mismatched × random/adversarial）因果设计闭合。
# ------------------------------------------------------------
# 与既有 E3pa_* 六个条件完全同源：同一 env、同一 train.py、同一 4 seeds、
# 同一 300K steps；唯一差别 = algo 配置里 matched_logprob: true。
# 输出：results/e3_peragent_v2/E3pa_matched_{rand,adv}/seed_N/pbft_cg_mappo/seed_N/metrics.json
#       （与 scripts/e3_peragent_report.py、table3_markdown.py 的 glob 模式兼容）
#
# 用法：
#   bash run_e3_matched.sh verify    # 预检（3K steps，约 20 秒）—— 必须先过
#   bash run_e3_matched.sh run       # 正式（8 个 run，4 路并发，约 1–1.5 h）
#   bash run_e3_matched.sh status    # 非阻塞查看进度
#   bash run_e3_matched.sh collect   # 跑完汇总 Table 3
# ============================================================
set -u
PROJECT=${PROJECT:-/root/autodl-tmp/PBFT-CG-MARL}
PY=${PY:-/root/miniconda3/bin/python}
RESULTS=$PROJECT/results/e3_peragent_v2
LOGS=$PROJECT/logs/e3_peragent_v2
ENV_CFG=configs/env/mpe_spread_n5.yaml
PARALLEL=${PARALLEL:-4}
GPU=${GPU:-0}
STEPS=${STEPS:-300000}
EVAL_INT=10000
EVAL_EP=10
SEEDS=${SEEDS:-"1 2 3 4"}
BYZ_R="--byzantine_n 1 --byzantine_type random"
BYZ_A="--byzantine_n 1 --byzantine_type adversarial"
MODE=${1:-run}

cd "$PROJECT" || { echo "!! 找不到项目目录 $PROJECT"; exit 1; }
mkdir -p "$RESULTS" "$LOGS"

log() { echo "[$(date +%H:%M:%S)] $*"; }

# label | algo_config | extra
JOBS="
E3pa_matched_rand|configs/algo/n5_hard_matched_byz_random.yaml|$BYZ_R
E3pa_matched_adv|configs/algo/n5_hard_matched_byz_adversarial.yaml|$BYZ_A
"

count_done() {
    local n=0
    for LBL in E3pa_matched_rand E3pa_matched_adv; do
        for S in $SEEDS; do
            [ -f "$RESULTS/$LBL/seed_$S/pbft_cg_mappo/seed_$S/metrics.json" ] && n=$((n+1))
        done
    done
    echo "$n"
}

case "$MODE" in
  verify)
    log "=== 预检：3000 步 × 1 seed（确认 matched 配置可跑 + 拜占庭注入生效）==="
    $PY -u src/train.py --algo pbft_cg_mappo --env mpe_spread \
        --env_config "$PROJECT/$ENV_CFG" \
        --algo_config "$PROJECT/configs/algo/n5_hard_matched_byz_random.yaml" \
        --seed 0 --n_timesteps 3000 --eval_interval 3000 --eval_episodes 1 \
        --gpu "$GPU" $BYZ_R --log_dir "$LOGS/_verify" > "$LOGS/_verify.log" 2>&1
    OK=1
    if grep -qiE "inject|拜占庭" "$LOGS/_verify.log"; then
        log "  ✅ 拜占庭注入生效："; grep -iE "inject|拜占庭" "$LOGS/_verify.log" | head -2 | sed 's/^/      /'
    else
        log "  ❌ 未见注入痕迹，中止。请把 $LOGS/_verify.log 末尾 20 行发给 Mihiro。"; OK=0
    fi
    if grep -qiE "matched|logprob" "$LOGS/_verify.log"; then
        log "  ✅ 日志里出现 matched/logprob 字样："; grep -iE "matched|logprob" "$LOGS/_verify.log" | head -2 | sed 's/^/      /'
    else
        log "  ⚠️  日志里没看到 matched 字样（不一定致命，但正式跑前请留意）"
    fi
    tail -5 "$LOGS/_verify.log" | sed 's/^/      /'
    [ "$OK" = 1 ] && log "预检通过 ✅ 可以执行： bash run_e3_matched.sh run" || exit 1
    ;;

  run)
    RUNNING=$(pgrep -fc "src/train.py" 2>/dev/null || echo 0)
    if [ "$RUNNING" -gt 0 ]; then
        echo "!! 已有 $RUNNING 个 train.py 在跑，请等它结束（避免并发失控抢卡）。"; exit 1
    fi
    log "=== E3-matched：2 条件 × seeds[$SEEDS] × ${STEPS} 步（并发 $PARALLEL）==="
    N=0
    for S in $SEEDS; do
        while IFS='|' read -r LBL ACFG EXTRA; do
            [ -z "$LBL" ] && continue
            OUTDIR=$RESULTS/$LBL/seed_$S
            mkdir -p "$OUTDIR"
            if [ -f "$OUTDIR/pbft_cg_mappo/seed_$S/metrics.json" ]; then
                log "  [SKIP] $LBL seed=$S（已完成）"; continue
            fi
            while [ "$(jobs -rp | wc -l)" -ge "$PARALLEL" ]; do sleep 10; done
            nohup $PY -u src/train.py --algo pbft_cg_mappo --env mpe_spread \
                --env_config "$PROJECT/$ENV_CFG" \
                --algo_config "$PROJECT/$ACFG" \
                --seed "$S" --n_timesteps "$STEPS" --eval_interval "$EVAL_INT" \
                --eval_episodes "$EVAL_EP" --gpu "$GPU" $EXTRA \
                --log_dir "$OUTDIR" > "$LOGS/${LBL}_s${S}.log" 2>&1 &
            log "  启动 $LBL seed=$S (PID=$!)"
            N=$((N+1))
        done <<< "$JOBS"
    done
    wait
    log "全部结束：完成 $(count_done)/8 → $RESULTS"
    log "请执行： bash run_e3_matched.sh collect"
    ;;

  status)
    DONE=$(count_done)
    log "已完成：$DONE / 8"
    for LBL in E3pa_matched_rand E3pa_matched_adv; do
        for S in $SEEDS; do
            F="$RESULTS/$LBL/seed_$S/pbft_cg_mappo/seed_$S/metrics.json"
            if [ -f "$F" ]; then echo "  ✅ $LBL seed=$S"; else echo "  ⏳ $LBL seed=$S"; fi
        done
    done
    echo "--- 正在运行的 train.py 进程 ---"
    pgrep -fa "src/train.py" | sed 's/^/  /' || echo "  （无）"
    ;;

  collect)
    log "=== 汇总 Table 3（8 行完整版）==="
    $PY scripts/table3_full.py "$RESULTS" 2>&1 | tee "$LOGS/table3_full.log"
    log "结果已写入 $LOGS/table3_full.log"
    ;;

  *)
    echo "用法: bash run_e3_matched.sh [verify|run|status|collect]"; exit 1;;
esac
