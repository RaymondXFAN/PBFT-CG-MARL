# 部署与复现手册（中文版）— PBFT-CG-MARL

面向 AutoDL 等 Linux 容器的逐步操作指南：从零把环境跑起来、复现论文里的数字、重新出图。

> 英文版见 [`DEPLOY.md`](DEPLOY.md)（内容一致，用于仓库）。本文件是中文对照稿。

**目录**

1. [最快上手](#1-最快上手)
2. [软硬件配置](#2-软硬件配置)
3. [环境安装](#3-环境安装)
4. [代码架构](#4-代码架构)
5. [数据从哪来](#5-数据从哪来)
6. [安装自检](#6-安装自检)
7. [怎么跑实验](#7-怎么跑实验)
8. [结果怎么看](#8-结果怎么看)
9. [图怎么画](#9-图怎么画)
10. [监控与运维](#10-监控与运维)
11. [常见问题](#11-常见问题)

---

## 1. 最快上手

```bash
# 1) 解压
mkdir -p /root/autodl-tmp && tar -xzf PBFT-CG-MARL-release.tar.gz -C /root/autodl-tmp/
cd /root/autodl-tmp/PBFT-CG-MARL-release

# 2) 装依赖
pip install -r requirements.txt

# 3) 约 5 分钟预检（务必先做）
bash scripts/verify_5min.sh 0

# 4) 正式跑一组实验
nohup bash scripts/run_n5_review.sh > logs/n5_review.log 2>&1 &

# 5) 看进度
find results -name metrics.json | wc -l
```

---

## 2. 软硬件配置

| 项目 | 论文全部结果所用的配置 |
|---|---|
| GPU | **NVIDIA RTX 4090 (24 GB)** |
| 可接受的替代 | 任何 ≥ 8 GB 的 CUDA 显卡（按比例调小并发） |
| CUDA 驱动 | 570.x（`nvidia-smi` 显示 CUDA 12.8） |
| PyTorch | **cu124** 版本（12.4 ≤ 12.8，兼容） |
| Python | 3.10 |
| 内存 / 磁盘 | 32 GB+ / 数据盘 ≥ 40 GB 可用 |
| 镜像 | 任意较新的 PyTorch 镜像；**不要重装 CUDA/torch**，镜像自带的版本已经匹配 |

**实测耗时**（4090，4 路并发）：

| 任务 | 墙钟时间 |
|---|---|
| 单方法 300K 步 × 8 seeds（MPE，$n=5$） | ≈ 1.5 h |
| $n=5$ 主实验集（4 方法 × 8 seeds） | ≈ 3 h |
| $n=7$, $f=2$ 每组 | ≈ 1.5 h |
| VMAS 批（连续控制，2 路并发） | ≈ 7–8 h |

> 💡 **AutoDL 技巧**：先在「无卡模式」装环境（便宜），再切到 GPU 模式训练，数据盘不受影响。

---

## 3. 环境安装

```bash
conda create -n pbft python=3.10 -y
conda activate pbft

# PyTorch 选与驱动匹配的（cu124 可用）
pip install torch --index-url https://download.pytorch.org/whl/cu124

# 其余依赖
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

验证：

```bash
python -c "import torch; print(torch.__version__, torch.cuda.is_available())"   # 期望 True
nvidia-smi
```

> ⚠️ **每次新开终端都要重新 `conda activate pbft`**，否则会报"找不到包"。

---

## 4. 代码架构

```
PBFT-CG-MARL-release/
├── src/
│   ├── train.py            ★ 单次实验入口（命令行参数）
│   ├── eval.py             独立评估工具
│   ├── algorithms/
│   │   ├── __init__.py     ALGORITHM_REGISTRY（算法名 → 类）
│   │   ├── pbft_cg_mappo.py ★ 本文方法：共识引导 MAPPO
│   │   ├── mappo.py        基线 MAPPO
│   │   ├── qmix.py maddpg.py commnet.py tarmac.py   其他基线
│   │   └── base.py         训练器统一接口
│   ├── consensus/pbft.py   ★ PBFT 协议：pre-prepare / prepare / commit、Leader 轮换、降级
│   ├── envs/               ENV_REGISTRY（环境名 → 适配器）
│   │   ├── mpe_wrapper.py  MPE simple_spread / simple_line
│   │   ├── smaclite_wrapper.py / vmas_wrapper.py / lbf_wrapper.py
│   │   ├── permafrost_env.py   真实数据环境（可选）
│   │   └── base.py         BaseEnv 接口
│   ├── networks/           actor_critic.py（GRU/MLP）、mixing_net.py（QMIX）
│   └── utils/              buffer.py、logger.py、metrics.py
├── configs/algo/*.yaml     算法 + PBFT 配置
├── configs/env/*.yaml      环境配置
├── scripts/                批处理启动器、汇总器、统计分析（见 §7）
│   └── figures/            绘图脚本（见 §9）
├── data/                   逐 seed 结果导出（见 §5）
├── experiments/            实验设计笔记与阶段脚本
├── baselines/ models/ legacy/
└── README.md  DEPLOY.md  DEPLOY_zh.md  requirements.txt  CITATION.cff  LICENSE
```

### 一次训练是怎么串起来的

1. `train.py` 解析命令行，然后读两个 YAML：`--algo_config` 和 `--env_config`。所有键会被
   **展平到同一命名空间**，所以顶层的 `pbft_f` 会覆盖嵌套在 `pbft:` 里的同名键。
2. 用 `ENV_REGISTRY[--env]` 建环境，用 `ALGORITHM_REGISTRY[--algo]` 建训练器。
3. `PBFTCGMAPPO` 每 `consensus_freq` 步调用一次 `consensus/pbft.py` 拿到共识动作 $a^{*}$，
   再按配置走两条条件化路径之一：

   | `conditioning_type` | `soft_consensus_mode` | 行为 |
   |---|---|---|
   | `multiplicative` | `false` | **硬替换**：执行动作被 $a^{*}$ 顶替 |
   | `additive` | `true` | **软条件化**：动作不动，往损失里加一个有界 KL 项 |

   第三个开关 `matched_logprob` 决定 PPO 梯度是在 $\log\pi(a^{*})$（matched）还是智能体自己
   的提议（mismatched）上求。**论文讲的正是这三个开关的相互作用。**

4. `utils/logger.py` 把逐 episode 历史写进 `<log_dir>/<algo>/seed_<N>/metrics.json`
   —— 注意这里**套了两层**。

### 拜占庭注入

两个机制同时用（双保险）：

```yaml
byzantine:            # 写在算法 YAML 里
  n: 1
  mode: random        # 或 adversarial
  inject_at: proposal
```

```bash
--byzantine_n 1 --byzantine_type random     # 命令行再写一遍
```

---

## 5. 数据从哪来

### 5.1 仿真环境 —— 无需下载

`mpe_spread`、`mpe_reference`、`smaclite_*`、`vmas_*`、`lbf_2s3f` 全部由
`pettingzoo` / `vmas` / `gymnasium` 在运行时合成。**主结果背后没有外部数据集。**

### 5.2 冻土环境（可选）

`permafrost_monitoring` 用到真实第三方观测。凭据只能走环境变量，绝不落盘：

```bash
export TPDC_EMAIL="you@example.com"
export TPDC_PWD="..."              # 不要写进任何文件
python scripts/download_tpdc.py
unset TPDC_PWD
```

使用时请引用数据提供方（国家青藏高原科学数据中心）。

### 5.3 我们自己的结果 —— `data/`

全部 **721 个 run / 93 个实验目录** 的数值结果已随包提供（精简形式）：

| 文件 | 行数 | 内容 |
|---|---:|---|
| `data/seeds_summary.csv` | 721 | 每个 run 一行；各头部指标的末 10 点均值 |
| `data/per_agent_entropy.csv` | 523 | 每个 (run, agent) 一行 —— 诚实/故障智能体的熵分解 |
| `data/seeds_tail10.csv.gz` | 67,606 | 上面每个数字背后的末 10 个原始点 |
| `data/export_data.tar.gz` | — | 上述三个文件的打包 |

逐列说明见 **[`data/README.md`](data/README.md)**。

在任意有 `results/` 的机器上重新导出：

```bash
python3 scripts/export_results.py --full
```

---

## 6. 安装自检

```bash
python -c "import sys; sys.path.insert(0,'.'); from src.envs import ENV_REGISTRY; print(list(ENV_REGISTRY))"
python -c "import sys; sys.path.insert(0,'.'); from src.algorithms import ALGORITHM_REGISTRY; print(list(ALGORITHM_REGISTRY))"

# 1 分钟冒烟测试
python src/train.py --algo mappo --env mpe_spread \
    --env_config configs/env/mpe_spread_n5.yaml \
    --algo_config configs/algo/n5_mappo_fair.yaml \
    --seed 1 --n_timesteps 5000 --eval_interval 2500 --eval_episodes 2 \
    --log_dir results/_smoke
find results/_smoke -name metrics.json          # 打印出路径 = 全链路通

# 5 分钟预检（覆盖数据加载、前向反向、存盘）
bash scripts/verify_5min.sh 0                   # 期望：预检结果: ✅ N ❌ 0
```

预检输出里有两行要特别看：

- **拜占庭自检** —— 应报告日志里出现了注入痕迹。
- **`f` 值检查** —— $n=7$ 的配置应读到 `f=2`；若读到 `f=1`，说明顶层 `pbft_f` 没生效。

---

## 7. 怎么跑实验

所有启动器都**可断点续跑**（已完成的 seed 自动跳过）且**带并发节流**（按存活的
`train.py` 进程数控制）。

| 论文产物 | 启动脚本 | 配置族 | 规模 |
|---|---|---|---|
| 表 1 —— 干净设置 | `scripts/run_n5_review.sh` | `configs/algo/n5_*.yaml` | $n{=}5$, 8 seeds, 300K |
| 表 2 —— matched/mismatched 因果 | `scripts/run_mpe_matched_v2.sh` | `n5_matched_logprob.yaml` | $n{=}5$, 8 seeds |
| 表 3 —— 拜占庭 $f{=}1$（逐 agent 熵） | `scripts/run_e3_peragent_v2.sh` | `n5_*_byz_*.yaml` | $n{=}5$, $f{=}1$, 4 seeds |
| 表 3 —— 第四个角（Hard-Matched, $f{=}1$） | `scripts/run_e3_matched.sh run` | `n5_hard_matched_byz_*.yaml` | 2 条件 × 4 seeds |
| 表 4 —— 更高故障比例 | `scripts/run_supplement.sh f2` + `scripts/run_hard_matched.sh run` | `supp_*_byz2_adv_n7.yaml` | $n{=}7$, $f{=}2$, 8 seeds |
| 表 5 —— 第二个任务（MPE simple\_line） | `scripts/run_mpe_formal.sh` | `experiments/configs/fair_*.yaml` | $n{=}5$, 5 seeds |
| 全部无人值守 | `scripts/run_all_serial.sh` | — | 完整队列 |

```bash
cd /root/autodl-tmp/PBFT-CG-MARL-release

nohup bash scripts/run_n5_review.sh       > logs/n5_review.log    2>&1 &   # ≈ 3 h
nohup bash scripts/run_supplement.sh f2   > logs/supp_f2.log      2>&1 &   # ≈ 3.5 h
nohup bash scripts/run_hard_matched.sh run> logs/hard_matched.log 2>&1 &   # ≈ 1.5 h
nohup bash scripts/run_e3_matched.sh run  > logs/e3_matched.log   2>&1 &   # ≈ 1.5 h
```

> ⚠️ **同一时间只开一个批处理脚本。** 每个脚本都会在 `/tmp/<名字>.lock` 加锁；两个实例同时
> 跑会绕过节流，把显存吃光。

单次跑（直接命令行）：

```bash
python src/train.py --algo pbft_cg_mappo --env mpe_spread \
    --env_config configs/env/mpe_spread_n5.yaml \
    --algo_config configs/algo/n5_hard_matched_byz_random.yaml \
    --seed 1 --n_timesteps 300000 --eval_interval 10000 --eval_episodes 10 \
    --gpu 0 --byzantine_n 1 --byzantine_type random \
    --log_dir results/manual/E3pa_matched_rand/seed_1
```

### 命令行参数速查（`src/train.py`）

| 参数 | 默认 | 说明 |
|---|---|---|
| `--algo` | — | `ALGORITHM_REGISTRY` 里的键 |
| `--env` | — | `ENV_REGISTRY` 里的键；**务必显式传**（默认值未注册，会导致环境配置被静默忽略） |
| `--algo_config` / `--env_config` | — | YAML 路径 |
| `--seed` | 1 | |
| `--n_timesteps` | 1000000 | 论文全部用 300K |
| `--eval_interval` / `--eval_episodes` | 5000 / 10 | 论文口径取末 10 个评估点 |
| `--log_dir` | `./results` | 结果落在 `<log_dir>/<algo>/seed_<N>/` |
| `--gpu` | 0 | |
| `--byzantine_n` / `--byzantine_type` / `--byzantine_mode` | 0 | 注入 $n$ 个指定行为的故障智能体 |

---

## 8. 结果怎么看

### 8.1 结果在哪

```
<log_dir>/<algo>/seed_<N>/metrics.json
```

**双层嵌套**（目录本身已经叫 `seed_<N>`，里面还有一层 `<algo>/seed_<N>/`）是设计如此，
收集脚本就是按这个模式 glob 的。如果"跑完了却找不到结果"，先查这个路径。

### 8.2 `metrics.json` 里有什么

一个"时间序列字典"（WandB 风格，每个键对应一个数组）：

| 键 | 含义 |
|---|---|
| `episode/episode_reward` | 回合回报 |
| `episode/episode_length` | 回合长度 |
| `episode/consensus_rate` | 每个评估点的 PBFT 共识达成率 |
| `train/entropy` | **全体**智能体的平均策略熵 |
| `train/entropy_agent_<i>` | 逐智能体熵（打了 per-agent 补丁才有） |
| `train/consensus_loss` | PBFT 共识辅助损失 |
| `train/kl_consensus_loss` | 加性条件化的 KL 项 |
| `train/policy_loss` / `train/value_loss` | PPO 损失 |
| `train/entropy_coef` / `train/lr` | 生效中的调度值 |

### 8.3 汇报口径

论文里每个标量都是该序列**最后 10 个评估点的均值**；跨 seed 的统计量（mean ± std、
Welch $t$、Cohen $d$、Hedges $g$、MWU、95% CI）都建在逐 seed 值上，**不是**建在原始时间步上。

```bash
# 用随包数据复算一个论文数字
python3 - <<'EOF'
import csv, statistics
rows = [r for r in csv.DictReader(open("data/seeds_summary.csv"))
        if r["experiment"] == "e3_peragent_v2" and r["label"] == "E3pa_matched_rand"]
vals = [float(r["entropy_all"]) for r in rows if r["entropy_all"]]
print(len(vals), "seeds |", round(statistics.mean(vals), 4), "±", round(statistics.stdev(vals), 4))
EOF
```

### 8.4 汇总脚本

```bash
python scripts/collect_n5_results.py      # 主表
python scripts/collect_results.py         # 补充实验
python scripts/statistical_analysis.py    # Welch t / Cohen d / Hedges g / MWU / 95% CI
python scripts/table3_full.py             # 表 3 完整 8 行版
python scripts/e3_peragent_report.py      # 诚实智能体熵分解
python scripts/export_results.py --full   # 从 results/ 重建 data/
```

> 论文里的数字**已经在 `data/` 里**，这些脚本是用来从你自己的 run 重新推的。

---

## 9. 图怎么画

绘图脚本在 `scripts/figures/`，读 `metrics.json`（或导出的 CSV），同时输出
**300 dpi 的 PNG** 和 **矢量 PDF**。

```bash
cd /root/autodl-tmp/PBFT-CG-MARL-release
python3 scripts/figures/make_figures.py      # 图 1–5（从 results/ 读）
python3 scripts/figures/make_fig4_v8.py      # 图 4（2×2 拜占庭面板，数据已内联）
```

输出在 `scripts/figures/out/`。

### 排版规范（新增图也照这个来）

- **所有文字 ≥ 12 pt**。更小的字号在双栏版式里活不下来。
- **莫兰迪低饱和配色，一色一方法**，全稿一致：
  MAPPO `#8E7CC3` · Hard (Mismatched) `#7FAF7F` · Hard (Matched) `#C3A36B` · Soft (Ours) `#4A7C96`
- **图内不写标题和图注** —— 图注是稿子里可编辑的正文字段落；只保留 `(a)`/`(b)` 面板标签。
- 同一条代码路径同时导出 **300 dpi PNG** 和 **矢量 PDF**。
- 误差棒 = 跨 seed 的 ±1 SD；这一点写在图注里，不写在图上。

### 图 ↔ 文件对照

| 论文图 | 脚本 | 数据来源 |
|---|---|---|
| 图 1 —— 条件化路径示意 | 示意图（无数据） | — |
| 图 2 —— 干净设置性能 | `make_figures.py` | `results/`（表 1 的 run） |
| 图 3 —— 熵随训练变化 | `make_figures.py` | `results/`，10K 步滑动均值 |
| 图 4 —— 拜占庭容错（2×2） | `make_fig4_v8.py` | 数据内联自表 3–4 |
| 图 5 —— 第二任务 + 设计准则 | `make_figures.py` | `results/`（表 5 的 run） |

---

## 10. 监控与运维

```bash
find results -name metrics.json | wc -l          # 已完成多少 run
bash scripts/run_hard_matched.sh status          # 分条件进度
tail -n 30 logs/hard_matched.log                 # 非阻塞看日志（别用 tail -f）
nvidia-smi --query-gpu=utilization.gpu,memory.used --format=csv
pgrep -fa src/train.py                           # 存活进程
pkill -f "src/train.py"                          # 全部停掉
```

**正常状态**：MPE $n=5$ 时 GPU 利用率约 50–95%，**4 路并发是最佳点**；VMAS 建议 2 路
（≈90%）。评估点之间 GPU 掉到 0% 是正常的。

**磁盘**：数据盘别超过 ~85%。长批次前清一清 `logs/` 和陈旧 `results/`。

**关机 vs 释放**：*关机*保留数据盘；*释放*会清空一切。有未收集结果的机器绝不释放。

**凭据**：密码、token 只走环境变量，绝不进源码、配置、shell history 或命令行。

**跨机搬运**：只搬不可再生的（代码、配置、结果）；模型权重和缓存可以重新下载。

---

## 11. 常见问题

| 现象 | 原因 / 解法 |
|---|---|
| `ModuleNotFoundError: No module named 'src'` | 要在仓库根目录运行，或把根目录加进 `PYTHONPATH`。 |
| `--env_config` 好像没生效 | 忘了 `--env mpe_spread`。默认的 `simple_spread` 不在注册表里，配置会被静默忽略。 |
| $n{=}7$ 的 run 里 `f` 一直是 1 | `pbft_f: 2` 要写在 YAML **顶层**，只写在嵌套 `pbft:` 里不生效。 |
| 训练"跑完了"却没有结果 | 去找 `<log_dir>/<algo>/seed_<N>/metrics.json` —— 双层嵌套最容易踩。 |
| OOM / 显存抖动 | 调小并发；确认只有一个批处理脚本在跑。 |
| 日志里看不到拜占庭注入 | YAML 的 `byzantine:` 块和命令行参数**两个都要有**。 |
| `nvidia-smi` 显示 0% 但任务在跑 | MPE 在评估点之间正常如此，用 `pgrep -fa src/train.py` 确认。 |
| SSH 里 `python3: command not found` | 非交互式 shell 不加载 conda，用 `bash -lc "…"` 或绝对路径。 |
| 刚装的包却报找不到 | 你在另一个 conda 环境里，新终端要重新 `conda activate pbft`。 |
| Ctrl-C 停不下来 | `pkill -f "src/train.py"` —— 后台任务不会随终端关闭而退出。 |
| 路径里有空格/特殊字符报错 | 所有路径都加引号：`--algo_config "configs/algo/xxx.yaml"`。 |

---

*项目总览见 [`README.md`](README.md)；数据字典见 [`data/README.md`](data/README.md)。*
