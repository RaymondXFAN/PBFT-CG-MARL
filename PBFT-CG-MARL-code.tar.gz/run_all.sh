#!/bin/bash
# PBFT-CG-MARL 完整实验脚本
# 使用方法: bash run_all.sh [gpu_id] [start_exp]
# 示例: bash run_all.sh 0 1

set -e

# ============================
# 全局参数
# ============================
GPU_ID=${1:-0}
START_EXP=${2:-1}
SEEDS_MAIN=10      # 主实验seed数
SEEDS_OTHER=5      # 其他实验seed数
LOG_DIR="results/$(date +%Y%m%d_%H%M%S)"
mkdir -p $LOG_DIR

echo "========================================="
echo "PBFT-CG-MARL 实验脚本"
echo "GPU: $GPU_ID"
echo "日志目录: $LOG_DIR"
echo "开始实验编号: $START_EXP"
echo "========================================="

# ============================
# 实验运行函数
# ============================
run_exp() {
    local exp_id=$1
    local algo=$2
    local env=$3
    local env_config=$4
    local n_timesteps=$5
    local n_seeds=$6
    shift 6
    local extra_args="$@"

    if [ $exp_id -lt $START_EXP ]; then
        return
    fi

    echo "[Exp $exp_id] $algo on $env, $n_seeds seeds, $n_timesteps steps ${extra_args}"

    for seed in $(seq 1 $n_seeds); do
        nohup python -u src/train.py \
            --algo $algo \
            --env $env \
            --env_config $env_config \
            --algo_config configs/algo/${algo}.yaml \
            --seed $seed \
            --n_timesteps $n_timesteps \
            --eval_interval 10000 \
            --eval_episodes 10 \
            --log_dir $LOG_DIR/${algo}_${env}_seed${seed} \
            --gpu $GPU_ID \
            $extra_args \
            > $LOG_DIR/${algo}_${env}_seed${seed}.log 2>&1 &
        echo "  Seed $seed started, PID: $!"
        # 间隔1秒，避免同时启动过多进程
        sleep 1
    done
}

# ============================
# E1: MPE-spread 主实验 (10 seeds)
# ============================
echo ""
echo ">>> E1: MPE-spread 主实验 (10 seeds)"
run_exp 1  pbft_cg_mappo mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_MAIN
run_exp 2  mappo          mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_MAIN
run_exp 3  qmix           mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_MAIN
run_exp 4  maddpg         mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_MAIN
run_exp 5  commnet        mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_MAIN
run_exp 6  tarmac         mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_MAIN

# ============================
# E2: MPE-reference 通信约束实验 (10 seeds)
# ============================
echo ""
echo ">>> E2: MPE-reference 通信约束实验 (10 seeds)"
run_exp 7  pbft_cg_mappo mpe_reference configs/env/mpe_reference.yaml 3000000 $SEEDS_MAIN
run_exp 8  mappo          mpe_reference configs/env/mpe_reference.yaml 3000000 $SEEDS_MAIN
run_exp 9  qmix           mpe_reference configs/env/mpe_reference.yaml 3000000 $SEEDS_MAIN
run_exp 10 maddpg         mpe_reference configs/env/mpe_reference.yaml 3000000 $SEEDS_MAIN
run_exp 11 commnet        mpe_reference configs/env/mpe_reference.yaml 3000000 $SEEDS_MAIN
run_exp 12 tarmac         mpe_reference configs/env/mpe_reference.yaml 3000000 $SEEDS_MAIN

# ============================
# E3: SMAClite 5m_vs_6m 复杂协作实验 (5 seeds)
# ============================
echo ""
echo ">>> E3: SMAClite 5m_vs_6m 复杂协作实验 (5 seeds)"
run_exp 13 pbft_cg_mappo smaclite_5m_vs_6m configs/env/smaclite_5m_vs_6m.yaml 10000000 $SEEDS_OTHER
run_exp 14 mappo          smaclite_5m_vs_6m configs/env/smaclite_5m_vs_6m.yaml 10000000 $SEEDS_OTHER
run_exp 15 qmix           smaclite_5m_vs_6m configs/env/smaclite_5m_vs_6m.yaml 10000000 $SEEDS_OTHER
run_exp 16 maddpg         smaclite_5m_vs_6m configs/env/smaclite_5m_vs_6m.yaml 10000000 $SEEDS_OTHER
run_exp 17 commnet        smaclite_5m_vs_6m configs/env/smaclite_5m_vs_6m.yaml 10000000 $SEEDS_OTHER
run_exp 18 tarmac         smaclite_5m_vs_6m configs/env/smaclite_5m_vs_6m.yaml 10000000 $SEEDS_OTHER

# ============================
# E4: SMAClite 3s5z 异构协作实验 (5 seeds)
# ============================
echo ""
echo ">>> E4: SMAClite 3s5z 异构协作实验 (5 seeds)"
run_exp 19 pbft_cg_mappo smaclite_3s5z configs/env/smaclite_3s5z.yaml 10000000 $SEEDS_OTHER
run_exp 20 mappo          smaclite_3s5z configs/env/smaclite_3s5z.yaml 10000000 $SEEDS_OTHER
run_exp 21 qmix           smaclite_3s5z configs/env/smaclite_3s5z.yaml 10000000 $SEEDS_OTHER
run_exp 22 maddpg         smaclite_3s5z configs/env/smaclite_3s5z.yaml 10000000 $SEEDS_OTHER
run_exp 23 commnet        smaclite_3s5z configs/env/smaclite_3s5z.yaml 10000000 $SEEDS_OTHER
run_exp 24 tarmac         smaclite_3s5z configs/env/smaclite_3s5z.yaml 10000000 $SEEDS_OTHER

# ============================
# E5: VMAS UAV覆盖应用实验 (5 seeds)
# ============================
echo ""
echo ">>> E5: VMAS UAV覆盖应用实验 (5 seeds)"
run_exp 25 pbft_cg_mappo vmas_uav_coverage configs/env/vmas_uav_coverage.yaml 5000000 $SEEDS_OTHER
run_exp 26 mappo          vmas_uav_coverage configs/env/vmas_uav_coverage.yaml 5000000 $SEEDS_OTHER
run_exp 27 qmix           vmas_uav_coverage configs/env/vmas_uav_coverage.yaml 5000000 $SEEDS_OTHER
run_exp 28 maddpg         vmas_uav_coverage configs/env/vmas_uav_coverage.yaml 5000000 $SEEDS_OTHER
run_exp 29 commnet        vmas_uav_coverage configs/env/vmas_uav_coverage.yaml 5000000 $SEEDS_OTHER
run_exp 30 tarmac         vmas_uav_coverage configs/env/vmas_uav_coverage.yaml 5000000 $SEEDS_OTHER

# ============================
# E6: VMAS 编队控制实验 (5 seeds)
# ============================
echo ""
echo ">>> E6: VMAS 编队控制实验 (5 seeds)"
run_exp 31 pbft_cg_mappo vmas_formation configs/env/vmas_formation.yaml 5000000 $SEEDS_OTHER
run_exp 32 mappo          vmas_formation configs/env/vmas_formation.yaml 5000000 $SEEDS_OTHER
run_exp 33 qmix           vmas_formation configs/env/vmas_formation.yaml 5000000 $SEEDS_OTHER
run_exp 34 maddpg         vmas_formation configs/env/vmas_formation.yaml 5000000 $SEEDS_OTHER
run_exp 35 commnet        vmas_formation configs/env/vmas_formation.yaml 5000000 $SEEDS_OTHER
run_exp 36 tarmac         vmas_formation configs/env/vmas_formation.yaml 5000000 $SEEDS_OTHER

# ============================
# E7: LBF 合作采集实验 (10 seeds)
# ============================
echo ""
echo ">>> E7: LBF 合作采集实验 (10 seeds)"
run_exp 37 pbft_cg_mappo lbf_2s3f configs/env/lbf_2s3f.yaml 1000000 $SEEDS_MAIN
run_exp 38 mappo          lbf_2s3f configs/env/lbf_2s3f.yaml 1000000 $SEEDS_MAIN
run_exp 39 qmix           lbf_2s3f configs/env/lbf_2s3f.yaml 1000000 $SEEDS_MAIN
run_exp 40 maddpg         lbf_2s3f configs/env/lbf_2s3f.yaml 1000000 $SEEDS_MAIN
run_exp 41 commnet        lbf_2s3f configs/env/lbf_2s3f.yaml 1000000 $SEEDS_MAIN
run_exp 42 tarmac         lbf_2s3f configs/env/lbf_2s3f.yaml 1000000 $SEEDS_MAIN

# ============================
# E8: 拜占庭容错实验 - MPE-spread (5 seeds)
# 仅对比 pbft_cg_mappo 和 mappo
# ============================
echo ""
echo ">>> E8: 拜占庭容错实验 (5 seeds)"

# 1个拜占庭Agent
run_exp 43 pbft_cg_mappo mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --byzantine_n 1
run_exp 44 mappo          mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --byzantine_n 1

# 2个拜占庭Agent
run_exp 45 pbft_cg_mappo mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --byzantine_n 2
run_exp 46 mappo          mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --byzantine_n 2

# 3个拜占庭Agent（超过容错上限）
run_exp 47 pbft_cg_mappo mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --byzantine_n 3
run_exp 48 mappo          mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --byzantine_n 3

# ============================
# E9: 拜占庭容错实验 - SMAClite (5 seeds)
# ============================
echo ""
echo ">>> E9: 拜占庭容错实验 - SMAClite (5 seeds)"
run_exp 49 pbft_cg_mappo smaclite_5m_vs_6m configs/env/smaclite_5m_vs_6m.yaml 10000000 $SEEDS_OTHER --byzantine_n 1
run_exp 50 mappo          smaclite_5m_vs_6m configs/env/smaclite_5m_vs_6m.yaml 10000000 $SEEDS_OTHER --byzantine_n 1
run_exp 51 pbft_cg_mappo smaclite_5m_vs_6m configs/env/smaclite_5m_vs_6m.yaml 10000000 $SEEDS_OTHER --byzantine_n 2
run_exp 52 mappo          smaclite_5m_vs_6m configs/env/smaclite_5m_vs_6m.yaml 10000000 $SEEDS_OTHER --byzantine_n 2

# ============================
# E10: 消融实验 - PBFT组件 (5 seeds)
# ============================
echo ""
echo ">>> E10: 消融实验 - PBFT组件 (5 seeds)"

# 无共识机制
run_exp 53 pbft_cg_mappo mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --ablation no_consensus
# 无Leader轮换
run_exp 54 pbft_cg_mappo mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --ablation no_leader_rotation
# 无fallback机制
run_exp 55 pbft_cg_mappo mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --ablation no_fallback
# 共识阈值消融
run_exp 56 pbft_cg_mappo mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --ablation consensus_threshold_0.3
run_exp 57 pbft_cg_mappo mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --ablation consensus_threshold_0.7
# 温度消融
run_exp 58 pbft_cg_mappo mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --ablation temperature_0.5
run_exp 59 pbft_cg_mappo mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --ablation temperature_2.0

# ============================
# E11: 消融实验 - 通信频率 (5 seeds)
# ============================
echo ""
echo ">>> E11: 消融实验 - 通信频率 (5 seeds)"
run_exp 60 pbft_cg_mappo mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --comm_freq 1
run_exp 61 pbft_cg_mappo mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --comm_freq 5
run_exp 62 pbft_cg_mappo mpe_spread configs/env/mpe_spread.yaml 3000000 $SEEDS_OTHER --comm_freq 10

# ============================
# E12: 消融实验 - LBF环境 (5 seeds)
# ============================
echo ""
echo ">>> E12: 消融实验 - LBF环境 (5 seeds)"
run_exp 63 pbft_cg_mappo lbf_2s3f configs/env/lbf_2s3f.yaml 1000000 $SEEDS_OTHER --ablation no_consensus
run_exp 64 pbft_cg_mappo lbf_2s3f configs/env/lbf_2s3f.yaml 1000000 $SEEDS_OTHER --ablation no_leader_rotation
run_exp 65 pbft_cg_mappo lbf_2s3f configs/env/lbf_2s3f.yaml 1000000 $SEEDS_OTHER --ablation no_fallback

echo ""
echo "========================================="
echo "所有实验已启动！"
echo "总实验数: 65"
echo "日志目录: $LOG_DIR"
echo "监控命令: tail -f $LOG_DIR/*.log"
echo "查看进程: ps aux | grep train.py"
echo "停止所有: pkill -f train.py"
echo "========================================="
