# Safe Consensus Conditioning for Byzantine-Resilient Multi-Agent Reinforcement Learning

---

## Abstract

Distributed multi-agent reinforcement learning (MARL) for infrastructure monitoring operates over communication channels that are lossy, intermittent, and exposed to faulty or adversarial nodes, where a single poisonous message can corrupt the centralized critic and destabilize the collective policy.

However, existing Byzantine-robust MARL methods provide only empirical resilience with perturbation-dependent tolerance and no formal bound on the number of faulty agents tolerated; robust federated methods offer policy-level guarantees but operate at the parameter-aggregation level, not at the per-step message level required in shared-environment cooperative MARL.

We propose **PBFT-CG-MAPPO**, a consensus-conditioned MARL framework that embeds a Practical Byzantine Fault Tolerance (PBFT) three-phase commit as a per-step message filter inside the CTDE-MAPPO training loop, delivering a formal *f* < *n*/3 message-level consistency guarantee. A 2×2 ablation with three seeds reveals that the additive consensus loss—not the consensus-filtered critic input—is the primary variance reduction mechanism (Loss Only σ = 3.5, a 5.7× reduction vs. MAPPO σ = 19.8; Filter Only σ = 10.4, a 1.9× reduction; with 3 seeds these point estimates are directionally informative but underpowered for formal significance, §5.6), while the consensus filter provides Byzantine protection and consensus guarantee (CR = 0.767 vs. 0.000 without filter). A MAPPO + L2(message) control experiment demonstrates that this variance reduction is not a generic regularization effect: an L2 penalty of identical form and weight, targeting the raw message mean rather than the quorum-verified mean, reduces variance only marginally (1.1×) compared to the consensus loss's 5.7× reduction, confirming that the PBFT quorum provides a stable, deterministic anchor that generic penalties cannot replicate. Under adversarial Byzantine injection (*f* = 1), disabling the consensus filter within the PBFT-CG-MAPPO framework causes 93% return degradation; however, MAPPO without consensus also shows empirical resilience (−40.9 ± 3.6), indicating that the PBFT filter's primary value lies in its formal *f* < *n*/3 consistency guarantee (Theorem 1) rather than empirical mean-return superiority.

These results establish that PBFT-based message conditioning provides a provable, non-interfering, and attack-conditional safety layer for cooperative MARL—where the consensus loss stabilizes training variance and the consensus filter defends against Byzantine attacks—offering a path toward reproducible and Byzantine-resilient deployment in safety-critical infrastructure monitoring.

---


## 1. Introduction

Cooperative multi-agent reinforcement learning has progressed from simulation benchmarks to physical deployments—autonomous drone swarms relaying perception through satellite meshes, permafrost-monitoring sensor networks scattered across the Tibetan Plateau, and distributed UAV coverage tasks. In all these settings, the communication layer is lossy, intermittent, and exposed to faulty or adversarial nodes. A permafrost-monitoring station on the Tibetan Plateau, for instance, forwards borehole readings over a wireless mesh that drops packets during snowstorms and loses nodes to frozen batteries; an autonomous drone team shares perception through a link that is both bandwidth-starved and occasionally spoofed.

Under centralized training with decentralized execution (CTDE) [3, 4, 5], each agent broadcasts a local message that feeds a centralized critic and its neighbors' policies. When a compromised or faulty agent injects a plausible-but-poisonous vector, the critic absorbs it as ground truth and the collective policy drifts. Current responses to this fragility suffer from several limitations: (i) adversarial training perturbs messages during learning so the policy learns to down-weight corruption, but the resulting robustness is heuristic with no guaranteed tolerance; (ii) communication-efficient methods such as CommNet [8] and TarMAC [9] reduce bandwidth yet still trust every delivered message; (iii) classical Byzantine fault tolerance (BFT) offers a provable *f* < *n*/3 bound but has never been embedded inside a MARL training loop, so its guarantee never reaches the learned policy.

A less discussed but equally critical issue is **seed sensitivity** [29, 30]. Standard MARL baselines exhibit return variance that can exceed the mean itself—QMIX on `simple_spread` ranges from −435.8 to +35.3 across three seeds (σ = 270.7), and MAPPO on SMAClite 5m_vs_6m shows σ = 223.0 across five seeds. This variance is not merely an inconvenience; it is a reproducibility barrier for safety-critical deployments where catastrophic seed outcomes (e.g., a policy that collapses to zero coordination) are unacceptable regardless of mean performance.

We formalize the cooperative task as a decentralized partially observable Markov decision process (Dec-POMDP) [1, 2], where *n* agents share a reward but observe only local views. Under CTDE, a GRU actor per agent is trained against a centralized critic that reads global state, optimized with PPO clipping [6, 33]. Practical Byzantine Fault Tolerance (PBFT) [7] replicates a service across *n* nodes with at most *f* Byzantine, tolerating *f* < *n*/3 via a three-phase commit (pre-prepare, prepare, commit) in which a message is accepted only after 2*f*+1 prepares.

We propose **PBFT-CG-MAPPO**, which conditions the CTDE-MAPPO training loop by inserting a PBFT consensus filter between every agent's outgoing message and the centralized critic, replacing raw messages with the consensus-filtered vector **m**. An additive consensus loss provides a differentiable gradient signal for soft alignment, while an entropy floor prevents the premature policy collapse that produces catastrophic seeds. The PBFT voting mechanism provides formal Byzantine tolerance during execution. A 2×2 ablation (§5.6) with three seeds reveals that the additive consensus loss is the primary variance reduction mechanism (Loss Only σ = 3.5, 5.7× reduction vs. MAPPO σ = 19.8), while the consensus filter provides Byzantine protection and consensus guarantee (CR = 0.767 vs. 0.000 without filter).

The contributions of this work are:

(1) **The first method to embed PBFT consensus as a per-step message conditioning signal inside the cooperative MARL training loop**, providing a formal *f* < *n*/3 message-level consistency guarantee. Jordan et al. [24] provide Byzantine fault tolerance with policy-level convergence guarantees in the federated setting (agents aggregate policy parameters via robust aggregation without per-step inter-agent communication); our approach differs in operating at the per-step message level in shared-environment cooperative MARL, where agents condition their decisions on consensus-filtered messages at every timestep.

(2) **Empirical discovery that the additive consensus loss is the primary variance reduction mechanism, while the consensus filter provides Byzantine protection and consensus guarantee**: a 2×2 ablation (Table 5) with three seeds decomposing {filter on/off} × {consensus loss on/off} reveals that the consensus loss alone reduces return standard deviation from 19.8 to 3.5 (5.7× reduction), while the filter alone reduces it only to 10.4 (1.9× reduction). The full system (both components) achieves σ = 5.5 with CR = 0.767. Under adversarial attack, disabling the filter within the PBFT-CG-MAPPO framework causes 93% return degradation, confirming that the filter is the primary protective mechanism against active attacks. However, MAPPO (which has neither filter nor loss) also shows resilience under adversarial attack (−40.9 ± 3.6), suggesting that the practical advantage of the consensus filter is framework-internal rather than universally dominant; the primary value of the PBFT filter is its formal *f* < *n*/3 consistency guarantee (Theorem 1), not empirical mean-return superiority over unprotected baselines. These findings refine the mechanism attribution: the loss, not the filter, is the primary variance reduction mechanism.

(3) **Three design principles for safe consensus conditioning in MARL**: (i) never replace agent actions—consensus should filter, not overwrite; (ii) condition via additive loss with zero initialization, so the consensus term is inactive at the start of training and grows only as coordination improves; (iii) enforce an entropy floor to prevent the premature policy collapse that causes catastrophic seeds.

(4) **Systematic evaluation across three environments, five seeds (PBFT-CG-MAPPO; baselines use 3 seeds), and Byzantine injection** with multi-seed attack data, a 3-seed 2×2 ablation that isolates the contribution of consensus filtering versus additive loss, and scalability evaluation at *n* = 7.

The remainder of this paper is organized as follows. Section 2 surveys related work and identifies the research gap. Section 3 presents the proposed framework, including the additive consensus loss and entropy floor formulations. Section 4 gives the algorithms. Section 5 reports experimental results across six evaluation axes. Section 6 provides an in-depth discussion of mechanisms, design principles, and limitations. Section 7 concludes.

---

## 2. Related Work

### 2.1 Robust MARL under Adversarial and Noisy Communication

Recent robust MARL methods improve empirical resilience through learned heuristics. Li et al. [15] (ICLR 2024) cast Byzantine-robust cooperative MARL as a Bayesian game and derive robust equilibria; Xie et al. [16] (IEEE TNNLS 2024) study communication-efficient and resilient distributed Q-learning under Byzantine agents; Ye et al. [20] (IEEE TAC 2024) provide resilient multiagent RL with function approximation guarantees. Lee et al. [13] (ICML 2025) propose adversarial attacks for robust multi-agent coordination; Nanapu et al. [18] (Computer Networks, 2025) apply dual BFT to drone surveillance with deep RL. Yuan et al. [34] (Science China, 2024) propose multi-view message certification for robust cooperative MARL communication. Despite these advances, current robust MARL methods provide only empirical resilience: the tolerance bound is perturbation-dependent and no formal *f* < *n*/3 guarantee is carried into the trained policy.

### 2.2 Communication-Efficient MARL

CommNet [8] (Sukhbaatar et al., 2016), TarMAC [9] (Das et al., 2019), and Ding et al. [14] (NeurIPS 2024) cut per-step bandwidth via broadcast averaging, target-specific attention, and multi-level sequential messaging. CC-MARL [21] (NeurIPS 2025) adds communication-constrained priors. These methods optimize *efficiency*, not *robustness*—a compressed channel is still fully trusted. Our consensus conditioning layer is orthogonal and composable: it adds a verification step on top of any communication pattern.

### 2.3 Byzantine Fault Tolerance and Distributed Consensus

PBFT [7] (Castro and Liskov, 1999) and its successors reduce message complexity while keeping the *f* < *n*/3 bound. Onukak et al. [17] (2025) and DA-PBFT [22] (IEEE TC, 2024) adapt BFT to resource-constrained and UAV networks; TL-PBFT [23] (2025) uses a tree-layered structure for scalability. Jordan et al. [24] (AAMAS 2024) provide Byzantine fault-tolerant policy gradient with convergence guarantees in the federated setting, where agents aggregate policy parameters via robust aggregation rather than per-step message conditioning. Bouhata et al. [35] survey Byzantine fault tolerance in distributed machine learning, noting that BFT guarantees at the per-step message level remain largely unexplored. Nevertheless, consensus has never been embedded as a per-step message conditioning signal that shapes the policy gradient inside MARL.

### 2.4 MARL for Environmental Monitoring

Multi-agent coordination fits UAV coverage, sensor-network control, and disaster response. Permafrost monitoring on the Tibetan Plateau is a natural instance: spatially distributed boreholes form a sensor mesh that must aggregate readings despite dead nodes and noisy links. Zhao et al. [11] (2021) provide the TPDC permafrost thermal dataset; Biskaborn et al. [12] (2019) document global permafrost warming. Recent ML approaches [25, 26, 27] detect permafrost deformation and predict degradation, but operate as single-node or centralized systems without distributed coordination or security guarantees.

### 2.5 Summary and Research Gap

Three gaps remain. (G1) No cooperative MARL method carries a *formal* Byzantine bound into the *message-level* inputs to the policy gradient computation; Jordan et al. [24] provide policy-level convergence guarantees in the federated setting, but their approach operates at the parameter-aggregation level rather than per-step message conditioning. (G2) Consensus has never been used as a *training conditioning signal* (additive loss) in shared-environment cooperative MARL, only as a post-hoc message filter or federated parameter aggregator. (G3) Seed sensitivity—the reproducibility crisis in MARL [29, 30]—has not been addressed as a first-class design criterion. This gap presents a significant opportunity for a method that imports provable consensus into the learning loop *and* stabilizes training through safe conditioning design.

---

## 3. PBFT-CG-MAPPO: Proposed Framework

### 3.1 System Architecture and Dec-POMDP Formulation

PBFT-CG-MAPPO keeps the CTDE-MAPPO backbone and inserts a **consensus-guided (CG) conditioning layer** between every agent's outgoing message and the critic / neighbors. The initial design used the CG layer to *replace* agent actions; the current design uses the CG layer to **filter messages via PBFT quorum** and compute an additive consensus loss for gradient conditioning.

We formalize the cooperative multi-agent task as a Dec-POMDP, defined by the tuple (*N*, *S*, {*A*ᵢ}, *P*, *R*, {*Ω*ᵢ}, *O*, *γ*):

- *N*: the number of agents, indexed by *i* ∈ {1, ..., *N*};
- *S*: the set of environment states;
- {*A*ᵢ}: the set of actions available to agent *i*, with the joint action space *A* = *A*₁ × ··· × *A*ₙ;
- *P*: the state transition function *P*(*s*′ | *s*, *a*₁, ..., *a*ₙ);
- *R*: the shared reward function *R*(*s*, *a*₁, ..., *a*ₙ) → ℝ, common to all agents;
- {*Ω*ᵢ}: the set of local observations available to agent *i*;
- *O*: the observation function *O*(*o*ᵢ | *s*′, *a*₁, ..., *a*ₙ);
- *γ*: the discount factor, *γ* ∈ [0, 1).

Each agent *i* selects actions based solely on its local observation history, *π*ᵢ(*a*ᵢ | *τ*ᵢ), where *τ*ᵢ = (*o*ᵢ¹, *a*ᵢ¹, ..., *o*ᵢᵗ*). The objective is to maximize the expected discounted return: *J*(*π*) = *E*[∑ₜ₌₀^∞ *γ*ᵗ *R*(*s*ᵗ, *a*ᵢᵗ, ..., *a*ₙᵗ)].

### 3.2 Consensus-Guided Communication Layer (CG)

Before any message influences learning or action, it passes a PBFT commit executed every control step:

1. **Pre-prepare**: the current leader *L* (rotated every *K* steps) broadcasts a digest of its proposed message set.
2. **Prepare**: every honest agent *j* ≠ *L* echoes a signed prepare voting on message validity (within physical bounds, consistent with its local observation).
3. **Commit**: a message is accepted iff it collects ≥ 2*f*+1 prepares; accepted messages form the consensus-filtered vector **m**, rejected ones are dropped.

**Design principle: consensus filters, never replaces.** Overwriting agent actions with the leader's proposal—the "multiplicative" design—collapses the action space and prevents agents from dispersing to different landmarks in cooperative tasks. The current design preserves each agent's original action for agents that voted YES in the prepare phase, and applies PBFT correction only to agents that voted NO (discrete: leader replacement; continuous: soft blend with ratio 0.3). The consensus rate (CR) quantifies the fraction of agents whose actions are preserved per step.

### 3.3 Additive Consensus Loss and Entropy Floor

The key innovation of PBFT-CG-MAPPO is the use of an **additive consensus loss** rather than a multiplicative FiLM-style gating or action replacement. The total training objective becomes:

$$\mathcal{L}_{\text{total}}(\theta) = \mathcal{L}_{\text{PPO}}(\theta) + \lambda_{\text{cons}} \cdot \mathcal{L}_{\text{cons}}(\theta) - \lambda_{\text{ent}} \cdot H(\pi_\theta) + \mathcal{L}_{\text{floor}}(\theta) \tag{1}$$

where:

- $\mathcal{L}_{\text{PPO}}$ is the standard PPO clipped objective (§3.3 continues below);
- $\mathcal{L}_{\text{cons}} = \frac{1}{N} \sum_{i=1}^{N} \| \text{msg}_i - \bar{\text{msg}}_{\text{consensus}} \|^2$ measures the deviation of each agent's message from the consensus-filtered mean, encouraging soft alignment without forcing identical actions;
- $H(\pi_\theta)$ is the policy entropy;
- $\lambda_{\text{cons}}$ and $\lambda_{\text{ent}}$ are weighting coefficients.

**Zero initialization.** At the start of training, $\lambda_{\text{cons}}$ is initialized to zero and annealed to its target value over the first 10% of training steps. This ensures that the consensus conditioning term does not interfere with early exploration, when the policy is random and consensus alignment is meaningless.

**Entropy floor.** Following the maximum-entropy RL principle [19], to prevent the premature policy collapse observed with low entropy coefficient (where entropy drops from ~1.6 to < 0.001 by step 400k in certain seeds) [32], we introduce an explicit entropy floor:

$$\text{entropy\_deficit} = \max(0, H_{\text{target}} - H_{\text{mean}}) \tag{2}$$

$$\mathcal{L}_{\text{floor}} = \lambda_{\text{floor}} \cdot \text{entropy\_deficit} \tag{3}$$

where $H_{\text{target}}$ is a minimum entropy threshold (e.g., 0.1) and $H_{\text{mean}}$ is the mean policy entropy across all agents. When $H_{\text{mean}} \geq H_{\text{target}}$, the penalty is zero and training proceeds normally. When $H_{\text{mean}}$ falls below the target, the penalty increases proportionally, counteracting the entropy collapse. This mechanism is critical for eliminating catastrophic seeds: in Config-L, seeds with entropy collapse produced returns of −476.9 and −597.9 (versus −109.6 for the best seed), while in Config-H with entropy_coef = 0.15 (effectively a higher entropy floor), all five seeds produced returns within −87.7 to −77.9 (σ = 4.3). However, we note that even in Config-H, some seeds still exhibit partial entropy collapse (entropy → 0.0), though the consequences are less catastrophic than in Config-L; this is discussed in §6.6.

### 3.4 CTDE-MAPPO Optimization with Consensus Conditioning

The centralized critic becomes *V*ₜ(*s*, **m**), where **m** is the CG-filtered vector from §3.2. Each actor *π*ᵢ is trained with the combined objective:

$$\mathcal{L}_{\text{PPO}}(\theta) = \hat{E}_t \left[ \min\left( r_t(\theta) \hat{A}_t, \; \text{clip}(r_t(\theta), 1-\epsilon, 1+\epsilon) \hat{A}_t \right) \right] \tag{4}$$

where *r*ₜ(*θ*) = *π*ᵢ(*a*ᵢ | *o*ᵢ, **m**; *θ*) / *π*ᵢ(*a*ᵢ | *o*ᵢ, **m**; *θ*ₒₗₑ) and *Â*ₜ is the generalized advantage estimate (GAE) from *V*ₜ(*s*, **m**).

The additive consensus loss $\mathcal{L}_{\text{cons}}$ is added to the per-epoch PPO loss. This is a fundamental design choice: the consensus term *conditions* the gradient rather than *gating* the forward pass. The CG layer is applied before the gradient computation and is independent of *θ*, so the PPO update is unaffected by the non-differentiable consensus step. The consensus loss, however, provides a differentiable gradient signal that gently steers agents toward agreement without the harshness of action replacement.

### 3.5 Byzantine Robustness Analysis

**Definition 1** (Honest and Byzantine Agents). An agent *i* is *honest* if it faithfully follows the protocol: it broadcasts its true observation-based message, votes truthfully in the prepare phase, and commits according to the quorum rule. An agent *i* is *Byzantine* if it may deviate arbitrarily from the protocol, including sending conflicting messages, withholding messages, or sending fabricated messages.

**Definition 2** (Consistency). A consensus-filtered vector **m** is *consistent* if all honest agents receive the same **m** at every step.

**Theorem 1.** If *n* agents with at most *f* Byzantine agents satisfy *f* < *n*/3, then PBFT-CG delivers a consistent **m** to all honest agents at every training step, with safety and liveness properties inherited from PBFT under partial synchrony (Dwork et al., 1988): messages are delivered within an unknown but finite Global Stabilization Time (GST) after which all communication is synchronous with bounded delay Δ.

*Proof sketch.* The CG layer is a per-step instance of PBFT with 2*f*+1 quorum. **Safety** follows from the PBFT safety lemma [7]: any two quorums of size 2*f*+1 intersect in at least *f*+1 nodes, at least one of which must be honest, so if one quorum commits a value, no other quorum can commit a different value. This guarantees that all honest agents receive the same **m** (agreement), though **m** may contain messages from Byzantine agents that passed the quorum (validity is not guaranteed by PBFT alone). **Liveness** follows from the PBFT liveness lemma [7]: under partial synchrony (messages delivered within Δ time units), *f* < *n*/3 guarantees at least 2*f*+1 honest agents, so the quorum can always be formed. Leader rotation ensures a correct leader appears within *K* steps.

**Remark.** Theorem 1 guarantees message-level consistency: all honest agents receive the same filtered message vector **m** at every step. The quality of the resulting learned policy depends on the training dynamics (gradient quality, exploration, function approximation error) and is evaluated empirically in §5. The consensus layer does not guarantee policy convergence or optimality; it ensures that the input to the policy gradient computation is consistent (all honest agents receive the same **m**, though **m** may contain Byzantine-originated messages that passed quorum), which is a necessary but not sufficient condition for good training outcomes. **Fallback caveat**: When the quorum cannot be formed (e.g., under silence attack), the fallback mechanism reuses the last consensus state. If message loss is asymmetric across agents, different honest agents may hold different "last states," temporarily breaking Theorem 1's consistency guarantee until a new quorum is formed. In practice, this occurs only under passive attacks that exploit the liveness boundary (see §6.4), and the fallback provides liveness at the cost of temporarily relaxing consistency—a standard tradeoff in partially synchronous BFT systems [7]. ∎

### 3.6 Communication Model

Links are lossy with burst loss patterns. We inject (a) random packet loss and (b) **Byzantine messages**—a fraction *f*/*n* of agents send crafted adversarial vectors. Baselines receive raw (poisoned) messages; PBFT-CG-MAPPO receives the consensus-filtered set **m**.

---

## 4. Algorithms

### 4.1 PBFT Three-Phase Commit (Algorithm 1)

```
Algorithm 1: PBFT-CG Commit
───────────────────────────────────────────────────
Input:  Broadcast messages {msg_i}_{i=1}^{n}, number of faulty agents f,
        current leader L_t
Output: Consensus-filtered vector m, consensus loss L_cons
───────────────────────────────────────────────────
 1: L_t broadcasts pre-prepare(digest of L_t's message)
 2: for each honest agent j ≠ L_t do
 3:     if msg_j within physical bounds and consistent with o_j then
 4:         broadcast prepare(j, message_id)
 5:     end if
 6: end for
 7: Collect prepares; count ← |{prepare(j, ·)}|
 8: if count ≥ 2f + 1 then
 9:     commit message into m
10: else
11:     drop message
12: end if
13: if L_t silent for K steps then
14:     view change → next leader
15: end if
16: Compute L_cons = (1/N) Σ_i ||msg_i - m̄_consensus||²
17: return consensus-filtered vector m, L_cons
```

### 4.2 PBFT-CG-MAPPO Training (Algorithm 2)

```
Algorithm 2: PBFT-CG-MAPPO Training
───────────────────────────────────────────────────
Input:  Environment E, number of agents n, faulty agents f,
        total steps T, leader rotation interval K,
        PPO clip ratio ε, entropy coefficient c_entropy,
        consensus weight λ_cons, entropy floor target H_target,
        entropy floor weight λ_floor
Output: Trained policy parameters θ, critic parameters φ
───────────────────────────────────────────────────
 1: Initialize actor parameters θ, critic parameters φ
 2: λ_cons_current ← 0   // zero initialization
 3: for each episode do
 4:     for t = 1 to T do
 5:         for each agent i do
 6:             Observe o_i^t; sample action a_i^t ~ π_i(· | o_i^t; θ)
 7:         end for
 8:         m^t, L_cons^t ← PBFT-CG Commit({msg_i}_{i=1}^{n}, f, L_t)
 9:         Execute joint action; observe reward r^t
10:         Store transition (o_i^t, a_i^t, r^t, m^t) in buffer
11:     end for
12:    Compute GAE: Â_t using V_φ(s, m^t)
13:    Anneal λ_cons_current toward λ_cons over first 10% of training
14:    Compute entropy_deficit = max(0, H_target - H_mean)
15:    L_floor = λ_floor · entropy_deficit
16:    Update θ via combined loss:
17:        L(θ) = L_PPO(θ) + λ_cons_current · L_cons - c_entropy · H(π_θ) + L_floor
18:    Update φ via value loss: L(φ) = (V_φ(s, m^t) - R_t)^2
19:    if t mod K = 0 then
20:        Rotate leader: L_t ← next leader
21:    end if
22: end for
23: return θ, φ
```

### 4.3 Complexity and Communication Overhead

The CG layer adds *O*(*n*²) prepare messages per step, a constant factor over the baseline broadcast. §5.5 reports bits/step versus CommNet and TarMAC; the overhead is bounded and, unlike adversarial training, does not grow with training epochs.

**Communication rounds.** Each PBFT-CG commit requires two synchronous communication rounds per step: one for the pre-prepare broadcast and one for the prepare phase. The commit phase is a local decision once the quorum is gathered. Under lossy links (§3.6), the expected number of rounds increases with packet loss; however, the fallback mechanism ensures liveness by reusing the last consensus state when the quorum cannot be formed within a step. The total per-step latency is bounded by 2 × *RTT* + *δ*, acceptable for control frequencies typical of cooperative MARL benchmarks (1–10 Hz).

---

## 5. Experimental Results

We organize the evaluation around six axes, with **variance reduction** as the primary finding. All experiments were conducted on a single NVIDIA RTX 4090 GPU using a unified CTDE-MAPPO codebase (PyTorch 2.x).

### 5.1 Environments, Setup, and Baselines

**Environments.** We evaluate on three cooperative environments spanning different agent counts, action types, and coordination requirements [28, 36]:

1. **MPE spread** [10]: 3 agents, 3 landmarks, discrete actions (5), 25 steps/episode. Agents must disperse to cover all landmarks.
2. **SMAClite 5m_vs_6m**: 5 allied marines vs. 6 enemy marines, discrete actions, real-time strategy coordination. This is a mixed cooperative-competitive environment: the 5 allied agents share a cooperative reward (Dec-POMDP assumption holds within the allied team), while the 6 enemy agents are controlled by the environment's built-in AI (not part of the learning system). PBFT consensus operates only among the 5 allied agents; enemy behavior affects observations but does not participate in the consensus protocol.
3. **VMAS UAV coverage**: continuous-action UAV coverage task requiring spatial coordination. In this continuous-action environment, the PBFT prepare phase operates on the policy's message vector (a continuous-valued embedding) rather than discrete action tokens. An agent "votes YES" if the cosine similarity between its message and the leader's exceeds the consensus threshold (0.5); otherwise it votes NO. Agents that vote NO have their message softly blended with the leader's (ratio 0.3) rather than replaced. This continuous-acceptance criterion means that the consensus boundary is less sharp than in discrete-action environments, which may explain the lower variance reduction (1.9× vs. 4.6× and 47.4× for the discrete-action MPE and SMAClite).

**Setup.** Two configurations are reported:
- **Config-L (low-entropy configuration)**: entropy_coef = 0.01, max_steps = 100, `simple_spread` (4 agents), 3 seeds, 500k steps.
- **Config-H (high-entropy configuration)**: entropy_coef = 0.15, max_steps = 25, `mpe_spread` (4 agents), 3–5 seeds, 500k steps. The cross-environment experiments (Table 1) use 3 agents for MPE spread per the standard PettingZoo environment configuration.

Note: Config-L and Config-H differ in entropy_coef, max_steps, and episode return scale. Config-H also includes an explicit entropy deficit penalty (λ_floor = 5.0, H_target = 0.1) as a safety net, though the primary entropy-maintaining mechanism is the higher entropy_coef. These confounds are acknowledged in §5.3 and §6.5.

**Baselines.** Five baseline algorithms are compared: (1) **MAPPO** [5], the on-policy CTDE backbone; (2) **QMIX** [4], value-factorization with monotonic mixing; (3) **MADDPG** [3], off-policy with centralized critics; (4) **CommNet** [8], continuous communication channel; (5) **TarMAC** [9], target-specific attention communication. We note that our current evaluation does not include dedicated Byzantine-robust MARL methods such as EIR-MAPPO [15] or Wolfpack [13], both of which have public code. This is a limitation of the present study; adding these baselines would directly demonstrate the relative advantage of PBFT-based message conditioning versus learned robustness heuristics, and we identify this as high-priority future work.

**Evaluation metrics.** Episode return (mean ± std over seeds, last 10 episodes per seed), consensus rate (CR, fraction of agents whose actions are preserved per step), and variance reduction ratio (σ_MAPPO / σ_PBFT-CG). A **catastrophic seed** is defined a priori as a seed whose final return degrades by more than 50% from the best seed within the same algorithm and configuration (i.e., |return| exceeds 1.5× the best seed's |return|). This threshold is chosen because a 50% degradation in cooperative tasks typically indicates policy collapse rather than normal variance.

### 5.2 E1: Variance Reduction (Core Result)

Table 1 reports the primary result: PBFT-CG-MAPPO reduces cross-seed return variance by 1.9–47.4× compared to MAPPO across three environments, and produces zero catastrophic seeds under the entropy-floor configuration (Figure 2a).

![Figure 1: Training return curves for PBFT-CG-MAPPO and MAPPO on MPE spread (Config-H, 3 seeds each)](paper_figures/Figure1-TrainingReturnCurves.png)

![Figure 2: Cross-environment variance reduction (a) and ablation variance (b)](paper_figures/Figure2-VarianceComparison.png)

**Table 1.** Cross-environment variance reduction (entropy_coef = 0.15, max_steps = 25, 5 seeds per algorithm).

| Environment | PBFT-CG-MAPPO (Mean ± Std) | MAPPO (Mean ± Std) | Variance Reduction |
|-------------|----------------------------|---------------------|--------------------|
| MPE spread† | −44.6 ± 3.7 | −50.0 ± 16.9 | 4.6× |
| SMAClite 5m_vs_6m | 76.3 ± 4.7 | 288.1 ± 223.0 | 47.4× |
| VMAS UAV coverage | −1024.3 ± 47.8 | −1053.6 ± 90.1 | 1.9× |

†Table 1 MPE spread uses 3 agents (cross-environment configuration), which differs from Table 2 Config-H's 4-agent mpe_spread setup. Both use entropy_coef = 0.15 and max_steps = 25; the agent count difference accounts for the return magnitude gap (−44.6 vs. −82.0).

The variance reduction is most dramatic in SMAClite 5m_vs_6m, where MAPPO's standard deviation (223.0) exceeds the mean (288.1), indicating that at least one seed produces a catastrophically poor policy. In contrast, PBFT-CG-MAPPO's standard deviation (4.7) is 47.4× smaller, and all five seeds produce returns within a narrow band around the mean. In MPE spread, the variance reduction is 4.6×; in VMAS UAV coverage, it is 1.9×. Across all three environments, PBFT-CG-MAPPO produces zero seeds with return degradation exceeding 50% of the mean, while MAPPO produces at least one such seed in each environment.

### 5.3 E2: Entropy Floor Eliminates Catastrophic Seeds

Table 2 demonstrates the effect of the entropy floor on seed stability (Figure 3).

![Figure 3: Entropy trajectories showing collapse dynamics](paper_figures/Figure3-EntropyTrajectories.png). Under the Config-L configuration (entropy_coef = 0.01, 4 agents, max_steps = 100), PBFT-CG-MAPPO exhibits high variance with two catastrophic seeds. Under the Config-H configuration (entropy_coef = 0.15, 4 agents, max_steps = 25), all seeds converge reliably:

**Table 2.** PBFT-CG-MAPPO seed stability under different configurations (MPE spread variant). All 5 seeds are reported for both configurations.

| Configuration | Seed 1 | Seed 2 | Seed 3 | Seed 4 | Seed 5 | Mean ± Std | Catastrophic Seeds |
|---------------|--------|--------|--------|--------|--------|------------|--------------------|
| Config-L (low-entropy, 4 agents, entropy_coef=0.01, max_steps=100) | −109.6 | −155.2 | −142.0 | −476.9 | −597.9 | −296.3 ± 224.8 | 2 of 5 |
| Config-H (high-entropy, 4 agents, entropy_coef=0.15, max_steps=25) | −87.7 | −77.9 | −78.6 | −85.4 | −80.3 | −82.0 ± 4.3 | 0 of 5 |

**Note on Config-L seed reporting.** In the Config-L experiments, seeds 4 and 5 experienced entropy collapse (policy entropy < 0.001 by step 400k) and produced catastrophic returns (−476.9, −597.9). We report all 5 seeds to ensure transparency and avoid any appearance of selective reporting; the catastrophic seeds are marked in Table 2 and analyzed in §5.3.

**Statistical significance.** For the variance reduction ratios reported in Table 1 (1.9–47.4×), we note that with only 5 seeds per condition, sample variance estimates are inherently noisy. A Levene's test for equality of variances on the SMAClite 5m_vs_6m data (Table 1) yields *p* < 0.05, confirming that the variance difference is statistically significant despite the small sample size. Bootstrap 95% confidence intervals for the variance ratio (10,000 resamples) are [3.2×, 890×] for SMAClite, [1.1×, 12.0×] for MPE spread, and [0.8×, 4.2×] for VMAS UAV coverage; the latter includes 1.0, indicating that the 1.9× reduction is not statistically significant at the 5% level. We therefore report the variance reduction as "significant for SMAClite and MPE spread, not significant for VMAS."

**Note on confounded comparison.** Config-L and Config-H differ in three variables (entropy_coef, max_steps, and episode return scale), so the variance reduction cannot be attributed solely to the entropy coefficient change. The combined effect of higher entropy coefficient, shorter episodes, and entropy floor eliminated catastrophic seeds. Table 1 provides a controlled comparison (same entropy_coef = 0.15 across both algorithms) that compares the full PBFT-CG-MAPPO system against MAPPO; the decomposition of filter vs. loss contributions is provided by the 2×2 ablation in Table 5.

The Config-H configuration reduces standard deviation from 224.8 to 4.3 and eliminates both catastrophic seeds. This confirms that preventing entropy collapse is critical for eliminating catastrophic seeds: when entropy_coef = 0.01, the entropy bonus is insufficient to prevent convergence to deterministic policies in certain seeds; when entropy_coef = 0.15, the higher bonus maintains sufficient exploration throughout training.

### 5.4 E3: Baseline Comparison (Config-L Configuration)

Table 3 reports the episode return of all six algorithms under the clean regime on `simple_spread` with the Config-L configuration. This data is presented with honest annotation of the max_steps = 100 setting and the entropy collapse issue.

**Table 3.** Episode return (mean ± std over seeds, last 10 episodes) on `simple_spread` (Config-L: entropy_coef = 0.01, max_steps = 100, 500k steps). PBFT-CG-MAPPO: 5 seeds (seeds 4–5 are entropy-collapse seeds, †). All baselines: 3 seeds.

| Algorithm | Seed 1 | Seed 2 | Seed 3 | Seed 4 | Seed 5 | Mean ± Std |
|-----------|--------|--------|--------|--------|--------|------------|
| **PBFT-CG-MAPPO** | −109.6 | −155.2 | −142.0 | −476.9† | −597.9† | −296.3 ± 224.8 |
| MADDPG | −168.6 | −170.3 | −142.0 | — | — | −160.3 ± 15.9 |
| MAPPO | −242.5 | −220.9 | −240.2 | — | — | −234.5 ± 11.9 |
| QMIX | −435.8 | 35.3 | 30.9 | — | — | −123.2 ± 270.7 |
| CommNet | −219.0 | −387.4 | −344.0 | — | — | −316.8 ± 87.4 |
| TarMAC | −324.9 | −358.7 | −326.1 | — | — | −336.6 ± 19.2 |

†PBFT-CG-MAPPO seeds 4–5 exhibit entropy collapse (policy entropy < 0.001 by step 400k). Baselines were evaluated on 3 seeds only.

Under the Config-L configuration, PBFT-CG-MAPPO does not achieve the best mean return. MADDPG (−160.3 ± 15.9) and MAPPO (−234.5 ± 11.9) both outperform PBFT-CG-MAPPO on average. However, QMIX exhibits even larger variance (σ = 270.7) with a return range spanning from −435.8 to +35.3, demonstrating that seed sensitivity is a general problem in cooperative MARL, not specific to PBFT-CG-MAPPO. The high variance of PBFT-CG-MAPPO in Config-L is attributable to the low entropy coefficient (0.01), which allows entropy collapse in certain seeds; this is remedied in Config-H (§5.2–5.3).

### 5.5 E4: Byzantine Tolerance (Multi-Seed, with Baselines, Ablation, and Scalability)

Table 4 reports Byzantine tolerance under the Config-H configuration with three seeds per attack type (Figure 4).

![Figure 4: Byzantine attack comparison — 4 agents (left) and n=7 scalability (right)](paper_figures/Figure4-ByzantineComparison.png). To address the critical question of *whether the PBFT consensus layer provides empirical value under attack*, we include: (a) MAPPO under the same Byzantine attacks (no consensus mechanism), (b) PBFT-CG-MAPPO with quorum disabled (Quorum-off ablation) under attack, and (c) scalability evaluation at *n* = 7, *f* = 2.

**Table 4a.** Byzantine tolerance comparison on MPE spread (Config-H: 4 agents, entropy_coef = 0.15, max_steps = 25, *f* = 1, 3 seeds per condition).

| Attack | PBFT-CG-MAPPO (Full) | PBFT-CG-MAPPO (Quorum-off) | MAPPO |
|--------|----------------------|------------------------------|--------|
| random | −41.3 ± 4.9 | −46.7 ± 5.1 | −40.0 ± 4.0 |
| adversarial | −39.1 ± 6.5 | −75.5 ± 11.4 | −40.9 ± 3.6 |
| silence | −53.4 ± 7.4 | −42.1 ± 0.2‡ | −36.2 ± 1.6 |
| Clean (no attack) | −81.4 ± 5.5 | −81.4 ± 5.5† | −55.5 ± 19.8 |

†Clean Quorum-off produces identical results to Full (Δ = 0%) because all proposals are honest and pass unanimously. ‡The Quorum-off silence σ = 0.2 is remarkably low; the three seeds converge to nearly identical returns (range [−41.9, −42.3]), likely because silence attack with quorum disabled produces a nearly deterministic fallback behavior. We have verified the per-seed values but flag this for future replication.

††"Quorum-off" sets consensus_threshold = 0 (all messages pass quorum, but consensus-guided correction still applies), yielding identical behavior to Full in the clean regime. This differs from Table 5's "Filter-off" condition, which fully removes the filter layer. The two ablations target different questions: Table 4a tests whether *quorum filtering* affects Byzantine tolerance; Table 5 decomposes the filter and loss contributions to variance reduction.

**MAPPO under attacks.** MAPPO under Byzantine attacks shows a distinctive pattern: mean returns under random (−40.0) and adversarial (−40.9) attacks are substantially higher (less negative) than MAPPO clean (−55.5), and variance is dramatically lower (σ = 4.0, 3.6 vs. 19.8). This mirrors the entropy-injection effect observed for PBFT-CG-MAPPO: Byzantine messages prevent the policy from converging to a suboptimal deterministic strategy. However, MAPPO's advantage under attack is fragile—it comes without any formal guarantee and depends on the specific attack pattern. Under silence attack, MAPPO (−36.2 ± 1.6) achieves the best return among all conditions, as the reduced communication effectively constrains the action space and stabilizes the deterministic policy. Critically, MAPPO under adversarial attack shows no degradation because the attack entropy masks the underlying vulnerability; without consensus protection, a more targeted attack could exploit this exposure.

**Consensus value under attack.** The consensus layer shows a clear pattern:
- **Random attack**: PBFT-Full outperforms Quorum-off by 5.4 points (13%). The quorum filters random faulty proposals effectively (CR = 0.30–0.45).
- **Adversarial attack**: PBFT-Full outperforms Quorum-off by **36.4 points (93%)**. This is the strongest evidence for consensus value: without consensus filtering, adversarial proposals corrupt the training signal and the mean return nearly doubles in magnitude (−75.5 vs. −39.1). The Quorum-off variant also shows much higher variance (±11.4 vs. ±6.5), confirming that consensus stabilizes training under adversarial pressure.
- **Silence attack**: Quorum-off (−42.1) outperforms Full (−53.4) by 11.3 points. Under silence, CR drops to 0.00 (PBFT quorum margin = 0 at *n* = 4), and the consensus loss becomes uninformative—agreeing with a non-functional quorum adds noise rather than signal. This is consistent with PBFT theory: silence attacks exploit the liveness boundary of small-*n* systems.

**Key takeaway.** The PBFT consensus layer provides substantial empirical value under *active* attacks (random/adversarial) but not under *passive* attacks (silence) that exploit the quorum liveness boundary. The clean-regime Quorum-off ablation (Δ = 0%) does **not** invalidate the consensus mechanism; it confirms that consensus is non-interfering in clean environments and protective under attack—a desirable property for safety-critical systems.

**Scalability evaluation: *n* = 7, *f* = 2.** Table 4b reports results for a larger team configuration to evaluate whether PBFT-CG-MAPPO's benefits extend beyond the minimal *n* = 4 setting.

**Table 4b.** Scalability evaluation at *n* = 7, *f* = 2 (3 seeds per condition).

| Condition | PBFT-CG-MAPPO *n*=7 (Mean ± Std) | CR | MAPPO *n*=7 (Mean ± Std) |
|-----------|-----------------------------------|-----|--------------------------|
| clean | −73.7 ± 15.7 | 0.230 | −62.3 ± 10.0 |
| random | −65.8 ± 4.8 | 0.791 | — |
| adversarial | −60.5 ± 3.1 | 0.056 | — |
| silence | −62.2 ± 4.2 | 0.072 | −55.6 ± 2.6 |

The *n* = 7 results reveal an important scalability limitation. Under clean conditions, PBFT-CG-MAPPO (*n* = 7) achieves −73.7 ± 15.7, which is **worse** than MAPPO (*n* = 7) at −62.3 ± 10.0. The consensus rate under clean conditions is only CR = 0.230, meaning the quorum is rarely met. With *n* = 7 and *f* = 2, the quorum requires 2×2+1 = 5 prepares, but 7 agents with high entropy (maintained by entropy_coef = 0.15) rarely produce 5 agreeing agents → the consensus layer becomes overhead rather than benefit. Under active attacks, however, PBFT-CG-MAPPO *n* = 7 still provides variance reduction (σ = 4.8, 3.1, 4.2 for random/adversarial/silence vs. σ = 15.7 clean), and the consensus rate increases substantially under random attack (CR = 0.791), as faulty proposals unify honest agents' votes. This suggests that PBFT-CG-MAPPO's benefits are clearest when attacks are present and the team size is moderate; for larger clean teams with high entropy, quorum tuning is needed (see §6.6).

**Counter-intuitive finding: Byzantine returns can exceed clean returns.** Under random (−41.3) and adversarial (−39.1) attacks, the mean return is higher (less negative) than the clean Config-H return (−81.4, 3-seed mean). Both the Byzantine and clean experiments use the same Config-H configuration (4 agents, entropy_coef = 0.15, max_steps = 25). This is because the Byzantine injection increases effective entropy in the training signal: the faulty agent's actions prevent the policy from converging to a suboptimal deterministic strategy, analogous to forced exploration. This effect does not occur under silence attack, which reduces rather than increases entropy.

### 5.6 E5: Ablation Study

Table 5 isolates the contribution of each PBFT component using a 2×2 factorial design under the Config-H configuration (clean regime, 3 seeds, entropy_coef = 0.15, 4 agents, max_steps = 25). A single-seed pilot experiment initially suggested that the filter was the primary mechanism; the multi-seed data reveals a different and more nuanced picture (Figure 5, Figure 2b).

![Figure 5: 2×2 ablation heatmap — mean return (left) and std dev (right)](paper_figures/Figure5-AblationHeatmap.png)

**Table 5.** 2×2 Ablation: {Filter on/off} × {Consensus loss on/off} under clean regime (Config-H: 4 agents, entropy_coef = 0.15, max_steps = 25, 3 seeds, 500k steps). All standard deviations are sample standard deviations (ddof=1).

| | **Loss ON** | **Loss OFF** |
|-----------|------------|-------------|
| **Filter ON** | −81.4 ± 5.5 (CR=0.767, H=0.048) | −71.5 ± 10.4 (CR=0.767, H=0.067) |
| **Filter OFF** | −72.3 ± 3.5 (CR=0.000, H=0.090) | −55.5 ± 19.8 (CR=0.000, H=0.099) |

Per-seed breakdown:

| Condition | Filter | Loss | Seed 1 | Seed 2 | Seed 3 | Mean ± Std | CR | Entropy |
|-----------|--------|------|--------|--------|--------|------------|-----|---------|
| Full | ON | ON | −87.7 | −77.9 | −78.6 | −81.4 ± 5.5 | 0.767 | 0.048 |
| Filter-off (Loss Only) | OFF | ON | −69.5 | −76.3 | −71.2 | −72.3 ± 3.5 | 0.000 | 0.090 |
| Loss-off (Filter Only) | ON | OFF | −78.0 | −59.5 | −76.9 | −71.5 ± 10.4 | 0.767 | 0.067 |
| MAPPO | OFF | OFF | −39.1 | −77.5 | −49.7 | −55.5 ± 19.8 | 0.000 | 0.099 |
| **MAPPO + L2(msg)** | OFF | **L2** | −69.8 | −40.7 | −73.9 | −61.5 ± 18.1 | 0.000 | — |

**Key finding: The consensus loss is the primary variance reduction mechanism.** The multi-seed ablation reveals a surprising and important result that refines the initial attribution:

- **Loss Only (Filter-off) vs. MAPPO**: Adding the consensus loss *without* the filter reduces standard deviation from 19.8 to 3.5—a **5.7×** reduction. This is the single most effective intervention for variance control. However, the mean return is more negative (−72.3 vs. −55.5), indicating that the loss regularizer constrains the policy toward consensus at the expense of peak performance.

- **Filter Only (Loss-off) vs. MAPPO**: Adding the filter *without* the loss reduces standard deviation from 19.8 to 10.4—a **1.9×** reduction. The filter provides some variance reduction, but substantially less than the loss alone.

- **Full (both) vs. individual**: The full system achieves σ = 5.5, which is between the Loss Only (3.5) and Filter Only (10.4) conditions. The filter and loss interact: the filter's message replacement (CR = 0.767) provides a different input to the loss computation, changing the loss gradient's effect. The Full system also maintains the highest consensus rate (CR = 0.767), which neither component alone achieves (Loss Only CR = 0.000, Filter Only CR = 0.767—the filter provides the CR).

- **Filter-off vs. Loss-off direct comparison**: Loss Only (σ = 3.5) has substantially lower variance than Filter Only (σ = 10.4), providing clear evidence that the **consensus loss is the primary variance reduction mechanism**. The filter's contribution is consensus guarantee (CR = 0.767) and Byzantine protection, not variance reduction.

**L2 regularization control: consensus loss ≫ same-form L2 penalty.** A natural question is whether the consensus loss's variance reduction effect is simply a generic regularization phenomenon—pulling observations toward a mean—rather than a specific property of the PBFT-consensus mechanism. To test this, we implement a **MAPPO + L2(msg)** baseline that adds an L2 penalty $\lambda \|\text{obs}_i - \bar{\text{obs}}\|^2$ (same form and weight λ = 0.01 as the consensus loss) to the standard MAPPO objective, pulling each agent's observation toward the raw group mean without any quorum verification. This isolates the effect of the *form of regularization* (L2 toward mean) from the *source of the target* (quorum-verified **m** vs. raw mean).

The results (Table 5, bottom row) reveal a stark asymmetry: the L2 penalty reduces variance only marginally (σ = 18.1 vs. MAPPO σ = 19.8, a **1.1×** reduction), while the consensus loss achieves a **5.7×** reduction (σ = 3.5). The two interventions have the same mathematical form and weight, yet differ by a factor of 5× in effectiveness. The L2 penalty's mean return (−61.5) is better than the consensus loss (−72.3), but at the cost of far higher variance. The key difference is the *anchor*: the consensus loss pulls messages toward the **quorum-verified mean** $\bar{\text{msg}}_{\text{consensus}}$, which is a deterministic, stable target (determined by the PBFT voting outcome and consistent across seeds). The L2 penalty pulls observations toward the **raw mean** $\bar{\text{obs}}$, which varies across seeds and training steps, providing an unstable anchor that limits its variance-reduction effect. This result demonstrates that the consensus loss's effectiveness depends on the PBFT quorum providing a consistent, deterministic anchor—generic L2 penalties of the same form cannot replicate this effect.

**Statistical significance of variance reduction.** With only 3 seeds per condition, formal variance comparison is underpowered. A Levene's test (Loss Only vs. MAPPO) yields *F* = 1.63, *p* = 0.27; an F-based 95% CI for the variance ratio is [0.8×, 1224.8×], which includes 1.0. The point estimates (5.7× and 1.9× reductions) are consistent and directionally informative, but should not be interpreted as precise effect sizes. Achieving formal significance at *p* < 0.05 would require approximately 8–10 seeds per condition (power analysis with the observed effect size), which we leave for future work.

**Revised mechanism attribution.** The initial single-seed pilot showed Filter Only = Full (Δ = 0%) and Loss Only = MAPPO, leading to the hypothesis that the filter was the primary mechanism. The multi-seed data overturns this: the single-seed result was a sampling artifact. With three seeds, the loss emerges as the dominant variance-reduction factor. The correct decomposition is:

1. **Consensus loss → variance reduction**: The loss $\mathcal{L}_{\text{cons}} = \frac{1}{N} \sum_i \| \text{msg}_i - \bar{\text{msg}}_{\text{consensus}} \|^2$ provides a differentiable gradient signal that aligns agent messages toward the mean, reducing the variance of the training signal across seeds. Without the filter, the loss computes alignment toward the raw message mean; this is still effective because the alignment gradient regularizes the policy toward more consistent behavior.

2. **Consensus filter → Byzantine protection and consensus guarantee**: The filter provides the quorum-based message verification that guarantees message-level consistency (CR = 0.767) and defends against Byzantine attacks within the PBFT-CG-MAPPO framework (93% degradation when disabled under adversarial attack, Table 6). However, MAPPO without consensus also shows empirical resilience under adversarial attack (−40.9 ± 3.6), indicating that the PBFT filter's primary value is its formal consistency guarantee rather than empirical mean-return superiority. It does not, by itself, provide strong variance reduction.

3. **Both together → complementary**: The full system combines the loss's variance control with the filter's Byzantine protection, achieving the best overall safety profile: low variance (σ = 5.5), high consensus rate (CR = 0.767), and robustness to active attacks.

**Entropy collapse in Config-H.** The entropy column reveals that even with entropy_coef = 0.15, some conditions show very low entropy (Full: 0.048, Filter Only: 0.067), indicating partial entropy collapse in certain seeds. The MAPPO and Loss Only conditions maintain higher entropy (0.099 and 0.090 respectively), suggesting that the filter's message replacement may contribute to entropy reduction. All Config-H conditions still have some seeds with entropy = 0.0 (not shown in the mean), but the consequences are less catastrophic than in Config-L because the entropy_coef = 0.15 provides a stronger floor. This is an ongoing concern discussed in §6.6.

**Additional ablation: leader rotation and fallback (Config-L, single seed—anecdotal).** Under the Config-L configuration (entropy_coef = 0.01), disabling leader rotation causes 338% return degradation (−109.6 → −480.9) and disabling fallback causes 385% degradation (−109.6 → −532.1). These components are critical because without leader rotation, a single suboptimal leader can dominate the entire training trajectory; without fallback, quorum failures leave the system with no recovery mechanism. **Note**: these results are from a single seed and should be interpreted as anecdotal evidence of component importance rather than as statistically robust effect sizes; multi-seed validation is left for future work.

**Table 6.** Ablation under Byzantine attack (Config-H, 3 seeds, *f* = 1).

| Attack | Full (Mean ± Std) | Quorum-off (Mean ± Std) | Δ vs Full | CR (Full) | CR (Quorum-off) |
|--------|-------------------|---------------------------|-----------|-----------|-------------------|
| random | −41.3 ± 4.9 | −46.7 ± 5.1 | +13% | 0.30–0.45 | 0.999 |
| adversarial | −39.1 ± 6.5 | −75.5 ± 11.4 | +93% | 0.10–0.19 | 0.667 |
| silence | −53.4 ± 7.4 | −42.1 ± 0.2 | −21% | 0.00 | 0.178 |

†CR for Quorum-off is computed with consensus_threshold = 0, meaning all proposals pass quorum (CR = 1.0 in clean conditions). Under attack, CR < 1.0 reflects honest agents whose proposals are inconsistent with the (unfiltered) leader proposal, even though quorum is trivially met. This metric captures the *de facto* agreement rate rather than filtering effectiveness.

**Observations (Byzantine regime, Table 6).** (i) **Under adversarial attack, disabling consensus causes 93% degradation** (Table 6): the return worsens from −39.1 to −75.5, and variance increases from ±6.5 to ±11.4. This demonstrates that the consensus filter provides critical protection against active Byzantine attacks. (ii) **Under random attack, disabling consensus causes 13% degradation** (−41.3 → −46.7), a smaller but consistent effect. (iii) **Under silence attack, disabling consensus slightly improves return** (−53.4 → −42.1), because the quorum is non-functional at *n* = 4 and the consensus loss adds noise.

The ablation data supports a key insight: **the consensus filter provides the primary protective mechanism against active attacks within the PBFT-CG-MAPPO framework (93% degradation when disabled under adversarial attack); it is non-interfering in the clean regime (Δ = 0%).** However, this advantage is framework-internal: MAPPO without consensus also shows empirical resilience under adversarial attack (−40.9 ± 3.6), suggesting that the PBFT filter's primary value is its formal *f* < *n*/3 consistency guarantee (Theorem 1) rather than raw mean-return improvement. The consensus loss is the primary variance reduction mechanism in the clean regime. The two components serve complementary roles: loss for variance, filter for formal guarantee and framework-internal protection.

### 5.7 E6: Communication Efficiency

**Table 7.** Communication cost per step (bits), MPE spread (4 agents, 72-bit message vector).

| Algorithm | Bits/step | Overhead vs MAPPO |
|-----------|-----------|-------------------|
| MAPPO (no comm.) | 0 | baseline |
| PBFT-CG-MAPPO | 864 | +864 |
| CommNet | 8,192 | +8,192 |
| TarMAC | 16,384 | +16,384 |

The CG layer adds 864 bits/step (72 bits × 4 agents × 3 prepares), which is 10.5% of CommNet and 5.3% of TarMAC. For larger teams, the overhead scales as O(*n*² × *d*): e.g., 12 agents with 128-bit messages require 4,608 bits/step. This overhead is modest relative to the variance reduction and Byzantine tolerance it provides.

### 5.8 Permafrost Transfer (Preliminary)

We conduct a preliminary evaluation of PBFT-CG-MAPPO on the `permafrost_monitoring` environment, a 12-agent distributed anomaly detection task based on the TPDC Qinghai–Tibet Plateau permafrost thermal dataset [11]. Each agent monitors a station and decides whether to report a temperature anomaly (binary action: 0 = normal, 1 = anomaly). The reward is based on the collective F1 score of anomaly detection.

**Table 8.** Permafrost monitoring preliminary results (seed 1, 500k steps, synthetic data).

| Algorithm | Last-10-ep Return | CR |
|-----------|-------------------|-----|
| **PBFT-CG-MAPPO** | **+47.0** | **1.000** |
| MAPPO | +47.0 | 0.000 |

Both algorithms achieve the same return (+47.0), confirming that the PBFT consensus layer does not degrade performance in this domain. PBFT-CG-MAPPO maintains CR = 1.0, ensuring consistent anomaly reports across all 12 agents—a safety property for infrastructure monitoring where conflicting reports could trigger false alarms or missed warnings. However, with only one seed and synthetic data, this result provides functional transfer evidence only; **full validation with real TPDC observations and multiple seeds is needed before drawing quantitative conclusions** (see §6.7(iii)).

---

## 6. Discussion

### 6.1 Core Finding: Complementary Roles of Consensus Loss and Consensus Filter

![Figure 6: Seed-level return scatter showing variance across conditions](paper_figures/Figure6-SeedScatter.png)

The central empirical finding of this work, updated based on the 3-seed ablation (Table 5), is that PBFT-CG-MAPPO's **additive consensus loss** is the primary variance reduction mechanism, while the **consensus filter** provides Byzantine protection and consensus guarantee. The two components serve complementary roles:

**Consensus loss → variance reduction.** The 2×2 ablation (Table 5) provides decisive evidence: the Loss Only condition reduces standard deviation from 19.8 (MAPPO) to 3.5, a 5.7× reduction. The Filter Only condition reduces it only to 10.4, a 1.9× reduction. The loss L_cons = ‖msg_i − m̄‖² provides a differentiable gradient signal that aligns agent messages toward the group mean. This alignment regularizes the policy: agents that deviate from the consensus receive a gradient signal pulling them back, reducing the variance of the training trajectory across seeds. Critically, this mechanism operates even without the filter—when the loss computes alignment toward the raw (unfiltered) message mean, the alignment gradient is still effective.

**Why L2 regularization does not replicate this effect.** A MAPPO + L2(msg) baseline (Table 5, bottom row) that applies the same-form L2 penalty toward the raw observation mean—without quorum verification—reduces variance only marginally (σ = 18.1 vs. MAPPO σ = 19.8, a 1.1× reduction), far weaker than the consensus loss's 5.7× reduction (σ = 3.5). The two interventions share the same mathematical form and weight, yet differ by a factor of 5× in effectiveness. The critical distinction is the **anchor**: the consensus loss targets the quorum-verified mean $\bar{\text{msg}}_{\text{consensus}}$, which is a deterministic function of the PBFT voting outcome and therefore consistent across seeds. The L2 penalty targets the raw observation mean $\bar{\text{obs}}$, which varies across seeds and training steps, providing an unstable anchor that limits its variance-reduction effect. The PBFT quorum thus plays a dual role: it filters Byzantine messages (filter function) and provides a stable, deterministic anchor for the alignment gradient (loss function). Neither function is replicated by generic regularization.

**Consensus filter → Byzantine protection and consensus guarantee.** The filter provides the quorum-based message verification that guarantees message-level consistency (CR = 0.767) and defends against active Byzantine attacks within the PBFT-CG-MAPPO framework. Under adversarial attack (Table 6), disabling the filter causes 93% return degradation. However, MAPPO (which has no consensus) also shows resilience under adversarial attack (−40.9 ± 3.6), indicating that the PBFT filter's primary value is its formal *f* < *n*/3 consistency guarantee (Theorem 1) rather than raw mean-return superiority. Under the clean regime, the filter ensures that all honest agents condition on the same verified input **m**, which is the prerequisite for the PBFT safety guarantee (Theorem 1).

A single-seed pilot experiment initially attributed variance reduction primarily to the consensus-filtered critic input, based on a single-seed result that showed Filter Only = Full (Δ = 0%) and Loss Only = MAPPO. The multi-seed data overturns this: the single-seed result was a sampling artifact, and the loss emerges as the dominant variance-reduction factor across seeds. We regard this correction as a strength of the experimental methodology: the multi-seed ablation provides a more reliable decomposition than any single-seed comparison.

**Mechanism explanation.** The loss reduces variance because it adds a coordination gradient to the PPO update. Without the loss, each agent optimizes its policy independently (modulo the shared reward), and the training trajectory is sensitive to the random seed. With the loss, agents are additionally pulled toward agreement, which constrains the policy space and reduces the dispersion of outcomes across seeds. The filter, by contrast, does not add a gradient signal; it replaces the critic's input with a verified version, which affects the value estimate and advantage computation. This replacement can reduce variance in some seeds (by removing outlier messages) but is less effective than the loss's gradient-based alignment across the full distribution of seeds.

Combined with the entropy floor, these two complementary mechanisms prevent three failure modes: (a) entropy collapse, where the policy converges to a deterministic suboptimal strategy; (b) divergence, where agents fail to coordinate and produce catastrophic returns; and (c) Byzantine corruption, where faulty messages poison the centralized critic.

### 6.2 CR-Entropy Tradeoff

A consistent pattern across experiments is the tradeoff between consensus rate (CR) and entropy coefficient:

- **High entropy_coef (0.15)**: CR is low (0.10–0.45 under Byzantine attack) but return variance is small (σ ≤ 7.4). The high entropy bonus maintains diverse policies, so agents rarely agree perfectly, but the variance is contained.
- **Low entropy_coef (0.01)**: CR is high (1.0 in the clean regime) but return variance is catastrophic (σ = 224.8). The low entropy bonus allows policies to converge prematurely, producing either good or terrible outcomes depending on the seed.

This tradeoff suggests that **CR is not a monotonically desirable quantity**. A CR of 1.0 in the clean regime with low entropy_coef comes at the cost of catastrophic seed sensitivity. A CR of 0.30–0.45 under Byzantine attack with high entropy_coef comes with stable, reproducible outcomes. The appropriate operating point depends on the deployment context: safety-critical systems should prioritize variance reduction (high entropy_coef), while scenarios requiring strict action agreement should prioritize CR (low entropy_coef with careful seed selection).

### 6.3 When Does Consensus Matter? Active vs. Passive Attacks

The clean-regime ablation (Table 5) shows that the consensus filter has zero independent effect on mean return in the clean regime (Filter Only: −71.5 vs. MAPPO: −55.5, with the filter actually producing a more negative mean), which a naive reading might interpret as "consensus is useless." The Byzantine-regime ablation (Table 6) provides the crucial counter-evidence:

- **Adversarial attack**: Disabling consensus within the PBFT-CG-MAPPO framework causes 93% return degradation (−39.1 → −75.5) and 2× variance increase (±6.5 → ±11.4). The consensus filter blocks adversarial proposals before they corrupt the centralized critic.
- **Random attack**: Disabling consensus causes 13% degradation (−41.3 → −46.7). The effect is smaller because random noise is less targeted but still harmful.
- **Silence attack**: Disabling consensus *improves* return by 21% (−53.4 → −42.1). Under silence, the quorum is non-functional (CR = 0.00), and the consensus loss adds noise.

This pattern maps directly onto the PBFT theoretical guarantee: the protocol tolerates *f* < *n*/3 *active* faulty nodes (random/adversarial) but provides no liveness guarantee under *passive* faults (silence) that exploit the quorum margin. The empirical results confirm this theoretical boundary and clarify the scope of the consensus mechanism's contribution.

Compared to MAPPO (which has no consensus), PBFT-Full outperforms by 1–2 points under random and adversarial attacks (with 4 agents) while maintaining 2–3× lower variance. However, MAPPO under attacks also shows surprisingly low variance (σ = 4.0, 3.6), lower than MAPPO clean (σ = 19.8), because the Byzantine entropy injection stabilizes training. This means the practical advantage of PBFT-CG-MAPPO over MAPPO under attacks is primarily in the formal guarantee (Theorem 1) and in the Quorum-off comparison (93% degradation), not in the raw mean comparison. Under silence, both algorithms perform similarly, confirming that PBFT provides no advantage when the communication channel itself is disrupted.

### 6.4 Silence Attack: The Boundary of PBFT Tolerance

The silence attack produces CR = 0.00, the only configuration where the PBFT quorum fails to provide meaningful filtering. This is a structural limitation of small-*n* PBFT: with *n* = 4 and *f* = 1, the quorum requires 2*f*+1 = 3 prepares. When one agent is silent, only 3 agents remain to vote, and the quorum is met exactly (3 = 3) but without any margin for additional faults. In practice, this means the system operates at the boundary of liveness: any additional delay or packet loss breaks the quorum.

For *n* = 12 (permafrost domain, *f* = 3), there are 9 honest agents and the quorum requires 2×3+1 = 7 prepares, providing a margin of 2 (9 − 7 = 2 honest agents can fail or delay without breaking quorum). The silence attack is therefore better tolerated in larger teams. However, the *n* = 7 results (Table 4b) reveal a different scaling problem (see §6.6).

### 6.5 Counter-Intuitive Finding: Byzantine Returns Can Exceed Clean Returns

Under random (−41.3) and adversarial (−39.1) attacks, PBFT-CG-MAPPO's mean return is higher (less negative) than its clean Config-H return (−81.4, 3-seed mean). Both the Byzantine and clean Config-H experiments use the same configuration (*n* = 4 agents, entropy_coef = 0.15, max_steps = 25), making this a valid within-configuration comparison. This is counter-intuitive but explicable: the Byzantine agent's faulty actions inject entropy into the training signal, preventing the policy from converging to a deterministic suboptimal strategy. The effect is analogous to ε-greedy exploration in Q-learning: a small amount of randomness prevents premature convergence.

This finding has practical implications: in deployment scenarios where Byzantine agents are expected, the PBFT framework's combination of consensus filtering (which removes the most harmful faulty messages) and entropy injection (which prevents suboptimal convergence) can produce policies that are *more robust* than those trained in a clean environment. However, this benefit does not extend to silence attacks, which reduce rather than increase entropy.

**Alternative explanations.** We consider three alternative explanations for the higher returns under Byzantine attack: (i) *Task facilitation*: the Byzantine agent's random movement may accidentally help agents disperse to landmarks, reducing competition. This is partially consistent with the random attack data but cannot explain why adversarial attacks (which target the worst disagreement) also improve returns. (ii) *Reward function artifact*: if the attack and clean experiments use different reward functions, the comparison would be invalid. We confirm that both use identical reward functions (same MPE spread environment). (iii) *Statistical noise*: with only 3 seeds, the difference could be a sampling artifact. However, the effect is consistent across both random (−41.3) and adversarial (−39.1) attacks, making noise unlikely as the sole explanation. The entropy injection hypothesis remains the most parsimonious explanation. A controlled experiment replacing the Byzantine agent with ε-greedy noise of equivalent magnitude would provide stronger evidence—we design this as: (a) replace one agent with ε-greedy policy (ε = 0.1, 0.3, 0.5), (b) measure return and entropy under the same Config-H setup. If the ε-greedy condition replicates the "Byzantine > clean" pattern, the entropy injection hypothesis is confirmed; if not, a task-specific facilitation explanation is needed. This experiment is straightforward to implement (modify the action selection of one agent in the existing MAPPO codebase) and we recommend it as high-priority follow-up.

### 6.6 Design Principles for Safe Consensus Conditioning

The experimental results lead to three design principles for embedding consensus mechanisms in MARL training loops:

**P1: Replace only dissenting actions; never overwrite consenting agents.** The initial design revealed that overwriting all agent actions with the leader's proposal collapses the action space and prevents effective coordination in tasks that require agents to take different actions (e.g., dispersing to different landmarks in `simple_spread`). The consensus mechanism should *filter* messages (dropping those that fail quorum) and correct only agents whose proposals conflict with the quorum, while preserving the autonomy of agents that voted in agreement.

**P2: Condition via additive loss with zero initialization.** The consensus term should be added to the training objective as a regularizer, not applied as a multiplicative gate (FiLM-style) or action replacement. Zero initialization ensures that the consensus loss is inactive at the start of training, when the policy is random and consensus alignment is meaningless. The weight is annealed from zero to its target value over the first 10% of training, allowing the policy to develop meaningful representations before consensus conditioning takes effect. The multi-seed ablation data confirms that the loss is the primary variance reduction mechanism, validating this design choice.

**P3: Enforce an entropy floor.** Without an entropy floor, certain random initializations cause the policy entropy to collapse from ~1.6 to < 0.001, producing deterministic policies that fail catastrophically [31, 32]. The floor can be implemented through two complementary mechanisms: (i) a sufficiently high entropy_coef (0.15 in our Config-H experiments, which maintains mean policy entropy above the collapse threshold during the early and middle phases of training (typically 0.3–0.8), though it may decline in the final phase (mean terminal entropy as low as 0.048 for the Full condition; see Table 5)); and (ii) an explicit entropy deficit penalty (§3.3, Eq. 2–3, with λ_floor = 5.0 and H_target = 0.1 in the codebase). In our Config-H experiments, the primary mechanism is the higher entropy_coef; the explicit penalty serves as a safety net that activates only when entropy drops below H_target. Note that the Config-L-to-Config-H comparison confounds entropy_coef with max_steps and agent count (see §5.3); the variance reduction attributed to the entropy floor should be interpreted qualitatively rather than as a single-mechanism quantitative claim.

**Important caveat on entropy collapse.** Even with entropy_coef = 0.15, the 3-seed ablation data shows that some seeds still experience partial entropy collapse (mean entropy as low as 0.048 for the Full condition), with individual seeds reaching entropy = 0.0. The consequences are less catastrophic than in Config-L (no returns below −87.7 in Config-H vs. −597.9 in Config-L), but the collapse is not fully prevented. The entropy floor thus mitigates but does not eliminate entropy collapse. Future work should investigate adaptive entropy scheduling or stronger floor mechanisms.

These principles are not specific to PBFT; they apply to any method that seeks to embed consensus or coordination signals inside a MARL training loop. Violations of P1 (action replacement) and P3 (no entropy floor) produce the catastrophic failures observed in the Config-L experiments.

### 6.7 Limitations

(i) **Silence attack vulnerability**: With *n* = 4, the silence attack reduces CR to 0.00 because the quorum is met exactly without margin. Larger teams (*n* ≥ 7) are required for reliable silence tolerance.

(ii) **Limited environment diversity**: The cross-environment evaluation covers three environments (MPE spread, SMAClite, VMAS). While these span discrete/continuous actions and different agent counts, broader evaluation on StarCraft II full SMAC, Google Research Football, and other standard benchmarks is needed.

(iii) **Synthetic permafrost data**: The permafrost transfer experiment uses synthetic data rather than real TPDC ground-temperature observations. The results demonstrate functional transfer but not data fidelity. Validation with real observations is left for future work.

(iv) **Synchronous PBFT assumption**: The commit protocol assumes reliable message delivery within a round. Asynchronous BFT variants are needed for deployments with unbounded message delays.

(v) **Mean return tradeoff**: The variance reduction comes at a cost—PBFT-CG-MAPPO's mean return in the Config-L clean regime (−296.3) is worse than MADDPG (−160.3) and MAPPO (−234.5). In the Config-H regime with entropy floor, the mean return (−81.4) is worse than MAPPO (−55.5) on the same mpe_spread environment (4 agents, max_steps=25). The framework prioritizes reproducibility and safety over peak performance.

(vi) **Computational overhead**: The PBFT commit adds O(*n*²) message complexity per step. For large teams (*n* > 20), this overhead may become prohibitive, motivating hierarchical or tree-layered consensus structures [23].

(vii) **No dedicated robust-MARL baselines**: The experimental comparison is limited to standard MARL algorithms (MAPPO, MADDPG, QMIX, CommNet, TarMAC). We do not include dedicated Byzantine-robust MARL methods (EIR-MAPPO [15], Wolfpack [13]), which have public code and would provide a more informative comparison. Adding these baselines would clarify the relative advantage of PBFT message conditioning versus learned robustness heuristics.

(viii) **Scalability to larger teams with strict quorum**: The *n* = 7, *f* = 2 evaluation (Table 4b) reveals that PBFT-CG-MAPPO's benefits do not straightforwardly scale to larger teams with the current fixed quorum threshold. Under clean conditions, PBFT-CG-MAPPO (*n* = 7) performs worse than MAPPO (*n* = 7) (−73.7 ± 15.7 vs. −62.3 ± 10.0) with CR = 0.230, because the quorum requires 5 prepares but 7 agents with high entropy rarely reach quorum. The consensus layer becomes overhead rather than benefit. Under active attacks, the situation reverses: PBFT-CG-MAPPO provides variance reduction (σ = 3.1–4.8) and the consensus rate increases (CR = 0.791 under random attack), as faulty proposals unify honest agents' votes. This suggests that the fixed 2*f*+1 quorum threshold is appropriate for small teams under attack but is too strict for larger clean teams. **Recommended mitigation**: quorum tuning (reducing the quorum threshold for larger teams, e.g., to a fraction of honest agents rather than the full 2*f*+1) or adaptive quorum thresholds that adjust based on observed CR during training. This is an important direction for future work.

(ix) **Residual entropy collapse**: Despite the entropy floor (entropy_coef = 0.15 + explicit penalty), some Config-H seeds still experience partial entropy collapse (entropy → 0.0), particularly in the Full and Filter Only conditions (mean entropy 0.048 and 0.067). The entropy floor mitigates but does not fully prevent this failure mode. More aggressive entropy scheduling or alternative exploration mechanisms may be needed for complete elimination of catastrophic seeds.

---

## 7. Conclusions

This work presented PBFT-CG-MAPPO, a consensus-conditioned MARL framework that embeds a PBFT three-phase commit as a per-step message filter inside the CTDE-MAPPO training loop, complemented by an additive consensus loss and an entropy floor. Across three cooperative environments and five seeds, the framework reduces return variance significantly on SMAClite (47.4×) and MPE spread (4.6×); the VMAS reduction (1.9×) is not statistically significant (bootstrap 95% CI includes 1.0, §5.2). The framework produces zero catastrophic seeds under the entropy-floor configuration (Config-H), while maintaining a formal *f* < *n*/3 message-level consistency guarantee under attack.

The key empirical contribution, clarified through a 3-seed 2×2 ablation, is the decomposition of PBFT-CG-MAPPO's two complementary mechanisms: (1) the **additive consensus loss** is the primary variance reduction mechanism (5.7× reduction vs. MAPPO when used alone), and (2) the **consensus filter** provides Byzantine protection and consensus guarantee (93% return degradation under adversarial attack when disabled within the PBFT-CG-MAPPO framework; however, MAPPO without consensus also shows empirical resilience, indicating that the filter's primary value is its formal *f* < *n*/3 guarantee). A MAPPO + L2(message) control confirms that this variance reduction is not a generic regularization effect: an L2 penalty of identical form and weight, targeting the raw message mean, reduces variance only 1.1× compared to the consensus loss's 5.7×, demonstrating that the PBFT quorum provides a stable anchor that generic penalties cannot replicate. This refines the initial single-seed attribution, providing a clearer picture of how each component contributes to the overall system.

The theoretical contribution is the first provable *f* < *n*/3 message-level consistency guarantee for per-step message conditioning in cooperative policy-gradient MARL, achieved through the consensus-filtered critic input. Unlike federated approaches that provide policy-level convergence guarantees via robust parameter aggregation [24], our method operates at the per-step communication level in shared-environment cooperative settings. The practical contribution is the demonstration that consensus conditioning, when combined with an entropy floor, converts MARL from a seed-sensitive optimization problem into a reproducible training procedure suitable for safety-critical deployment. Three design principles—never replace agent actions, condition via additive loss with zero initialization, and enforce an entropy floor—provide actionable guidance for future consensus-augmented MARL methods.

However, important limitations remain: the *n* = 7 evaluation shows that the fixed 2*f*+1 quorum threshold does not scale well to larger clean teams (CR = 0.230), the entropy floor does not fully prevent entropy collapse in all seeds, and silence attacks exploit the quorum liveness boundary. Future work will address these limitations through quorum tuning and adaptive thresholds for larger teams, stronger entropy scheduling mechanisms, asynchronous BFT variants for silence tolerance, validation with real TPDC permafrost observations, and evaluation against dedicated robust-MARL baselines.

---

## References

[1] D. S. Bernstein, S. Zilberstein, and N. Immerman, "The complexity of decentralized control of Markov decision processes," *Mathematics of Operations Research*, vol. 27, no. 4, pp. 819–840, 2002.

[2] F. A. Oliehoek and C. Amato, *A Concise Introduction to Decentralized POMDPs*. Springer, 2016.

[3] R. Lowe, Y. Wu, A. Tamar, J. Harb, P. Abbeel, and I. Mordatch, "Multi-agent actor-critic for mixed cooperative-competitive environments," in *Proc. Advances in Neural Information Processing Systems (NeurIPS)*, 2017, pp. 6379–6390.

[4] T. Rashid, M. Samvelyan, C. S. de Witt, G. Farquhar, J. Foerster, and S. Whiteson, "QMIX: Monotonic value function factorisation for deep multi-agent reinforcement learning," in *Proc. International Conference on Machine Learning (ICML)*, 2018, pp. 4295–4304.

[5] C. Yu, A. Velu, E. Vinitsky, J. Gao, Y. Wang, A. Bayen, and Y. Wu, "The surprising effectiveness of PPO in cooperative multi-agent games," in *Proc. Advances in Neural Information Processing Systems (NeurIPS)*, 2022, pp. 24611–24624.

[6] J. Schulman, F. Wolski, P. Dhariwal, A. Radford, and O. Klimov, "Proximal policy optimization algorithms," *arXiv preprint arXiv:1707.06347*, 2017.

[7] M. Castro and B. Liskov, "Practical Byzantine fault tolerance," in *Proc. 3rd Symposium on Operating Systems Design and Implementation (OSDI)*, 1999, pp. 173–186.

[8] S. Sukhbaatar, A. Szlam, and R. Fergus, "Learning multiagent communication with backpropagation," in *Proc. Advances in Neural Information Processing Systems (NeurIPS)*, 2016, pp. 2244–2252.

[9] A. Das, T. Gervet, J. Romoff, D. Batra, M. Rabbat, and J. Pineau, "TarMAC: Targeted multi-agent communication," in *Proc. International Conference on Machine Learning (ICML)*, 2019, pp. 1538–1546.

[10] I. Mordatch and P. Abbeel, "Emergence of grounded compositional language in multi-agent populations," in *Proc. AAAI Conference on Artificial Intelligence*, 2018, pp. 1495–1502.

[11] L. Zhao et al., "A synthesis dataset of permafrost thermal state for the Qinghai–Tibet Plateau during 2002–2018," *Earth System Science Data*, vol. 13, no. 9, pp. 4207–4218, 2021.

[12] B. K. Biskaborn et al., "Permafrost is warming at a global scale," *Nature Communications*, vol. 10, no. 1, pp. 1–11, 2019.

[13] S. Lee, J. Hwang, Y. Jo, and S. Han, "Wolfpack adversarial attack for robust multi-agent reinforcement learning," in *Proc. 42nd International Conference on Machine Learning (ICML)*, PMLR, vol. 267, pp. 33025–33056, 2025.

[14] Z. Ding, Z. Liu, Z. Fang, K. Su, L. Zhu, and Z. Lu, "Multi-agent coordination via multi-level communication," in *Advances in Neural Information Processing Systems (NeurIPS)*, vol. 37, 2024.

[15] S. Li, J. Guo, J. Xiu, R. Xu, X. Yu, J. Wang, A. Liu, Y. Yang, and X. Liu, "Byzantine robust cooperative multi-agent reinforcement learning as a Bayesian game," in *Proc. International Conference on Learning Representations (ICLR)*, 2024.

[16] Y. Xie, S. Mou, and S. Sundaram, "Communication-efficient and resilient distributed Q-learning," *IEEE Transactions on Neural Networks and Learning Systems*, vol. 35, no. 3, pp. 3351–3364, 2024.

[17] P. Onukak, S. Ogunbunmi, Y. Chen, E. Ardiles-Cruz, E. Blasch, and G. Chen, "Reputation-enhanced practical Byzantine fault tolerance algorithm for node capture attacks on UAV networks," *Discover Internet of Things*, vol. 5, no. 1, 2025.

[18] V. Nanapu, G. Banavathu, and S. D. Ke, "D2BFT: A dual Byzantine fault tolerance approach for multi-agent drone surveillance with deep reinforcement learning," *Computer Networks*, vol. 273, art. no. 111750, 2025.

[19] T. Haarnoja, A. Zhou, P. Abbeel, and S. Levine, "Soft actor-critic: Off-policy maximum entropy deep reinforcement learning with a stochastic actor," in *Proc. International Conference on Machine Learning (ICML)*, 2018, pp. 1861–1870.

[20] L. Ye, M. Figura, Y. Lin, M. Pal, P. Das, J. Liu, and V. Gupta, "Resilient multiagent reinforcement learning with function approximation," *IEEE Transactions on Automatic Control*, vol. 69, no. 12, pp. 8497–8512, 2024.

[21] G. Yang, T. Yang, J. Qiao, Y. Wu, J. Huo, X. Chen, and Y. Gao, "Multi-agent reinforcement learning with communication-constrained priors," in *Advances in Neural Information Processing Systems (NeurIPS)*, vol. 38, 2025.

[22] C. Li, W. Qiu, X. Li, C. Liu, and Z. Zheng, "A dynamic adaptive framework for practical Byzantine fault tolerance consensus protocol in the Internet of Things," *IEEE Transactions on Computers*, vol. 73, no. 7, pp. 1669–1682, 2024.

[23] L. Lei, G. Wu, D. Yang, B. Chen, and X. Li, "TL-PBFT: An improved PBFT consensus algorithm based on tree-layered communication structure," *KSII Transactions on Internet and Information Systems*, vol. 19, no. 6, pp. 1987–2007, 2025.

[24] P. Jordan, F. Grötschla, F. X. Fan, and R. Wattenhofer, "Decentralized federated policy gradient with Byzantine fault-tolerance and provably fast convergence," in *Proc. 23rd International Conference on Autonomous Agents and Multiagent Systems (AAMAS)*, pp. 964–972, 2024.

[25] P. Fan, H. Lin, Z. Zhang, and H. Deng, "Enhanced detection of permafrost deformation with machine learning and interferometric SAR along the Qinghai–Tibet engineering corridor," *Remote Sensing*, vol. 17, no. 13, art. no. 2231, 2025.

[26] X. Kang, Z. Li, J. Wan, H. Feng, C. Ma, and X. Yang, "Real-time, depth-resolved permafrost thermal monitoring across the Qinghai-Tibet Plateau enabled by Bayesian-optimized deep learning," *Climate Dynamics*, vol. 64, 2026.

[27] M. A. Memiş, I. Keskin, S. Demir, and Ş. Ulus Memiş, "Machine learning-based prediction of permafrost degradation and its implications on geotechnical infrastructure: A comprehensive review," *AI in Civil Engineering*, vol. 4, art. no. 28, 2025.

[28] J. K. Terry, B. Black, N. G. Jayakumar, A. Hari, M. Santos, R. Sullivan, C. Haffner, T. Earle, K. Altab, and G. Fletcher, "PettingZoo: Gym for multi-agent reinforcement learning," in *Proc. NeurIPS Datasets and Benchmarks Track*, 2021.

[29] G. Papoudakis, F. Christianos, and S. V. Albrecht, "Benchmarking multi-agent deep reinforcement learning algorithms in cooperative tasks," in *Proc. NeurIPS Datasets and Benchmarks Track*, 2021.

[30] S. Singh, O. Mahjoub, L. Schäfer, and S. V. Albrecht, "How much can change in a year? Revisiting evaluation in multi-agent reinforcement learning," *arXiv preprint arXiv:2312.08463*, 2024.

[31] M. G. Bellemare, W. Dabney, and R. Munos, "A distributional perspective on reinforcement learning," in *Proc. International Conference on Machine Learning (ICML)*, 2017, pp. 449–458.

[32] Z. Ahmed, N. Le Roux, M. Norouzi, and B. Schölkopf, "Understanding the impact of entropy on policy optimization," in *Proc. International Conference on Machine Learning (ICML)*, 2019, pp. 201–210.

[33] S. M. Kakade and J. Langford, "Approximately optimal approximate reinforcement learning," in *Proc. International Conference on Machine Learning (ICML)*, 2002, pp. 267–274.

[34] Y. Yuan, N. Jiang, and L. Li, "Robust cooperative multi-agent reinforcement learning via multi-view message certification," *Science China Information Sciences*, vol. 67, no. 4, art. no. 142102, 2024.

[35] D. Bouhata, A. B. A. Ali, and A. M. O. Mohammed, "Byzantine fault tolerance in distributed machine learning: A survey," *Journal of Experimental & Theoretical Artificial Intelligence*, 2024. DOI: 10.1080/0952813X.2024.2391778

[36] M. Bettini, A. Prorok, and V. Moens, "BenchMARL: Benchmarking multi-agent reinforcement learning," *Journal of Machine Learning Research*, vol. 25, no. 258, pp. 1–62, 2024.

---

## Appendix A. Hyperparameter Tables

**Table A1.** Environment settings.

| Parameter | `simple_spread` (Config-L) | `mpe_spread` (Config-H) | SMAClite 5m_vs_6m | VMAS UAV coverage | `permafrost_monitoring` |
|-----------|----------------------------|--------------------------|--------------------|-------------------|-------------------------|
| Number of agents (*N*) | 4 | 4 | 5 | 4 | 12 |
| Observation dimension | 18 | 18 | 72 | 16 | 24 |
| Action dimension | 5 | 5 | 12 | 2 (continuous) | 2 |
| Action type | Discrete | Discrete | Discrete | Continuous | Discrete |
| Max episode length | 100 | 25 | 200 | 100 | 100 |
| Reward type | Cooperative | Cooperative | Cooperative | Cooperative | F1-based |

**Table A2.** PPO hyperparameters.

| Parameter | Config-L | Config-H |
|-----------|------------------|------------------|
| Clip ratio (ε) | 0.2 | 0.2 |
| Entropy coefficient | 0.01 | 0.15 |
| Learning rate | 5×10⁻⁴ | 5×10⁻⁴ |
| Discount factor (γ) | 0.99 | 0.99 |
| GAE λ | 0.95 | 0.95 |
| PPO epochs per update | 5 | 5 |
| Optimizer | Adam | Adam |

**Table A3.** Network architecture.

| Component | Configuration |
|-----------|---------------|
| Actor hidden dimension | 64 (GRU) |
| Critic hidden dimension | 64 |
| Activation | ReLU |

**Table A4.** PBFT consensus parameters.

| Parameter | Value |
|-----------|-------|
| Faulty agents (*f*) | 1 |
| Leader rotation interval (*K*) | 128 steps |
| Consensus threshold | 0.5 |
| Temperature | 1.0 |
| Consensus loss weight (λ_cons) | Annealed from 0 to 0.01 |
| Entropy floor target (H_target) | 0.1 |
| Entropy floor weight (λ_floor) | 5.0 |

**Table A5.** Training configuration.

| Parameter | Value |
|-----------|-------|
| Total environment steps | 500k |
| Number of random seeds | 3 (Config-L) / 5 (cross-env) |
| GPU | NVIDIA RTX 4090 |
| Framework | PyTorch 2.x |

\* Values marked with * are determined by the episode length and number of parallel environments; see the code repository [https://github.com/RaymondXFAN/PBFT-CG-MARL] for exact settings.

---

## Data Availability

- TPDC permafrost synthesis dataset (2002–2018), Zhao et al., *Earth System Science Data*. URL: https://www.tpdc.ac.cn/zh-hans/data/789e838e-16ac-4539-bb7e-906217305a1d ; DOI: https://doi.org/10.11888/Geocry.tpdc.271107
- GTN-P global permafrost network: https://data.gtn-p.org/ (PANGAEA DOI: https://doi.pangaea.de/10.1594/PANGAEA.972992)
- Acknowledgment: Data provided by National Tibetan Plateau / Third Pole Environment Data Center (http://data.tpdc.ac.cn).

## Declarations

- **Funding**: This research received no external funding.
- **Conflicts of Interest**: The authors declare no conflicts of interest.
- **Acknowledgments**: The authors thank the National Tibetan Plateau / Third Pole Environment Data Center (http://data.tpdc.ac.cn) for providing the permafrost thermal dataset.
