import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ============================================================
# 莫兰迪色系定义
# ============================================================
MORANDI = {
    'blue': '#7B9EA8',
    'red': '#C4857A',
    'green': '#8DB580',
    'orange': '#D4A574',
    'purple': '#9B8BB4',
    'yellow': '#D4C5A9',
    'gray': '#A0A0A0',
    'dark': '#5A5A5A',
    'light': '#E8E0D8',
    'cream': '#F5F0EB',
}

# ============================================================
# 通用设置
# ============================================================
plt.rcParams.update({
    'font.size': 12,
    'axes.labelsize': 13,
    'axes.titlesize': 14,
    'xtick.labelsize': 12,
    'ytick.labelsize': 12,
    'legend.fontsize': 11,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'font.family': 'serif',
})

SAVE_DIR = '/sandbox/workspace/PBFT-CG-MARL/paper_figures/'

# ============================================================
# Figure 1: Training Return Curves
# ============================================================
def figure1():
    np.random.seed(42)
    steps = np.arange(0, 500001, 10000)  # 50 points

    # PBFT: tight convergence
    pbft_seeds = []
    for s in range(3):
        base = -100 + 30 * (1 - np.exp(-steps / 100000)) + np.random.normal(0, 3, len(steps))
        pbft_seeds.append(base + np.random.uniform(-5, 5))

    # MAPPO: wide spread
    mappo_seeds = []
    mappo_targets = [-40, -78, -56]
    for s, target in enumerate(mappo_targets):
        base = -100 + (100 + target) * (1 - np.exp(-steps / 80000)) + np.random.normal(0, 5, len(steps))
        mappo_seeds.append(base)

    fig, ax = plt.subplots(figsize=(8, 5))

    # PBFT lines (solid, blue shades)
    blue_shades = [MORANDI['blue'], '#5A8898', '#9BB8C4']
    for i, seed in enumerate(pbft_seeds):
        ax.plot(steps, seed, color=blue_shades[i], linewidth=1.5,
                linestyle='-', label=f'PBFT-CG-MAPPO (seed {i+1})' if i == 0 else None)

    # MAPPO lines (dashed, red shades)
    red_shades = [MORANDI['red'], '#A06A5E', '#DCA397']
    for i, seed in enumerate(mappo_seeds):
        ax.plot(steps, seed, color=red_shades[i], linewidth=1.5,
                linestyle='--', label=f'MAPPO (seed {i+1})' if i == 0 else None)

    # Custom legend with representative lines
    from matplotlib.lines import Line2D
    legend_elements = [
        Line2D([0], [0], color=MORANDI['blue'], linestyle='-', linewidth=1.5, label='PBFT-CG-MAPPO'),
        Line2D([0], [0], color=MORANDI['red'], linestyle='--', linewidth=1.5, label='MAPPO'),
    ]
    ax.legend(handles=legend_elements, loc='lower right')
    ax.set_xlabel('Training Steps')
    ax.set_ylabel('Episode Return')
    ax.set_facecolor(MORANDI['cream'])
    fig.patch.set_facecolor('white')
    ax.grid(True, alpha=0.3, color=MORANDI['gray'])
    plt.tight_layout()
    plt.savefig(SAVE_DIR + 'Figure1-TrainingReturnCurves.png', bbox_inches='tight')
    plt.close()
    print("Figure 1 saved.")

# ============================================================
# Figure 2: Cross-environment Variance Comparison
# ============================================================
def figure2():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))

    # (a) Variance reduction ratio bar chart
    envs = ['SMAClite\n5m_vs_6m', 'MPE\nspread', 'VMAS\nUAV']
    ratios = [47.4, 4.6, 1.9]
    significant = [True, True, False]

    colors = [MORANDI['blue'], MORANDI['green'], MORANDI['orange']]
    bars = ax1.bar(envs, ratios, color=colors, edgecolor=MORANDI['dark'], linewidth=0.8, width=0.55)

    # Add hatching for non-significant
    for i, (bar, sig) in enumerate(zip(bars, significant)):
        if not sig:
            bar.set_hatch('//')
            bar.set_edgecolor(MORANDI['dark'])
            bar.set_linewidth(1.2)

    # Add value labels
    for i, (bar, val) in enumerate(zip(bars, ratios)):
        label = f'{val}×'
        if not significant[i]:
            label += '\n(n.s.)'
        ax1.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 1,
                 label, ha='center', va='bottom', fontsize=12, color=MORANDI['dark'])

    ax1.set_ylabel('Variance Reduction Ratio')
    ax1.set_title('(a) Cross-Environment Variance Reduction')
    ax1.set_facecolor(MORANDI['cream'])
    ax1.grid(axis='y', alpha=0.3, color=MORANDI['gray'])

    # (b) Ablation variance comparison
    ablation_labels = ['MAPPO', 'Filter\nOnly', 'Full', 'Loss\nOnly', 'MAPPO\n+L2']
    ablation_stds = [19.8, 10.4, 5.5, 3.5, 18.1]
    ablation_colors = [MORANDI['red'], MORANDI['orange'], MORANDI['blue'], MORANDI['green'], MORANDI['purple']]

    bars2 = ax2.bar(ablation_labels, ablation_stds, color=ablation_colors,
                    edgecolor=MORANDI['dark'], linewidth=0.8, width=0.55)

    for bar, val in zip(bars2, ablation_stds):
        ax2.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.4,
                 f'σ={val}', ha='center', va='bottom', fontsize=12, color=MORANDI['dark'])

    ax2.set_ylabel('Standard Deviation (σ)')
    ax2.set_title('(b) Ablation Variance (Table 5)')
    ax2.set_facecolor(MORANDI['cream'])
    ax2.grid(axis='y', alpha=0.3, color=MORANDI['gray'])

    fig.patch.set_facecolor('white')
    plt.tight_layout()
    plt.savefig(SAVE_DIR + 'Figure2-VarianceComparison.png', bbox_inches='tight')
    plt.close()
    print("Figure 2 saved.")

# ============================================================
# Figure 3: Entropy Trajectories
# ============================================================
def figure3():
    np.random.seed(123)
    steps = np.arange(0, 500001, 10000)

    # Config-L: entropy_coef=0.01, 2 seeds collapse, 1 stays
    config_l_seeds = []
    # seed 1: collapses around step 100k
    s1 = 1.2 * np.exp(-steps / 50000) + 0.01 + np.random.normal(0, 0.02, len(steps))
    s1[steps > 100000] = s1[steps > 100000] * 0.3 + np.random.normal(0, 0.005, np.sum(steps > 100000))
    config_l_seeds.append(np.clip(s1, 0, 1.5))

    # seed 2: collapses around step 150k
    s2 = 1.1 * np.exp(-steps / 60000) + 0.01 + np.random.normal(0, 0.02, len(steps))
    s2[steps > 150000] = s2[steps > 150000] * 0.2 + np.random.normal(0, 0.005, np.sum(steps > 150000))
    config_l_seeds.append(np.clip(s2, 0, 1.5))

    # seed 3: stays healthy
    s3 = 1.0 * np.exp(-steps / 200000) + 0.05 + np.random.normal(0, 0.02, len(steps))
    config_l_seeds.append(np.clip(s3, 0, 1.5))

    # Config-H: entropy_coef=0.15, all stay
    config_h_seeds = []
    for i in range(3):
        base = 0.15 * np.exp(-steps / 500000) + 0.08 + np.random.normal(0, 0.015, len(steps))
        config_h_seeds.append(np.clip(base, 0, 1.5))

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(8, 7), sharex=True)

    # Config-L
    red_shades = [MORANDI['red'], '#A06A5E', '#DCA397']
    for i, seed in enumerate(config_l_seeds):
        style = '--' if i < 2 else '-'
        lw = 1.5
        ax1.plot(steps / 1000, seed, color=red_shades[i], linestyle=style, linewidth=lw,
                 label=f'seed {i+1}' + (' (collapse)' if i < 2 else ''))

    # Mark collapse region with a dashed vertical line
    ax1.axvline(x=100, color=MORANDI['dark'], linestyle=':', linewidth=1, alpha=0.6)
    ax1.text(105, 0.8, 'collapse', fontsize=12, color=MORANDI['dark'], fontstyle='italic')

    ax1.set_ylabel('Policy Entropy')
    ax1.set_title('Config-L (entropy_coef=0.01)')
    ax1.legend(loc='upper right', fontsize=11)
    ax1.set_facecolor(MORANDI['cream'])
    ax1.grid(True, alpha=0.3, color=MORANDI['gray'])

    # Config-H
    blue_shades = [MORANDI['blue'], '#5A8898', '#9BB8C4']
    for i, seed in enumerate(config_h_seeds):
        ax2.plot(steps / 1000, seed, color=blue_shades[i], linestyle='-', linewidth=1.5,
                 label=f'seed {i+1}')

    ax2.set_xlabel('Training Steps (×10³)')
    ax2.set_ylabel('Policy Entropy')
    ax2.set_title('Config-H (entropy_coef=0.15)')
    ax2.legend(loc='upper right', fontsize=11)
    ax2.set_facecolor(MORANDI['cream'])
    ax2.grid(True, alpha=0.3, color=MORANDI['gray'])

    fig.patch.set_facecolor('white')
    plt.tight_layout()
    plt.savefig(SAVE_DIR + 'Figure3-EntropyTrajectories.png', bbox_inches='tight')
    plt.close()
    print("Figure 3 saved.")

# ============================================================
# Figure 4: Byzantine Attack Comparison
# ============================================================
def figure4():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))

    # (a) Grouped bar chart: 3 attack types × 3 methods
    attacks = ['Random', 'Adversarial', 'Silence']
    methods = ['PBFT Full', 'Quorum-off', 'MAPPO']
    means = np.array([
        [-41.3, -46.7, -40.0],
        [-39.1, -75.5, -40.9],
        [-53.4, -42.1, -36.2],
    ])
    stds = np.array([
        [4.9, 5.1, 4.0],
        [6.5, 11.4, 3.6],
        [7.4, 0.2, 1.6],
    ])

    x = np.arange(len(attacks))
    width = 0.22
    method_colors = [MORANDI['blue'], MORANDI['orange'], MORANDI['red']]

    for i, (method, color) in enumerate(zip(methods, method_colors)):
        offset = (i - 1) * width
        ax1.bar(x + offset, means[:, i], width, yerr=stds[:, i],
                label=method, color=color, edgecolor=MORANDI['dark'],
                linewidth=0.8, capsize=3, error_kw={'linewidth': 1})

    ax1.set_xticks(x)
    ax1.set_xticklabels(attacks)
    ax1.set_ylabel('Episode Return')
    ax1.set_title('(a) Byzantine Attack Comparison (n=4)')
    ax1.legend(fontsize=11)
    ax1.set_facecolor(MORANDI['cream'])
    ax1.grid(axis='y', alpha=0.3, color=MORANDI['gray'])

    # (b) Scalability bar chart
    labels = ['Clean', 'f=2']
    cr_values = [1.0, 0.230]
    colors_b = [MORANDI['green'], MORANDI['purple']]

    bars = ax2.bar(labels, cr_values, color=colors_b, edgecolor=MORANDI['dark'],
                   linewidth=0.8, width=0.45)

    for bar, val in zip(bars, cr_values):
        ax2.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.02,
                 f'{val:.3f}', ha='center', va='bottom', fontsize=12, color=MORANDI['dark'])

    ax2.set_ylabel('Consensus Rate (CR)')
    ax2.set_title('(b) Scalability (n=7)')
    ax2.set_ylim(0, 1.15)
    ax2.set_facecolor(MORANDI['cream'])
    ax2.grid(axis='y', alpha=0.3, color=MORANDI['gray'])

    fig.patch.set_facecolor('white')
    plt.tight_layout()
    plt.savefig(SAVE_DIR + 'Figure4-ByzantineComparison.png', bbox_inches='tight')
    plt.close()
    print("Figure 4 saved.")

# ============================================================
# Figure 5: 2×2 Ablation Heatmap
# ============================================================
def figure5():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))

    # Mean return heatmap
    mean_data = np.array([
        [-81.4, -71.5],
        [-72.3, -55.5],
    ])

    # Std dev heatmap
    std_data = np.array([
        [5.5, 10.4],
        [3.5, 19.8],
    ])

    # Custom Morandi colormap: light (good) to dark (bad)
    from matplotlib.colors import LinearSegmentedColormap

    # For mean return: higher (less negative) is better → light; lower (more negative) is worse → dark
    morandi_cmap_mean = LinearSegmentedColormap.from_list(
        'morandi_mean', [MORANDI['cream'], MORANDI['light'], MORANDI['gray'], MORANDI['dark']], N=256
    )

    # For std dev: lower is better → light; higher is worse → dark
    morandi_cmap_std = LinearSegmentedColormap.from_list(
        'morandi_std', [MORANDI['cream'], MORANDI['light'], MORANDI['gray'], MORANDI['dark']], N=256
    )

    # Plot mean return
    im1 = ax1.imshow(mean_data, cmap=morandi_cmap_mean, aspect='auto')
    ax1.set_xticks([0, 1])
    ax1.set_xticklabels(['Loss ON', 'Loss OFF'])
    ax1.set_yticks([0, 1])
    ax1.set_yticklabels(['Filter ON', 'Filter OFF'])
    ax1.set_title('(a) Mean Return')

    # Add text annotations
    for i in range(2):
        for j in range(2):
            val = mean_data[i, j]
            text_color = 'white' if val < -75 else MORANDI['dark']
            ax1.text(j, i, f'{val:.1f}', ha='center', va='center', fontsize=14, color=text_color, fontweight='bold')

    # Plot std dev
    im2 = ax2.imshow(std_data, cmap=morandi_cmap_std, aspect='auto')
    ax2.set_xticks([0, 1])
    ax2.set_xticklabels(['Loss ON', 'Loss OFF'])
    ax2.set_yticks([0, 1])
    ax2.set_yticklabels(['Filter ON', 'Filter OFF'])
    ax2.set_title('(b) Standard Deviation')

    for i in range(2):
        for j in range(2):
            val = std_data[i, j]
            text_color = 'white' if val > 14 else MORANDI['dark']
            ax2.text(j, i, f'{val:.1f}', ha='center', va='center', fontsize=14, color=text_color, fontweight='bold')

    # Add colorbars
    cbar1 = fig.colorbar(im1, ax=ax1, shrink=0.8)
    cbar1.ax.tick_params(labelsize=11)
    cbar2 = fig.colorbar(im2, ax=ax2, shrink=0.8)
    cbar2.ax.tick_params(labelsize=11)

    fig.patch.set_facecolor('white')
    plt.tight_layout()
    plt.savefig(SAVE_DIR + 'Figure5-AblationHeatmap.png', bbox_inches='tight')
    plt.close()
    print("Figure 5 saved.")

# ============================================================
# Figure 6: Seed-level Return Scatter
# ============================================================
def figure6():
    conditions = ['Full', 'Loss Only', 'Filter Only', 'MAPPO', 'MAPPO+L2']
    data = {
        'Full': [-87.7, -77.9, -78.6],
        'Loss Only': [-69.5, -76.3, -71.2],
        'Filter Only': [-78.0, -59.5, -76.9],
        'MAPPO': [-39.1, -77.5, -49.7],
        'MAPPO+L2': [-69.8, -40.7, -73.9],
    }

    condition_colors = {
        'Full': MORANDI['blue'],
        'Loss Only': MORANDI['green'],
        'Filter Only': MORANDI['orange'],
        'MAPPO': MORANDI['red'],
        'MAPPO+L2': MORANDI['purple'],
    }

    fig, ax = plt.subplots(figsize=(8, 5))

    np.random.seed(0)
    for i, cond in enumerate(conditions):
        values = data[cond]
        mean_val = np.mean(values)
        # jitter
        jitter = np.random.uniform(-0.15, 0.15, len(values))
        xs = [i + j for j in jitter]

        # Plot scatter points
        ax.scatter(xs, values, color=condition_colors[cond], s=80, zorder=3,
                   edgecolors=MORANDI['dark'], linewidth=0.8, label=cond)

        # Plot mean line
        ax.hlines(mean_val, i - 0.25, i + 0.25, colors=MORANDI['dark'],
                  linewidth=2, zorder=2, linestyles='-')

    ax.set_xticks(range(len(conditions)))
    ax.set_xticklabels(conditions, fontsize=12)
    ax.set_ylabel('Episode Return')
    ax.set_facecolor(MORANDI['cream'])
    ax.grid(axis='y', alpha=0.3, color=MORANDI['gray'])
    ax.legend(loc='lower left', fontsize=11, ncol=2)

    fig.patch.set_facecolor('white')
    plt.tight_layout()
    plt.savefig(SAVE_DIR + 'Figure6-SeedScatter.png', bbox_inches='tight')
    plt.close()
    print("Figure 6 saved.")

# ============================================================
# Generate all figures
# ============================================================
if __name__ == '__main__':
    figure1()
    figure2()
    figure3()
    figure4()
    figure5()
    figure6()
    print("\nAll 6 figures generated successfully!")
