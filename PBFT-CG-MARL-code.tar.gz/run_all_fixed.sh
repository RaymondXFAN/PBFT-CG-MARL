#!/bin/bash
# ============================================================
# PBFT-CG-MARL 串行实验脚本（避免 fork 资源耗尽）
# 设计: 6 算法 × 4 环境 × 3 seed = 72 个实验，逐次串行运行
# 用法:
#   前台:  bash run_all_fixed.sh 0 1
#   后台:  nohup bash run_all_fixed.sh 0 1 > all_experiments.log 2>&1 &
# 参数:  $1=gpu_id  $2=start_exp(用于断点续跑)
# ============================================================
set -e

GPU_ID=${1:-0}
START_EXP=${2:-1}
SEEDS=3                      # 每个 (algo,env) 跑 3 个 seed
LOG_DIR="results/$(date +%Y%m%d_%H%M%S)"
mkdir -p "$LOG_DIR"

echo "========================================="
echo "PBFT-CG-MARL 串行实验 (run_all_fixed.sh)"
echo "GPU: $GPU_ID | LOG: $LOG_DIR | START_EXP: $START_EXP"
echo "总实验数: 72 (6 algo x 4 env x 3 seed)"
echo "========================================="

# 单个实验: 前台运行，完成后再进入下一个（关键: 不加 & ）
run_exp() {
    local exp_id=$1 algo=$2 env=$3 env_config=$4 n_timesteps=$5 n_seeds=$6
    shift 6
    local extra_args="$@"
    if [ "$exp_id" -lt "$START_EXP" ]; then
        echo "[$(date +%H:%M:%S)] Exp $exp_id 跳过 (start=$START_EXP)"
        return
    fi
    echo "[$(date +%H:%M:%S)] >>> Exp $exp_id: $algo @ $env ($n_seeds seeds, $n_timesteps steps)"
    for seed in $(seq 1 "$n_seeds"); do
        echo "[$(date +%H:%M:%S)]   - seed $seed 开始"
        python -u src/train.py \
            --algo "$algo" \
            --env "$env" \
            --env_config "$env_config" \
            --algo_config "configs/algo/${algo}.yaml" \
            --seed "$seed" \
            --n_timesteps "$n_timesteps" \
            --eval_interval 10000 \
            --eval_episodes 10 \
            --log_dir "$LOG_DIR/${algo}_${env}_seed${seed}" \
            --gpu "$GPU_ID" \
            $extra_args \
            2>&1 | tee "$LOG_DIR/${algo}_${env}_seed${seed}.log"
        echo "[$(date +%H:%M:%S)]   - seed $seed 完成"
    done
    echo "[$(date +%H:%M:%S)] <<< Exp $exp_id 结束"
}

# ============================================================
# 环境步数 (按环境复杂度设定合理上限, 适配 ~8h 总时长)
# ============================================================
MPE_STEPS=1000000        # MPE 系列
SMAC_STEPS=2000000       # SMAClite 系列
LBF_STEPS=1000000        # LBF
VMAS_STEPS=1000000       # VMAS 系列

# ============================================================
# E1: MPE-spread (基础协作)
# ============================================================
run_exp 1  pbft_cg_mappo mpe_spread     configs/env/mpe_spread.yaml     $MPE_STEPS  $SEEDS
run_exp 2  mappo          mpe_spread     configs/env/mpe_spread.yaml     $MPE_STEPS  $SEEDS
run_exp 3  qmix           mpe_spread     configs/env/mpe_spread.yaml     $MPE_STEPS  $SEEDS
run_exp 4  maddpg         mpe_spread     configs/env/mpe_spread.yaml     $MPE_STEPS  $SEEDS
run_exp 5  commnet        mpe_spread     configs/env/mpe_spread.yaml     $MPE_STEPS  $SEEDS
run_exp 6  tarmac         mpe_spread     configs/env/mpe_spread.yaml     $MPE_STEPS  $SEEDS

# ============================================================
# E2: MPE-reference (通信约束)
# ============================================================
run_exp 7  pbft_cg_mappo mpe_reference   configs/env/mpe_reference.yaml   $MPE_STEPS  $SEEDS
run_exp 8  mappo          mpe_reference   configs/env/mpe_reference.yaml   $MPE_STEPS  $SEEDS
run_exp 9  qmix           mpe_reference   configs/env/mpe_reference.yaml   $MPE_STEPS  $SEEDS
run_exp 10 maddpg         mpe_reference   configs/env/mpe_reference.yaml   $MPE_STEPS  $SEEDS
run_exp 11 commnet        mpe_reference   configs/env/mpe_reference.yaml   $MPE_STEPS  $SEEDS
run_exp 12 tarmac         mpe_reference   configs/env/mpe_reference.yaml   $MPE_STEPS  $SEEDS

# ============================================================
# E3: SMAClite 3s5z (异构协作)
# ============================================================
run_exp 13 pbft_cg_mappo smaclite_3s5z   configs/env/smaclite_3s5z.yaml   $SMAC_STEPS  $SEEDS
run_exp 14 mappo          smaclite_3s5z   configs/env/smaclite_3s5z.yaml   $SMAC_STEPS  $SEEDS
run_exp 15 qmix           smaclite_3s5z   configs/env/smaclite_3s5z.yaml   $SMAC_STEPS  $SEEDS
run_exp 16 maddpg         smaclite_3s5z   configs/env/smaclite_3s5z.yaml   $SMAC_STEPS  $SEEDS
run_exp 17 commnet        smaclite_3s5z   configs/env/smaclite_3s5z.yaml   $SMAC_STEPS  $SEEDS
run_exp 18 tarmac         smaclite_3s5z   configs/env/smaclite_3s5z.yaml   $SMAC_STEPS  $SEEDS

# ============================================================
# E4: LBF 2s3f (负载均衡协作) —— 贴近冻土监测站协同场景
# ============================================================
run_exp 19 pbft_cg_mappo lbf_2s3f        configs/env/lbf_2s3f.yaml        $LBF_STEPS  $SEEDS
run_exp 20 mappo          lbf_2s3f        configs/env/lbf_2s3f.yaml        $LBF_STEPS  $SEEDS
run_exp 21 qmix           lbf_2s3f        configs/env/lbf_2s3f.yaml        $LBF_STEPS  $SEEDS
run_exp 22 maddpg         lbf_2s3f        configs/env/lbf_2s3f.yaml        $LBF_STEPS  $SEEDS
run_exp 23 commnet        lbf_2s3f        configs/env/lbf_2s3f.yaml        $LBF_STEPS  $SEEDS
run_exp 24 tarmac         lbf_2s3f        configs/env/lbf_2s3f.yaml        $LBF_STEPS  $SEEDS

# ============================================================
echo "[$(date +%H:%M:%S)] ====== 全部 72 实验完成 ======"
echo "结果目录: $LOG_DIR"
