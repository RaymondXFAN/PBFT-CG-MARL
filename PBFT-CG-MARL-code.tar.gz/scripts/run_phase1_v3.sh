#!/bin/bash
# ============================================================
# PBFT-CG-MARL Phase 1-v3: 自适应熵调度 (0.1→0.01 线性衰减)
# 总计: 6 组实验, 预计 ~9 小时 (RTX 4090)
#
# 用法:
#   后台:  nohup bash scripts/run_phase1_v3.sh 0 > phase1_v3.log 2>&1 &
#   监控:  tail -f phase1_v3.log
# 参数:  $1=gpu_id
# ============================================================
set -e

GPU_ID=${1:-0}
LOG_ROOT="results/v2/phase1_v3"
mkdir -p "$LOG_ROOT"

echo "========================================="
echo "PBFT-CG-MARL Phase 1-v3: 自适应熵调度"
echo "GPU: $GPU_ID | LOG: $LOG_ROOT"
echo "entropy_coef: 0.1 → 0.01 (linear decay)"
echo "总实验数: 6 (PBFT-CG 3 seeds + MAPPO 3 seeds)"
echo "========================================="

TOTAL=0
DONE=0

run_one() {
    local exp_name=$1; shift
    echo ""
    echo "[$(date +%H:%M:%S)] >>> [$TOTAL] $exp_name"
    local start_time=$(date +%s)
    
    python -u src/train.py "$@" 2>&1 | tee "$LOG_ROOT/${exp_name}.log"
    local exit_code=${PIPESTATUS[0]}
    
    local end_time=$(date +%s)
    local elapsed=$(( (end_time - start_time) / 60 ))
    
    if [ $exit_code -eq 0 ]; then
        DONE=$((DONE+1))
        echo "[$(date +%H:%M:%S)] <<< $exp_name 完成 (${elapsed}min) | 进度: $DONE/$TOTAL"
    else
        echo "[$(date +%H:%M:%S)] <<< $exp_name 失败! (exit=$exit_code) | 进度: $DONE/$TOTAL"
    fi
}

# ============================================================
# PBFT-CG-MAPPO (v3: 自适应熵调度) on simple_spread
# ============================================================
echo ""
echo "=== PBFT-CG-MAPPO (adaptive entropy) on simple_spread ==="

for seed in 1 2 3; do
    TOTAL=$((TOTAL+1))
    run_one "pbft_v3_spread_seed${seed}" \
        --algo pbft_cg_mappo \
        --env simple_spread \
        --algo_config configs/algo/pbft_cg_mappo_v3.yaml \
        --seed $seed \
        --n_timesteps 500000 \
        --eval_interval 10000 \
        --eval_episodes 10 \
        --log_dir "$LOG_ROOT/pbft_v3_spread_seed${seed}" \
        --gpu $GPU_ID
done

# ============================================================
# MAPPO (v3: 自适应熵调度) 对照组
# ============================================================
echo ""
echo "=== MAPPO (adaptive entropy) on simple_spread ==="

for seed in 1 2 3; do
    TOTAL=$((TOTAL+1))
    run_one "mappo_v3_spread_seed${seed}" \
        --algo mappo \
        --env simple_spread \
        --algo_config configs/algo/mappo_v3.yaml \
        --seed $seed \
        --n_timesteps 500000 \
        --eval_interval 10000 \
        --eval_episodes 10 \
        --log_dir "$LOG_ROOT/mappo_v3_spread_seed${seed}" \
        --gpu $GPU_ID
done

# ============================================================
# 完成
# ============================================================
echo ""
echo "========================================="
echo "Phase 1-v3 完成! $DONE/$TOTAL 成功"
echo "结果目录: $LOG_ROOT"
echo ""
echo "=== 快速查看结果 ==="
echo "python3 << 'PYEOF'"
echo "import json, os, numpy as np"
echo "def get_last10(path):"
echo "    d = json.load(open(path))"
echo "    r = d.get('episode/episode_reward', [])"
echo "    return float(np.mean(r[-10:])) if r else None"
echo "for algo in ['pbft_v3', 'mappo_v3']:"
echo "    vals = []"
echo "    for s in [1,2,3]:"
echo "        f = '$LOG_ROOT/{a}_spread_seed{s}/{a.replace(\"_v3\",\"\")}/seed_{s}/metrics.json'"
echo "        if os.path.exists(f): vals.append(get_last10(f)); print(f'  {a} seed{s}: {vals[-1]:.1f}')"
echo "    if vals: print(f'  >>> {algo}: {np.mean(vals):.1f} ± {np.std(vals):.1f}')"
echo "PYEOF"
echo "========================================="
