#!/bin/bash
# ============================================================
# PBFT-CG-MARL v5 结果收集脚本
# 用法:  bash scripts/collect_v5_results.sh
# ============================================================

LOG_ROOT="results/v5_rerun"
OUTFILE="results/v5_rerun/summary.txt"

echo "=== PBFT-CG-MARL v5 结果汇总 ===" > "$OUTFILE"
echo "生成时间: $(date)" >> "$OUTFILE"
echo "" >> "$OUTFILE"

collect_one() {
    local label=$1
    local dir=$2
    local mfile=$(find "$dir" -name "metrics.json" 2>/dev/null | head -1)
    if [ -n "$mfile" ]; then
        echo "  ✅ $label: $(cat $mfile)" | tee -a "$OUTFILE"
    else
        echo "  ❌ $label: 未找到" | tee -a "$OUTFILE"
    fi
}

echo "--- P0: PBFT-CG-MAPPO (entropy_coef=0.15) ---" | tee -a "$OUTFILE"
for seed in 1 2 3; do
    collect_one "Seed $seed" "$LOG_ROOT/pbft_v5_spread_seed${seed}"
done

echo "" | tee -a "$OUTFILE"
echo "--- P0-ctrl: MAPPO (entropy_coef=0.15) ---" | tee -a "$OUTFILE"
for seed in 1 2 3; do
    collect_one "Seed $seed" "$LOG_ROOT/mappo_v5_spread_seed${seed}"
done

echo "" | tee -a "$OUTFILE"
echo "--- P1: Byzantine f=1 ---" | tee -a "$OUTFILE"
for btype in random adversarial silence; do
    echo "  Attack: $btype" | tee -a "$OUTFILE"
    for seed in 1 2 3; do
        collect_one "  Seed $seed" "$LOG_ROOT/byzantine_f1_${btype}_seed${seed}"
    done
done

echo "" | tee -a "$OUTFILE"
echo "=== 汇总完成 ===" | tee -a "$OUTFILE"
