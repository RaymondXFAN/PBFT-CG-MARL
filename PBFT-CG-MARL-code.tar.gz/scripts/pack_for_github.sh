#!/bin/bash
###############################################################################
# PBFT-CG-MARL 打包脚本 (v2.1)
# 在 AutoDL 服务器上执行，生成可上传 GitHub 的代码包
# 排除: 原始数据、模型权重、大日志、__pycache__
###############################################################################

set -e

PROJ="/root/autodl-tmp/CGMARL"
OUTDIR="/root/autodl-tmp"
OUTNAME="PBFT-CG-MARL_v2.1_code.tar.gz"
OUTPATH="$OUTDIR/$OUTNAME"

cd "$PROJ"

echo "========================================="
echo "PBFT-CG-MARL v2.1 打包"
echo "========================================="

tar czf "$OUTPATH" \
  --exclude='*.pt' \
  --exclude='*.pth' \
  --exclude='__pycache__' \
  --exclude='*.pyc' \
  --exclude='wandb' \
  --exclude='*.log' \
  --exclude='results/*/model_*' \
  --exclude='results/reviewer_exp/*/metrics.json' \
  --exclude='tpdc_data' \
  --exclude='hf_cache' \
  --exclude='.git' \
  --exclude='DARE' \
  --exclude='nohup.out' \
  --exclude='*.xlsx' \
  --exclude='*.docx' \
  --transform='s,^,PBFT-CG-MARL/,' \
  src/ \
  configs/ \
  scripts/ \
  paper_figures/ \
  figures/ \
  results/*/metrics.json \
  results/*/*/metrics.json \
  results/*/*/*/metrics.json \
  requirements.txt \
  README.md \
  PBFT_CG_MAPPO_paper_v2.md \
  run_all.sh \
  run_all_fixed.sh \
  2>/dev/null || true

echo ""
echo "✅ 打包完成!"
echo "文件: $OUTPATH"
echo "大小: $(du -h $OUTPATH | cut -f1)"
echo ""
echo "=== 解压命令 (目标机器上) ==="
echo "mkdir -p /root/autodl-tmp/PBFT-CG-MARL && tar -xzf $OUTNAME -C /root/autodl-tmp/"
echo ""
echo "=== 上传 GitHub ==="
echo "1. 下载 $OUTPATH 到本地"
echo "2. 解压到本地文件夹"
echo "3. cd PBFT-CG-MARL && git init && git add . && git commit -m 'v2.1'"
echo "4. git remote add origin https://github.com/RaymondXFAN/PBFT-CG-MARL.git"
echo "5. git push -u origin main --force"
