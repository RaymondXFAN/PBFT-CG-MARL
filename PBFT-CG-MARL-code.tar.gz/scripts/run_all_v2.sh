#!/bin/bash
# ============================================================
# PBFT-CG-MARL 一键启动脚本
# 自动执行: 预检 → Phase1 → Phase2
#
# 用法:
#   后台运行(推荐):  nohup bash scripts/run_all_v2.sh 0 > rerun_v2.log 2>&1 &
#   前台运行:        bash scripts/run_all_v2.sh 0
#   监控:            tail -f rerun_v2.log
#   查看进度:        grep "进度:" rerun_v2.log | tail -5
#   查看结果:        bash scripts/collect_results.sh
# 参数:  $1=gpu_id
# ============================================================
set -e

GPU_ID=${1:-0}
LOG_ROOT="results/v2"
mkdir -p "$LOG_ROOT"

echo "========================================="
echo "PBFT-CG-MARL V2 重跑实验 (一键启动)"
echo "GPU: $GPU_ID | LOG: $LOG_ROOT"
echo "开始时间: $(date)"
echo "========================================="

# ── Step 0: 预检 ──
echo ""
echo "=== Step 0: 预检 (~5分钟) ==="
bash scripts/precheck.sh $GPU_ID
if [ $? -ne 0 ]; then
    echo "❌ 预检失败! 请修复后再运行"
    exit 1
fi
echo "✅ 预检通过!"

# ── Step 1: Phase 1 (P0+P1) ──
echo ""
echo "=== Step 1: Phase 1 — 熵修复 + 拜占庭多种子 (~22-24h) ==="
bash scripts/run_phase1.sh $GPU_ID

# ── Step 2: Phase 2 (P2) ──
echo ""
echo "=== Step 2: Phase 2 — 新环境 mpe_reference (~22-24h) ==="
bash scripts/run_phase2.sh $GPU_ID

# ── Step 3: 收集结果 ──
echo ""
echo "=== Step 3: 收集结果 ==="
bash scripts/collect_results.sh

echo ""
echo "========================================="
echo "全部实验完成! 结束时间: $(date)"
echo "结果目录: $LOG_ROOT"
echo "========================================="
