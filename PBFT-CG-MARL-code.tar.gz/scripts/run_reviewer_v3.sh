#!/bin/bash
# ============================================================
# PBFT-CG-MARL 审稿补充实验脚本 (v3.0 Reviewer Experiments)
# ============================================================
# 四大实验组：
#   EXP-1: 2×2 消融 (Filter × Loss) — clean + 3 attacks × 3 seeds
#   EXP-2: MAPPO baseline under Byzantine attacks (补充对照组)
#   EXP-3: n=7 (f=2) 规模实验 — 证明大团队下 silence 可容忍
#   EXP-4: 预检 (5分钟验证)
#
# 部署位置: /root/autodl-tmp/PBFT-CG-MARL/
# 环境: conda activate pbft
# 运行: nohup bash scripts/run_reviewer_v3.sh > reviewer_v3.log 2>&1 &
# 监控: tail -f reviewer_v3.log
# ============================================================

set -e

# ============== 配置 ==============
MAX_PARALLEL=3          # RTX 4090 + 16核CPU，3路并行无压力
N_TIMESTEPS=500000      # 500k steps per run
EVAL_INTERVAL=10000     # 评估间隔
EVAL_EPISODES=10        # 评估回合数
SEEDS="1 2 3"           # 3 seeds
GPU=0                   # GPU ID

# V5 配置文件
ALGO_CFG="configs/algo/pbft_cg_mappo_v5.yaml"
ENV_CFG="configs/env/mpe_spread.yaml"

# 结果根目录
RESULT_ROOT="./results/reviewer_v3"
mkdir -p "$RESULT_ROOT"

# ============== 预检 (EXP-4) ==============
echo "============================================================"
echo "[PRECHECK] 5分钟冒烟测试 (3 seeds并行)"
echo "============================================================"

PRECHECK_DIR="$RESULT_ROOT/precheck"
mkdir -p "$PRECHECK_DIR"

# 测试4个关键配置
declare -A PRECHECK_CONFIGS
PRECHECK_CONFIGS["full"]=""
PRECHECK_CONFIGS["no_consensus"]="--ablation no_consensus"
PRECHECK_CONFIGS["no_filter"]="--ablation no_filter"
PRECHECK_CONFIGS["no_loss"]="--ablation no_loss"

for variant in full no_consensus no_filter no_loss; do
    ablation_flag="${PRECHECK_CONFIGS[$variant]}"
    python -u src/train.py \
        --algo pbft_cg_mappo --env mpe_spread \
        --algo_config "$ALGO_CFG" \
        --n_timesteps 5000 --eval_interval 5000 --eval_episodes 5 \
        --seed 1 --gpu $GPU \
        $ablation_flag \
        --log_dir "$PRECHECK_DIR/${variant}" &
done

echo "[PRECHECK] 等待4个预检任务完成..."
wait
echo "[PRECHECK] ✅ 预检完成！检查结果:"
for variant in full no_consensus no_filter no_loss; do
    if [ -f "$PRECHECK_DIR/${variant}/pbft_cg_mappo/metrics.json" ]; then
        echo "  ✅ $variant: metrics.json 存在"
    else
        echo "  ❌ $variant: metrics.json 缺失！"
    fi
done

echo ""
echo "============================================================"
echo "预检通过，开始正式实验"
echo "============================================================"
echo ""

# ============== EXP-1: 2×2 消融 (Filter × Loss) ==============
echo "============================================================"
echo "[EXP-1] 2×2 消融: {Filter on/off} × {Loss on/off}"
echo "  - Full (Filter=ON, Loss=ON): 已有数据，跳过"
echo "  - no_filter (Filter=OFF, Loss=ON): 新增"
echo "  - no_loss (Filter=ON, Loss=OFF): 新增"
echo "  - no_consensus (Filter=OFF, Loss=OFF): 已有部分数据"
echo "  - 条件: clean + 3 attacks × 3 seeds"
echo "============================================================"

RUN_COUNT=0
TOTAL_RUNS=0

# 4 variants × 4 conditions (clean + 3 attacks) × 3 seeds = 48 runs
# Full 已有: clean 3 seeds + 3 attacks 3 seeds = 12 runs (跳过)
# no_consensus 已有: 3 attacks 3 seeds = 9 runs (需补 clean 3 seeds)
# 新增: no_filter 4×3 = 12 runs, no_loss 4×3 = 12 runs, no_consensus clean 3 seeds

ATTACKS=("clean" "random" "adversarial" "silence")

for variant in no_filter no_loss; do
    for condition in "${ATTACKS[@]}"; do
        for seed in $SEEDS; do
            
            # 确定 ablation flag
            ablation_flag="--ablation ${variant}"
            
            # 确定 byzantine 参数
            if [ "$condition" = "clean" ]; then
                byz_n=0
                byz_type="random"  # 不影响
            else
                byz_n=1
                byz_type="$condition"
            fi
            
            # log 目录
            log_dir="$RESULT_ROOT/exp1_2x2/${variant}/${condition}/seed_${seed}"
            mkdir -p "$log_dir"
            
            # 并行控制
            if [ $((RUN_COUNT % MAX_PARALLEL)) -eq 0 ] && [ $RUN_COUNT -gt 0 ]; then
                echo "[EXP-1] 等待当前批次完成... (已提交 $RUN_COUNT 个任务)"
                wait
            fi
            
            echo "[EXP-1] 启动: variant=$variant condition=$condition seed=$seed"
            python -u src/train.py \
                --algo pbft_cg_mappo --env mpe_spread \
                --algo_config "$ALGO_CFG" \
                --n_timesteps $N_TIMESTEPS \
                --eval_interval $EVAL_INTERVAL \
                --eval_episodes $EVAL_EPISODES \
                --seed $seed --gpu $GPU \
                --byzantine_n $byz_n --byzantine_type "$byz_type" \
                $ablation_flag \
                --log_dir "$log_dir" &
            
            RUN_COUNT=$((RUN_COUNT + 1))
            TOTAL_RUNS=$((TOTAL_RUNS + 1))
        done
    done
done

# no_consensus 补 clean 条件 (3 seeds)
for seed in $SEEDS; do
    log_dir="$RESULT_ROOT/exp1_2x2/no_consensus/clean/seed_${seed}"
    mkdir -p "$log_dir"
    
    if [ $((RUN_COUNT % MAX_PARALLEL)) -eq 0 ] && [ $RUN_COUNT -gt 0 ]; then
        echo "[EXP-1] 等待当前批次完成..."
        wait
    fi
    
    echo "[EXP-1] 启动: variant=no_consensus condition=clean seed=$seed"
    python -u src/train.py \
        --algo pbft_cg_mappo --env mpe_spread \
        --algo_config "$ALGO_CFG" \
        --n_timesteps $N_TIMESTEPS \
        --eval_interval $EVAL_INTERVAL \
        --eval_episodes $EVAL_EPISODES \
        --seed $seed --gpu $GPU \
        --ablation no_consensus \
        --log_dir "$log_dir" &
    
    RUN_COUNT=$((RUN_COUNT + 1))
    TOTAL_RUNS=$((TOTAL_RUNS + 1))
done

echo "[EXP-1] 等待所有2×2消融任务完成... (共 $TOTAL_RUNS 个新任务)"
wait
echo "[EXP-1] ✅ 完成！"

# ============== EXP-2: MAPPO baseline under attacks (补充对照) ==============
echo ""
echo "============================================================"
echo "[EXP-2] MAPPO baseline under Byzantine attacks"
echo "  - 3 attacks × 3 seeds = 9 runs"
echo "  - 目的: 为 Table 4 提供完整 MAPPO+attack 对照"
echo "============================================================"

RUN_COUNT=0
TOTAL_EXP2=0

for attack in random adversarial silence; do
    for seed in $SEEDS; do
        log_dir="$RESULT_ROOT/exp2_mappo_attacked/${attack}/seed_${seed}"
        mkdir -p "$log_dir"
        
        if [ $((RUN_COUNT % MAX_PARALLEL)) -eq 0 ] && [ $RUN_COUNT -gt 0 ]; then
            echo "[EXP-2] 等待当前批次完成..."
            wait
        fi
        
        echo "[EXP-2] 启动: mappo attack=$attack seed=$seed"
        python -u src/train.py \
            --algo mappo --env mpe_spread \
            --algo_config configs/algo/mappo_v3.yaml \
            --n_timesteps $N_TIMESTEPS \
            --eval_interval $EVAL_INTERVAL \
            --eval_episodes $EVAL_EPISODES \
            --seed $seed --gpu $GPU \
            --byzantine_n 1 --byzantine_type "$attack" \
            --log_dir "$log_dir" &
        
        RUN_COUNT=$((RUN_COUNT + 1))
        TOTAL_EXP2=$((TOTAL_EXP2 + 1))
    done
done

echo "[EXP-2] 等待所有 MAPPO+attack 任务完成... (共 $TOTAL_EXP2 个)"
wait
echo "[EXP-2] ✅ 完成！"

# ============== EXP-3: n=7 (f=2) 规模实验 ==============
echo ""
echo "============================================================"
echo "[EXP-3] n=7 (f=2) 规模实验"
echo "  - 证明大团队下 silence attack 可容忍"
echo "  - 条件: clean + 3 attacks × 3 seeds"
echo "  - 需要先创建 n=7 环境配置"
echo "============================================================"

# 创建 n=7 环境配置
ENV7_CFG="configs/env/mpe_spread_n7.yaml"
if [ ! -f "$ENV7_CFG" ]; then
    cat > "$ENV7_CFG" <<EOF
env: mpe_spread
scenario: simple_spread
n_agents: 7
max_steps: 100
continuous_actions: false
EOF
    echo "[EXP-3] 已创建 $ENV7_CFG"
fi

# 创建 n=7 + f=2 算法配置
ALGO7_CFG="configs/algo/pbft_cg_mappo_v5_n7.yaml"
if [ ! -f "$ALGO7_CFG" ]; then
    cat > "$ALGO7_CFG" <<EOF
algorithm: pbft_cg_mappo
lr: 0.0005
clip_ratio: 0.2
value_loss_coef: 1.0
entropy_coef: 0.15
gamma: 0.99
gae_lambda: 0.95
ppo_epoch: 5
num_mini_batch: 1
hidden_dim: 64
use_ReLU: true
use_feature_normalization: true
share_param: true
use_rnn: true
rnn_type: gru
# PBFT specific
pbft:
  f: 2
  leader_rotation: true
  use_fallback: true
  consensus_threshold: 0.5
  temperature: 1.0
EOF
    echo "[EXP-3] 已创建 $ALGO7_CFG"
fi

RUN_COUNT=0
TOTAL_EXP3=0

# PBFT-CG-MAPPO: clean + 3 attacks × 3 seeds = 12 runs
for condition in clean random adversarial silence; do
    for seed in $SEEDS; do
        if [ "$condition" = "clean" ]; then
            byz_n=0
            byz_type="random"
        else
            byz_n=2
            byz_type="$condition"
        fi
        
        log_dir="$RESULT_ROOT/exp3_n7/pbft/${condition}/seed_${seed}"
        mkdir -p "$log_dir"
        
        if [ $((RUN_COUNT % MAX_PARALLEL)) -eq 0 ] && [ $RUN_COUNT -gt 0 ]; then
            echo "[EXP-3] 等待当前批次完成..."
            wait
        fi
        
        echo "[EXP-3] 启动: pbft n=7 f=2 condition=$condition seed=$seed"
        python -u src/train.py \
            --algo pbft_cg_mappo --env mpe_spread \
            --algo_config "$ALGO7_CFG" \
            --env_config "$ENV7_CFG" \
            --n_timesteps $N_TIMESTEPS \
            --eval_interval $EVAL_INTERVAL \
            --eval_episodes $EVAL_EPISODES \
            --seed $seed --gpu $GPU \
            --byzantine_n $byz_n --byzantine_type "$byz_type" \
            --log_dir "$log_dir" &
        
        RUN_COUNT=$((RUN_COUNT + 1))
        TOTAL_EXP3=$((TOTAL_EXP3 + 1))
    done
done

# MAPPO baseline: clean + silence × 3 seeds = 6 runs (只跑最关键的)
for condition in clean silence; do
    for seed in $SEEDS; do
        if [ "$condition" = "clean" ]; then
            byz_n=0
            byz_type="random"
        else
            byz_n=2
            byz_type="silence"
        fi
        
        log_dir="$RESULT_ROOT/exp3_n7/mappo/${condition}/seed_${seed}"
        mkdir -p "$log_dir"
        
        if [ $((RUN_COUNT % MAX_PARALLEL)) -eq 0 ] && [ $RUN_COUNT -gt 0 ]; then
            echo "[EXP-3] 等待当前批次完成..."
            wait
        fi
        
        echo "[EXP-3] 启动: mappo n=7 condition=$condition seed=$seed"
        python -u src/train.py \
            --algo mappo --env mpe_spread \
            --algo_config configs/algo/mappo_v3.yaml \
            --env_config "$ENV7_CFG" \
            --n_timesteps $N_TIMESTEPS \
            --eval_interval $EVAL_INTERVAL \
            --eval_episodes $EVAL_EPISODES \
            --seed $seed --gpu $GPU \
            --byzantine_n $byz_n --byzantine_type "$byz_type" \
            --log_dir "$log_dir" &
        
        RUN_COUNT=$((RUN_COUNT + 1))
        TOTAL_EXP3=$((TOTAL_EXP3 + 1))
    done
done

echo "[EXP-3] 等待所有 n=7 任务完成... (共 $TOTAL_EXP3 个)"
wait
echo "[EXP-3] ✅ 完成！"

# ============== 结果汇总 ==============
echo ""
echo "============================================================"
echo "全部实验完成！结果汇总:"
echo "============================================================"

echo ""
echo "=== EXP-1: 2×2 消融 ==="
echo "Variant | Condition | Seed | Last-10 Return | CR"
echo "--------|-----------|------|----------------|-----"
for variant in no_filter no_loss no_consensus; do
    for condition in clean random adversarial silence; do
        for seed in $SEEDS; do
            metrics="$RESULT_ROOT/exp1_2x2/${variant}/${condition}/seed_${seed}/pbft_cg_mappo/metrics.json"
            if [ -f "$metrics" ]; then
                # 提取最后10个episode reward的均值
                ret=$(python -c "
import json
with open('$metrics') as f: d=json.load(f)
r = d.get('episode/episode_reward', [])
print(f'{r[-1]:.1f}' if r else 'N/A')
" 2>/dev/null || echo "N/A")
                cr=$(python -c "
import json
with open('$metrics') as f: d=json.load(f)
r = d.get('train/consensus_rate', [])
print(f'{r[-1]:.3f}' if r else 'N/A')
" 2>/dev/null || echo "N/A")
                echo "$variant | $condition | $seed | $ret | $cr"
            else
                echo "$variant | $condition | $seed | MISSING | -"
            fi
        done
    done
done

echo ""
echo "=== EXP-2: MAPPO under attacks ==="
for attack in random adversarial silence; do
    for seed in $SEEDS; do
        metrics="$RESULT_ROOT/exp2_mappo_attacked/${attack}/seed_${seed}/mappo/metrics.json"
        if [ -f "$metrics" ]; then
            ret=$(python -c "
import json
with open('$metrics') as f: d=json.load(f)
r = d.get('episode/episode_reward', [])
print(f'{r[-1]:.1f}' if r else 'N/A')
" 2>/dev/null || echo "N/A")
            echo "mappo | $attack | $seed | $ret"
        else
            echo "mappo | $attack | $seed | MISSING"
        fi
    done
done

echo ""
echo "=== EXP-3: n=7 (f=2) ==="
for algo in pbft mappo; do
    for condition in clean random adversarial silence; do
        for seed in $SEEDS; do
            metrics="$RESULT_ROOT/exp3_n7/${algo}/${condition}/seed_${seed}/${algo}/metrics.json"
            if [ -f "$metrics" ]; then
                ret=$(python -c "
import json
with open('$metrics') as f: d=json.load(f)
r = d.get('episode/episode_reward', [])
print(f'{r[-1]:.1f}' if r else 'N/A')
" 2>/dev/null || echo "N/A")
                cr=$(python -c "
import json
with open('$metrics') as f: d=json.load(f)
r = d.get('train/consensus_rate', [])
print(f'{r[-1]:.3f}' if r else 'N/A')
" 2>/dev/null || echo "N/A")
                echo "n=7 $algo | $condition | $seed | $ret | $cr"
            else
                if [ "$algo" = "mappo" ] && [ "$condition" != "clean" ] && [ "$condition" != "silence" ]; then
                    continue  # MAPPO 只跑 clean + silence
                fi
                echo "n=7 $algo | $condition | $seed | MISSING"
            fi
        done
    done
done

echo ""
echo "============================================================"
echo "全部完成！结果在 $RESULT_ROOT"
echo "============================================================"
