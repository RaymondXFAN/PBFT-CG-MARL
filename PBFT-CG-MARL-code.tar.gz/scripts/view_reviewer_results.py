#!/usr/bin/env python
"""
PBFT-CG-MARL 审稿人补充实验结果查看器
读取 metrics.json，生成 EXP-A / EXP-B 对比表

用法: python view_reviewer_results.py
"""

import json, os, numpy as np

ROOT = "/root/autodl-tmp/CGMARL/results/reviewer_exp"

def get_metrics(path):
    """从 metrics.json 提取 last-10 episode 均值"""
    if not os.path.exists(path):
        return None, None
    try:
        with open(path) as f:
            d = json.load(f)
        r = d.get("episode/episode_reward", [])
        cr = d.get("episode/consensus_rate", d.get("train/consensus_rate", []))
        r10 = float(np.mean(r[-10:])) if len(r) >= 10 else (float(np.mean(r)) if r else None)
        cr10 = float(np.mean(cr[-10:])) if len(cr) >= 10 else (float(np.mean(cr)) if cr else None)
        return r10, cr10
    except Exception as e:
        print(f"  ⚠️ 读取 {path} 失败: {e}")
        return None, None

def find_metrics(label, seed, algo_dir):
    """查找 metrics.json 路径"""
    base = f"{ROOT}/{label}_seed{seed}"
    # 尝试多种目录结构
    candidates = [
        f"{base}/{algo_dir}/seed_{seed}/metrics.json",
        f"{base}/metrics.json",
        f"{base}/{algo_dir}/metrics.json",
    ]
    # 也尝试 glob
    for c in candidates:
        if os.path.exists(c):
            return c
    # glob fallback
    import glob
    matches = glob.glob(f"{base}/**/metrics.json", recursive=True)
    return matches[0] if matches else None

print("=" * 72)
print("PBFT-CG-MARL 审稿人补充实验结果")
print("=" * 72)

# ============ 1. 运行状态总览 ============
print("\n📋 运行状态总览")
print("-" * 72)
exp_labels = []
for label_dir in sorted(os.listdir(ROOT)):
    full_path = os.path.join(ROOT, label_dir)
    if os.path.isdir(full_path):
        log_file = full_path + ".log"
        has_metrics = False
        # 递归查找 metrics.json
        for root, dirs, files in os.walk(full_path):
            if "metrics.json" in files:
                has_metrics = True
                break
        status = "✅ 完成" if has_metrics else ("⚠️ 无结果" if os.path.exists(log_file) else "❓ 未知")
        print(f"  {label_dir:45s} {status}")

# ============ 2. EXP-A: MAPPO under Byzantine ============
print("\n" + "=" * 72)
print("📊 EXP-A: MAPPO under Byzantine Attack (对照基线)")
print("-" * 72)
print(f"  {'Attack':>12s} | {'Seed 1':>8s} | {'Seed 2':>8s} | {'Seed 3':>8s} | {'Mean ± Std':>14s}")
print(f"  {'-'*12}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}-+-{'-'*14}")

mappo_results = {}
for btype in ["random", "adversarial", "silence"]:
    vals = []
    row = f"  {btype:>12s} |"
    for s in [1, 2, 3]:
        path = find_metrics(f"mappo_byz_f1_{btype}", s, "mappo")
        r, cr = get_metrics(path) if path else (None, None)
        if r is not None:
            vals.append(r)
            row += f" {r:>8.1f} |"
        else:
            row += f"   N/A   |"
    if vals:
        a = np.array(vals)
        row += f" {a.mean():>6.1f} ± {a.std():<5.1f}"
        mappo_results[btype] = {"mean": a.mean(), "std": a.std(), "seeds": vals}
    else:
        row += "    N/A        "
    print(row)

# ============ 3. EXP-B: PBFT no_consensus + Byzantine ============
print("\n" + "=" * 72)
print("📊 EXP-B: PBFT no_consensus + Byzantine Attack (攻击下消融)")
print("-" * 72)
print(f"  {'Attack':>12s} | {'Seed 1':>8s} | {'Seed 2':>8s} | {'Seed 3':>8s} | {'Mean ± Std':>14s} | {'CR (last10)':>12s}")
print(f"  {'-'*12}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}-+-{'-'*14}-+-{'-'*12}")

nocons_results = {}
for btype in ["random", "adversarial", "silence"]:
    vals = []
    crs = []
    row = f"  {btype:>12s} |"
    for s in [1, 2, 3]:
        path = find_metrics(f"pbft_nocons_byz_f1_{btype}", s, "pbft_cg_mappo")
        r, cr = get_metrics(path) if path else (None, None)
        if r is not None:
            vals.append(r)
            if cr is not None:
                crs.append(cr)
            row += f" {r:>8.1f} |"
        else:
            row += f"   N/A   |"
    if vals:
        a = np.array(vals)
        cr_str = f"{np.mean(crs):.3f}" if crs else "N/A"
        row += f" {a.mean():>6.1f} ± {a.std():<5.1f} | {cr_str:>12s}"
        nocons_results[btype] = {"mean": a.mean(), "std": a.std(), "seeds": vals, "cr": np.mean(crs) if crs else None}
    else:
        row += "    N/A         |          N/A"
    print(row)

# ============ 4. 三方对比表 (核心!) ============
print("\n" + "=" * 72)
print("📊 核心对比: PBFT-Full vs PBFT-NoCons vs MAPPO (均 under Byzantine f=1)")
print("-" * 72)

# V5 已有的 PBFT-Full 数据
pbft_full = {
    "random":     {"mean": -41.3, "std": 4.9, "cr_range": "0.30–0.45"},
    "adversarial": {"mean": -39.1, "std": 6.5, "cr_range": "0.10–0.19"},
    "silence":    {"mean": -53.4, "std": 7.4, "cr_range": "0.00"},
}

print(f"  {'Attack':>12s} | {'PBFT-Full':>14s} | {'PBFT-NoCons':>14s} | {'MAPPO':>14s} | {'PBFT优势':>20s}")
print(f"  {'-'*12}-+-{'-'*14}-+-{'-'*14}-+-{'-'*14}-+-{'-'*20}")

for btype in ["random", "adversarial", "silence"]:
    pf = pbft_full.get(btype, {})
    nc = nocons_results.get(btype, {})
    mp = mappo_results.get(btype, {})
    
    pf_str = f"{pf['mean']:>6.1f}±{pf['std']:<5.1f}" if pf else "     N/A     "
    nc_str = f"{nc['mean']:>6.1f}±{nc['std']:<5.1f}" if nc else "     N/A     "
    mp_str = f"{mp['mean']:>6.1f}±{mp['std']:<5.1f}" if mp else "     N/A     "
    
    # 计算优势
    advantage = ""
    if pf and nc:
        consensus_gain = nc["mean"] - pf["mean"]  # 正=PBFT更差，负=PBFT更好
        if abs(consensus_gain) < 5:
            advantage += f"共识: ≈0%"
        else:
            sign = "+" if consensus_gain > 0 else ""
            advantage += f"共识: {sign}{consensus_gain:.1f}"
    if pf and mp:
        mappo_diff = pf["mean"] - mp["mean"]  # 正=PBFT更好，负=MAPPO更好
        if abs(mappo_diff) < 5:
            advantage += " | vs MAPPO: ≈0%"
        else:
            advantage += f" | vs MAPPO: {mappo_diff:+.1f}"
    
    print(f"  {btype:>12s} | {pf_str} | {nc_str} | {mp_str} | {advantage}")

# ============ 5. 关键结论提示 ============
print("\n" + "=" * 72)
print("📝 关键审稿问题验证")
print("-" * 72)

print("""
审稿人F1: "共识被消融证伪(clean下no_consensus=0%)"
  → 需要看: 攻击下 PBFT-Full vs PBFT-NoCons 是否有显著差异
  → 如果攻击下 NoCons 退化 >> Full退化 → 共识在攻击下有效，F1反驳成功
  → 如果攻击下 NoCons ≈ Full → 共识确实无用，需重新叙事

审稿人F4: "缺MAPPO受攻击对照"
  → 需要看: 攻击下 MAPPO vs PBFT-Full 的差异
  → 如果 MAPPO 退化 >> PBFT退化 → PBFT层实证价值成立
  → 如果 MAPPO ≈ PBFT → PBFT层在攻击下也没用，需重新叙事
""")

print("=" * 72)
