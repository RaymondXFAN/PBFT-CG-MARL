#!/bin/bash
# ============================================================
# PBFT-CG-MARL 全量实验脚本
# 目标：安全韧性基础设施论文的实验数据
# GPU：RTX 4090 (24GB)
# 预估总时间：~52h
# ============================================================

set -e  # 遇到错误立即停止

# ========== 配置 ==========
PROJECT_ROOT="/root/autodl-tmp/PBFT-CG-MARL"
RESULT_ROOT="/root/autodl-tmp/results"
LOG_FILE="${RESULT_ROOT}/run_all.log"
TIMESTAMPS="${RESULT_ROOT}/timestamps.txt"

# 环境激活
cd ${PROJECT_ROOT}
source /root/miniconda3/etc/profile.d/conda.sh
conda activate pbft

# 创建目录
mkdir -p ${RESULT_ROOT}

# 日志函数
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a ${LOG_FILE}
}

# 时间记录
mark_time() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> ${TIMESTAMPS}
}

# ========== 预检查 ==========
log "=== 预检查 ==="
python -c "import torch; print(f'PyTorch: {torch.__version__}, CUDA: {torch.cuda.is_available()}')"
nvidia-smi --query-gpu=name,memory.total --format=csv

# ========== P0-1: 修复种子敏感性 ==========
mark_time "P0-1 START: Seed sensitivity fix (entropy_coef=0.05)"

log "=== P0-1: PBFT-CG-MAPPO × 3 seeds (entropy_coef=0.05) ==="
for seed in 1 2 3; do
    log "Running PBFT-CG-MAPPO seed ${seed}..."
    python src/train.py \
        --algo pbft_cg_mappo \
        --algo_config configs/algo/pbft_cg_mappo_v2.yaml \
        --env simple_spread \
        --env_config configs/env/mpe_spread.yaml \
        --seed ${seed} --n_timesteps 500000 \
        --log_dir ${RESULT_ROOT}/p0_seed_fix/pbft_cg_mappo_seed${seed} \
        2>&1 | tee -a ${LOG_FILE}
    mark_time "P0-1 PBFT-CG-MAPPO seed${seed} done"
done

log "=== P0-1: MAPPO × 3 seeds (entropy_coef=0.05) ==="
for seed in 1 2 3; do
    log "Running MAPPO seed ${seed}..."
    python src/train.py \
        --algo mappo \
        --algo_config configs/algo/mappo_v2.yaml \
        --env simple_spread \
        --env_config configs/env/mpe_spread.yaml \
        --seed ${seed} --n_timesteps 500000 \
        --log_dir ${RESULT_ROOT}/p0_seed_fix/mappo_seed${seed} \
        2>&1 | tee -a ${LOG_FILE}
    mark_time "P0-1 MAPPO seed${seed} done"
done

log "=== P0-1: QMIX × 3 seeds ==="
for seed in 1 2 3; do
    python src/train.py --algo qmix --env simple_spread \
        --seed ${seed} --n_timesteps 500000 \
        --log_dir ${RESULT_ROOT}/p0_seed_fix/qmix_seed${seed} \
        2>&1 | tee -a ${LOG_FILE}
    mark_time "P0-1 QMIX seed${seed} done"
done

log "=== P0-1: MADDPG × 3 seeds ==="
for seed in 1 2 3; do
    python src/train.py --algo maddpg --env simple_spread \
        --seed ${seed} --n_timesteps 500000 \
        --log_dir ${RESULT_ROOT}/p0_seed_fix/maddpg_seed${seed} \
        2>&1 | tee -a ${LOG_FILE}
    mark_time "P0-1 MADDPG seed${seed} done"
done

log "=== P0-1: CommNet × 3 seeds ==="
for seed in 1 2 3; do
    python src/train.py --algo commnet --env simple_spread \
        --seed ${seed} --n_timesteps 500000 \
        --log_dir ${RESULT_ROOT}/p0_seed_fix/commnet_seed${seed} \
        2>&1 | tee -a ${LOG_FILE}
    mark_time "P0-1 CommNet seed${seed} done"
done

log "=== P0-1: TarMAC × 3 seeds ==="
for seed in 1 2 3; do
    python src/train.py --algo tarmac --env simple_spread \
        --seed ${seed} --n_timesteps 500000 \
        --log_dir ${RESULT_ROOT}/p0_seed_fix/tarmac_seed${seed} \
        2>&1 | tee -a ${LOG_FILE}
    mark_time "P0-1 TarMAC seed${seed} done"
done

mark_time "P0-1 END: Seed sensitivity fix"

# ========== P0-2: 拜占庭多种子 ==========
mark_time "P0-2 START: Byzantine multi-seed"

log "=== P0-2: PBFT-CG-MAPPO × 3 seeds × 3 attacks × f=1 ==="
for seed in 1 2 3; do
    for attack in random adversarial silence; do
        log "Running PBFT-CG-MAPPO f=1 ${attack} seed ${seed}..."
        python src/train.py \
            --algo pbft_cg_mappo \
            --algo_config configs/algo/pbft_cg_mappo_v2.yaml \
            --env simple_spread \
            --env_config configs/env/mpe_spread.yaml \
            --seed ${seed} --n_timesteps 500000 \
            --byzantine_n 1 --byzantine_type ${attack} \
            --log_dir ${RESULT_ROOT}/p0_byzantine/pbft_f1_${attack}_seed${seed} \
            2>&1 | tee -a ${LOG_FILE}
        mark_time "P0-2 PBFT-CG-MAPPO f=1 ${attack} seed${seed} done"
    done
done

log "=== P0-2: Baselines × 3 seeds × 3 attacks × f=1 ==="
for algo in mappo qmix maddpg commnet tarmac; do
    for seed in 1 2 3; do
        for attack in random adversarial silence; do
            log "Running ${algo} f=1 ${attack} seed ${seed}..."
            python src/train.py \
                --algo ${algo} --env simple_spread \
                --seed ${seed} --n_timesteps 500000 \
                --byzantine_n 1 --byzantine_type ${attack} \
                --log_dir ${RESULT_ROOT}/p0_byzantine/${algo}_f1_${attack}_seed${seed} \
                2>&1 | tee -a ${LOG_FILE}
            mark_time "P0-2 ${algo} f=1 ${attack} seed${seed} done"
        done
    done
done

mark_time "P0-2 END: Byzantine multi-seed"

# ========== P1-1: 补充MPE环境 ==========
mark_time "P1-1 START: simple_reference"

log "=== P1-1: simple_reference × 6 algorithms × 3 seeds ==="
for algo in pbft_cg_mappo mappo qmix maddpg commnet tarmac; do
    for seed in 1 2 3; do
        ALGO_CFG=""
        if [ "$algo" = "pbft_cg_mappo" ]; then
            ALGO_CFG="--algo_config configs/algo/pbft_cg_mappo_v2.yaml"
        fi
        log "Running ${algo} simple_reference seed ${seed}..."
        python src/train.py \
            --algo ${algo} ${ALGO_CFG} \
            --env simple_reference \
            --env_config configs/env/mpe_reference.yaml \
            --seed ${seed} --n_timesteps 500000 \
            --log_dir ${RESULT_ROOT}/p1_reference/${algo}_seed${seed} \
            2>&1 | tee -a ${LOG_FILE}
        mark_time "P1-1 ${algo} seed${seed} done"
    done
done

# simple_reference + Byzantine
for algo in pbft_cg_mappo mappo; do
    for seed in 1 2 3; do
        for attack in random adversarial silence; do
            ALGO_CFG=""
            if [ "$algo" = "pbft_cg_mappo" ]; then
                ALGO_CFG="--algo_config configs/algo/pbft_cg_mappo_v2.yaml"
            fi
            log "Running ${algo} simple_reference f=1 ${attack} seed ${seed}..."
            python src/train.py \
                --algo ${algo} ${ALGO_CFG} \
                --env simple_reference \
                --env_config configs/env/mpe_reference.yaml \
                --seed ${seed} --n_timesteps 500000 \
                --byzantine_n 1 --byzantine_type ${attack} \
                --log_dir ${RESULT_ROOT}/p1_reference/${algo}_f1_${attack}_seed${seed} \
                2>&1 | tee -a ${LOG_FILE}
            mark_time "P1-1 ${algo} f=1 ${attack} seed${seed} done"
        done
    done
done

mark_time "P1-1 END: simple_reference"

# ========== P1-2: 通信丢包实验 ==========
mark_time "P1-2 START: Packet loss (Gilbert-Elliott)"

log "=== P1-2: 注意 — 需先完成代码修改（packet_loss.py + pbft.py修改）==="
log "=== 如果代码修改未完成，跳过此实验 ==="

# 检查packet_loss模块是否存在
if [ -f "${PROJECT_ROOT}/src/consensus/packet_loss.py" ]; then
    for p_g in 0.01 0.05; do
        for p_b in 0.1 0.2 0.3; do
            for seed in 1 2 3; do
                log "Running PBFT-CG-MAPPO p_g=${p_g} p_b=${p_b} seed ${seed}..."
                python src/train.py \
                    --algo pbft_cg_mappo \
                    --algo_config configs/algo/pbft_cg_mappo_v2.yaml \
                    --env simple_spread \
                    --seed ${seed} --n_timesteps 500000 \
                    --packet_loss_p_g ${p_g} --packet_loss_p_b ${p_b} \
                    --log_dir ${RESULT_ROOT}/p1_packetloss/pg${p_g}_pb${p_b}_seed${seed} \
                    2>&1 | tee -a ${LOG_FILE}
                mark_time "P1-2 pg${p_g}_pb${p_b}_seed${seed} done"
            done
        done
    done
    
    # 基线丢包
    for algo in mappo commnet tarmac; do
        for p_b in 0.1 0.2 0.3; do
            for seed in 1 2 3; do
                log "Running ${algo} p_g=0.01 p_b=${p_b} seed ${seed}..."
                python src/train.py \
                    --algo ${algo} --env simple_spread \
                    --seed ${seed} --n_timesteps 500000 \
                    --packet_loss_p_g 0.01 --packet_loss_p_b ${p_b} \
                    --log_dir ${RESULT_ROOT}/p1_packetloss/${algo}_pg0.01_pb${p_b}_seed${seed} \
                    2>&1 | tee -a ${LOG_FILE}
                mark_time "P1-2 ${algo}_pg0.01_pb${p_b}_seed${seed} done"
            done
        done
    done
else
    log "WARNING: packet_loss.py not found, skipping P1-2"
fi

mark_time "P1-2 END: Packet loss"

# ========== P1-3: 冻土真实数据 ==========
mark_time "P1-3 START: Permafrost real data"

log "=== P1-3: 安装openpyxl ==="
pip install openpyxl 2>&1 | tee -a ${LOG_FILE}

log "=== P1-3: 冻土监测 × PBFT-CG-MAPPO × 3 seeds (真实数据) ==="
for seed in 1 2 3; do
    log "Running PBFT-CG-MAPPO permafrost seed ${seed}..."
    python src/train.py \
        --algo pbft_cg_mappo \
        --algo_config configs/algo/permafrost_pbft.yaml \
        --env permafrost_monitoring \
        --env_config configs/env/permafrost_monitoring.yaml \
        --seed ${seed} --n_timesteps 500000 \
        --log_dir ${RESULT_ROOT}/p1_permafrost_real/pbft_seed${seed} \
        2>&1 | tee -a ${LOG_FILE}
    mark_time "P1-3 PBFT-CG-MAPPO seed${seed} done"
done

log "=== P1-3: 冻土监测 × MAPPO × 3 seeds (真实数据) ==="
for seed in 1 2 3; do
    log "Running MAPPO permafrost seed ${seed}..."
    python src/train.py \
        --algo mappo --env permafrost_monitoring \
        --env_config configs/env/permafrost_monitoring.yaml \
        --seed ${seed} --n_timesteps 500000 \
        --log_dir ${RESULT_ROOT}/p1_permafrost_real/mappo_seed${seed} \
        2>&1 | tee -a ${LOG_FILE}
    mark_time "P1-3 MAPPO seed${seed} done"
done

# 冻土 + Byzantine
log "=== P1-3: 冻土 + Byzantine (f=1,2) ==="
for f in 1 2; do
    for seed in 1 2 3; do
        for attack in random adversarial silence; do
            log "Running PBFT-CG-MAPPO permafrost f=${f} ${attack} seed ${seed}..."
            python src/train.py \
                --algo pbft_cg_mappo \
                --algo_config configs/algo/permafrost_pbft.yaml \
                --env permafrost_monitoring \
                --env_config configs/env/permafrost_monitoring.yaml \
                --seed ${seed} --n_timesteps 500000 \
                --byzantine_n ${f} --byzantine_type ${attack} \
                --log_dir ${RESULT_ROOT}/p1_permafrost_real/pbft_f${f}_${attack}_seed${seed} \
                2>&1 | tee -a ${LOG_FILE}
            mark_time "P1-3 PBFT f=${f} ${attack} seed${seed} done"
        done
    done
done

mark_time "P1-3 END: Permafrost real data"

# ========== P2-1: 安全基线对比 ==========
mark_time "P2-1 START: Adversarial training baseline"

log "=== P2-1: 注意 — 需先完成adversarial_mappo.py代码 ==="
if [ -f "${PROJECT_ROOT}/src/algorithms/adversarial_mappo.py" ]; then
    for seed in 1 2 3; do
        log "Running Adversarial MAPPO seed ${seed}..."
        python src/train.py \
            --algo adversarial_mappo \
            --algo_config configs/algo/adversarial_mappo.yaml \
            --env simple_spread \
            --seed ${seed} --n_timesteps 500000 \
            --log_dir ${RESULT_ROOT}/p2_adv_baseline/adv_mappo_seed${seed} \
            2>&1 | tee -a ${LOG_FILE}
        mark_time "P2-1 adv_mappo seed${seed} done"
    done
    
    # Adversarial MAPPO + Byzantine
    for seed in 1 2 3; do
        for attack in random adversarial silence; do
            log "Running Adversarial MAPPO f=1 ${attack} seed ${seed}..."
            python src/train.py \
                --algo adversarial_mappo --env simple_spread \
                --seed ${seed} --n_timesteps 500000 \
                --byzantine_n 1 --byzantine_type ${attack} \
                --log_dir ${RESULT_ROOT}/p2_adv_baseline/adv_mappo_f1_${attack}_seed${seed} \
                2>&1 | tee -a ${LOG_FILE}
            mark_time "P2-1 adv_mappo f=1 ${attack} seed${seed} done"
        done
    done
else
    log "WARNING: adversarial_mappo.py not found, skipping P2-1"
fi

mark_time "P2-1 END: Adversarial training baseline"

# ========== P2-2: 不同f值 ==========
mark_time "P2-2 START: Different f values (n=12)"

log "=== P2-2: 冻土环境 × 不同f值 × 3 seeds ==="
for f in 0 1 2 3; do
    for seed in 1 2 3; do
        # 创建临时配置
        cat configs/algo/permafrost_pbft.yaml | \
            sed "s/pbft_f: .*/pbft_f: $f/" > /tmp/permafrost_pbft_f${f}.yaml
        
        log "Running PBFT-CG-MAPPO permafrost f=${f} seed ${seed}..."
        python src/train.py \
            --algo pbft_cg_mappo \
            --algo_config /tmp/permafrost_pbft_f${f}.yaml \
            --env permafrost_monitoring \
            --env_config configs/env/permafrost_monitoring.yaml \
            --seed ${seed} --n_timesteps 500000 \
            --byzantine_n ${f} --byzantine_type random \
            --log_dir ${RESULT_ROOT}/p2_f_values/pbft_f${f}_seed${seed} \
            2>&1 | tee -a ${LOG_FILE}
        mark_time "P2-2 PBFT f=${f} seed${seed} done"
    done
done

mark_time "P2-2 END: Different f values"

# ========== 完成 ==========
log "=== ALL EXPERIMENTS COMPLETE ==="
mark_time "ALL DONE"

# 汇总结果
log "=== 汇总结果 ==="
find ${RESULT_ROOT} -name "progress.csv" -o -name "results.json" | head -20
log "结果保存在: ${RESULT_ROOT}"
log "时间记录保存在: ${TIMESTAMPS}"
