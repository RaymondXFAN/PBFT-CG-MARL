#!/bin/bash
# ============================================================
# PBFT-CG-MARL 结果收集脚本
# 从 results/v2/ 中提取所有 metrics.json，汇总为论文用的表格
# 用法:  bash scripts/collect_results.sh
# ============================================================

LOG_ROOT="results/v2"
OUTFILE="results/v2/summary_$(date +%Y%m%d_%H%M%S).txt"

echo "收集结果到 $OUTFILE"
echo "=========================================" > "$OUTFILE"

# ── Phase 1: P0 熵修复 ──
echo "" >> "$OUTFILE"
echo "=== P0: PBFT-CG-MAPPO (entropy_coef=0.05) on mpe_spread ===" >> "$OUTFILE"
for seed in 1 2 3; do
    dir="$LOG_ROOT/phase1/pbft_v2_spread_seed${seed}"
    mfile=$(find "$dir" -name "metrics.json" 2>/dev/null | head -1)
    if [ -n "$mfile" ]; then
        echo "  Seed $seed: $(cat $mfile)" >> "$OUTFILE"
    else
        echo "  Seed $seed: 未找到结果" >> "$OUTFILE"
    fi
done

echo "" >> "$OUTFILE"
echo "=== P0-ctrl: MAPPO (entropy_coef=0.05) on mpe_spread ===" >> "$OUTFILE"
for seed in 1 2 3; do
    dir="$LOG_ROOT/phase1/mappo_v2_spread_seed${seed}"
    mfile=$(find "$dir" -name "metrics.json" 2>/dev/null | head -1)
    if [ -n "$mfile" ]; then
        echo "  Seed $seed: $(cat $mfile)" >> "$OUTFILE"
    else
        echo "  Seed $seed: 未找到结果" >> "$OUTFILE"
    fi
done

# ── Phase 1: P1 拜占庭多种子 ──
echo "" >> "$OUTFILE"
echo "=== P1: 拜占庭多种子 (f=1) ===" >> "$OUTFILE"
for btype in random adversarial silence; do
    echo "  Attack: $btype" >> "$OUTFILE"
    for seed in 1 2 3; do
        dir="$LOG_ROOT/phase1/byzantine_f1_${btype}_seed${seed}"
        mfile=$(find "$dir" -name "metrics.json" 2>/dev/null | head -1)
        if [ -n "$mfile" ]; then
            echo "    Seed $seed: $(cat $mfile)" >> "$OUTFILE"
        else
            echo "    Seed $seed: 未找到结果" >> "$OUTFILE"
        fi
    done
done

# ── Phase 2: mpe_reference ──
echo "" >> "$OUTFILE"
echo "=== P2: mpe_reference ===" >> "$OUTFILE"
for algo in pbft_v2 mappo_v2 qmix commnet tarmac; do
    echo "  Algorithm: $algo" >> "$OUTFILE"
    for seed in 1 2 3; do
        dir="$LOG_ROOT/phase2/${algo}_reference_seed${seed}"
        mfile=$(find "$dir" -name "metrics.json" 2>/dev/null | head -1)
        if [ -n "$mfile" ]; then
            echo "    Seed $seed: $(cat $mfile)" >> "$OUTFILE"
        else
            echo "    Seed $seed: 未找到结果" >> "$OUTFILE"
        fi
    done
done

echo "" >> "$OUTFILE"
echo "=========================================" >> "$OUTFILE"
cat "$OUTFILE"
echo ""
echo "结果已保存到: $OUTFILE"
