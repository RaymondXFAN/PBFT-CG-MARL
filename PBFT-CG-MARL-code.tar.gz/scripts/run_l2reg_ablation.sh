#!/bin/bash
# MAPPO + L2 消息正则对照实验 (3 seeds)
# 目的：验证 consensus loss 的方差降低是否来自"正则化"效应（拉消息向均值）
# 对照：MAPPO (no reg) vs MAPPO+L2(msg) vs PBFT-CG-MAPPO(Full) vs PBFT Loss Only
# 预计耗时：每seed约40min (500k steps) × 3 = 2h

GPU_ID=${1:-0}
N_SEEDS=3
STEPS=500000
LOG_BASE="results/l2reg_ablation"

echo "=== MAPPO + L2 Message Regularization Ablation ==="
echo "GPU: $GPU_ID | Seeds: $N_SEEDS | Steps: $STEPS"
echo "Start: $(date)"

for SEED in $(seq 1 $N_SEEDS); do
    echo ""
    echo "--- Seed $SEED / $N_SEEDS ---"
    
    # 1. MAPPO + L2 msg regularization
    echo "[1/1] MAPPO+L2 seed=$SEED"
    python -u src/train.py \
        --algo mappo \
        --env mpe_spread \
        --algo_config configs/algo/mappo_l2reg.yaml \
        --seed $SEED \
        --n_timesteps $STEPS \
        --eval_interval 50000 \
        --eval_episodes 10 \
        --log_dir ${LOG_BASE}/mappo_l2reg_seed${SEED} \
        --gpu $GPU_ID
    
    echo "✓ Seed $SEED done at $(date)"
done

echo ""
echo "=== All L2-reg experiments complete! ==="
echo "Results: $LOG_BASE"
echo "Compare with existing results:"
echo "  MAPPO clean:     results/overnight/mappo_v3_clean_seed*/"
echo "  PBFT Full:       results/overnight/pbft_v3_clean_seed*/"
echo ""
echo "=== Quick check ==="
for d in ${LOG_BASE}/mappo_l2reg_seed*/; do
    name=$(basename $d)
    if [ -f "$d/mappo/metrics.json" ]; then
        echo "✅ $name"
    else
        echo "❌ $name"
    fi
done
