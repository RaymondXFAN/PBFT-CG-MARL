# -*- coding: utf-8 -*-
"""
PBFT-CG-MARL 预检脚本 (Pre-flight Check)
=========================================
目的：在启动 ~52h 完整实验之前，用 ~5 分钟的小规模真实运行证明
      (1) 数据/环境加载正确
      (2) 算法前向+反向(梯度)能跑通
      (3) 存盘逻辑正确 (确实写出 metrics.json)
      (4) 设备/GPU 一致性 (张量在正确设备上)

设计原则（将军 2026-08-12 预检规范）：
- 比冒烟测试大一些，但只跑少量样本 (1 算法 × 1 环境 × 1 seed, 少 step)
- 真实调用生产入口 src/train.py（子进程），不重写训练循环 → 避免引入新 bug
- 每一步给出明确的 PASS / FAIL + 耗时，便于将军一键判断能否开跑长任务

使用方法（在 AutoDL 实例、项目根目录 /root/autodl-tmp/PBFT-CG-MARL 下）：
    python src/scripts/precheck.py            # 自动用 GPU:0
    python src/scripts/precheck.py --gpu 0    # 指定 GPU
退出码 0 = 全部通过，可开跑；非 0 = 有失败，先排查。
"""

import argparse
import json
import os
import subprocess
import sys
import time

import torch
import numpy as np

# precheck.py 位于 <PROJECT_ROOT>/scripts/precheck.py，故向上两层即项目根
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def section(title: str):
    print("\n" + "=" * 72)
    print(title)
    print("=" * 72)


def run_train_subprocess(label, args: list, timeout: int = 300):
    """调用生产入口 train.py 跑一个最小实验，返回 (success, log_text, elapsed)。"""
    cmd = [sys.executable, "src/train.py"] + args
    print(f"\n[RUN] {label}")
    print(f"      $ {' '.join(cmd)}")
    t0 = time.time()
    try:
        proc = subprocess.run(
            cmd,
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        print(f"  ✗ 超时 (> {timeout}s)，终止")
        return False, "", timeout
    elapsed = time.time() - t0
    out = proc.stdout + "\n" + proc.stderr
    if proc.returncode != 0:
        print(f"  ✗ 退出码 {proc.returncode}，耗时 {elapsed:.1f}s")
        # 打印尾部错误便于排查
        tail = "\n".join(out.strip().splitlines()[-25:])
        print("  ---- 错误尾部 ----")
        print("  " + tail.replace("\n", "\n  "))
        return False, out, elapsed
    print(f"  ✓ 完成，耗时 {elapsed:.1f}s")
    return True, out, elapsed


def check_metrics(label, algo, log_dir):
    """检查 metrics.json 是否写出且可解析为有效数值。"""
    metrics_path = os.path.join(PROJECT_ROOT, log_dir, algo, "metrics.json")
    if not os.path.exists(metrics_path):
        print(f"  ✗ 未找到 {metrics_path}")
        return False, None
    try:
        with open(metrics_path) as f:
            m = json.load(f)
        rew = m.get("episode_reward_mean_last10")
        total = m.get("total_steps")
        ok = isinstance(rew, (int, float)) and isinstance(total, (int, float)) and total > 0
        print(f"  ✓ metrics.json 存在: mean_last10={rew}, total_steps={total}")
        return ok, m
    except Exception as e:
        print(f"  ✗ 解析 metrics.json 失败: {e}")
        return False, None


def test_gpu_consistency(out_text: str):
    """从 train.py 的 [DEBUG] 行确认算法参数在 GPU 上。"""
    for line in out_text.splitlines():
        if "[DEBUG] 设备" in line:
            print(f"  · {line.strip()}")
            return "cuda" in line
    print("  · 未检测到 [DEBUG] 设备行（可能 stdout 被缓冲），但不影响主流程")
    return True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--clean_steps", type=int, default=3000)
    parser.add_argument("--byz_steps", type=int, default=2000)
    parser.add_argument("--timeout", type=int, default=300)
    args = parser.parse_args()

    section("PBFT-CG-MARL 预检 (Pre-flight Check)")
    print(f"Python : {sys.version.split()[0]}")
    print(f"Torch  : {torch.__version__}")
    print(f"CUDA   : {'available' if torch.cuda.is_available() else 'NOT available'}")
    if torch.cuda.is_available():
        print(f"GPU    : {torch.cuda.get_device_name(args.gpu)} (id={args.gpu})")
    else:
        print("  ⚠ 无 GPU，将退化为 CPU 运行（功能可验证，但长任务请务必用 GPU）")

    results = []

    # ---------- TEST 1: simple_spread 干净环境 (主算法) ----------
    section("TEST 1  数据加载 + 前向/反向 + 存盘  (simple_spread / pbft_cg_mappo / clean)")
    log_dir1 = "results/precheck/test1_clean"
    ok1, out1, el1 = run_train_subprocess(
        "Clean training (3000 steps)",
        [
            "--algo", "pbft_cg_mappo",
            "--env", "mpe_spread",
            "--env_config", "configs/env/mpe_spread.yaml",
            "--algo_config", "configs/algo/pbft_cg_mappo_v3.yaml",
            "--seed", "1",
            "--n_timesteps", str(args.clean_steps),
            "--eval_interval", "1000",
            "--eval_episodes", "3",
            "--log_dir", log_dir1,
            "--gpu", str(args.gpu),
        ],
        timeout=args.timeout,
    )
    if ok1:
        ok1_metrics, m1 = check_metrics("TEST 1", "pbft_cg_mappo", log_dir1)
        gpu_ok = test_gpu_consistency(out1)
        ok1 = ok1 and ok1_metrics and gpu_ok
        if m1:
            # 打印 consensus_rate（若日志中有）
            pass
    results.append(("TEST1 clean train", ok1, el1))

    # ---------- TEST 2: simple_spread 拜占庭注入 (攻击路径) ----------
    section("TEST 2  拜占庭攻击注入路径  (simple_spread / pbft_cg_mappo / byzantine f=1)")
    log_dir2 = "results/precheck/test2_byz"
    ok2, out2, el2 = run_train_subprocess(
        "Byzantine training (f=1, 2000 steps)",
        [
            "--algo", "pbft_cg_mappo",
            "--env", "mpe_spread",
            "--env_config", "configs/env/mpe_spread.yaml",
            "--algo_config", "configs/algo/pbft_cg_mappo_v3.yaml",
            "--seed", "1",
            "--n_timesteps", str(args.byz_steps),
            "--eval_interval", "1000",
            "--eval_episodes", "3",
            "--byzantine_n", "1",
            "--byzantine_type", "random",
            "--log_dir", log_dir2,
            "--gpu", str(args.gpu),
        ],
        timeout=args.timeout,
    )
    if ok2:
        ok2_metrics, m2 = check_metrics("TEST 2", "pbft_cg_mappo", log_dir2)
        ok2 = ok2 and ok2_metrics
    results.append(("TEST2 byzantine", ok2, el2))

    # ---------- TEST 3: 冻土 TPDC 数据加载 (真实数据管线) ----------
    section("TEST 3  冻土数据管线  (GTNPDataLoader / synthetic fallback)")
    t0 = time.time()
    try:
        from src.scripts.gtnp_data import GTNPDataLoader
        loader = GTNPDataLoader(data_dir=None, use_synthetic=True)
        df = loader.load_data()
        elapsed = time.time() - t0
        if hasattr(df, "shape") and df.shape[0] > 0 and df.shape[1] > 0:
            print(f"  ✓ 数据加载成功: shape={df.shape}, 耗时 {elapsed:.1f}s")
            print(f"  · 列: {list(df.columns)[:8]}{'...' if len(df.columns) > 8 else ''}")
            ok3 = True
        else:
            print(f"  ✗ 数据形状异常: {getattr(df, 'shape', None)}")
            ok3 = False
    except Exception as e:
        print(f"  ✗ 冻土数据加载异常: {e}")
        import traceback
        traceback.print_exc()
        ok3 = False
        elapsed = time.time() - t0
    results.append(("TEST3 permafrost data", ok3, elapsed))

    # ---------- 汇总 ----------
    section("预检结果汇总")
    all_ok = True
    for name, ok, el in results:
        status = "PASS ✓" if ok else "FAIL ✗"
        print(f"  [{status}]  {name:<28}  {el:6.1f}s")
        all_ok = all_ok and ok
    print()
    if all_ok:
        print("  ✅ 全部通过！数据+算法+存盘+GPU 一致性均正常，可以开跑完整实验。")
        print("     启动命令: bash run_all.sh 0 1")
        sys.exit(0)
    else:
        print("  ❌ 存在失败项，请先排查后再开跑长任务（避免跑很久才发现崩溃）。")
        sys.exit(1)


if __name__ == "__main__":
    main()
