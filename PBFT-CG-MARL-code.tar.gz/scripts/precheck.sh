#!/bin/bash
# ============================================================
# PBFT-CG-MARL 预检脚本（~5分钟）
# 目的: 在跑长任务前验证 数据加载+算法前向/反向+存盘逻辑 正确
# 用法:  bash scripts/precheck.sh [gpu_id]
# ============================================================
set -e

GPU_ID=${1:-0}
echo "========================================="
echo "PBFT-CG-MARL 预检脚本"
echo "GPU: $GPU_ID"
echo "========================================="

PASS=0
FAIL=0

check_metrics() {
    # 用 find 搜索，因为实际路径可能含 seed_XX/ 子目录
    local search_dir=$1
    local label=$2
    local mfile=$(find "$search_dir" -name "metrics.json" 2>/dev/null | head -1)
    if [ -n "$mfile" ]; then
        echo "  ✅ $label — metrics.json 存在"
        echo "     路径: $mfile"
        cat "$mfile"
        PASS=$((PASS+1))
    else
        echo "  ❌ $label — metrics.json 不存在!"
        FAIL=$((FAIL+1))
    fi
}

# ── Test 1: PBFT-CG-MAPPO (entropy_coef=0.05) on mpe_spread ──
echo ""
echo "[Test 1] PBFT-CG-MAPPO (v2 config) on mpe_spread, 5000 steps..."
python -u src/train.py \
    --algo pbft_cg_mappo \
    --env mpe_spread \
    --algo_config configs/algo/pbft_cg_mappo_v2.yaml \
    --seed 42 \
    --n_timesteps 5000 \
    --eval_interval 2500 \
    --eval_episodes 2 \
    --log_dir results/precheck/pbft_v2_spread \
    --gpu $GPU_ID 2>&1 | tail -5

check_metrics "results/precheck/pbft_v2_spread" "PBFT-CG-MAPPO mpe_spread"

# ── Test 2: MAPPO (entropy_coef=0.05) on mpe_spread ──
echo ""
echo "[Test 2] MAPPO (v2 config) on mpe_spread, 5000 steps..."
python -u src/train.py \
    --algo mappo \
    --env mpe_spread \
    --algo_config configs/algo/mappo_v2.yaml \
    --seed 42 \
    --n_timesteps 5000 \
    --eval_interval 2500 \
    --eval_episodes 2 \
    --log_dir results/precheck/mappo_v2_spread \
    --gpu $GPU_ID 2>&1 | tail -5

check_metrics "results/precheck/mappo_v2_spread" "MAPPO mpe_spread"

# ── Test 3: mpe_reference 环境可用性 ──
echo ""
echo "[Test 3] PBFT-CG-MAPPO on mpe_reference, 5000 steps..."
python -u src/train.py \
    --algo pbft_cg_mappo \
    --env mpe_reference \
    --algo_config configs/algo/pbft_cg_mappo_v2.yaml \
    --seed 42 \
    --n_timesteps 5000 \
    --eval_interval 2500 \
    --eval_episodes 2 \
    --log_dir results/precheck/pbft_v2_reference \
    --gpu $GPU_ID 2>&1 | tail -5

check_metrics "results/precheck/pbft_v2_reference" "mpe_reference"

# ── Test 4: Byzantine 注入 ──
echo ""
echo "[Test 4] PBFT-CG-MAPPO with f=1 random Byzantine, 5000 steps..."
python -u src/train.py \
    --algo pbft_cg_mappo \
    --env mpe_spread \
    --algo_config configs/algo/pbft_cg_mappo_v2.yaml \
    --seed 42 \
    --n_timesteps 5000 \
    --byzantine_n 1 \
    --byzantine_type random \
    --log_dir results/precheck/pbft_v2_byzantine \
    --gpu $GPU_ID 2>&1 | tail -5

check_metrics "results/precheck/pbft_v2_byzantine" "Byzantine 注入"

# ── 清理预检结果 ──
echo ""
echo "清理预检结果..."
rm -rf results/precheck/

# ── 汇总 ──
echo ""
echo "========================================="
echo "预检结果: ${PASS} 通过, ${FAIL} 失败"
if [ $FAIL -eq 0 ]; then
    echo "✅ 全部通过! 可以开始正式实验"
else
    echo "❌ 有测试失败，请先修复再跑正式实验"
fi
echo "========================================="
