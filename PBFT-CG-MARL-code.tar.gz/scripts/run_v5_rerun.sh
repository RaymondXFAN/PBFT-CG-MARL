#!/bin/bash
# ============================================================
# PBFT-CG-MARL 重跑脚本 v5 — 修复审稿致命问题
# 核心修复: entropy_coef 0.05→0.15 (与成功的additive配置一致)
# 
# 实验内容:
#   P0: PBFT-CG-MAPPO × 3 seeds on mpe_spread (additive配置)
#   P0-ctrl: MAPPO × 3 seeds on mpe_spread (entropy_coef=0.15 对照)
#   P1: Byzantine 多种子: 3 seeds × 3 attack types
#
# 用法:
#   后台:  nohup bash scripts/run_v5_rerun.sh 0 > rerun_v5.log 2>&1 &
#   监控:  tail -f rerun_v5.log
#   进度:  grep "进度:" rerun_v5.log | tail -5
# 参数:  $1=gpu_id
# ============================================================
set -e

GPU_ID=${1:-0}
LOG_ROOT="results/v5_rerun"
mkdir -p "$LOG_ROOT"

echo "========================================="
echo "PBFT-CG-MARL v5 重跑 (entropy_coef=0.15)"
echo "GPU: $GPU_ID | LOG: $LOG_ROOT"
echo "开始: $(date)"
echo "========================================="

TOTAL=0
DONE=0
FAIL=0

run_one() {
    local exp_name=$1; shift
    TOTAL=$((TOTAL+1))
    echo ""
    echo "[$(date +%H:%M:%S)] >>> [$TOTAL] $exp_name"
    local start_time=$(date +%s)
    
    python -u src/train.py "$@" 2>&1 | tee "$LOG_ROOT/${exp_name}.log"
    local exit_code=${PIPESTATUS[0]}
    
    local end_time=$(date +%s)
    local elapsed=$(( (end_time - start_time) / 60 ))
    
    if [ $exit_code -eq 0 ]; then
        DONE=$((DONE+1))
        echo "[$(date +%H:%M:%S)] <<< $exp_name 完成 (${elapsed}min) | 进度: $DONE/$TOTAL (失败: $FAIL)"
    else
        FAIL=$((FAIL+1))
        echo "[$(date +%H:%M:%S)] <<< $exp_name 失败! (exit=$exit_code) | 进度: $DONE/$TOTAL (失败: $FAIL)"
    fi
}

# ============================================================
# P0: PBFT-CG-MAPPO (entropy_coef=0.15) on mpe_spread
# 3 seeds × 500k steps
# 预期: entropy≈1.609, CR≈0.1, Return≈-45 (与cross-env additive一致)
# ============================================================
echo ""
echo "=== P0: PBFT-CG-MAPPO (entropy_coef=0.15, additive) on mpe_spread ==="

for seed in 1 2 3; do
    run_one "p0_pbft_spread_seed${seed}" \
        --algo pbft_cg_mappo \
        --env mpe_spread \
        --algo_config configs/algo/pbft_cg_mappo_v5.yaml \
        --seed $seed \
        --n_timesteps 500000 \
        --eval_interval 10000 \
        --eval_episodes 10 \
        --log_dir "$LOG_ROOT/pbft_v5_spread_seed${seed}" \
        --gpu $GPU_ID
done

# ============================================================
# P0-ctrl: MAPPO (entropy_coef=0.15) 对照组
# 验证高entropy_coef对MAPPO的影响
# 3 seeds × 500k steps
# ============================================================
echo ""
echo "=== P0-ctrl: MAPPO (entropy_coef=0.15) on mpe_spread ==="

for seed in 1 2 3; do
    run_one "p0_mappo_spread_seed${seed}" \
        --algo mappo \
        --env mpe_spread \
        --algo_config configs/algo/mappo_v5.yaml \
        --seed $seed \
        --n_timesteps 500000 \
        --eval_interval 10000 \
        --eval_episodes 10 \
        --log_dir "$LOG_ROOT/mappo_v5_spread_seed${seed}" \
        --gpu $GPU_ID
done

# ============================================================
# P1: Byzantine 多种子 (最关键的缺失实验!)
# 3 seeds × 3 attack types = 9 组
# ============================================================
echo ""
echo "=== P1: Byzantine 多种子 (f=1, 3 seeds × 3 attacks) ==="

for seed in 1 2 3; do
    for btype in random adversarial silence; do
        run_one "p1_byzantine_f1_${btype}_seed${seed}" \
            --algo pbft_cg_mappo \
            --env mpe_spread \
            --algo_config configs/algo/pbft_cg_mappo_v5.yaml \
            --seed $seed \
            --n_timesteps 500000 \
            --byzantine_n 1 \
            --byzantine_type $btype \
            --eval_interval 10000 \
            --eval_episodes 10 \
            --log_dir "$LOG_ROOT/byzantine_f1_${btype}_seed${seed}" \
            --gpu $GPU_ID
    done
done

# ============================================================
# 完成
# ============================================================
echo ""
echo "========================================="
echo "v5 重跑完成! $DONE/$TOTAL 成功, $FAIL 失败"
echo "结束: $(date)"
echo "结果目录: $LOG_ROOT"
echo ""
echo "=== 快速查看结果 ==="
echo "  bash scripts/collect_v5_results.sh"
echo "========================================="
