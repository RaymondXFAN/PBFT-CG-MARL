#!/bin/bash
###############################################################################
# PBFT-CG-MARL 审稿人意见补充实验 (v2.1)
# 
# EXP-A: MAPPO under Byzantine attack (3 seeds × 3 attacks = 9 runs)
# EXP-B: PBFT-CG-MAPPO no_consensus ablation + Byzantine (3 seeds × 3 attacks = 9 runs)
#
# 并行策略: 最多4个进程同时跑（CPU瓶颈，GPU空闲）
# 预计总耗时: ~6h (18 runs / 4 parallel × ~1.5h per run)
#
# 用法: 
#   nohup bash scripts/run_reviewer_experiments.sh > reviewer_exp.log 2>&1 &
#   tail -f reviewer_exp.log
###############################################################################

set -e

# ====== 配置 ======
PROJ_DIR="/root/autodl-tmp/CGMARL"
PYTHON="python"                 # AutoDL环境用python而非python3
TRAIN="$PROJ_DIR/src/train.py"
N_TIMESTEPS=500000
MAX_PARALLEL=4                  # 最多4个并行（16核CPU / 4核每个实验）

# V5配置参数
ENTROPY_COEF=0.15
ENTROPY_TARGET=0.1
ENTROPY_FLOOR_COEF=5.0

# 结果根目录
RESULTS_ROOT="$PROJ_DIR/results/reviewer_exp"
mkdir -p "$RESULTS_ROOT"

cd "$PROJ_DIR"

# ====== 计数器 ======
TOTAL=0
SUCCESS=0
FAILED=0
PIDS=()

# ====== 函数: 等待直到并行数降到阈值以下 ======
wait_for_slot() {
    while [ $(jobs -r | wc -l) -ge $MAX_PARALLEL ]; do
        sleep 30
    done
}

# ====== 函数: 运行单个实验 ======
run_one() {
    local label="$1"
    local algo="$2"
    local seed="$3"
    local byz_n="$4"
    local byz_type="$5"
    local ablation="$6"
    local log_dir="$RESULTS_ROOT/${label}_seed${seed}"
    local logfile="${log_dir}.log"
    
    echo "[$(date +%H:%M:%S)] >>> [$label] seed=$seed byz=$byz_n/$byz_type ablation=$ablation"
    
    # 构建命令
    local cmd="$PYTHON -u $TRAIN \
        --algo $algo \
        --env mpe_spread \
        --seed $seed \
        --n_timesteps $N_TIMESTEPS \
        --log_dir $log_dir \
        --byzantine_n $byz_n \
        --byzantine_type $byz_type \
        --gpu 0"
    
    # 消融参数
    if [ -n "$ablation" ]; then
        cmd="$cmd --ablation $ablation"
    fi
    
    # 运行并记录结果
    if $cmd > "$logfile" 2>&1; then
        echo "[$(date +%H:%M:%S)] <<< [$label] seed=$seed ✅ 成功! | 进度: $((SUCCESS+1))/$TOTAL"
        SUCCESS=$((SUCCESS + 1))
    else
        echo "[$(date +%H:%M:%S)] <<< [$label] seed=$seed ❌ 失败! (exit=$?) | 进度: $((SUCCESS+FAILED+1))/$TOTAL"
        FAILED=$((FAILED + 1))
    fi
}

# ====== 主实验 ======
echo "========================================="
echo "PBFT-CG-MARL Reviewer Experiments (v2.1)"
echo "========================================="
echo "并行数: $MAX_PARALLEL"
echo "总步数: $N_TIMESTEPS"
echo "结果目录: $RESULTS_ROOT"
echo "开始时间: $(date)"
echo "========================================="

# ==========================================
# EXP-A: MAPPO under Byzantine (9 runs)
# ==========================================
echo ""
echo "=== EXP-A: MAPPO under Byzantine Attack ==="
echo "目标: 证明PBFT在攻击下的实证价值（vs MAPPO无防护）"
echo ""

for btype in random adversarial silence; do
    for seed in 1 2 3; do
        TOTAL=$((TOTAL + 1))
    done
done

for btype in random adversarial silence; do
    for seed in 1 2 3; do
        wait_for_slot
        label="mappo_byz_f1_${btype}"
        run_one "$label" "mappo" "$seed" 1 "$btype" "" &
    done
done

# 等EXP-A完成（先跑完再看结果比较保险）
echo "[$(date +%H:%M:%S)] 等待 EXP-A 全部完成..."
wait

echo ""
echo "=== EXP-A 完成! $SUCCESS 成功 / $FAILED 失败 ==="

# ==========================================
# EXP-B: PBFT no_consensus + Byzantine (9 runs)  
# ==========================================
echo ""
echo "=== EXP-B: PBFT no_consensus + Byzantine Attack ==="
echo "目标: 证明共识层在攻击下有效（clean下0%不等于攻击下0%）"
echo ""

SUCCESS_B=0
FAILED_B=0

for btype in random adversarial silence; do
    for seed in 1 2 3; do
        wait_for_slot
        label="pbft_nocons_byz_f1_${btype}"
        (
            echo "[$(date +%H:%M:%S)] >>> [$label] seed=$seed"
            log_dir="$RESULTS_ROOT/${label}_seed${seed}"
            logfile="${log_dir}.log"
            
            if $PYTHON -u $TRAIN \
                --algo pbft_cg_mappo \
                --env mpe_spread \
                --seed $seed \
                --n_timesteps $N_TIMESTEPS \
                --log_dir $log_dir \
                --byzantine_n 1 \
                --byzantine_type $btype \
                --ablation no_consensus \
                --gpu 0 > "$logfile" 2>&1; then
                echo "[$(date +%H:%M:%S)] <<< [$label] seed=$seed ✅"
                SUCCESS_B=$((SUCCESS_B + 1))
            else
                echo "[$(date +%H:%M:%S)] <<< [$label] seed=$seed ❌"
                FAILED_B=$((FAILED_B + 1))
            fi
        ) &
    done
done

echo "[$(date +%H:%M:%S)] 等待 EXP-B 全部完成..."
wait

echo ""
echo "=== EXP-B 完成! $SUCCESS_B 成功 / $FAILED_B 失败 ==="

# ==========================================
# 结果汇总
# ==========================================
echo ""
echo "========================================="
echo "全部实验完成!"
echo "结果目录: $RESULTS_ROOT"
echo "结束时间: $(date)"
echo "========================================="
echo ""
echo "=== 快速查看结果 ==="
echo "$PYTHON3 << 'PYEOF'
import json, os, numpy as np

root = '$RESULTS_ROOT'

def get_last10(path):
    with open(path) as f:
        d = json.load(f)
    r = d.get('episode/episode_reward', [])
    cr = d.get('episode/consensus_rate', [])
    r10 = float(np.mean(r[-10:])) if len(r) >= 10 else float('nan')
    cr10 = float(np.mean(cr[-10:])) if len(cr) >= 10 else float('nan')
    return r10, cr10

print('\\n📊 EXP-A: MAPPO under Byzantine (对照基线)')
for btype in ['random', 'adversarial', 'silence']:
    vals = []
    for s in [1,2,3]:
        f = f'{root}/mappo_byz_f1_{btype}_seed{s}/mappo/seed_{s}/metrics.json'
        if os.path.exists(f):
            r, cr = get_last10(f)
            vals.append(r)
            print(f'  {btype:>12s} seed{s}: Return={r:>8.1f}  CR={cr:.3f}')
        else:
            print(f'  {btype:>12s} seed{s}: ❌ 未找到')
    if vals:
        a = np.array(vals)
        print(f'  {\"\":>12s} >>> Mean: {a.mean():.1f} ± {a.std():.1f}')

print('\\n📊 EXP-B: PBFT no_consensus + Byzantine (攻击下消融)')
for btype in ['random', 'adversarial', 'silence']:
    vals = []
    for s in [1,2,3]:
        f = f'{root}/pbft_nocons_byz_f1_{btype}_seed{s}/pbft_cg_mappo/seed_{s}/metrics.json'
        if os.path.exists(f):
            r, cr = get_last10(f)
            vals.append(r)
            print(f'  {btype:>12s} seed{s}: Return={r:>8.1f}  CR={cr:.3f}')
        else:
            print(f'  {btype:>12s} seed{s}: ❌ 未找到')
    if vals:
        a = np.array(vals)
        print(f'  {\"\":>12s} >>> Mean: {a.mean():.1f} ± {a.std():.1f}')

# 对比表格
print('\\n📊 对比: PBFT-Full vs PBFT-NoCons vs MAPPO (均 under Byzantine)')
pbft_full = {'random': -41.3, 'adversarial': -39.1, 'silence': -53.4}  # V5已有数据
for btype in ['random', 'adversarial', 'silence']:
    print(f'  {btype:>12s}: PBFT-Full={pbft_full[btype]:>7.1f} | ', end='')
    # NoCons
    f = f'{root}/pbft_nocons_byz_f1_{btype}_seed1/pbft_cg_mappo/seed_1/metrics.json'
    if os.path.exists(f):
        r, cr = get_last10(f)
        print(f'PBFT-NoCons={r:>7.1f} | ', end='')
    else:
        print(f'PBFT-NoCons=  N/A  | ', end='')
    # MAPPO
    f = f'{root}/mappo_byz_f1_{btype}_seed1/mappo/seed_1/metrics.json'
    if os.path.exists(f):
        r, cr = get_last10(f)
        print(f'MAPPO={r:>7.1f}')
    else:
        print(f'MAPPO=  N/A')
PYEOF"
