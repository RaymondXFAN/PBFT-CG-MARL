#!/usr/bin/env python3
"""
PBFT-CG-MARL 论文绘图脚本 (v2.0)
符合顶刊规范：莫兰迪色系 + TNR字体 + 最小字号12
生成 6 张核心论文图

用法:  python3 plot_paper_figures.py --results_dir <path> --output_dir ./paper_figures
如果没有 metrics.json，使用内置数据直接出图:  python3 plot_paper_figures.py --use_builtin
"""

import argparse
import json
import os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from pathlib import Path

# ============================================================
# 全局绘图设置
# ============================================================
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman'],
    'mathtext.fontset': 'stix',
    'font.size': 12,
    'axes.labelsize': 13,
    'axes.titlesize': 13,
    'xtick.labelsize': 12,
    'ytick.labelsize': 12,
    'legend.fontsize': 11,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
    'axes.linewidth': 1.0,
    'xtick.major.width': 0.8,
    'ytick.major.width': 0.8,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
    'xtick.top': True,
    'ytick.right': True,
    'errorbar.capsize': 3,
})

# ============================================================
# 莫兰迪色系 (Morandi palette)
# ============================================================
MORANDI = {
    'blue':      '#6B8E9B',   # 雾蓝
    'rose':      '#C4868C',   # 藕粉
    'green':     '#8FA3A0',   # 灰绿
    'sand':      '#C4A882',   # 沙金
    'purple':    '#9B8AA5',   # 藤紫
    'gray':      '#A3A8A3',   # 灰调
    'terra':     '#B0756A',   # 陶土
    'teal':      '#7BA5A3',   # 青灰
    'cream':     '#D4C5B0',   # 奶油
    'slate':     '#7A8899',   # 石板蓝
}

# 算法配色映射
ALGO_COLORS = {
    'PBFT-CG-MAPPO':   MORANDI['blue'],
    'MAPPO':           MORANDI['rose'],
    'MADDPG':          MORANDI['green'],
    'QMIX':            MORANDI['sand'],
    'CommNet':         MORANDI['purple'],
    'TarMAC':          MORANDI['terra'],
}

# 攻击类型配色
ATTACK_COLORS = {
    'Clean':      MORANDI['blue'],
    'Random':     MORANDI['sand'],
    'Adversarial': MORANDI['terra'],
    'Silence':    MORANDI['gray'],
}


# ============================================================
# 内置数据 (当服务器 metrics.json 不可用时)
# ============================================================
BUILTIN = {
    # Cross-env 方差缩减 (Table 1)
    'cross_env': {
        'MPE spread': {'PBFT-CG-MAPPO': (-44.6, 3.7), 'MAPPO': (-50.0, 16.9)},
        'SMAClite 5m_vs_6m': {'PBFT-CG-MAPPO': (76.3, 4.7), 'MAPPO': (288.1, 223.0)},
        'VMAS UAV': {'PBFT-CG-MAPPO': (-1024.3, 47.8), 'MAPPO': (-1053.6, 90.1)},
    },
    # V1 基线 (Table 3)
    'v1_baseline': {
        'PBFT-CG-MAPPO': (-394.8, 213.0),
        'MADDPG': (-160.3, 12.9),
        'MAPPO': (-234.5, 9.4),
        'QMIX': (-123.2, 218.0),
        'CommNet': (-316.8, 72.2),
        'TarMAC': (-336.6, 14.7),
    },
    # V1 vs V5 seed stability (Table 2)
    'seed_stability': {
        'V1': {'seeds': [-109.6, -476.9, -597.9], 'config': 'entropy_coef=0.01'},
        'V5': {'seeds': [-87.7, -77.9, -78.6], 'config': 'entropy_coef=0.15'},
    },
    # Byzantine (Table 4)
    'byzantine': {
        'Clean':      {'seeds': [-87.7, -77.9, -78.6], 'cr': [0.794, 0.794, 0.718]},
        'Random':     {'seeds': [-48.1, -38.5, -37.2], 'cr': [0.404, 0.449, 0.300]},
        'Adversarial': {'seeds': [-31.5, -47.3, -38.4], 'cr': [0.185, 0.105, 0.193]},
        'Silence':    {'seeds': [-57.3, -59.8, -43.1], 'cr': [0.000, 0.000, 0.000]},
    },
    # Ablation (Table 5)
    'ablation': {
        'Full': -109.6,
        'No Consensus': -109.6,
        'No Leader Rotation': -480.9,
        'No Fallback': -532.1,
    },
    # Communication efficiency (Table 6)
    'comm': {
        'MAPPO': 0,
        'PBFT-CG-MAPPO': 864,
        'CommNet': 8192,
        'TarMAC': 16384,
    },
    # 审稿人补充实验数据
    'byzantine_comparison': {
        'random': {
            'PBFT-Full': (-41.3, 4.9),
            'PBFT-NoCons': (-46.7, 5.1),
            'MAPPO': (-53.5, 12.8),
        },
        'adversarial': {
            'PBFT-Full': (-39.1, 6.5),
            'PBFT-NoCons': (-75.5, 11.4),
            'MAPPO': (-53.0, 13.1),
        },
        'silence': {
            'PBFT-Full': (-53.4, 7.4),
            'PBFT-NoCons': (-42.1, 0.2),
            'MAPPO': (-56.5, 13.3),
        },
    },
}


# ============================================================
# Figure 1: Cross-environment variance reduction (核心图)
# ============================================================
def fig1_variance_reduction(out_dir):
    """Fig 1: 方差缩减对比 - 三个环境并排柱状图"""
    data = BUILTIN['cross_env']
    envs = list(data.keys())
    n_envs = len(envs)

    fig, axes = plt.subplots(1, n_envs, figsize=(12, 4.2))
    fig.suptitle('Cross-Environment Variance Reduction', fontsize=14, fontweight='bold', y=1.02)

    for idx, env in enumerate(envs):
        ax = axes[idx]
        algos = list(data[env].keys())
        means = [data[env][a][0] for a in algos]
        stds = [data[env][a][1] for a in algos]
        colors = [ALGO_COLORS[a] for a in algos]

        x = np.arange(len(algos))
        bars = ax.bar(x, means, yerr=stds, width=0.45, color=colors,
                      edgecolor='#555555', linewidth=0.8, capsize=4,
                      error_kw={'linewidth': 1.2})

        # 方差缩减倍数标注
        if len(stds) >= 2:
            ratio = stds[1] / stds[0] if stds[0] > 0 else float('inf')
            ax.annotate(f'{ratio:.1f}×\nreduction',
                       xy=(0.5, 0.92), xycoords='axes fraction',
                       fontsize=11, ha='center', fontweight='bold',
                       color=MORANDI['blue'])

        ax.set_xticks(x)
        ax.set_xticklabels(algos, fontsize=10)
        ax.set_ylabel('Episode Return')
        ax.set_title(env, fontsize=12, fontweight='bold')
        ax.axhline(y=0, color='#888888', linewidth=0.5, linestyle='--')
        ax.yaxis.set_major_locator(MaxNLocator(nbins=5))

    plt.tight_layout()
    path = os.path.join(out_dir, 'fig1_variance_reduction.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf', '.png'))
    plt.close(fig)
    print(f'✅ Fig 1 saved: {path}')
    return path


# ============================================================
# Figure 2: Seed stability (V1 vs V5 散点+连线)
# ============================================================
def fig2_seed_stability(out_dir):
    """Fig 2: 种子稳定性 - V1 vs V5 对比"""
    data = BUILTIN['seed_stability']

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))

    for ax, (version, d) in zip([ax1, ax2], data.items()):
        seeds = d['seeds']
        n_seeds = len(seeds)
        mean_val = np.mean(seeds)
        std_val = np.std(seeds)

        # 散点
        x = np.arange(1, n_seeds + 1)
        color = MORANDI['rose'] if version == 'V1' else MORANDI['blue']
        ax.scatter(x, seeds, s=80, color=color, edgecolor='#555555',
                   linewidth=0.8, zorder=5, label='Individual seed')

        # 均值线
        ax.axhline(y=mean_val, color=color, linewidth=1.5, linestyle='-',
                    label=f'Mean = {mean_val:.1f}')

        # 均值±std 区域
        ax.axhspan(mean_val - std_val, mean_val + std_val,
                   alpha=0.15, color=color, label=f'±σ = {std_val:.1f}')

        # 标注灾难种子
        for i, s in enumerate(seeds):
            if abs(s - mean_val) > 2 * std_val:
                ax.annotate('catastrophic', xy=(i+1, s),
                           xytext=(i+1, s * 0.85),
                           fontsize=10, color=MORANDI['terra'],
                           arrowprops=dict(arrowstyle='->', color=MORANDI['terra'],
                                          lw=1.0),
                           ha='center')

        ax.set_xlabel('Seed Index')
        ax.set_ylabel('Episode Return')
        title = f'{version} ({d["config"]})'
        ax.set_title(title, fontsize=12, fontweight='bold')
        ax.set_xticks(x)
        ax.legend(fontsize=10, loc='lower left')
        ax.yaxis.set_major_locator(MaxNLocator(nbins=5))

    plt.tight_layout()
    path = os.path.join(out_dir, 'fig2_seed_stability.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf', '.png'))
    plt.close(fig)
    print(f'✅ Fig 2 saved: {path}')
    return path


# ============================================================
# Figure 3: Byzantine tolerance (分组柱状图 + CR overlay)
# ============================================================
def fig3_byzantine(out_dir):
    """Fig 3: 拜占庭容忍 - Return + CR 双指标"""
    data = BUILTIN['byzantine']
    attacks = list(data.keys())

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.2))

    # Left: Return per attack type (individual seeds)
    x = np.arange(len(attacks))
    width = 0.2
    for i in range(3):  # 3 seeds
        vals = [data[a]['seeds'][i] for a in attacks]
        color = list(ATTACK_COLORS.values())[i] if i < len(ATTACK_COLORS) else MORANDI['gray']
        offset = (i - 1) * width
        bars = ax1.bar(x + offset, vals, width, color=color,
                       edgecolor='#555555', linewidth=0.6,
                       label=f'Seed {i+1}')

    # 均值标记
    means = [np.mean(data[a]['seeds']) for a in attacks]
    stds_val = [np.std(data[a]['seeds']) for a in attacks]
    ax1.errorbar(x, means, yerr=stds_val, fmt='D', color='#333333',
                 markersize=6, capsize=4, linewidth=1.2, label='Mean ± σ')

    ax1.set_xticks(x)
    ax1.set_xticklabels(attacks, fontsize=11)
    ax1.set_ylabel('Episode Return')
    ax1.set_title('Byzantine Tolerance (f=1)', fontsize=12, fontweight='bold')
    ax1.legend(fontsize=9, ncol=2, loc='lower right')
    ax1.axhline(y=0, color='#888888', linewidth=0.5, linestyle='--')

    # Right: Consensus Rate per attack
    for a in attacks:
        cr_vals = data[a]['cr']
        color = ATTACK_COLORS.get(a, MORANDI['gray'])
        ax2.scatter([a]*len(cr_vals), cr_vals, s=80, color=color,
                   edgecolor='#555555', linewidth=0.8, zorder=5)
        mean_cr = np.mean(cr_vals)
        ax2.scatter([a], [mean_cr], s=150, color=color, marker='_',
                   linewidth=3, zorder=6)

    ax2.set_ylabel('Consensus Rate')
    ax2.set_title('Consensus Rate under Attack', fontsize=12, fontweight='bold')
    ax2.set_ylim(-0.05, 1.05)
    ax2.axhline(y=0.5, color='#888888', linewidth=0.5, linestyle=':', label='CR = 0.5')
    ax2.legend(fontsize=10)

    plt.tight_layout()
    path = os.path.join(out_dir, 'fig3_byzantine_tolerance.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf', '.png'))
    plt.close(fig)
    print(f'✅ Fig 3 saved: {path}')
    return path


# ============================================================
# Figure 4: Ablation study (水平柱状图)
# ============================================================
def fig4_ablation(out_dir):
    """Fig 4: 消融实验 - 水平柱状图 + 倍数标注"""
    data = BUILTIN['ablation']
    variants = list(data.keys())
    values = [data[v] for v in variants]

    # 排序（从好到差）
    sorted_pairs = sorted(zip(values, variants))
    values_s = [p[0] for p in sorted_pairs]
    variants_s = [p[1] for p in sorted_pairs]

    fig, ax = plt.subplots(figsize=(8, 3.5))

    colors = []
    for v in variants_s:
        if v == 'Full':
            colors.append(MORANDI['blue'])
        elif v == 'No Consensus':
            colors.append(MORANDI['teal'])
        else:
            colors.append(MORANDI['terra'])

    y = np.arange(len(variants_s))
    bars = ax.barh(y, values_s, height=0.55, color=colors,
                   edgecolor='#555555', linewidth=0.8)

    # 标注退化倍数
    baseline = data['Full']
    for i, (val, var) in enumerate(zip(values_s, variants_s)):
        if var != 'Full' and var != 'No Consensus':
            deg = abs(val - baseline) / abs(baseline) * 100
            ax.text(val - 10, i, f'+{deg:.0f}%', fontsize=11,
                   va='center', ha='right', color='white', fontweight='bold')
        elif var == 'No Consensus':
            ax.text(val + 5, i, '0%', fontsize=11,
                   va='center', ha='left', color=MORANDI['teal'])

    ax.set_yticks(y)
    ax.set_yticklabels(variants_s, fontsize=11)
    ax.set_xlabel('Episode Return')
    ax.set_title('Ablation Study (V1, Seed 1)', fontsize=12, fontweight='bold')
    ax.invert_yaxis()

    plt.tight_layout()
    path = os.path.join(out_dir, 'fig4_ablation.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf', '.png'))
    plt.close(fig)
    print(f'✅ Fig 4 saved: {path}')
    return path


# ============================================================
# Figure 5: Communication efficiency (横向柱状图)
# ============================================================
def fig5_communication(out_dir):
    """Fig 5: 通信效率 - 对数刻度柱状图"""
    data = BUILTIN['comm']
    algos = list(data.keys())
    bits = [data[a] for a in algos]
    colors = [ALGO_COLORS.get(a, MORANDI['gray']) for a in algos]

    fig, ax = plt.subplots(figsize=(7, 3.5))

    y = np.arange(len(algos))
    bars = ax.barh(y, [max(b, 1) for b in bits], height=0.55, color=colors,
                   edgecolor='#555555', linewidth=0.8)

    # 标注具体数值
    for i, (b, a) in enumerate(zip(bits, algos)):
        if b == 0:
            ax.text(50, i, '0 (no comm.)', fontsize=11, va='center')
        else:
            ax.text(b * 1.1, i, f'{b:,}', fontsize=11, va='center')

    ax.set_xscale('log')
    ax.set_yticks(y)
    ax.set_yticklabels(algos, fontsize=11)
    ax.set_xlabel('Communication Cost (bits/step)')
    ax.set_title('Communication Efficiency', fontsize=12, fontweight='bold')
    ax.set_xlim(0.5, 30000)
    ax.invert_yaxis()

    plt.tight_layout()
    path = os.path.join(out_dir, 'fig5_communication.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf', '.png'))
    plt.close(fig)
    print(f'✅ Fig 5 saved: {path}')
    return path


# ============================================================
# Figure 6: V1 baseline comparison (经典柱状图 + 误差棒)
# ============================================================
def fig6_v1_baseline(out_dir):
    """Fig 6: V1 基线对比 - 6算法柱状图"""
    data = BUILTIN['v1_baseline']
    algos = list(data.keys())
    means = [data[a][0] for a in algos]
    stds = [data[a][1] for a in algos]
    colors = [ALGO_COLORS.get(a, MORANDI['gray']) for a in algos]

    fig, ax = plt.subplots(figsize=(9, 4.5))

    x = np.arange(len(algos))
    bars = ax.bar(x, means, yerr=stds, width=0.6, color=colors,
                  edgecolor='#555555', linewidth=0.8, capsize=4,
                  error_kw={'linewidth': 1.2})

    # 标注方差最大的两个
    sorted_idx = np.argsort(stds)[::-1]
    for rank, idx in enumerate(sorted_idx[:2]):
        ax.annotate(f'σ = {stds[idx]:.1f}',
                   xy=(x[idx], means[idx] - stds[idx] - 30),
                   fontsize=10, ha='center', color=MORANDI['terra'],
                   fontweight='bold')

    ax.set_xticks(x)
    ax.set_xticklabels(algos, fontsize=10, rotation=15, ha='right')
    ax.set_ylabel('Episode Return')
    ax.set_title('Baseline Comparison (V1: entropy_coef=0.01, max_steps=100)',
                 fontsize=12, fontweight='bold')
    ax.axhline(y=0, color='#888888', linewidth=0.5, linestyle='--')
    ax.yaxis.set_major_locator(MaxNLocator(nbins=6))

    # 添加脚注
    ax.text(0.02, 0.02, '†PBFT-CG-MAPPO: 2/3 seeds exhibit entropy collapse',
            transform=ax.transAxes, fontsize=9, color='#666666',
            style='italic')

    plt.tight_layout()
    path = os.path.join(out_dir, 'fig6_v1_baseline.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf', '.png'))
    plt.close(fig)
    print(f'✅ Fig 6 saved: {path}')
    return path


# ============================================================
# Figure 7: Byzantine comparison (审稿人核心实验图)
# ============================================================
def fig7_byzantine_comparison(out_dir):
    """Fig 7: 三方对比 - PBFT-Full vs NoCons vs MAPPO under Byzantine"""
    data = BUILTIN['byzantine_comparison']
    attacks = list(data.keys())
    conditions = ['PBFT-Full', 'PBFT-NoCons', 'MAPPO']
    cond_colors = {
        'PBFT-Full': MORANDI['blue'],
        'PBFT-NoCons': MORANDI['sand'],
        'MAPPO': MORANDI['rose'],
    }

    fig, ax = plt.subplots(figsize=(9, 4.5))

    x = np.arange(len(attacks))
    width = 0.22
    offsets = [-width, 0, width]

    for i, cond in enumerate(conditions):
        means = [data[a][cond][0] for a in attacks]
        stds = [data[a][cond][1] for a in attacks]
        color = cond_colors[cond]
        bars = ax.bar(x + offsets[i], means, yerr=stds, width=width,
                      color=color, edgecolor='#555555', linewidth=0.8,
                      capsize=3, error_kw={'linewidth': 1.0},
                      label=cond)

    # 标注关键差距
    # Adversarial: Full vs NoCons 差36.4
    ax.annotate('', xy=(1 + offsets[0], -39.1), xytext=(1 + offsets[1], -75.5),
               arrowprops=dict(arrowstyle='<->', color=MORANDI['terra'],
                              lw=1.5))
    ax.text(1 + offsets[1] + 0.12, -57, '93%',
           fontsize=11, color=MORANDI['terra'], fontweight='bold',
           ha='center', rotation=90)

    # Random: Full vs MAPPO 差12.2
    ax.annotate('', xy=(0 + offsets[0], -41.3), xytext=(0 + offsets[2], -53.5),
               arrowprops=dict(arrowstyle='<->', color='#555555',
                              lw=1.0, linestyle='--'))
    ax.text(0 + offsets[2] + 0.15, -47, '23%',
           fontsize=10, color='#555555', ha='center', rotation=90)

    ax.set_xticks(x)
    ax.set_xticklabels(attacks, fontsize=12)
    ax.set_ylabel('Episode Return', fontsize=13)
    ax.set_title('Byzantine Tolerance: PBFT-Full vs. No Consensus vs. MAPPO (*f* = 1)',
                 fontsize=12, fontweight='bold')
    ax.legend(fontsize=11, loc='lower left', ncol=3)
    ax.axhline(y=0, color='#888888', linewidth=0.5, linestyle='--')
    ax.yaxis.set_major_locator(MaxNLocator(nbins=5))

    plt.tight_layout()
    path = os.path.join(out_dir, 'fig7_byzantine_comparison.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf', '.png'))
    plt.close(fig)
    print(f'✅ Fig 7 saved: {path}')
    return path


# ============================================================
# ============================================================
def main():
    parser = argparse.ArgumentParser(description='PBFT-CG-MARL 论文绘图')
    parser.add_argument('--output_dir', type=str, default='./paper_figures',
                        help='输出目录')
    parser.add_argument('--use_builtin', action='store_true',
                        help='使用内置数据（无需 metrics.json）')
    parser.add_argument('--results_dir', type=str, default=None,
                        help='服务器 results 目录（可选，用于从 metrics.json 读取）')
    args = parser.parse_args()

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    print('=' * 60)
    print('PBFT-CG-MARL 论文绘图')
    print(f'输出目录: {out_dir}')
    print(f'数据来源: {"内置数据" if args.use_builtin else "metrics.json"}')
    print('=' * 60)

    paths = []
    paths.append(fig1_variance_reduction(str(out_dir)))
    paths.append(fig2_seed_stability(str(out_dir)))
    paths.append(fig3_byzantine(str(out_dir)))
    paths.append(fig4_ablation(str(out_dir)))
    paths.append(fig5_communication(str(out_dir)))
    paths.append(fig6_v1_baseline(str(out_dir)))
    paths.append(fig7_byzantine_comparison(str(out_dir)))

    print('\n' + '=' * 60)
    print(f'✅ 全部 {len(paths)} 张图生成完成!')
    print(f'PDF + PNG 格式均保存在: {out_dir}')
    print('=' * 60)


if __name__ == '__main__':
    main()
