#!/bin/bash
# ============================================================
# PBFT-CG-MARL Phase 1: P0 熵修复 + P1 拜占庭多种子
# 总计: 15 组实验, 预计 ~22-24 小时 (RTX 4090)
#
# 用法:
#   前台:  bash scripts/run_phase1.sh 0
#   后台:  nohup bash scripts/run_phase1.sh 0 > phase1.log 2>&1 &
#   监控:  tail -f phase1.log
#          ls results/v2/phase1/*/
# 参数:  $1=gpu_id
# ============================================================
set -e

GPU_ID=${1:-0}
LOG_ROOT="results/v2/phase1"
mkdir -p "$LOG_ROOT"

echo "========================================="
echo "PBFT-CG-MARL Phase 1: 熵修复 + 拜占庭多种子"
echo "GPU: $GPU_ID | LOG: $LOG_ROOT"
echo "总实验数: 15 (预计 ~22-24h)"
echo "========================================="

TOTAL=0
DONE=0

run_one() {
    local exp_name=$1; shift
    echo ""
    echo "[$(date +%H:%M:%S)] >>> [$TOTAL] $exp_name"
    local start_time=$(date +%s)
    
    python -u src/train.py "$@" 2>&1 | tee "$LOG_ROOT/${exp_name}.log"
    local exit_code=${PIPESTATUS[0]}
    
    local end_time=$(date +%s)
    local elapsed=$(( (end_time - start_time) / 60 ))
    
    if [ $exit_code -eq 0 ]; then
        DONE=$((DONE+1))
        echo "[$(date +%H:%M:%S)] <<< $exp_name 完成 (${elapsed}min) | 进度: $DONE/$TOTAL"
    else
        echo "[$(date +%H:%M:%S)] <<< $exp_name 失败! (exit=$exit_code) | 进度: $DONE/$TOTAL"
    fi
}

# ============================================================
# P0: 熵修复 — PBFT-CG-MAPPO (entropy_coef=0.05) on mpe_spread
# 3 seeds × 500k steps, 预计 ~4.5h
# ============================================================
echo ""
echo "=== P0: PBFT-CG-MAPPO (entropy_coef=0.05) on mpe_spread ==="

for seed in 1 2 3; do
    TOTAL=$((TOTAL+1))
    run_one "p0_pbft_spread_seed${seed}" \
        --algo pbft_cg_mappo \
        --env mpe_spread \
        --algo_config configs/algo/pbft_cg_mappo_v2.yaml \
        --seed $seed \
        --n_timesteps 500000 \
        --eval_interval 10000 \
        --eval_episodes 10 \
        --log_dir "$LOG_ROOT/pbft_v2_spread_seed${seed}" \
        --gpu $GPU_ID
done

# ============================================================
# P0-ctrl: MAPPO (entropy_coef=0.05) 对照组
# 验证熵修复是否 PBFT-CG 特有, 3 seeds × 500k steps, 预计 ~4.5h
# ============================================================
echo ""
echo "=== P0-ctrl: MAPPO (entropy_coef=0.05) on mpe_spread ==="

for seed in 1 2 3; do
    TOTAL=$((TOTAL+1))
    run_one "p0_mappo_spread_seed${seed}" \
        --algo mappo \
        --env mpe_spread \
        --algo_config configs/algo/mappo_v2.yaml \
        --seed $seed \
        --n_timesteps 500000 \
        --eval_interval 10000 \
        --eval_episodes 10 \
        --log_dir "$LOG_ROOT/mappo_v2_spread_seed${seed}" \
        --gpu $GPU_ID
done

# ============================================================
# P1: 拜占庭多种子 — 3 seeds × 3 attack types
# 9 组 × 500k steps, 预计 ~13.5h
# ============================================================
echo ""
echo "=== P1: 拜占庭多种子 (f=1, 3 seeds × 3 attack types) ==="

for seed in 1 2 3; do
    for btype in random adversarial silence; do
        TOTAL=$((TOTAL+1))
        run_one "p1_byzantine_f1_${btype}_seed${seed}" \
            --algo pbft_cg_mappo \
            --env mpe_spread \
            --algo_config configs/algo/pbft_cg_mappo_v2.yaml \
            --seed $seed \
            --n_timesteps 500000 \
            --byzantine_n 1 \
            --byzantine_type $btype \
            --eval_interval 10000 \
            --eval_episodes 10 \
            --log_dir "$LOG_ROOT/byzantine_f1_${btype}_seed${seed}" \
            --gpu $GPU_ID
    done
done

# ============================================================
# Phase 1 完成
# ============================================================
echo ""
echo "========================================="
echo "Phase 1 完成! $DONE/$TOTAL 成功"
echo "结果目录: $LOG_ROOT"
echo "========================================="
