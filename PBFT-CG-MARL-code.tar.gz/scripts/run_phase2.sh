#!/bin/bash
# ============================================================
# PBFT-CG-MARL Phase 2: P2 新环境 mpe_reference
# 总计: 15 组实验 (5 algos × 3 seeds, MADDPG 不支持离散动作空间)
# 预计 ~22-24 小时 (RTX 4090)
#
# 用法:
#   前台:  bash scripts/run_phase2.sh 0
#   后台:  nohup bash scripts/run_phase2.sh 0 > phase2.log 2>&1 &
#   监控:  tail -f phase2.log
# 参数:  $1=gpu_id
# ============================================================
set -e

GPU_ID=${1:-0}
LOG_ROOT="results/v2/phase2"
mkdir -p "$LOG_ROOT"

echo "========================================="
echo "PBFT-CG-MARL Phase 2: 新环境 mpe_reference"
echo "GPU: $GPU_ID | LOG: $LOG_ROOT"
echo "总实验数: 15 (5 algos × 3 seeds, 不含 MADDPG)"
echo "========================================="

TOTAL=0
DONE=0

run_one() {
    local exp_name=$1; shift
    echo ""
    echo "[$(date +%H:%M:%S)] >>> [$TOTAL] $exp_name"
    local start_time=$(date +%s)
    
    python -u src/train.py "$@" 2>&1 | tee "$LOG_ROOT/${exp_name}.log"
    local exit_code=${PIPESTATUS[0]}
    
    local end_time=$(date +%s)
    local elapsed=$(( (end_time - start_time) / 60 ))
    
    if [ $exit_code -eq 0 ]; then
        DONE=$((DONE+1))
        echo "[$(date +%H:%M:%S)] <<< $exp_name 完成 (${elapsed}min) | 进度: $DONE/$TOTAL"
    else
        echo "[$(date +%H:%M:%S)] <<< $exp_name 失败! (exit=$exit_code) | 进度: $DONE/$TOTAL"
    fi
}

# ============================================================
# mpe_reference: 4 agents (2 reference + 2 target), discrete actions
# PBFT-CG-MAPPO 使用 entropy_coef=0.05
# ============================================================

# 1. PBFT-CG-MAPPO (v2 config)
echo ""
echo "=== PBFT-CG-MAPPO on mpe_reference ==="
for seed in 1 2 3; do
    TOTAL=$((TOTAL+1))
    run_one "p2_pbft_reference_seed${seed}" \
        --algo pbft_cg_mappo \
        --env mpe_reference \
        --algo_config configs/algo/pbft_cg_mappo_v2.yaml \
        --seed $seed \
        --n_timesteps 500000 \
        --eval_interval 10000 \
        --eval_episodes 10 \
        --log_dir "$LOG_ROOT/pbft_v2_reference_seed${seed}" \
        --gpu $GPU_ID
done

# 2. MAPPO (v2 config, entropy_coef=0.05)
echo ""
echo "=== MAPPO on mpe_reference ==="
for seed in 1 2 3; do
    TOTAL=$((TOTAL+1))
    run_one "p2_mappo_reference_seed${seed}" \
        --algo mappo \
        --env mpe_reference \
        --algo_config configs/algo/mappo_v2.yaml \
        --seed $seed \
        --n_timesteps 500000 \
        --eval_interval 10000 \
        --eval_episodes 10 \
        --log_dir "$LOG_ROOT/mappo_v2_reference_seed${seed}" \
        --gpu $GPU_ID
done

# 3. QMIX
echo ""
echo "=== QMIX on mpe_reference ==="
for seed in 1 2 3; do
    TOTAL=$((TOTAL+1))
    run_one "p2_qmix_reference_seed${seed}" \
        --algo qmix \
        --env mpe_reference \
        --algo_config configs/algo/qmix.yaml \
        --seed $seed \
        --n_timesteps 500000 \
        --eval_interval 10000 \
        --eval_episodes 10 \
        --log_dir "$LOG_ROOT/qmix_reference_seed${seed}" \
        --gpu $GPU_ID
done

# 4. CommNet
echo ""
echo "=== CommNet on mpe_reference ==="
for seed in 1 2 3; do
    TOTAL=$((TOTAL+1))
    run_one "p2_commnet_reference_seed${seed}" \
        --algo commnet \
        --env mpe_reference \
        --algo_config configs/algo/commnet.yaml \
        --seed $seed \
        --n_timesteps 500000 \
        --eval_interval 10000 \
        --eval_episodes 10 \
        --log_dir "$LOG_ROOT/commnet_reference_seed${seed}" \
        --gpu $GPU_ID
done

# 5. TarMAC
echo ""
echo "=== TarMAC on mpe_reference ==="
for seed in 1 2 3; do
    TOTAL=$((TOTAL+1))
    run_one "p2_tarmac_reference_seed${seed}" \
        --algo tarmac \
        --env mpe_reference \
        --algo_config configs/algo/tarmac.yaml \
        --seed $seed \
        --n_timesteps 500000 \
        --eval_interval 10000 \
        --eval_episodes 10 \
        --log_dir "$LOG_ROOT/tarmac_reference_seed${seed}" \
        --gpu $GPU_ID
done

# ============================================================
# Phase 2 完成
# ============================================================
echo ""
echo "========================================="
echo "Phase 2 完成! $DONE/$TOTAL 成功"
echo "结果目录: $LOG_ROOT"
echo "========================================="
