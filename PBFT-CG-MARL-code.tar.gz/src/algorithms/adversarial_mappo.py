"""
Adversarial MAPPO: 带对抗训练的MAPPO基线

在标准MAPPO基础上，训练期间对Agent间通信消息添加随机扰动，
作为对抗训练基线与PBFT-CG-MAPPO的共识机制进行对比。

与PBFT-CG-MAPPO的区别：
- PBFT-CG-MAPPO: 通过PBFT共识层的形式化保证来抵御扰动
- Adversarial MAPPO: 通过对抗训练获得经验鲁棒性，但无形式化保证

支持的扰动类型：
- uniform: 均匀噪声扰动
- gaussian: 高斯噪声扰动
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, Tuple, Optional, Any, List

from src.algorithms.mappo import MAPPO
from src.networks.actor_critic import ActorNetwork, CriticNetwork


class AdversarialMAPPO(MAPPO):
    """
    对抗训练MAPPO基线

    继承标准MAPPO，在训练期间对Agent间通信消息添加扰动。
    通过对抗训练提升经验鲁棒性，但无形式化保证。

    Args:
        config: 算法超参数字典
        env_info: 环境信息字典
    """

    def __init__(self, config: dict, env_info: dict):
        super().__init__(config, env_info)

        # 对抗训练参数
        adv_config = config.get("adversarial", {})
        self.perturbation_strength = adv_config.get("perturbation_strength", 0.1)
        self.perturbation_type = adv_config.get("perturbation_type", "uniform")
        self.perturbation_probability = adv_config.get("perturbation_probability", 0.3)
        self.adversarial_training = adv_config.get("adversarial_training", True)

        # 扰动统计
        self._total_perturbations = 0
        self._total_steps = 0

    def act(
        self,
        obs: torch.Tensor,
        hidden_state: torch.Tensor,
        deterministic: bool = False,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        批量动作选择（带对抗扰动）

        在训练期间，对每个Agent的动作输出添加随机扰动，
        模拟消息被篡改的场景。

        Args:
            obs: 观测, shape=(n_agents, obs_dim)
            hidden_state: 隐藏状态, shape=(n_agents, hidden_dim)
            deterministic: 是否确定性选择

        Returns:
            actions: 动作
            hidden_state: 更新后的隐藏状态
            action_log_probs: 动作对数概率
        """
        # 先获取标准MAPPO的动作
        actions, hidden_state, action_log_probs = super().act(
            obs, hidden_state, deterministic=deterministic
        )

        # 训练期间添加扰动
        if self.adversarial_training and self.training and not deterministic:
            actions = self._perturb_actions(actions)

        return actions, hidden_state, action_log_probs

    def get_action(
        self,
        obs: torch.Tensor,
        hidden_state: torch.Tensor,
        deterministic: bool = False,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        单Agent动作选择（带对抗扰动）

        Args:
            obs: 单Agent观测, shape=(obs_dim,)
            hidden_state: 隐藏状态, shape=(hidden_dim,)
            deterministic: 是否确定性选择

        Returns:
            action: 动作
            action_log_prob: 动作对数概率
            hidden_state: 更新后的隐藏状态
        """
        action, action_log_prob, hidden_state = super().get_action(
            obs, hidden_state, deterministic=deterministic
        )

        # 训练期间添加扰动
        if self.adversarial_training and self.training and not deterministic:
            action = self._perturb_single_action(action)

        return action, action_log_prob, hidden_state

    def _perturb_actions(self, actions: torch.Tensor) -> torch.Tensor:
        """
        对批量动作添加扰动

        以perturbation_probability的概率对每个Agent的动作添加扰动

        Args:
            actions: 动作张量, shape=(n_agents, ...)

        Returns:
            扰动后的动作张量
        """
        self._total_steps += 1
        perturbed_actions = actions.clone()

        for agent_id in range(self.n_agents):
            if torch.rand(1).item() < self.perturbation_probability:
                perturbed_actions[agent_id] = self._apply_perturbation(
                    perturbed_actions[agent_id]
                )
                self._total_perturbations += 1

        return perturbed_actions

    def _perturb_single_action(self, action: torch.Tensor) -> torch.Tensor:
        """
        对单个动作添加扰动

        Args:
            action: 单个动作张量

        Returns:
            扰动后的动作张量
        """
        if torch.rand(1).item() < self.perturbation_probability:
            action = self._apply_perturbation(action)
            self._total_perturbations += 1
        return action

    def _apply_perturbation(self, action: torch.Tensor) -> torch.Tensor:
        """
        对动作施加扰动

        Args:
            action: 动作张量

        Returns:
            扰动后的动作张量
        """
        if self.perturbation_type == "uniform":
            # 均匀噪声
            noise = torch.rand_like(action) * 2 - 1  # [-1, 1]
            noise = noise * self.perturbation_strength
        elif self.perturbation_type == "gaussian":
            # 高斯噪声
            noise = torch.randn_like(action) * self.perturbation_strength
        else:
            raise ValueError(f"未知扰动类型: {self.perturbation_type}")

        perturbed = action + noise

        # 离散动作：选择离扰动后logits最近的动作
        if self.action_type == "discrete":
            # action是离散动作索引，转换为one-hot后加噪声再取argmax
            n_actions = self.action_shape
            one_hot = F.one_hot(action.long(), n_actions).float()
            perturbed_logits = one_hot + noise[:n_actions] if noise.numel() >= n_actions else one_hot + noise
            perturbed = perturbed_logits.argmax(dim=-1)

        return perturbed

    def update(self, batch: Dict[str, torch.Tensor]) -> Dict[str, float]:
        """
        从batch更新参数

        使用标准MAPPO的PPO更新，但记录扰动统计信息

        Args:
            batch: 数据batch字典

        Returns:
            loss_dict: 损失字典（包含扰动统计）
        """
        loss_dict = super().update(batch)

        # 添加扰动统计
        loss_dict["perturbation_rate"] = (
            self._total_perturbations / max(self._total_steps, 1)
        )
        loss_dict["total_perturbations"] = self._total_perturbations

        return loss_dict

    def save(self, path: str) -> None:
        """保存模型"""
        torch.save(
            {
                "model_state_dict": self.state_dict(),
                "optimizer_state_dict": self.optimizer.state_dict(),
                "config": self.config,
                "perturbation_strength": self.perturbation_strength,
                "perturbation_type": self.perturbation_type,
                "perturbation_probability": self.perturbation_probability,
                "adversarial_training": self.adversarial_training,
            },
            path,
        )

    def load(self, path: str) -> None:
        """加载模型"""
        checkpoint = torch.load(path, map_location=self.device, weights_only=False)
        self.load_state_dict(checkpoint["model_state_dict"])
        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        if "perturbation_strength" in checkpoint:
            self.perturbation_strength = checkpoint["perturbation_strength"]
        if "perturbation_type" in checkpoint:
            self.perturbation_type = checkpoint["perturbation_type"]
        if "perturbation_probability" in checkpoint:
            self.perturbation_probability = checkpoint["perturbation_probability"]
        if "adversarial_training" in checkpoint:
            self.adversarial_training = checkpoint["adversarial_training"]
