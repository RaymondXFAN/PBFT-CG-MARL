"""
Gilbert-Elliott丢包模型

模拟真实网络中突发性丢包的Markov模型：
- GOOD状态：丢包率低 (p_g)
- BAD状态：丢包率高 (p_b)
- 状态转移由p_gg和p_bb控制

用于PBFT共识层prepare阶段的通信丢包模拟，
验证PBFT-CG-MAPPO在不可靠通信下的韧性。
"""

import random
from typing import Optional


class GilbertElliottModel:
    """
    Gilbert-Elliott丢包模型

    状态: GOOD (丢包率p_g) / BAD (丢包率p_b)
    转移: GOOD→BAD概率(1-p_gg), BAD→GOOD概率(1-p_bb)

    Args:
        p_g: GOOD状态下的丢包率 (默认0.01)
        p_b: BAD状态下的丢包率 (默认0.2)
        p_gg: GOOD→GOOD的转移概率 (默认0.95)
        p_bb: BAD→BAD的转移概率 (默认0.9)
    """

    def __init__(
        self,
        p_g: float = 0.01,
        p_b: float = 0.2,
        p_gg: float = 0.95,
        p_bb: float = 0.9,
    ):
        self.p_g = p_g
        self.p_b = p_b
        self.p_gg = p_gg
        self.p_bb = p_bb
        self.state = "GOOD"

        # 统计信息
        self._total_calls = 0
        self._total_drops = 0

    def drop(self) -> bool:
        """
        判断当前step是否丢包

        Returns:
            True表示丢包，False表示不丢包
        """
        self._total_calls += 1

        if self.state == "GOOD":
            # 状态转移
            if random.random() > self.p_gg:
                self.state = "BAD"
            # 丢包判断
            is_drop = random.random() < self.p_g
        else:
            # 状态转移
            if random.random() > self.p_bb:
                self.state = "GOOD"
            # 丢包判断
            is_drop = random.random() < self.p_b

        if is_drop:
            self._total_drops += 1

        return is_drop

    def should_drop_agent(self, agent_id: int) -> bool:
        """
        判断某个Agent的消息是否应该被丢包

        每个Agent的丢包独立判断，模拟真实网络中不同链路的丢包

        Args:
            agent_id: Agent的ID

        Returns:
            True表示该Agent的消息被丢包
        """
        return self.drop()

    def reset(self):
        """重置模型状态"""
        self.state = "GOOD"
        self._total_calls = 0
        self._total_drops = 0

    @property
    def drop_rate(self) -> float:
        """实际丢包率"""
        if self._total_calls == 0:
            return 0.0
        return self._total_drops / self._total_calls

    @property
    def current_state(self) -> str:
        """当前状态"""
        return self.state

    def __repr__(self) -> str:
        return (
            f"GilbertElliottModel(p_g={self.p_g}, p_b={self.p_b}, "
            f"p_gg={self.p_gg}, p_bb={self.p_bb}, state={self.state}, "
            f"drop_rate={self.drop_rate:.3f})"
        )


class MultiAgentPacketLossModel:
    """
    多Agent丢包模型

    为每个Agent对（sender, receiver）维护独立的Gilbert-Elliott模型，
    模拟真实网络中不同链路的独立丢包特性。

    Args:
        n_agents: Agent数量
        p_g: GOOD状态下的丢包率
        p_b: BAD状态下的丢包率
        p_gg: GOOD→GOOD的转移概率
        p_bb: BAD→BAD的转移概率
    """

    def __init__(
        self,
        n_agents: int,
        p_g: float = 0.01,
        p_b: float = 0.2,
        p_gg: float = 0.95,
        p_bb: float = 0.9,
    ):
        self.n_agents = n_agents
        self.p_g = p_g
        self.p_b = p_b
        self.p_gg = p_gg
        self.p_bb = p_bb

        # 为每对Agent创建独立的丢包模型
        # models[i][j] 表示从Agent i 到 Agent j 的丢包模型
        self.models: dict = {}
        for i in range(n_agents):
            for j in range(n_agents):
                if i != j:
                    self.models[(i, j)] = GilbertElliottModel(
                        p_g=p_g, p_b=p_b, p_gg=p_gg, p_bb=p_bb
                    )

    def should_drop(self, sender: int, receiver: int) -> bool:
        """
        判断从sender到receiver的消息是否应该被丢包

        Args:
            sender: 发送者Agent ID
            receiver: 接收者Agent ID

        Returns:
            True表示该消息被丢包
        """
        if sender == receiver:
            return False  # 不丢自己的消息
        key = (sender, receiver)
        if key in self.models:
            return self.models[key].drop()
        return False

    def get_dropped_agents(self, sender: int) -> list:
        """
        获取sender发消息时，哪些receiver会丢包

        Args:
            sender: 发送者Agent ID

        Returns:
            被丢包的receiver ID列表
        """
        dropped = []
        for j in range(self.n_agents):
            if j != sender and self.should_drop(sender, j):
                dropped.append(j)
        return dropped

    def reset(self):
        """重置所有丢包模型"""
        for model in self.models.values():
            model.reset()

    def __repr__(self) -> str:
        return (
            f"MultiAgentPacketLossModel(n_agents={self.n_agents}, "
            f"p_g={self.p_g}, p_b={self.p_b})"
        )
