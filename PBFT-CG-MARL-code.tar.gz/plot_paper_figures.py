#!/usr/bin/env python3
"""
PBFT-CG-MAPPO 论文图表生成脚本 v2
莫兰迪色系 | 字号≥12 | 无 caption | Figure X-Name 命名
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import os
import pandas as pd
from matplotlib.lines import Line2D

# ============ 全局设置 ============
plt.rcParams.update({
    'font.size': 12,
    'axes.labelsize': 13,
    'axes.titlesize': 13,
    'xtick.labelsize': 12,
    'ytick.labelsize': 12,
    'legend.fontsize': 11,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'axes.spines.top': False,
    'axes.spines.right': False,
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
})

# 莫兰迪色系
M = {
    'blue':    '#7B9EA8',
    'rose':    '#C4A4A4',
    'green':   '#9CB8A0',
    'tan':     '#C8B88A',
    'purple':  '#A09BB5',
    'coral':   '#D4A09B',
    'slate':   '#8FA3B0',
    'sage':    '#B5C4B1',
    'dust':    '#B8A9C9',
    'sand':    '#C9B99A',
    'dkblue':  '#5A7A88',
    'dkrose':  '#A08080',
    'dkgreen': '#7A9A7E',
}

DATA_DIR = '/sandbox/workspace/PBFT-CG-MARL/paper_data'
OUT_DIR = '/sandbox/workspace/PBFT-CG-MARL/paper_figures'
os.makedirs(OUT_DIR, exist_ok=True)

def smooth(y, window=100):
    if len(y) < window:
        return y
    return np.convolve(y, np.ones(window)/window, mode='valid')

def load_csv(name, suffix='reward'):
    df = pd.read_csv(os.path.join(DATA_DIR, f'{name}_{suffix}.csv'))
    col = 'value' if 'value' in df.columns else suffix
    return df['step'].values, df[col].values

# ============ Figure 1: 训练回报曲线 ============
print("=== Figure 1 ===")
fig, ax = plt.subplots(figsize=(7, 4.5))

# PBFT Full: seed1 bold, seed2/3 lighter
for s, alpha, lw in [(1, 1.0, 1.4), (2, 0.5, 0.7), (3, 0.5, 0.7)]:
    steps, r = load_csv(f'pbft_full_s{s}', 'reward')
    sm = smooth(r, 80)
    ax.plot(steps[:len(sm)], sm, color=M['blue'], alpha=alpha, linewidth=lw)

# MAPPO: seed1 bold, seed2/3 lighter
for s, alpha, lw in [(1, 1.0, 1.4), (2, 0.5, 0.7), (3, 0.5, 0.7)]:
    steps, r = load_csv(f'mappo_s{s}', 'reward')
    sm = smooth(r, 80)
    ax.plot(steps[:len(sm)], sm, color=M['rose'], alpha=alpha, linewidth=lw)

# 均值虚线
pbft_means = [np.mean(load_csv(f'pbft_full_s{s}', 'reward')[1][-10:]) for s in [1,2,3]]
mappo_means = [np.mean(load_csv(f'mappo_s{s}', 'reward')[1][-10:]) for s in [1,2,3]]
ax.axhline(np.mean(pbft_means), color=M['dkblue'], ls='--', lw=1.5, label=f'PBFT-CG-MAPPO μ={np.mean(pbft_means):.1f}')
ax.axhline(np.mean(mappo_means), color=M['dkrose'], ls='--', lw=1.5, label=f'MAPPO μ={np.mean(mappo_means):.1f}')

# 方差带
ax.axhspan(np.mean(pbft_means)-np.std(pbft_means), np.mean(pbft_means)+np.std(pbft_means), alpha=0.15, color=M['blue'])
ax.axhspan(np.mean(mappo_means)-np.std(mappo_means), np.mean(mappo_means)+np.std(mappo_means), alpha=0.15, color=M['rose'])

ax.set_xlabel('Training Steps')
ax.set_ylabel('Episode Return')
ax.legend(loc='lower right')
fig.savefig(os.path.join(OUT_DIR, 'Figure1-TrainingReturnCurves.png'))
plt.close()
print("  ✓ Figure1")

# ============ Figure 2: 熵轨迹 ============
print("=== Figure 2 ===")
fig, ax = plt.subplots(figsize=(7, 4.5))

for s, alpha, lw in [(1, 1.0, 1.3), (2, 0.5, 0.6), (3, 0.5, 0.6)]:
    steps, e = load_csv(f'pbft_full_s{s}', 'entropy')
    sm = smooth(e, 15)
    ax.plot(steps[:len(sm)], sm, color=M['blue'], alpha=alpha, linewidth=lw)

for s, alpha, lw in [(1, 1.0, 1.3), (2, 0.5, 0.6), (3, 0.5, 0.6)]:
    steps, e = load_csv(f'mappo_s{s}', 'entropy')
    sm = smooth(e, 15)
    ax.plot(steps[:len(sm)], sm, color=M['rose'], alpha=alpha, linewidth=lw)

ax.axhline(0.1, color=M['sage'], ls=':', lw=1.0)
ax.axhline(1.609, color=M['sand'], ls=':', lw=1.0)

legend_elements = [
    Line2D([0],[0], color=M['blue'], lw=1.5, label='PBFT-CG-MAPPO'),
    Line2D([0],[0], color=M['rose'], lw=1.5, label='MAPPO'),
    Line2D([0],[0], color=M['sage'], ls=':', lw=1.0, label='Collapse threshold (H=0.1)'),
    Line2D([0],[0], color=M['sand'], ls=':', lw=1.0, label='Uniform random (ln5≈1.61)'),
]
ax.legend(handles=legend_elements, loc='upper right', fontsize=10)
ax.set_xlabel('Training Steps')
ax.set_ylabel('Policy Entropy')
ax.set_ylim(-0.05, 1.8)
fig.savefig(os.path.join(OUT_DIR, 'Figure2-EntropyTrajectories.png'))
plt.close()
print("  ✓ Figure2")

# ============ Figure 3: 方差对比 ============
print("=== Figure 3 ===")
fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))

# (a) Cross-env
envs = ['MPE\nspread', 'SMAClite\n5m_vs_6m', 'VMAS\nUAV']
pbft_std = [3.7, 4.7, 47.8]
mappo_std = [16.9, 223.0, 90.1]
vr = [4.6, 47.4, 1.9]
x = np.arange(3)
w = 0.3
bars1 = axes[0].bar(x-w/2, pbft_std, w, color=M['blue'], label='PBFT-CG-MAPPO')
bars2 = axes[0].bar(x+w/2, mappo_std, w, color=M['rose'], label='MAPPO')
for i, v in enumerate(vr):
    axes[0].text(x[i], max(pbft_std[i], mappo_std[i])*1.3, f'{v}×↓', ha='center', fontsize=12, fontweight='bold', color=M['dkblue'])
axes[0].set_xticks(x)
axes[0].set_xticklabels(envs)
axes[0].set_ylabel('Return Std Dev (σ)')
axes[0].set_yscale('log')
axes[0].legend()

# (b) Ablation
conds = ['Full\n(Filter+Loss)', 'Loss Only\n(no filter)', 'Filter Only\n(no loss)', 'MAPPO\n(neither)']
stds = [5.5, 3.5, 10.4, 19.8]
means = [-81.4, -72.3, -71.5, -55.5]
colors = [M['blue'], M['green'], M['tan'], M['rose']]
bars = axes[1].bar(range(4), stds, color=colors, width=0.55)
for bar, s, m in zip(bars, stds, means):
    axes[1].text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.4,
                 f'σ={s}\nμ={m:.0f}', ha='center', va='bottom', fontsize=10, fontweight='bold')
axes[1].set_xticks(range(4))
axes[1].set_xticklabels(conds, fontsize=9.5)
axes[1].set_ylabel('Return Std Dev (σ)')
axes[1].set_ylim(0, 20)

fig.tight_layout(pad=2.5)
fig.savefig(os.path.join(OUT_DIR, 'Figure3-VarianceComparison.png'))
plt.close()
print("  ✓ Figure3")

# ============ Figure 4: 2×2 消融热力图 ============
print("=== Figure 4 ===")
fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))

mean_d = np.array([[-81.4, -71.5], [-72.3, -55.5]])
std_d = np.array([[5.5, 10.4], [3.5, 19.8]])

im1 = axes[0].imshow(mean_d, cmap='RdYlGn', aspect='auto', vmin=-90, vmax=-50)
for i in range(2):
    for j in range(2):
        axes[0].text(j, i, f'{mean_d[i,j]:.1f}', ha='center', va='center', fontsize=14, fontweight='bold')
axes[0].set_xticks([0,1]); axes[0].set_xticklabels(['Loss ON', 'Loss OFF'])
axes[0].set_yticks([0,1]); axes[0].set_yticklabels(['Filter ON', 'Filter OFF'])
axes[0].set_xlabel('Consensus Loss'); axes[0].set_ylabel('Consensus Filter')
fig.colorbar(im1, ax=axes[0], label='Mean Return', shrink=0.8)

im2 = axes[1].imshow(std_d, cmap='RdYlGn_r', aspect='auto', vmin=0, vmax=18)
for i in range(2):
    for j in range(2):
        axes[1].text(j, i, f'{std_d[i,j]:.1f}', ha='center', va='center', fontsize=14, fontweight='bold')
axes[1].set_xticks([0,1]); axes[1].set_xticklabels(['Loss ON', 'Loss OFF'])
axes[1].set_yticks([0,1]); axes[1].set_yticklabels(['Filter ON', 'Filter OFF'])
axes[1].set_xlabel('Consensus Loss'); axes[1].set_ylabel('Consensus Filter')
fig.colorbar(im2, ax=axes[1], label='Std Dev (σ)', shrink=0.8)

fig.tight_layout(pad=2.5)
fig.savefig(os.path.join(OUT_DIR, 'Figure4-AblationHeatmap.png'))
plt.close()
print("  ✓ Figure4")

# ============ Figure 5: Byzantine 攻击对比 ============
print("=== Figure 5 ===")
fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))

# (a) 4-agent
attacks = ['clean', 'random', 'adversarial', 'silence']
pbft4 = [-81.4, -41.3, -39.1, -53.4]
pbft4s = [5.5, 4.9, 6.5, 7.4]
nocons = [-81.4, -46.7, -75.5, -42.1]
noconss = [5.5, 5.1, 11.4, 0.2]
map4 = [-55.5, -40.0, -40.9, -36.2]
map4s = [19.8, 4.0, 3.6, 1.6]

x = np.arange(4)
w = 0.22
axes[0].bar(x-w, pbft4, w, yerr=pbft4s, color=M['blue'], capsize=3, label='PBFT (Full)', error_kw={'linewidth':1})
axes[0].bar(x, nocons, w, yerr=noconss, color=M['green'], capsize=3, label='No Consensus', error_kw={'linewidth':1})
axes[0].bar(x+w, map4, w, yerr=map4s, color=M['rose'], capsize=3, label='MAPPO', error_kw={'linewidth':1})
axes[0].set_xticks(x)
axes[0].set_xticklabels(attacks)
axes[0].set_ylabel('Mean Return')
axes[0].legend(fontsize=9, loc='lower left')

# (b) n=7 — 只画有数据的组
pbft7 = [-73.7, -65.8, -60.5, -62.2]
pbft7s = [15.7, 4.8, 3.1, 4.2]
axes[1].bar(x-w/2, pbft7, w, yerr=pbft7s, color=M['slate'], capsize=3, label='PBFT n=7', error_kw={'linewidth':1})
# MAPPO n=7: only clean and silence
map7_vals = [None, None, None, None]
map7_vals[0] = -62.3; map7_errs = [10.0, 0, 0, 2.6]
map7_vals[3] = -55.6
for i in [0, 3]:
    axes[1].bar(x[i]+w/2, map7_vals[i], w, yerr=map7_errs[i], color=M['coral'], capsize=3, label='MAPPO n=7' if i==0 else '', error_kw={'linewidth':1})
axes[1].set_xticks(x)
axes[1].set_xticklabels(attacks)
axes[1].set_ylabel('Mean Return')
axes[1].legend(fontsize=9)

fig.tight_layout(pad=2.5)
fig.savefig(os.path.join(OUT_DIR, 'Figure5-ByzantineComparison.png'))
plt.close()
print("  ✓ Figure5")

# ============ Figure 6: 种子散点图（补充） ============
print("=== Figure 6 ===")
fig, ax = plt.subplots(figsize=(7, 4.5))

# 每个算法的 3 个种子终值
algos = ['Full\n(Filter+Loss)', 'Loss Only', 'Filter Only', 'MAPPO']
seed_data = {
    'Full\n(Filter+Loss)': [-87.7, -77.9, -78.6],
    'Loss Only': [-69.5, -76.3, -71.2],
    'Filter Only': [-78.0, -59.5, -76.9],
    'MAPPO': [-39.1, -77.5, -49.7],
}
colors_list = [M['blue'], M['green'], M['tan'], M['rose']]

for i, (algo, seeds) in enumerate(seed_data.items()):
    mean = np.mean(seeds)
    std = np.std(seeds)
    ax.errorbar(i, mean, yerr=std, fmt='o', markersize=8, color=colors_list[i],
                capsize=6, linewidth=2, markeredgecolor='black', markeredgewidth=0.5)
    for s, seed_val in enumerate(seeds):
        ax.scatter(i + (s-1)*0.08, seed_val, s=50, color=colors_list[i],
                   edgecolors='black', linewidths=0.5, zorder=5, alpha=0.7)

ax.set_xticks(range(4))
ax.set_xticklabels(algos, fontsize=10)
ax.set_ylabel('Final Return (last-10 mean)')
ax.axhline(0, color='gray', linewidth=0.5)

fig.savefig(os.path.join(OUT_DIR, 'Figure6-SeedScatter.png'))
plt.close()
print("  ✓ Figure6")

print(f"\n✅ All 6 figures in {OUT_DIR}")
