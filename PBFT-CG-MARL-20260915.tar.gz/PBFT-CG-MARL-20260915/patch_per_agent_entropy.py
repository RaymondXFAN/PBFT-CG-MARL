#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
给 mappo.py / pbft_cg_mappo.py 增加 per-agent entropy 日志。

动机：现有 metrics.json 只记录 train/entropy（全体 agent 均值），
     导致 Table 3 无法还原 honest-agent 熵（反推为负，见 STATS_2026-09-11.md 第 4 节）。

本补丁特性：
  * 纯日志追加，不改 loss / 优化器 / 网络结构 / 随机性 → 训练结果完全一致
  * 新增指标：train/entropy_agent_0 ... train/entropy_agent_{N-1}
  * 幂等（重复执行会跳过）
  * 自动备份为 *.bak_peragent

用法:  python patch_per_agent_entropy.py
"""
import os
import shutil

ROOT = os.path.dirname(os.path.abspath(__file__))
TARGETS = [
    os.path.join(ROOT, "src", "algorithms", "mappo.py"),
    os.path.join(ROOT, "src", "algorithms", "pbft_cg_mappo.py"),
]

MARK = "# [per-agent entropy logging]"

INIT_OLD = "        total_entropy = 0.0\n"
INIT_NEW = ("        total_entropy = 0.0\n"
            "        total_entropy_per_agent = None   " + MARK + "\n")

ACC_OLD = "            total_entropy += mean_entropy.item()\n"
ACC_NEW = ("            total_entropy += mean_entropy.item()\n"
           "            _ea = [float(x.mean().item()) if hasattr(x, 'mean') else float(x)\n"
           "                   for x in entropies]   " + MARK + "\n"
           "            total_entropy_per_agent = _ea if total_entropy_per_agent is None else \\\n"
           "                [a + b for a, b in zip(total_entropy_per_agent, _ea)]\n")

RET_MARK = "        self._training_step += 1\n\n        return {\n"
INJECT = ("        if total_entropy_per_agent is not None:   " + MARK + "\n"
          "            for _i, _v in enumerate(total_entropy_per_agent):\n"
          "                _out[f\"entropy_agent_{_i}\"] = _v / self.ppo_epoch\n"
          "        return _out\n")


def patch(path):
    if not os.path.exists(path):
        print(f"[ERR] 找不到 {path}")
        return False
    src = open(path, encoding="utf-8").read()

    if MARK in src:
        print(f"[SKIP] {os.path.basename(path)} 已打过补丁")
        return True

    for old, name in ((INIT_OLD, "total_entropy = 0.0"),
                      (ACC_OLD, "total_entropy += mean_entropy.item()"),
                      (RET_MARK, "self._training_step += 1 + return {")):
        cnt = src.count(old)
        if cnt != 1:
            print(f"[ERR] {os.path.basename(path)}: 锚点 {name!r} 出现 {cnt} 次（应为 1），中止")
            return False

    shutil.copy2(path, path + ".bak_peragent")

    src = src.replace(INIT_OLD, INIT_NEW, 1)
    src = src.replace(ACC_OLD, ACC_NEW, 1)

    # 把 return {...} 改成 _out = {...} + 注入 + return _out
    brace = src.index(RET_MARK) + len(RET_MARK) - len("        return {\n")
    end = src.index("\n        }\n", brace) + len("\n        }\n")
    block = src[brace:end]
    assert block.startswith("        return {\n") and block.endswith("        }\n"), block[:40]
    new_block = block.replace("        return {\n", "        _out = {\n", 1) + INJECT
    src = src[:brace] + new_block + src[end:]

    open(path, "w", encoding="utf-8").write(src)
    print(f"[OK]   {os.path.basename(path)} 已打补丁（备份 .bak_peragent）")
    return True


if __name__ == "__main__":
    ok = all(patch(p) for p in TARGETS)
    print("\n结果：" + ("全部成功 ✅" if ok else "有失败 ❌"))
    if ok:
        print("提示：可选做一次 5K 步冒烟，确认 metrics.json 里出现 train/entropy_agent_0")
