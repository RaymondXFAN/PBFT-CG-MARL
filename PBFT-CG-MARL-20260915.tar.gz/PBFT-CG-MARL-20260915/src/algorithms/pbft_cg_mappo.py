"""
PBFT-CG-MAPPO: PBFT共识引导的多Agent近端策略优化

核心创新算法！将PBFT拜占庭容错共识协议嵌入MAPPO，
实现共识引导的协作决策。

训练流程：
1. 每个Agent的Actor输出action proposal
2. PBFT共识层聚合proposals → final_actions
3. final_actions执行环境
4. 收集轨迹(包含consensus_info)
5. GAE计算优势
6. PPO clip更新（使用final_actions的log_prob）

支持参数共享（share_param=True）和独立参数（share_param=False）
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, Tuple, Optional, Any, List

from src.algorithms.base import BaseAlgorithm
from src.networks.actor_critic import ActorNetwork, CriticNetwork
from src.consensus.pbft import PBFTConsensusLayer


class PBFTCGMAPPO(BaseAlgorithm):
    """
    PBFT-Consensus-Guided MAPPO算法
    
    在MAPPO基础上引入PBFT共识层，实现共识引导的协作决策。
    
    Args:
        config: 算法超参数字典
        env_info: 环境信息字典
    """

    def __init__(self, config: dict, env_info: dict):
        super().__init__(config, env_info)

        # 超参数
        self.lr = config.get("lr", 0.0005)
        self.clip_ratio = config.get("clip_ratio", 0.2)
        self.value_loss_coef = config.get("value_loss_coef", 0.5)
        self.entropy_coef = config.get("entropy_coef", 0.01)
        self.gamma = config.get("gamma", 0.99)
        self.gae_lambda = config.get("gae_lambda", 0.95)
        self.ppo_epoch = config.get("ppo_epoch", 5)
        self.num_mini_batch = config.get("num_mini_batch", 1)
        self.max_grad_norm = config.get("max_grad_norm", 0.5)
        self.hidden_dim = config.get("hidden_dim", 64)
        self.use_rnn = config.get("use_rnn", True)
        self.share_param = config.get("share_param", True)

        # PBFT共识层参数
        self.pbft_f = config.get("pbft_f", 1)
        self.leader_rotation = config.get("leader_rotation", True)
        self.use_fallback = config.get("use_fallback", True)
        self.consensus_temperature = config.get("consensus_temperature", 1.0)
        self.consensus_threshold = config.get("consensus_threshold", 0.5)
        self.consensus_loss_coef = config.get("consensus_loss_coef", 0.1)

        # v4: 共识频率控制
        self.consensus_freq = config.get("consensus_freq", 1)
        self.matched_logprob = config.get("matched_logprob", False)
        self.byzantine_mode = config.get("byzantine_mode", "random")
        self.kl_direction = config.get("kl_direction", "reverse")
        self.byzantine_indices = config.get("byzantine_indices", [])
        self.consensus_blend_ratio = config.get("consensus_blend_ratio", 0.3)
        # v4.2: 软共识参数
        self.soft_consensus_mode = config.get("soft_consensus_mode", False)
        # v4.5: 提案层拜占庭参数
        self.proposal_byzantine_agents = []
        self.proposal_byzantine_type = None
        self.kl_consensus_coef = config.get("kl_consensus_coef", 0.1)
        self.entropy_floor = config.get("entropy_floor", 0.05)
        self._kl_consensus_loss_val = 0.0
        self._entropy_floor_penalty_val = 0.0
        self._consensus_step_counter = 0

        # v4: 自适应熵调度
        self.use_adaptive_entropy = config.get("use_adaptive_entropy", False)
        self.target_entropy = config.get("target_entropy", 0.10)
        self.entropy_coef_min = config.get("entropy_coef_min", 0.02)
        self.entropy_coef_max = config.get("entropy_coef_max", 0.30)
        self.entropy_adjustment_rate = config.get("entropy_adjustment_rate", 0.05)

        # 构建网络
        self._build_networks()

        # 构建PBFT共识层
        self.pbft_consensus = PBFTConsensusLayer(
            n_agents=self.n_agents,
            f=self.pbft_f,
            leader_rotation=self.leader_rotation,
            use_fallback=self.use_fallback,
            temperature=self.consensus_temperature,
            consensus_threshold=self.consensus_threshold,
            action_dim=self.action_shape,
        )

        # v5: Separate optimizers - actor and critic
        actor_params = list(self.actor.parameters()) if self.share_param else list(self.actors.parameters())
        critic_params = list(self.critic.parameters())
        self.actor_optimizer = torch.optim.Adam(actor_params, lr=self.lr, eps=1e-5)
        self.critic_optimizer = torch.optim.Adam(critic_params, lr=self.lr, eps=1e-5)
        self.optimizer = self.actor_optimizer  # compat for lr_scheduler

        # 训练步数
        self._training_step = 0

    def _build_networks(self) -> None:
        """构建Actor和Critic网络"""
        if self.share_param:
            # 参数共享：所有Agent共享一个Actor网络
            self.actor = ActorNetwork(
                obs_dim=self.obs_shape,
                action_dim=self.action_shape,
                action_type=self.action_type,
                hidden_dim=self.hidden_dim,
                use_rnn=self.use_rnn,
            )
            self.critic = CriticNetwork(
                state_dim=self.state_shape,
                hidden_dim=self.hidden_dim,
                use_rnn=self.use_rnn,
            )
        else:
            # 独立参数：每个Agent一个Actor网络
            self.actors = nn.ModuleList([
                ActorNetwork(
                    obs_dim=self.obs_shape,
                    action_dim=self.action_shape,
                    action_type=self.action_type,
                    hidden_dim=self.hidden_dim,
                    use_rnn=self.use_rnn,
                )
                for _ in range(self.n_agents)
            ])
            self.critic = CriticNetwork(
                state_dim=self.state_shape,
                hidden_dim=self.hidden_dim,
                use_rnn=self.use_rnn,
            )

    def act(
        self,
        obs: torch.Tensor,
        hidden_state: torch.Tensor,
        deterministic: bool = False,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        批量动作选择（带PBFT共识）
        
        Args:
            obs: 观测, shape=(n_agents, obs_dim)
            hidden_state: 隐藏状态, shape=(n_agents, hidden_dim)
            deterministic: 是否确定性选择
            
        Returns:
            final_actions: 共识后的动作
            hidden_state: 更新后的隐藏状态
            action_log_probs: 动作对数概率
        """
        # 步骤1：每个Agent的Actor输出action proposal
        proposals = []
        actions_list = []
        log_probs_list = []
        new_hidden_states = []

        for agent_id in range(self.n_agents):
            agent_obs = obs[agent_id].unsqueeze(0)  # (1, obs_dim)
            # hidden_state 形状: (num_layers=1, batch=n_agents, hidden_size)
            # 取第 agent_id 个 agent 的 hidden: (1, hidden_size) -> unsqueeze(0) -> (1, 1, hidden_size)
            agent_hidden = hidden_state[:, agent_id, :].unsqueeze(0)  # (1, 1, hidden_dim)

            if self.share_param:
                action, log_prob, new_hidden = self.actor.get_action(
                    agent_obs, agent_hidden, deterministic=deterministic
                )
            else:
                action, log_prob, new_hidden = self.actors[agent_id].get_action(
                    agent_obs, agent_hidden, deterministic=deterministic
                )

            actions_list.append(action.squeeze(0))
            log_probs_list.append(log_prob.squeeze(0))
            # new_hidden 是 (1, 1, hidden_dim) -> squeeze(0).squeeze(0) -> (hidden_dim,)
            new_hidden_states.append(new_hidden.squeeze(0).squeeze(0))
            proposals.append((action.squeeze(0), log_prob.squeeze(0)))

        # 重新组装为 (num_layers=1, batch=n_agents, hidden_size)
        hidden_state = torch.stack(new_hidden_states, dim=0).unsqueeze(0)

        # ===== v4.5: 提案层拜占庭攻击（共识之前） =====
        if hasattr(self, "proposal_byzantine_agents") and self.proposal_byzantine_agents:
            for byz_id in self.proposal_byzantine_agents:
                if byz_id < len(proposals):
                    action_b, log_prob_b = proposals[byz_id]
                    if self.proposal_byzantine_type == "adversarial":
                        if self.action_type == "discrete":
                            n_acts = 5
                            adv_action = (action_b.item() + n_acts // 2) % n_acts
                            proposals[byz_id] = (torch.tensor(adv_action, dtype=action_b.dtype, device=action_b.device), log_prob_b)
                        else:
                            proposals[byz_id] = (-action_b, log_prob_b)
                    elif self.proposal_byzantine_type == "random":
                        if self.action_type == "discrete":
                            import random as _rnd
                            rand_action = _rnd.randint(0, 4)
                            proposals[byz_id] = (torch.tensor(rand_action, dtype=action_b.dtype, device=action_b.device), log_prob_b)
                        else:
                            proposals[byz_id] = (torch.randn_like(action_b), log_prob_b)
        # ===== v4.5 END =====

        # 步骤2：PBFT共识层（v4.2: 支持软共识模式）
        self._consensus_step_counter += 1
        if self.soft_consensus_mode:
            consensus_actions, consensus_info = self.pbft_consensus(
                proposals, obs, step=self._training_step, action_type=self.action_type
            )
            self._last_consensus_actions = consensus_actions
            self._last_consensus_info = consensus_info
            final_actions = [a for a, _ in proposals]
        elif self.consensus_freq <= 1 or self._consensus_step_counter % self.consensus_freq == 0:
            if hasattr(self, "pbft_consensus") and hasattr(self, "consensus_blend_ratio"):
                self.pbft_consensus.blend_ratio = self.consensus_blend_ratio
            consensus_actions, consensus_info = self.pbft_consensus(
                proposals, obs, step=self._training_step, action_type=self.action_type
            )
            final_actions = consensus_actions
        else:
            final_actions = [a for a, _ in proposals]
            consensus_info = {"consensus_rate": 1.0, "consensus_achieved": True, "skipped": True}
        # 步骤3：使用动作
        # 确保所有final_actions形状一致
        ref_shape = final_actions[0].shape
        normalized_actions = []
        for ca in final_actions:
            if ca.shape != ref_shape:
                ca = ca.reshape(ref_shape)
            normalized_actions.append(ca)
        actions_tensor = torch.stack(normalized_actions, dim=0)

        # 计算共识动作的对数概率
        # v5: 支持 mismatched-logprob 对照（E2因果实验）
        if not getattr(self, 'matched_logprob', True):
            # mismatched模式：使用原始提案的log_prob（log_prob与执行动作不一致）
            action_log_probs = torch.stack([lp for _, lp in proposals], dim=0)
        else:
            # matched模式（默认）：对执行动作重新计算log_prob
            action_log_probs_list = []
            for agent_id in range(self.n_agents):
                agent_obs = obs[agent_id].unsqueeze(0)
                # hidden_state 形状: (num_layers=1, batch=n_agents, hidden_size)
                agent_hidden = hidden_state[:, agent_id, :].unsqueeze(0)  # (1, 1, hidden_dim)
                consensus_action = final_actions[agent_id]

                if self.share_param:
                    action_dist, _ = self.actor(agent_obs, agent_hidden)
                else:
                    action_dist, _ = self.actors[agent_id](agent_obs, agent_hidden)

                if self.action_type == "discrete":
                    # 离散动作：确保consensus_action是有效的整数类型
                    ca = consensus_action.long()
                    log_prob = action_dist.log_prob(ca.unsqueeze(0))
                else:
                    log_prob = action_dist.log_prob(consensus_action.unsqueeze(0))
                    if log_prob.dim() > 1:
                        log_prob = log_prob.sum(dim=-1)

                action_log_probs_list.append(log_prob.squeeze(0))

            action_log_probs = torch.stack(action_log_probs_list, dim=0)

        # 保存consensus_info用于训练
        self._last_consensus_info = consensus_info

        return actions_tensor, hidden_state, action_log_probs

    def get_action(
        self,
        obs: torch.Tensor,
        hidden_state: torch.Tensor,
        deterministic: bool = False,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        单Agent动作选择（无共识）
        
        Args:
            obs: 单Agent观测, shape=(obs_dim,)
            hidden_state: 隐藏状态, shape=(hidden_dim,)
            deterministic: 是否确定性选择
            
        Returns:
            action: 动作
            action_log_prob: 动作对数概率
            hidden_state: 更新后的隐藏状态
        """
        obs = obs.unsqueeze(0)  # (1, obs_dim)
        hidden_state = hidden_state.unsqueeze(0)  # (1, hidden_dim)

        if self.share_param:
            action, log_prob, new_hidden = self.actor.get_action(
                obs, hidden_state, deterministic=deterministic
            )
        else:
            action, log_prob, new_hidden = self.actors[0].get_action(
                obs, hidden_state, deterministic=deterministic
            )

        return action.squeeze(0), log_prob.squeeze(0), new_hidden.squeeze(0)

    def get_value(
        self,
        state: torch.Tensor,
        hidden_state: torch.Tensor,
    ) -> torch.Tensor:
        """
        集中式Critic价值估计
        
        Args:
            state: 全局状态, shape=(state_dim,) 或 (batch, state_dim)
            hidden_state: 隐藏状态
            
        Returns:
            value: 价值估计
        """
        if state.dim() == 1:
            state = state.unsqueeze(0)
        if hidden_state is None:
            hidden_state = torch.zeros(
                1, state.size(0), self.hidden_dim, device=self.device
            )
        value, _ = self.critic(state, hidden_state)
        return value.squeeze(-1)



    def evaluate_log_prob(self, obs, actions):
        """用当前策略网络重新计算给定动作的 log-prob（用于 matched-logprob 对照）。
        obs: dict of tensors (per-agent) 或 tensor；actions: list/np.array of executed actions。
        返回: list[float]，每个 agent 的执行动作对应的 log π(a|o)。
        若底层环境为离散动作，直接从 categorical 分布取 log_prob。"""
        import torch
        self.actor.eval()
        with torch.no_grad():
            try:
                if hasattr(self, "actor"):
                    logits = self.actor(obs)
                    if isinstance(logits, tuple):
                        logits = logits[0]
                    dist = torch.distributions.Categorical(logits=logits)
                    act_t = torch.as_tensor(actions, device=logits.device)
                    if act_t.dim() == 1:
                        act_t = act_t.unsqueeze(-1)
                    lp = dist.log_prob(act_t.squeeze(-1))
                    return lp.cpu().numpy().tolist()
            except Exception as e:
                print(f"[matched_logprob] evaluate_log_prob 失败: {e}")
        self.actor.train()
        return None


    def adversarial_action(self, obs_i, consensus_action_i, action_dim):
        """对抗拜占庭：选择最破坏共识的动作。
        简单有效实现：在与共识动作不同的动作中，选 argmax 距离；
        离散 5 动作环境：取 (consensus_action_i + action_dim//2) % action_dim（反向）。"""
        import numpy as np
        if consensus_action_i is None:
            return int(np.random.randint(action_dim))
        # 反向动作（最远离共识）
        return int((consensus_action_i + action_dim // 2) % action_dim)

    def apply_byzantine(self, actions, consensus_actions, action_dim):
        """对标记为拜占庭的 agent 覆写动作。"""
        if not self.byzantine_indices:
            return actions
        out = list(actions)
        for i in self.byzantine_indices:
            if i >= len(out):
                continue
            if self.byzantine_mode == "adversarial":
                c = consensus_actions[i] if consensus_actions else None
                out[i] = self.adversarial_action(None, c, action_dim)
            else:
                import numpy as np
                out[i] = int(np.random.randint(action_dim))
        return out

    def update(self, batch: Dict[str, torch.Tensor]) -> Dict[str, float]:
        """
        PPO clip更新
        
        使用final_actions的log_prob进行更新，
        并添加consensus-aware loss。
        
        Args:
            batch: 数据batch字典
            
        Returns:
            loss_dict: 损失字典
        """
        obs = batch["obs"].to(self.device)  # (batch, n_agents, obs_dim)
        state = batch["state"].to(self.device)  # (batch, state_dim)
        actions = batch["actions"].to(self.device)  # (batch, n_agents)
        old_log_probs = batch["action_log_probs"].to(self.device)  # (batch, n_agents)
        returns = batch["returns"].to(self.device)  # (batch, 1)
        advantages = batch["advantages"].to(self.device)  # (batch, 1)

        # 优势归一化
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        total_policy_loss = 0.0
        total_value_loss = 0.0
        total_entropy = 0.0
        total_entropy_per_agent = None   # [per-agent entropy logging]
        total_consensus_loss = 0.0

        for _ in range(self.ppo_epoch):
            # 评估当前策略
            new_log_probs = []
            entropies = []

            for agent_id in range(self.n_agents):
                agent_obs = obs[:, agent_id, :]  # (batch, obs_dim)
                if self.share_param:
                    log_prob, entropy, _ = self.actor.evaluate_action(
                        agent_obs, actions[:, agent_id]
                    )
                else:
                    log_prob, entropy, _ = self.actors[agent_id].evaluate_action(
                        agent_obs, actions[:, agent_id]
                    )
                new_log_probs.append(log_prob)
                entropies.append(entropy)
            # v5: KL共识损失（区分离散/连续动作）
            if self.soft_consensus_mode and hasattr(self, "_last_consensus_actions") and self._last_consensus_actions is not None:
                try:
                    cons_a = self._last_consensus_actions[agent_id]
                    # 调用 forward() 获取策略分布
                    if self.share_param:
                        real_dist, _ = self.actor.forward(agent_obs)
                    else:
                        real_dist, _ = self.actors[agent_id].forward(agent_obs)
                    # 区分离散/连续动作
                    if self.action_type == "discrete":
                        # 离散动作：cons_a 是整数索引
                        if isinstance(cons_a, int):
                            ca_idx = cons_a
                        elif hasattr(cons_a, 'item'):
                            ca_idx = int(cons_a.item())
                        else:
                            ca_idx = int(cons_a)
                        ca_tensor = torch.tensor(ca_idx, dtype=torch.long, device=self.device)
                        if getattr(self, 'kl_direction', 'reverse') == 'forward':
                            ce_loss = -action_dist.log_prob(ca_tensor)
                        else:
                            ce_loss = -real_dist.log_prob(ca_tensor)
                    else:
                        # 连续动作：cons_a 是向量，直接用
                        if not isinstance(cons_a, torch.Tensor):
                            cons_a = torch.tensor(cons_a, dtype=torch.float32, device=self.device)
                        else:
                            cons_a = cons_a.detach().to(self.device)
                        # 确保 shape 匹配 (action_dim,)
                        if cons_a.dim() == 0:
                            cons_a = cons_a.unsqueeze(0)
                        # 连续动作用 MSE 代理 KL（更稳定）
                        mean = real_dist.mean  # (batch, action_dim)
                        # cons_a 扩展到 batch 维度
                        if cons_a.dim() == 1 and cons_a.shape[0] == mean.shape[-1]:
                            target = cons_a.unsqueeze(0).expand_as(mean)
                        else:
                            target = cons_a
                        ce_loss = ((mean - target) ** 2).mean()
                    if not hasattr(self, "_batch_ce_losses"):
                        self._batch_ce_losses = []
                    self._batch_ce_losses.append(ce_loss.mean())
                except Exception:
                    pass

            new_log_probs = torch.stack(new_log_probs, dim=-1)  # (batch, n_agents)
            mean_entropy = torch.stack(entropies, dim=-1).mean()

            # 旧策略的对数概率
            if old_log_probs.dim() == 2:
                old_log_probs_sum = old_log_probs.sum(dim=-1, keepdim=True)
            else:
                old_log_probs_sum = old_log_probs
            new_log_probs_sum = new_log_probs.sum(dim=-1, keepdim=True)

            # PPO clip
            ratio = torch.exp(new_log_probs_sum - old_log_probs_sum)
            surr1 = ratio * advantages
            surr2 = torch.clamp(ratio, 1.0 - self.clip_ratio, 1.0 + self.clip_ratio) * advantages
            policy_loss = -torch.min(surr1, surr2).mean()

            # 价值损失
            value_preds = batch["value_preds"].to(self.device)
            value, _ = self.critic(state)
            value = value.squeeze(-1)
            value_loss = F.mse_loss(returns.squeeze(-1), value)

            # 共识感知损失：鼓励Agent的动作与共识动作一致
            # 使用consensus_info中的共识率
            # v4.2: 共识损失 + 熵底线 + 软共识损失
            consensus_loss = torch.tensor(0.0, device=self.device)
            if hasattr(self, "_last_consensus_info") and self._last_consensus_info is not None:
                consensus_rate = self._last_consensus_info.get("consensus_rate", 0.0)
                consensus_loss = torch.tensor(
                    (1.0 - consensus_rate) * self.consensus_loss_coef,
                    device=self.device,
                )
            entropy_floor_penalty = torch.tensor(0.0, device=self.device)
            if hasattr(self, "entropy_floor") and mean_entropy < self.entropy_floor:
                deficit = self.entropy_floor - mean_entropy
                entropy_floor_penalty = 10.0 * (self.entropy_floor - mean_entropy)
            kl_consensus_loss = torch.tensor(0.0, device=self.device)
            if self.soft_consensus_mode and hasattr(self, "_batch_ce_losses") and self._batch_ce_losses:
                kl_consensus_loss = torch.stack(self._batch_ce_losses).mean()
                self._batch_ce_losses = []
            self._kl_consensus_loss_val = kl_consensus_loss.item()
            self._entropy_floor_penalty_val = entropy_floor_penalty.item()
            # v5: Separate actor/critic updates
            actor_loss = (
                policy_loss
                - self.entropy_coef * mean_entropy
                + consensus_loss
                + entropy_floor_penalty
                + self.kl_consensus_coef * kl_consensus_loss
            )
            critic_loss = self.value_loss_coef * value_loss
            # Actor gradient update
            self.actor_optimizer.zero_grad()
            actor_loss.backward(retain_graph=True)
            if self.share_param:
                nn.utils.clip_grad_norm_(self.actor.parameters(), self.max_grad_norm)
            else:
                nn.utils.clip_grad_norm_(self.actors.parameters(), self.max_grad_norm)
            self.actor_optimizer.step()
            # Critic gradient update
            self.critic_optimizer.zero_grad()
            critic_loss.backward()
            nn.utils.clip_grad_norm_(self.critic.parameters(), self.max_grad_norm)
            self.critic_optimizer.step()

            total_policy_loss += policy_loss.item()
            total_value_loss += value_loss.item()
            total_entropy += mean_entropy.item()
            _ea = [float(x.mean().item()) if hasattr(x, 'mean') else float(x)
                   for x in entropies]   # [per-agent entropy logging]
            total_entropy_per_agent = _ea if total_entropy_per_agent is None else \
                [a + b for a, b in zip(total_entropy_per_agent, _ea)]
            total_consensus_loss += consensus_loss.item()

        # v4: 自适应熵调度
        if self.use_adaptive_entropy:
            current_entropy = total_entropy / self.ppo_epoch
            if current_entropy < self.target_entropy:
                # 熵太低，增加熵系数
                self.entropy_coef = min(
                    self.entropy_coef * (1.0 + self.entropy_adjustment_rate),
                    self.entropy_coef_max
                )
            elif current_entropy > self.target_entropy * 1.5:
                # 熵太高，适当降低
                self.entropy_coef = max(
                    self.entropy_coef * (1.0 - self.entropy_adjustment_rate * 0.5),
                    self.entropy_coef_min
                )

        self._training_step += 1

        _out = {
            "policy_loss": total_policy_loss / self.ppo_epoch,
            "value_loss": total_value_loss / self.ppo_epoch,
            "entropy": total_entropy / self.ppo_epoch,
            "entropy_coef": self.entropy_coef,
            "kl_consensus_loss": self._kl_consensus_loss_val,
            "entropy_floor_penalty": self._entropy_floor_penalty_val,
            "consensus_loss": total_consensus_loss / self.ppo_epoch,
            "lr": self.optimizer.param_groups[0]["lr"],
        }
        if total_entropy_per_agent is not None:   # [per-agent entropy logging]
            for _i, _v in enumerate(total_entropy_per_agent):
                _out[f"entropy_agent_{_i}"] = _v / self.ppo_epoch
        return _out

    def inject_proposal_byzantine(self, agent_ids, byzantine_type="adversarial"):
        """v4.5: 在提案层注入拜占庭（共识之前）"""
        self.proposal_byzantine_agents = list(agent_ids)
        self.proposal_byzantine_type = byzantine_type
        print(f"[v4.5] 提案层拜占庭注入: agents={agent_ids}, type={byzantine_type}")


    def inject_byzantine(self, n_byzantine: int, byzantine_type: str = "random") -> None:
        """
        注入拜占庭Agent
        
        Args:
            n_byzantine: 拜占庭Agent数量
            byzantine_type: 拜占庭类型
        """
        self.pbft_consensus.inject_byzantine(n_byzantine, byzantine_type)

    def get_consensus_stats(self) -> Dict[str, Any]:
        """获取共识统计信息"""
        return self.pbft_consensus.get_consensus_stats()

    def save(self, path: str) -> None:
        """保存模型"""
        torch.save({
            "model_state_dict": self.state_dict(),
            "actor_optimizer_state_dict": self.actor_optimizer.state_dict(),
            "critic_optimizer_state_dict": self.critic_optimizer.state_dict(),
            "optimizer_state_dict": self.actor_optimizer.state_dict(),  # compat
            "training_step": self._training_step,
            "config": self.config,
            "env_info": self.env_info,
        }, path)

    def load(self, path: str) -> None:
        """加载模型"""
        checkpoint = torch.load(path, map_location=self.device)
        self.load_state_dict(checkpoint["model_state_dict"])
        # v5: Load separate optimizers
        if "actor_optimizer_state_dict" in checkpoint:
            self.actor_optimizer.load_state_dict(checkpoint["actor_optimizer_state_dict"])
            self.critic_optimizer.load_state_dict(checkpoint["critic_optimizer_state_dict"])
        else:
            self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        self._training_step = checkpoint["training_step"]
