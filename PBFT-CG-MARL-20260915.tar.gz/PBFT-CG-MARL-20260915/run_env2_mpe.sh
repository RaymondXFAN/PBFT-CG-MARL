#!/bin/bash
# ============================================================
# ENV2 = MPE simple_line（n=5, Discrete(5)）—— 第二环境
# ------------------------------------------------------------
# 为什么选它：
#   * mpe2 原生场景，零安装（SMAClite 在 PyPI 不存在、GitHub 抓不到）
#   * 能自定义 N=5 → 可注入 f=1（满足 PBFT 的 f < n/3）
#   * 动作空间 Discrete(5) 与主环境同构 → 共识层 / 软共识 KL 一行不改
#   * 任务不同（编队成线，非覆盖）→ 能证明设计准则可迁移
#
# 前置：先跑  python3 patch_env_line.py
#
# 用法:
#   bash run_env2_mpe.sh probe      # 预检：1 方法 × 1 seed × 5K 步（约 3-5 分钟）
#   bash run_env2_mpe.sh run        # 正式：3 方法 × {clean, byz f=1} × 5 seeds
#   STEPS=300000 SEEDS="1 2 3 4 5" bash run_env2_mpe.sh run    # 可覆盖
# ============================================================
set -u

PROJECT=/root/autodl-tmp/PBFT-CG-MARL
PY=${PY:-/root/miniconda3/bin/python}
[ -x "$PY" ] || PY=$(command -v python3)
RESULTS=$PROJECT/results/env2_mpe
LOGS=$PROJECT/logs/env2_mpe
mkdir -p "$RESULTS" "$LOGS"
cd "$PROJECT" || exit 1

PARALLEL=4          # MPE n=5 单步很轻，4 路可把它们喂饱（VMAS 才需要 2 路）
GPU=0
EVAL_INT=10000
EVAL_EP=10
STEPS=${STEPS:-300000}      # 与主表 n5_review 保持一致，便于横向对比
SEEDS=${SEEDS:-"1 2 3 4 5"}

ENV_NAME=mpe_line
ENV_CFG=configs/env/mpe_line.yaml

CFG_MAPPO=configs/algo/n5_mappo_fair.yaml
CFG_HARD=configs/algo/n5_hard_fair.yaml
CFG_SOFT=configs/algo/n5_soft_fair.yaml

BYZ="--byzantine_n 1 --byzantine_type random --byzantine_mode random"

log() { echo "[$(date +%H:%M:%S)] $*"; }

# 并发节流：按"当前实际在跑的进程数"控制，与方法数无关（旧写法 %PARALLEL 会失控）
throttle() { while [ "$(jobs -rp | wc -l)" -ge "$PARALLEL" ]; do sleep 10; done; }

preflight() {
    log "=== 前置检查 ==="
    [ -f "$ENV_CFG" ] || { log "❌ 缺少 $ENV_CFG —— 先跑： python3 patch_env_line.py"; exit 1; }
    for c in "$CFG_MAPPO" "$CFG_HARD" "$CFG_SOFT"; do
        [ -f "$c" ] || { log "❌ 缺少 $c"; exit 1; }
    done
    $PY - <<'PYEOF'
import sys
sys.path.insert(0, '.')
from src.envs import ENV_REGISTRY
assert "mpe_line" in ENV_REGISTRY, \
    "❌ mpe_line 未注册 —— 先跑： python3 patch_env_line.py"
env = ENV_REGISTRY["mpe_line"]({"scenario": "simple_line", "n_agents": 5, "max_steps": 25})
obs, info = env.reset()
print(f"✅ mpe_line 可用: agents={len(obs)}  obs_dim={obs['agent_0'].shape}  "
      f"state_dim={info['agent_0']['state'].shape}")
PYEOF
    log "GPU 现状：$(nvidia-smi --query-gpu=utilization.gpu,memory.used --format=csv,noheader | head -1)"
}

run() {   # $1=algo $2=algo_cfg $3=seed $4=label $5=额外参数
    local ALGO=$1 ACFG=$2 SEED=$3 LABEL=$4 EXTRA=${5:-}
    local OUTDIR=$RESULTS/$LABEL/seed_$SEED
    mkdir -p "$OUTDIR"
    if [ -f "$OUTDIR/$ALGO/seed_$SEED/metrics.json" ]; then
        log "  [SKIP] $LABEL seed=$SEED（已完成）"
        return
    fi
    throttle
    # shellcheck disable=SC2086
    nohup $PY -u src/train.py --algo "$ALGO" --env "$ENV_NAME" \
        --env_config "$PROJECT/$ENV_CFG" \
        --algo_config "$PROJECT/$ACFG" \
        --seed "$SEED" --n_timesteps "$STEPS" --eval_interval "$EVAL_INT" \
        --eval_episodes "$EVAL_EP" --gpu "$GPU" \
        --log_dir "$OUTDIR" $EXTRA \
        > "$LOGS/${LABEL}_s${SEED}.log" 2>&1 &
    log "  启动 $LABEL seed=$SEED (PID=$!)"
}

probe() {
    log "=== 预检：1 方法(soft) × 1 seed × 5K 步，验证 数据/前向/存盘/攻击注入 ==="
    preflight
    local T0 T1 EL
    T0=$(date +%s)
    $PY -u src/train.py --algo pbft_cg_mappo --env "$ENV_NAME" \
        --env_config "$PROJECT/$ENV_CFG" --algo_config "$PROJECT/$CFG_SOFT" \
        --seed 1 --n_timesteps 5000 --eval_interval 5000 --eval_episodes 1 \
        --gpu "$GPU" --log_dir /tmp/env2_mpe_probe $BYZ \
        > "$LOGS/probe.log" 2>&1
    T1=$(date +%s); EL=$((T1 - T0))
    local M=/tmp/env2_mpe_probe/pbft_cg_mappo/seed_1/metrics.json
    if [ ! -f "$M" ]; then
        log "❌ 没写出 metrics.json（真实路径：<log_dir>/<algo>/seed_N/metrics.json）"
        tail -25 "$LOGS/probe.log"
        exit 1
    fi
    log "✅ 存盘正常  $M"
    $PY - "$M" <<'PYEOF'
import json, sys
d = json.load(open(sys.argv[1]))
per = sorted([k for k in d if k.startswith("train/entropy_agent_")])
print(f"  指标条数={len(d)}")
print(f"  per-agent 熵键={per[:6]}{'...' if len(per) > 6 else ''}  (共 {len(per)} 个)")
need = ["episode/episode_reward", "train/entropy", "train/consensus_loss", "train/kl_consensus_loss"]
missing = [k for k in need if k not in d]
print("  ❌ 缺关键指标: " + str(missing) if missing else "  ✅ 关键指标齐全")
PYEOF
    log "拜占庭注入痕迹：$(grep -ci 'byzantine\|拜占庭' "$LOGS/probe.log") 行"
    local FULL=$(( EL * STEPS / 5000 ))
    local TOT=$(( FULL * 30 / PARALLEL ))
    log "  5K 步 = ${EL}s  →  单跑 $STEPS 步约 $((FULL/60)) 分 $((FULL%60)) 秒"
    log "  30 个 run / $PARALLEL 路并行 ≈ $((TOT/3600)) 小时 $((TOT%3600/60)) 分钟"
    log "=== 预检结束：若上面全绿，执行  bash run_env2_mpe.sh run ==="
}

batch() {
    log "=== ENV2 MPE simple_line：3 方法 × {clean, byz f=1} × seeds[$SEEDS] × $STEPS 步 ==="
    preflight
    local S
    for S in $SEEDS; do
        log "--- seed $S ---"
        run mappo         "$CFG_MAPPO" $S "ENV2L_mappo_clean" ""
        run pbft_cg_mappo "$CFG_HARD"  $S "ENV2L_hard_clean"  ""
        run pbft_cg_mappo "$CFG_SOFT"  $S "ENV2L_soft_clean"  ""
        run mappo         "$CFG_MAPPO" $S "ENV2L_mappo_byz"   "$BYZ"
        run pbft_cg_mappo "$CFG_HARD"  $S "ENV2L_hard_byz"    "$BYZ"
        run pbft_cg_mappo "$CFG_SOFT"  $S "ENV2L_soft_byz"    "$BYZ"
    done
    wait
    log "ENV2 全部结束：共 $(find "$RESULTS" -name metrics.json | wc -l) / $(( $(echo "$SEEDS" | wc -w) * 6 )) 个 run"
    log "汇总： python3 scripts/collect_results.py   （或看 $RESULTS）"
}

case "${1:-probe}" in
    probe) probe ;;
    run)   batch ;;
    *)     echo "用法: bash run_env2_mpe.sh {probe|run}" ;;
esac
