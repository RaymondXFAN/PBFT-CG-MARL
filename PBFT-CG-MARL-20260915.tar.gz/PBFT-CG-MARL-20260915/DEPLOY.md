# PBFT-CG-MARL 补充实验 —— 部署手册（对齐主表口径 · 2026-09-10）

## 0. 主表口径（已从服务器核实）

主表数据来自 `results/n5_review`，由 `scripts/run_n5_review.sh` 生成，9 个条件：

| 条件 | 算法配置 | 环境 |
|---|---|---|
| E1_mappo | `configs/algo/n5_mappo_fair.yaml` | `configs/env/mpe_spread_n5.yaml` |
| E1_hard | `configs/algo/n5_hard_fair.yaml` | 同上 |
| E1_soft | `configs/algo/n5_soft_fair.yaml` | 同上 |
| E2_matched | `configs/algo/n5_matched_logprob.yaml` | 同上 |
| E3_hard_rand / E3_hard_adv | `configs/algo/n5_hard_byz_random.yaml` / `n5_hard_byz_adversarial.yaml` | 同上 |
| E3_soft_rand / E3_soft_adv | `configs/algo/n5_soft_byz_random.yaml` / `n5_soft_byz_adversarial.yaml` | 同上 |
| E3_mappo_rand | `configs/algo/n5_mappo_byz_random.yaml` | 同上 |

**三条铁律（务必遵守）**

1. **拜占庭用 YAML 里的 `byzantine:` 块注入**，不是命令行参数。主脚本 E3 一个命令行参数都没传。
   ```yaml
   byzantine:
     inject_at: proposal
     mode: adversarial     # 或 random
     n: 1
   ```
2. **环境必须显式传 `--env mpe_spread`**（默认值 `simple_spread` 不在 `ENV_REGISTRY`，会让 `env_config` 失效）。
3. **`metrics.json` 在 `<log_dir>/<algo>/seed_<N>/` 下**（train.py 自动再套一层）。

## 1. 上传 & 安装

```bash
mkdir -p /root/autodl-tmp/PBFT-CG-MARL-supplement
tar -xzf /root/autodl-tmp/PBFT-CG-MARL-supplement.tar.gz -C /root/autodl-tmp/

cd /root/autodl-tmp/PBFT-CG-MARL-supplement
cp configs/env/mpe_spread_n7.yaml  /root/autodl-tmp/PBFT-CG-MARL/configs/env/
cp configs/algo/supp_*.yaml        /root/autodl-tmp/PBFT-CG-MARL/configs/algo/
cp verify_5min.sh collect_results.py /root/autodl-tmp/PBFT-CG-MARL/scripts/
cp run_supplement.sh               /root/autodl-tmp/PBFT-CG-MARL/
cp DEPLOY.md                       /root/autodl-tmp/PBFT-CG-MARL/

cd /root/autodl-tmp/PBFT-CG-MARL
chmod +x scripts/verify_5min.sh run_supplement.sh

# 确认文件到位
ls configs/env/mpe_spread_n7.yaml configs/algo/supp_*.yaml \
   configs/algo/n5_mappo_fair.yaml configs/algo/n5_soft_fair.yaml \
   configs/algo/n5_hard_fair.yaml configs/algo/n5_matched_logprob.yaml
```

## 2. 五分钟预检（必做）

```bash
cd /root/autodl-tmp/PBFT-CG-MARL
bash scripts/verify_5min.sh 0
```

对标：`预检结果: ✅ 6 ❌ 0`。预检覆盖：MAPPO / Soft / **MAPPO+拜占庭(新配置)** / VMAS / **n=7 f=2(新配置)** / Hard。

特别留意两行自检输出：
- `拜占庭机制自检` —— 应显示"日志里出现拜占庭注入痕迹"；若显示 ⚠️，说明 YAML 的 `byzantine:` 块没生效，要改用命令行参数。
- `确认 f 读到了 2` —— 应能看到 `f=2`；若只有 `f=1`，说明顶层 `pbft_f: 2` 没生效。

## 3. 正式实验（一条命令跑到底，无人值守）

**推荐：全自动串行**（A→B→D→C→汇总，中途零交互，可直接下班）

```bash
cd /root/autodl-tmp/PBFT-CG-MARL
chmod +x run_all_serial.sh
nohup bash run_all_serial.sh > logs/supplement/serial_master.log 2>&1 &

# 监控
tail -f logs/supplement/serial_master.log
```

**手动逐批**（想自己控制节奏时）

```bash
cd /root/autodl-tmp/PBFT-CG-MARL
nohup bash run_supplement.sh mappo > logs/supplement/batchA.log 2>&1 &   # A
nohup bash run_supplement.sh seeds > logs/supplement/batchB.log 2>&1 &   # B（等 A 完）
nohup bash run_supplement.sh f2    > logs/supplement/batchD.log 2>&1 &   # D
nohup bash run_supplement.sh vmas  > logs/supplement/batchC.log 2>&1 &   # C（放最后）
bash run_supplement.sh results                                          # 汇总
```

**⚠️ 拜占庭注入方式（重要修正）**

预检发现：**YAML 里的 `byzantine:` 块在服务器上不产生任何注入痕迹**。因此脚本已改为**双保险**——
YAML 块保留（若生效则与主表同源）**并同时传命令行参数**：

```
--byzantine_n 1 --byzantine_type adversarial     # Batch A
--byzantine_n 2 --byzantine_type adversarial     # Batch D
```

两条路径指向同一批 agent，不会重复叠加。`run_all_serial.sh` 开跑前会自动做一次 10 秒自检并在日志里报告。

**并发约定**

| 批 | 并发 | 原因 |
|---|---|---|
| A / B / D（MPE） | 4 | 4090 上 4 路利用率约 90% |
| C（VMAS） | **2** | VMAS 环境重，4 路抢显存/带宽（脚本已内置） |

- ⚠️ **绝不同时开两个 `run_supplement.sh` 实例**（并发会冲到 7-8）。脚本已加锁 `/tmp/run_supplement.lock`。
- 预估总墙钟：**~13–14 h**（A 0.6h + B 2h + D 3.5h + C 7–8h）。时间紧可把 `SEEDS_VMAS` 改成 `"1 2 3 4 5"`，C 压到 ~5h。

## 4. 本次包内新增/改动的文件

| 文件 | 用途 |
|---|---|
| `configs/algo/supp_mappo_byz_adv_n5.yaml` | **Batch A**：镜像 `n5_mappo_byz_random.yaml`，仅 `mode: adversarial` |
| `configs/algo/supp_soft_byz2_adv_n7.yaml` | **Batch D** Soft：加 `pbft_f: 2`、`byzantine.n: 2` |
| `configs/algo/supp_hard_byz2_adv_n7.yaml` | **Batch D** Hard：同上 |
| `configs/algo/supp_mappo_byz2_adv_n7.yaml` | **Batch D** MAPPO：`byzantine.n: 2` |
| `configs/env/mpe_spread_n7.yaml` | n=7 环境（服务器上原本没有） |

> ⚠️ 为什么 n=7 的配置要写**顶层** `pbft_f: 2`：
> 服务器 `train.py` 展平已改成 `config[k] = v`，但算法读的键是 `pbft_f`，
> 嵌套 `pbft: {f: 2}` 只会写成 `config["f"]`，会被忽略 → f 停在默认 1。

## 5. 监控

```bash
tail -f logs/supplement/E1_soft_s5.log                       # 看单个日志
ps aux | grep train.py | grep -v grep                        # 在跑的进程
find results/supplement -name metrics.json | wc -l           # 完成数
nvidia-smi --query-gpu=utilization.gpu,memory.used --format=csv
pkill -f train.py                                            # 全停
```

## 6. FAQ

- **`unrecognized arguments: --byzantine_faults`** → 没这个参数。本项目只有 `--byzantine_n` / `--byzantine_type` / `--byzantine_mode`；**主表口径其实是用 YAML 的 `byzantine:` 块**。
- **日志说"训练完成"但脚本报没结果** → 去 `<log_dir>/<algo>/seed_N/metrics.json` 找。
- **VMAS shape 报错** → 确认 `--env vmas_uav_coverage`（不存在 `vmas_navigation`）。
- **重跑安全** → 已完成的会自动 SKIP（按 `<algo>/seed_N/metrics.json` 判断）。
