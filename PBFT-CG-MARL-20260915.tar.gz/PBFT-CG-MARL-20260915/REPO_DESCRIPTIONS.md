# Repository descriptions (English)

Drop-in text for GitHub. Replace the placeholder names/links before publishing.

---

## Suggested repository name

```
pbft-cg-marl
```

## Suggested GitHub "About" line (one sentence, ≤ 200 characters)

```
Diagnosing and fixing entropy collapse in PBFT-consensus-guided MAPPO: hard action replacement
with matched log-probability updates destroys policy diversity; soft additive guidance restores it.
```

*(173 characters — fits the GitHub About field.)*

---

## One-sentence description

**Option A — diagnostic framing (recommended)**

> Layering PBFT consensus onto MAPPO reveals an entropy collapse that task reward never shows:
> replacing the executed action with the agreed action and computing the PPO gradient at that
> action drives policy entropy from 1.61 to 0.045 nats in 300K steps, and moving the consensus
> signal into the loss as a bounded additive KL term restores baseline diversity.

**Option B — short version (for a paper abstract box or a slide)**

> Soft consensus conditioning prevents an entropy collapse that hard action replacement inflicts
> on PBFT-consensus-guided MAPPO.

**Option C — design-guideline framing (for a methods-community audience)**

> We characterise when execution-time consensus helps and when it destroys the policy, and derive
> three design guidelines for coupling fault-tolerant consensus to multi-agent policy learning.

---

## One-paragraph description

**Option A — technical (recommended for the repository README or a code-release note)**

> This repository accompanies a study of how Byzantine fault-tolerant consensus should be coupled
> to multi-agent policy learning. Layering PBFT consensus on MAPPO exposes a failure mode that task
> reward does not reveal: when the consensus action replaces the executed action and the PPO
> gradient is computed at that action, policy entropy collapses from 1.61 to 0.045 nats within
> 300K steps while episode reward stays statistically indistinguishable from a variant that differs
> only in how the gradient is computed. The collapse follows an unbounded feedback loop—agreeing
> with the leader raises the consensus rate, which narrows the proposal distribution—so it resists
> entropy-coefficient tuning. The repository provides the training code, algorithm and environment
> configurations, and figure-generation scripts used to establish the mechanism; to show that a
> bounded, additive KL guidance term (Soft Consensus) restores baseline entropy without violating
> the policy gradient theorem; to characterise when execution-time consensus becomes valuable as the
> faulty fraction grows; and to replicate the fault-time collapse on a second cooperative task. It
> also documents the measurement pitfall that made the failure invisible: averaging entropy over all
> agents, including faulty ones, hides what happens to the honest population.

**Option B — shorter (≈90 words, for a workshop page or a lab website)**

> Consensus-guided MARL can fail in a way that reward never shows. When PBFT's agreed action
> replaces an agent's action and PPO is trained to reinforce it, policy entropy collapses from 1.61
> to 0.045 nats in 300K steps while reward is unchanged—a self-reinforcing loop rather than a tuning
> problem. This repository contains the code, configurations and analysis scripts behind a
> diagnosis of that failure, a Soft Consensus variant that restores baseline entropy through bounded
> additive KL guidance, and a characterisation of when execution-time consensus starts to pay as
> more agents turn faulty.

**Option C — for an ML-engineering audience (emphasis on artefacts)**

> A reference implementation of PBFT-consensus-guided MAPPO with two conditioning schemes:
> multiplicative (the agreed action replaces the executed action) and additive (a bounded KL
> penalty toward the agreed action). Includes the MAPPO baseline, nine clean and faulted
> configurations, batch launchers with resumable, throttled scheduling, per-agent entropy
> instrumentation, Welch/Cohen/Mann–Whitney statistics scripts, and figure-generation code that
> reproduces all five paper figures from raw run logs. Two environments are exercised
> (MPE simple_spread and MPE simple_line); every result in the accompanying paper is reproducible
> from a single RTX 4090.

---

## Suggested GitHub topics

```
multi-agent-reinforcement-learning  mappo  byzantine-fault-tolerance  pbft
policy-gradient  entropy  marl  reinforcement-learning  pytorch
```

## Suggested citation block (add the final reference on publication)

```bibtex
@article{pbftcgmarl2026,
  title   = {Soft Consensus Mitigates Entropy Collapse in Consensus-Guided Multi-Agent Reinforcement Learning},
  author  = {<authors>},
  journal = {<venue>},
  year    = {2026}
}
```
