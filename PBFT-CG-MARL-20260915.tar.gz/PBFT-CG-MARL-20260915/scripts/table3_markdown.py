#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E3 per-agent 结果 → 论文可直接用的 Markdown 表 + honest-only 统计。

v2 变更（2026-09-12）：
  * faulty 列标记为「注入伪影」，从主表移出，只作诊断输出
  * 新增 honest-only Welch t 检验
  * 新增「塌陷 agent 比例」（honest 熵 < 0.01 的个数）
  * 逐 agent 原始值全量导出（含全部 seed）

用法（项目根目录）：
    python3 scripts/table3_markdown.py                          # 默认 results/e3_peragent_v2
    python3 scripts/table3_markdown.py results/e3_peragent_v2 5
"""
import json
import os
import sys
import glob
import math
import numpy as np

RESULTS = sys.argv[1] if len(sys.argv) > 1 else "results/e3_peragent_v2"
N_AGENTS = int(sys.argv[2]) if len(sys.argv) > 2 else 5
BYZ = 1
COLLAPSE_TH = 0.01

CONDS = [
    ("E3pa_mappo_rand", "MAPPO", "Random"),
    ("E3pa_mappo_adv",  "MAPPO", "Adversarial"),
    ("E3pa_hard_rand",  "Hard (Mismatched)", "Random"),
    ("E3pa_hard_adv",   "Hard (Mismatched)", "Adversarial"),
    ("E3pa_soft_rand",  "Soft (Ours)", "Random"),
    ("E3pa_soft_adv",   "Soft (Ours)", "Adversarial"),
]


def last10(v):
    return float(np.mean(v[-10:])) if isinstance(v, list) and v else None


def collect(label):
    rows = {}
    for p in sorted(glob.glob(os.path.join(RESULTS, label, "seed_*", "*", "seed_*", "metrics.json"))):
        try:
            seed = int(p.split(os.sep)[-2].split("_")[1])
        except (IndexError, ValueError):
            continue
        try:
            d = json.load(open(p))
        except Exception:
            continue
        ks = sorted([k for k in d if k.startswith("train/entropy_agent_")],
                    key=lambda k: int(k.rsplit("_", 1)[1]))
        ag = [last10(d[k]) for k in ks]
        ag = [a for a in ag if a is not None]
        honest = ag[BYZ:] if len(ag) > BYZ else []
        rows[seed] = {
            "all": last10(d.get("train/entropy")),
            "honest": (float(np.mean(honest)) if honest else None),
            "faulty": (ag[0] if ag else None),
            "collapsed": (int(np.sum(np.array(honest) < COLLAPSE_TH)) if honest else None),
            "n_honest": len(honest),
            "agents": ag,
            "reward": last10(d.get("episode/episode_reward") or d.get("episode_reward")),
            "cr": last10(d.get("episode/consensus_rate") or d.get("train/consensus_rate")),
        }
    return rows


def ms(vals):
    a = np.array([v for v in vals if v is not None], dtype=float)
    if len(a) == 0:
        return "-"
    if len(a) == 1:
        return f"{a[0]:.3f}"
    return f"{a.mean():.3f} $\\pm$ {a.std(ddof=1):.3f}"


def welch(a, b):
    """Welch t 检验（纯 numpy，不依赖 scipy）→ (t, p 近似, cohen d)"""
    a = np.array([x for x in a if x is not None], float)
    b = np.array([x for x in b if x is not None], float)
    if len(a) < 2 or len(b) < 2:
        return None
    va, vb = a.var(ddof=1), b.var(ddof=1)
    se = math.sqrt(va / len(a) + vb / len(b))
    if se == 0:
        return (float("inf"), 0.0, float("nan"))
    t = (a.mean() - b.mean()) / se
    df = (va / len(a) + vb / len(b)) ** 2 / (
        (va / len(a)) ** 2 / (len(a) - 1) + (vb / len(b)) ** 2 / (len(b) - 1))
    # 正态近似（n 小，仅作参考；正式报 p 用 scipy）
    p = 2 * (1 - 0.5 * (1 + math.erf(abs(t) / math.sqrt(2))))
    sp = math.sqrt(((len(a) - 1) * va + (len(b) - 1) * vb) / (len(a) + len(b) - 2))
    return (t, p, (a.mean() - b.mean()) / sp if sp > 0 else float("nan"))


DATA = {}
for lbl, method, fault in CONDS:
    DATA[lbl] = collect(lbl)

print(f"<!-- 数据源: {RESULTS} | agent 总数 {N_AGENTS} | 拜占庭 {BYZ} 个 -->\n")
print("## Table 3（主表：不含 faulty 列）\n")
print("| Method | Fault | Reward $\\uparrow$ | Entropy (all agents) | Entropy (honest only) | Collapsed honest | Consensus Rate |")
print("|--------|:-----:|:-----------------:|:--------------------:|:---------------------:|:----------------:|:--------------:|")
for lbl, method, fault in CONDS:
    r = DATA[lbl]
    if not r:
        print(f"| {method} | {fault} | 无数据 | | | | |")
        continue
    ss = sorted(r)
    g = lambda k: [r[s][k] for s in ss]
    nh = r[ss[0]]["n_honest"]
    cfrac = ms([None if r[s]["collapsed"] is None else r[s]["collapsed"] / r[s]["n_honest"] for s in ss])
    print(f"| {method} | {fault} | {ms(g('reward'))} | {ms(g('all'))} | {ms(g('honest'))} | "
          f"{cfrac} (of {nh}) | {ms(g('cr'))} |")

print("\n## honest-only 熵：组间对比（Welch t，n=4，p 为近似值）\n")
print("| A | B | A mean | B mean | t | p | Cohen d |")
print("|---|---|--------|--------|---|---|---------|")
PAIRS = [("E3pa_mappo_rand", "E3pa_hard_rand", "MAPPO+R vs Hard+R"),
         ("E3pa_mappo_adv",  "E3pa_hard_adv",  "MAPPO+A vs Hard+A"),
         ("E3pa_hard_rand",  "E3pa_soft_rand", "Hard+R vs Soft+R"),
         ("E3pa_hard_adv",   "E3pa_soft_adv",  "Hard+A vs Soft+A"),
         ("E3pa_mappo_rand", "E3pa_soft_rand", "MAPPO+R vs Soft+R"),
         ("E3pa_mappo_adv",  "E3pa_soft_adv",  "MAPPO+A vs Soft+A")]
for la, lb, name in PAIRS:
    if not DATA[la] or not DATA[lb]:
        continue
    A = [DATA[la][s]["honest"] for s in sorted(DATA[la])]
    B = [DATA[lb][s]["honest"] for s in sorted(DATA[lb])]
    res = welch(A, B)
    if res is None:
        continue
    t, p, d = res
    print(f"| {name} | | {np.mean(A):.3f} | {np.mean(B):.3f} | {t:.2f} | {p:.4f} | {d:.2f} |")

print("\n## 诊断（不进主表）：faulty agent 的熵 = 注入机制伪影\n")
print("| Method | Fault | faulty 熵 | 逐 seed | 说明 |")
print("|--------|:-----:|:---------:|---------|------|")
for lbl, method, fault in CONDS:
    r = DATA[lbl]
    if not r:
        continue
    ss = sorted(r)
    vals = [r[s]["faulty"] for s in ss]
    note = "≈ln5=1.609，零方差 → 注入动作是均匀随机" if (np.mean(vals) > 1.3 and np.std(vals) < 0.05) else \
           ("精确 0.000，零方差 → 注入动作是确定性 argmax" if np.std(vals) < 1e-9 else "受注入动作分布支配")
    print(f"| {method} | {fault} | {ms(vals)} | {[None if v is None else round(v,4) for v in vals]} | {note} |")

print("\n## 逐 seed × 逐 agent 原始值（全部 seed）\n")
for lbl, method, fault in CONDS:
    r = DATA[lbl]
    if not r:
        continue
    print(f"**{method} + {fault}**")
    for s in sorted(r):
        ag = [round(a, 4) for a in r[s]["agents"]]
        print(f"  - seed {s}: agents={ag[BYZ:]} (honest) | faulty={ag[0] if ag else None} | "
              f"all={None if r[s]['all'] is None else round(r[s]['all'],4)} | "
              f"reward={None if r[s]['reward'] is None else round(r[s]['reward'],2)}")
    print()
