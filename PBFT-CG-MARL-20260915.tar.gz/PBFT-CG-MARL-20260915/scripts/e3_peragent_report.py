#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
从 E3 per-agent 重跑结果中提取 honest-only 熵，直接产出 Table 3。

用法（在项目根目录）: python3 scripts/e3_peragent_report.py
读取 results/e3_peragent/E3pa_*
"""
import json
import os
import sys
import glob
import numpy as np
try:
    from scipy import stats as st
except Exception:
    st = None

# 结果目录可由命令行指定；默认指向 v2（命令行注入版）
RESULTS = sys.argv[1] if len(sys.argv) > 1 else "results/e3_peragent_v2"
BYZ = 1          # 每个条件注入的拜占庭 agent 数（n=5, f=1）

LABELS = [
    ("E3pa_mappo_rand", "MAPPO + random"),
    ("E3pa_mappo_adv",  "MAPPO + adversarial"),
    ("E3pa_hard_rand",  "Hard + random"),
    ("E3pa_hard_adv",   "Hard + adversarial"),
    ("E3pa_soft_rand",  "Soft + random"),
    ("E3pa_soft_adv",   "Soft + adversarial"),
]


def last10(v):
    return float(np.mean(v[-10:])) if isinstance(v, list) and v else None


def collect(label):
    rows = {}
    for p in sorted(glob.glob(os.path.join(RESULTS, label, "seed_*", "*", "seed_*", "metrics.json"))):
        try:
            seed = int(p.split(os.sep)[-2].split("_")[1])
        except (IndexError, ValueError):
            continue
        try:
            d = json.load(open(p))
        except Exception:
            continue
        ag = sorted([k for k in d if k.startswith("train/entropy_agent_")],
                    key=lambda k: int(k.rsplit("_", 1)[1]))
        if not ag:
            rows[seed] = {"all": last10(d.get("train/entropy")), "honest": None, "n_agents": None}
            continue
        agents = [last10(d[k]) for k in ag]
        agents = [a for a in agents if a is not None]
        n = len(agents)
        honest = float(np.mean(agents[BYZ:])) if n > BYZ else None
        rows[seed] = {"all": last10(d.get("train/entropy")), "honest": honest, "n_agents": n}
    return rows


print("=" * 104)
print("Table 3 重算（honest-only 熵）—— 拜占庭 agent = 前 %d 个，honest = 其余 agent 均值" % BYZ)
print("=" * 104)
print(f"{'condition':<26}{'n':>3}  {'all-agent entropy':>20}  {'honest-agent entropy':>24}  per-seed honest")
print("-" * 104)

DATA = {}
for lbl, name in LABELS:
    r = collect(lbl)
    DATA[lbl] = r
    if not r:
        print(f"{name:<26}{0:>3}   无数据（还没跑 / 还没打补丁）")
        continue
    ss = sorted(r)
    a = [r[s]["all"] for s in ss if r[s]["all"] is not None]
    h = [r[s]["honest"] for s in ss if r[s]["honest"] is not None]
    ah = f"{np.mean(a):.4f} ± {np.std(a, ddof=1):.4f}" if a else "-"
    hh = f"{np.mean(h):.4f} ± {np.std(h, ddof=1):.4f}" if h else "-（缺 entropy_agent_* 键）"
    print(f"{name:<26}{len(ss):>3}  {ah:>20}  {hh:>24}  {[round(x, 4) for x in h]}")

print("=" * 104)
print("【honest-only 熵 组间对比】")
print(f"{'comparison':<40}{'n':>6}  {'A':>9}{'B':>9}{'t':>8}{'p':>9}{'d':>7}")
PAIRS = [("E3pa_hard_rand", "E3pa_hard_adv"), ("E3pa_soft_rand", "E3pa_soft_adv"),
         ("E3pa_hard_rand", "E3pa_soft_rand"), ("E3pa_hard_adv", "E3pa_soft_adv"),
         ("E3pa_mappo_rand", "E3pa_hard_rand"), ("E3pa_mappo_rand", "E3pa_soft_rand")]
for A, B in PAIRS:
    a = [DATA[A][s]["honest"] for s in sorted(DATA[A]) if DATA[A][s]["honest"] is not None]
    b = [DATA[B][s]["honest"] for s in sorted(DATA[B]) if DATA[B][s]["honest"] is not None]
    if len(a) < 2 or len(b) < 2:
        print(f"{A+' vs '+B:<40}{'-':>6}   数据不足"); continue
    a, b = np.array(a), np.array(b)
    sa, sb = a.std(ddof=1), b.std(ddof=1)
    sp = np.sqrt(((len(a)-1)*sa**2 + (len(b)-1)*sb**2) / (len(a)+len(b)-2))
    d = (a.mean()-b.mean())/sp if sp > 0 else float('nan')
    t, p = (st.ttest_ind(a, b, equal_var=False) if st else (float('nan'), float('nan')))
    print(f"{A+' vs '+B:<40}{f'{len(a)}/{len(b)}':>6}  {a.mean():>9.4f}{b.mean():>9.4f}{t:>8.2f}{p:>9.4f}{d:>7.2f}")
print("=" * 104)
