#!/bin/bash
set -e
GPU_ID=${1:-0}
SMOKE=""
PHASE="ALL"
shift 2>/dev/null || true
for arg in "$@"; do
  case $arg in
    --smoke) SMOKE="--smoke" ;;
    E1|E2|E3) PHASE=$arg ;;
  esac
done

if [ -n "$SMOKE" ]; then
  SEEDS="1"; N_STEPS=50000; EVAL_INT=5000; EVAL_EP=5
  echo ">>> SMOKE (1 seed x 50K)"
else
  SEEDS="1 2 3 4"; N_STEPS=300000; EVAL_INT=10000; EVAL_EP=10
  echo ">>> FORMAL (4 seeds x 300K)"
fi

CODE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
LOG="${CODE_DIR}/results/n5_review"
ENV_CFG="${CODE_DIR}/configs/env/mpe_spread_n5.yaml"
ACFG="${CODE_DIR}/configs/algo"
mkdir -p "$LOG"

run_exp() {
  local name=$1 algo=$2 algo_cfg=$3 extra=$4
  for S in $SEEDS; do
    echo "===== $name seed=$S ===== [$(date '+%H:%M:%S')]"
    python -u src/train.py --algo $algo --env mpe_spread \
      --env_config "$ENV_CFG" --algo_config "$algo_cfg" \
      --seed $S --n_timesteps $N_STEPS --eval_interval $EVAL_INT \
      --eval_episodes $EVAL_EP --log_dir "$LOG/$name" --gpu $GPU_ID $extra
  done
}

if [ "$PHASE" = "ALL" ] || [ "$PHASE" = "E1" ]; then
  echo "### E1: Fair 3-way (alpha=0.05) ###"
  run_exp "E1_mappo"  mappo         "$ACFG/n5_mappo_fair.yaml"
  run_exp "E1_hard"   pbft_cg_mappo "$ACFG/n5_hard_fair.yaml"
  run_exp "E1_soft"   pbft_cg_mappo "$ACFG/n5_soft_fair.yaml"
fi

if [ "$PHASE" = "ALL" ] || [ "$PHASE" = "E2" ]; then
  echo "### E2: matched-logprob causal control ###"
  run_exp "E2_matched" pbft_cg_mappo "$ACFG/n5_matched_logprob.yaml"
fi

if [ "$PHASE" = "ALL" ] || [ "$PHASE" = "E3" ]; then
  echo "### E3: Byzantine (N=5, f=1) ###"
  run_exp "E3_hard_rand" pbft_cg_mappo "$ACFG/n5_hard_byz_random.yaml"
  run_exp "E3_hard_adv"  pbft_cg_mappo "$ACFG/n5_hard_byz_adversarial.yaml"
  run_exp "E3_soft_rand" pbft_cg_mappo "$ACFG/n5_soft_byz_random.yaml"
  run_exp "E3_soft_adv"  pbft_cg_mappo "$ACFG/n5_soft_byz_adversarial.yaml"
  run_exp "E3_mappo_rand" mappo "$ACFG/n5_mappo_byz_random.yaml"
fi

echo "DONE. Results: $LOG"
