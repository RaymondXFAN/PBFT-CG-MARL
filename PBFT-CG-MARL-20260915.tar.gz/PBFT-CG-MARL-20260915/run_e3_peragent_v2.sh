#!/bin/bash
# ============================================================
# E3 per-agent entropy 重跑 v2 —— 改用命令行注入拜占庭
# ------------------------------------------------------------
# v1 失败原因：配置文件里的 byzantine: 块没有生效（6 个条件的
#   全域熵全部落在干净区间 0.077–0.117，说明根本没攻击）。
#   → 改为命令行 --byzantine_n / --byzantine_type（已验证可用）。
#
# 开跑前会自动做一次 3K 步注入验证：若日志里看不到注入痕迹，
# 直接中止，不会白跑 4.5 小时。
#
# 输出：results/e3_peragent_v2/E3pa_<cond>_seed<N>/<algo>/seed_<N>/metrics.json
# 用法： bash run_e3_peragent_v2.sh
# ============================================================
PROJECT=/root/autodl-tmp/PBFT-CG-MARL
PY=/root/miniconda3/bin/python
RESULTS=$PROJECT/results/e3_peragent_v2
LOGS=$PROJECT/logs/e3_peragent_v2
mkdir -p "$RESULTS" "$LOGS"
cd "$PROJECT" || exit 1

# ---- 并发守卫 ----
RUNNING=$(pgrep -fc "src/train.py" 2>/dev/null || echo 0)
if [ "$RUNNING" -gt 0 ]; then
    echo "!! 已有 $RUNNING 个 train.py 在运行，请等它结束（避免并发失控）。"; exit 1
fi

PARALLEL=4
GPU=0
STEPS=${STEPS:-300000}
EVAL_INT=10000
EVAL_EP=10
SEEDS="1 2 3 4"

ENV_CFG=configs/env/mpe_spread_n5.yaml
BYZ_R="--byzantine_n 1 --byzantine_type random"
BYZ_A="--byzantine_n 1 --byzantine_type adversarial"

# label | algo | algo_config | extra
JOBS="
E3pa_hard_rand|pbft_cg_mappo|configs/algo/n5_hard_byz_random.yaml|$BYZ_R
E3pa_hard_adv|pbft_cg_mappo|configs/algo/n5_hard_byz_adversarial.yaml|$BYZ_A
E3pa_soft_rand|pbft_cg_mappo|configs/algo/n5_soft_byz_random.yaml|$BYZ_R
E3pa_soft_adv|pbft_cg_mappo|configs/algo/n5_soft_byz_adversarial.yaml|$BYZ_A
E3pa_mappo_rand|mappo|configs/algo/n5_mappo_byz_random.yaml|$BYZ_R
E3pa_mappo_adv|mappo|configs/algo/supp_mappo_byz_adv_n5.yaml|$BYZ_A
"

log() { echo "[$(date +%H:%M:%S)] $*"; }
throttle() { while [ "$(jobs -rp | wc -l)" -ge "$PARALLEL" ]; do sleep 10; done; }

# ------------------------------------------------------------
# 开跑前验证：命令行注入是否真的生效
# ------------------------------------------------------------
log "=== 注入机制验证（3000 步，约 20 秒）==="
$PY -u src/train.py --algo pbft_cg_mappo --env mpe_spread \
    --env_config "$PROJECT/$ENV_CFG" \
    --algo_config "$PROJECT/configs/algo/n5_hard_byz_random.yaml" \
    --seed 0 --n_timesteps 3000 --eval_interval 3000 --eval_episodes 1 \
    --gpu $GPU $BYZ_R --log_dir "$LOGS/_verify" > "$LOGS/_verify.log" 2>&1
if grep -qiE "inject|拜占庭" "$LOGS/_verify.log"; then
    log "验证 ✅ 命令行注入生效："
    grep -iE "inject|拜占庭" "$LOGS/_verify.log" | head -3 | sed 's/^/      /'
else
    log "验证 ❌ 仍未见注入痕迹，中止。请把下方日志内容发给 Mihiro："
    tail -20 "$LOGS/_verify.log" | sed 's/^/      /'
    exit 1
fi
rm -rf "$LOGS/_verify"

run() {  # $1=algo $2=algo_cfg $3=seed $4=label $5=extra
    local ALGO=$1 ACFG=$2 SEED=$3 LABEL=$4 EXTRA=$5
    local OUTDIR=$RESULTS/$LABEL/seed_$SEED
    mkdir -p "$OUTDIR"
    if [ -f "$OUTDIR/$ALGO/seed_$SEED/metrics.json" ]; then
        log "  [SKIP] $LABEL seed=$SEED（已完成）"; return
    fi
    throttle
    nohup $PY -u src/train.py --algo "$ALGO" --env mpe_spread \
        --env_config "$PROJECT/$ENV_CFG" \
        --algo_config "$PROJECT/$ACFG" \
        --seed "$SEED" --n_timesteps "$STEPS" --eval_interval "$EVAL_INT" \
        --eval_episodes "$EVAL_EP" --gpu "$GPU" $EXTRA \
        --log_dir "$OUTDIR" > "$LOGS/${LABEL}_s${SEED}.log" 2>&1 &
    log "  启动 $LABEL seed=$SEED (PID=$!)"
}

log "=== E3 per-agent v2：6 条件 × seeds [$SEEDS] × ${STEPS} 步（并发 $PARALLEL）==="
N=0
for S in $SEEDS; do
    while IFS='|' read -r LBL ALGO ACFG EXTRA; do
        [ -z "$LBL" ] && continue
        run "$ALGO" "$ACFG" "$S" "$LBL" "$EXTRA"
        N=$((N+1))
        (( N % PARALLEL == 0 )) && { wait; log "  [批次完成，累计 $N]"; }
    done <<< "$JOBS"
done
wait
log "E3 per-agent v2 完成 → $RESULTS（共 $N 个 run）"

# ---- 立刻出 Table 3 ----
log "=== 生成 Table 3（honest-only 熵）==="
$PY scripts/e3_peragent_report.py results/e3_peragent_v2 2>&1 | tee "$LOGS/table3_v2.log"
log "Table 3 已写入 $LOGS/table3_v2.log"
