#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENV2（MPE simple_line）落地补丁 —— 幂等、自动备份、自带自检。

做三件事：
  1) src/envs/mpe_wrapper.py
       - 把写死的 if/elif 场景分支改成「场景表」，并按场景决定是否传 N
         （关键：simple_reference / simple_world_comm 等**不接受 N**，
          原代码传 N= 会 TypeError 直接崩，而 except 只抓 ImportError）
       - 新增 simple_line / simple_formation 支持
  2) src/envs/__init__.py
       - 注册 "mpe_line" / "mpe_formation"
  3) 生成 configs/env/mpe_line.yaml
       - 从 mpe_spread_n5.yaml 复制并改 scenario（保证格式一定对）

用法（项目根目录）：
    python3 patch_env_line.py
"""
import os
import re
import shutil
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
WRAPPER = os.path.join(ROOT, "src", "envs", "mpe_wrapper.py")
REGISTRY = os.path.join(ROOT, "src", "envs", "__init__.py")
CFG_DIR = os.path.join(ROOT, "configs", "env")

MARK = "# [mpe-scenario-table]"

TABLE = '''    # [mpe-scenario-table] 场景 → (mpe2 模块名, 是否接受 N 参数)
    # 注意：MPE2 里只有少数场景能自定义 agent 数，其余传 N= 会 TypeError。
    MPE_SCENARIOS = {
        "simple_spread":     ("simple_spread_v3",     True),
        "simple_adversary":  ("simple_adversary_v3",  True),
        "simple_line":       ("simple_line_v1",       True),
        "simple_formation":  ("simple_formation_v1",  True),
        "simple_reference":  ("simple_reference_v3",  False),   # 固定 2 agent
        "simple_world_comm": ("simple_world_comm_v3", False),
        "simple_tag":        ("simple_tag_v3",        False),
    }

'''

NEW_TRY = '''        try:
            import importlib
            if self.scenario not in self.MPE_SCENARIOS:   # [mpe-scenario-table]
                raise ValueError(
                    f"未知MPE场景: {self.scenario}；可选: {list(self.MPE_SCENARIOS)}")
            _mod_name, _takes_N = self.MPE_SCENARIOS[self.scenario]
            _env_mod = importlib.import_module(f"mpe2.{_mod_name}")
            _kw = dict(max_cycles=self._max_steps,
                       continuous_actions=self.continuous_actions)
            if _takes_N:
                _kw["N"] = self._n_agents
            self._env = _env_mod.parallel_env(**_kw)
'''


def patch_wrapper():
    if not os.path.exists(WRAPPER):
        print(f"[ERR] 找不到 {WRAPPER}")
        return False
    src = open(WRAPPER, encoding="utf-8").read()
    if MARK in src:
        print("[SKIP] mpe_wrapper.py 已打过补丁")
        return True

    start_anchor = "        try:\n            from mpe2 import simple_spread_v3, simple_reference_v3\n"
    end_anchor = 'raise ValueError(f"未知MPE场景: {self.scenario}")'
    if src.count(start_anchor) != 1 or src.count(end_anchor) != 1:
        print(f"[ERR] 锚点异常：start={src.count(start_anchor)} end={src.count(end_anchor)}")
        return False

    init_anchor = "    def __init__(self, config: dict):\n        super().__init__(config)\n"
    if src.count(init_anchor) != 1:
        print(f"[ERR] __init__ 锚点出现 {src.count(init_anchor)} 次")
        return False

    shutil.copy2(WRAPPER, WRAPPER + ".bak_mpeenv")
    src = src.replace(init_anchor, TABLE + init_anchor, 1)
    i = src.index(start_anchor)
    j = src.index(end_anchor) + len(end_anchor) + 1
    src = src[:i] + NEW_TRY + src[j:]
    open(WRAPPER, "w", encoding="utf-8").write(src)
    print("[OK]   mpe_wrapper.py 已改造为场景表（备份 .bak_mpeenv）")
    return True


def patch_registry():
    src = open(REGISTRY, encoding="utf-8").read()
    if '"mpe_line"' in src:
        print("[SKIP] __init__.py 已注册 mpe_line")
        return True
    old = '    "mpe_reference": MPEEnv,\n'
    if src.count(old) != 1:
        print(f"[ERR] 注册表锚点出现 {src.count(old)} 次")
        return False
    shutil.copy2(REGISTRY, REGISTRY + ".bak_mpeenv")
    src = src.replace(old, old + '    "mpe_line": MPEEnv,\n    "mpe_formation": MPEEnv,\n', 1)
    open(REGISTRY, "w", encoding="utf-8").write(src)
    print("[OK]   __init__.py 已注册 mpe_line / mpe_formation")
    return True


def make_config():
    out = os.path.join(CFG_DIR, "mpe_line.yaml")
    if os.path.exists(out):
        print(f"[SKIP] {os.path.relpath(out, ROOT)} 已存在")
        return True
    src = None
    for cand in ["mpe_spread_n5.yaml", "mpe_spread.yaml", "mpe_reference.yaml"]:
        p = os.path.join(CFG_DIR, cand)
        if os.path.exists(p):
            src = p
            break
    if src is None:
        print("[ERR] 找不到可参考的 MPE 环境配置（mpe_spread_n5.yaml / mpe_spread.yaml）")
        return False

    import yaml
    cfg = yaml.safe_load(open(src, encoding="utf-8")) or {}
    print(f"[INFO] 以 {os.path.basename(src)} 为模板，原始内容：{cfg}")
    cfg["scenario"] = "simple_line"
    cfg["n_agents"] = cfg.get("n_agents", 5)
    cfg["max_steps"] = cfg.get("max_steps", 25)
    os.makedirs(CFG_DIR, exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        yaml.safe_dump(cfg, f, allow_unicode=True, sort_keys=False)
    print(f"[OK]   生成 {os.path.relpath(out, ROOT)} → {cfg}")
    return True


def self_test():
    print("\n===== 自检：真造一次 simple_line 环境 =====")
    sys.path.insert(0, ROOT)
    try:
        from src.envs import ENV_REGISTRY
        print("ENV_REGISTRY:", list(ENV_REGISTRY.keys()))
        env = ENV_REGISTRY["mpe_line"]({"scenario": "simple_line", "n_agents": 5, "max_steps": 25})
        obs, info = env.reset()
        import numpy as np
        print(f"  agents={len(obs)}  obs_dim={np.array(obs['agent_0']).shape}  "
              f"state_dim={np.array(info['agent_0']['state']).shape}")
        info2 = env.step({k: 0 for k in obs})
        print("  step() 返回 4 元组长度:", len(info2))
        print("  ✅ simple_line 可用")
    except Exception as e:
        print(f"  ❌ 自检失败: {type(e).__name__}: {e}")
        return False
    return True


if __name__ == "__main__":
    ok = patch_wrapper() and patch_registry() and make_config()
    print("\n结果：" + ("全部成功 ✅" if ok else "有失败 ❌"))
    if ok:
        self_test()
        print("\n下一步：  bash run_env2_mpe.sh probe")
